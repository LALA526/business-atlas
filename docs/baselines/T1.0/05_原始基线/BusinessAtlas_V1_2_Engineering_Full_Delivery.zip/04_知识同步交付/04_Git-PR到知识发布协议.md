# V1.2｜开发同步交付知识：Git / PR / CI / Self Knowledge 运行协议

> **SUPERSEDES V1.1** `Knowledge Delivery` 中 PR 候选包 `repo.commitSha` 必填和“合并时修改同一 PR 文件写入最终 SHA”的做法。绝不要求包含自身 SHA 的 Git 文件预知最终 commit。

## 1. 两份知识交付物，三个独立时间

| 时机 | 机器文件 | 谁生成 | 包含何种事实 | 不能做什么 |
|---|---|---|---|---|
| PR 创建/更新 | `KnowledgeChangeProposal v1.2` | 开发 Agent + CI | requirementIds、changeKind、文件、Git blob SHA、baseHead、contract/API/DB 变化、测试及候选事实 | 不要求最终 mergedCommitSha；不批准业务规范 |
| 合并完成后的 CI | `KnowledgeDeliveryManifest v1.2` | 可信 Integration/CI | PR ID、最终 mergeCommitSha、构建/镜像摘要、签出合同版本、对应 Proposal SHA256、测试证据 hash、代码来源 | 不写回产生它的旧 Git Commit；不把测试成功当业务批准 |
| 人类知识审核/发布 | `KnowledgeReview / ChangeSet / Baseline` | 有权限的 BA/知识负责人 | 经过审阅的知识事实与不可变 Baseline、审批时间和来源 | 不因 Deploy 自动修改旧批准 Baseline |

**元数据链条**：`taskId → pullRequestId → proposalBlobSha → mergeCommitSha → buildArtifactDigest → deliveryId → selfImportProposalId → reviewId → baselineId → deploymentId`。

## 2. PR CI 精确 Gate

PR 内 `knowledge/changes/<PR-or-task>.json` 必须符合 `knowledge-change-proposal-v1.2.schema.json`。`repo.baseSha` 和 `repo.headSha` 是**PR 当时 HEAD**的观测值，可随 PR commit 更新；**不能将其当作最终合并提交**。

候选来源锚点 `{path, locator, blobSha?, contentSha256?}` 绑定 Git 对象或文件内容，不存最终合并 SHA。CI 执行：

1. 验证 JSON Schema / `schemaVersion` / projectId / taskId / requirementIds 均存在且属于当前任务合同。
2. 读取 Git diff，检查变更文件声明是否完整；对于 API/schema/migration/权限/Flow 变化，要求对应 `apiChanges/dataChanges/assertionChanges/authorizationTests`，不足返回明确失败原因。
3. 检查 declared source paths 存在；blobSha 与 HEAD 对应文件 Git blob 相等，或 contentSha256 与字节一致；不接受伪造路径和行号。
4. 验证 OpenAPI/Schema contract 与生成 SDK，consumer/provider tests；对适用的领域/图形/授权黄金回归执行。
5. 测试证据必须有 CI artifact URI/Job ID，不接受仅文字“测试通过”。
6. 审阅者检查候选推断的事实等级、权限影响和与批准规范差异；没证据的推断必须标 unknown 或 Issue。
7. **PR 合并前 Gate**：编译、合同、测试、候选知识、关键来源、权限、变更影响全部通过。失败阻断合并，授权应急例外除外。

## 3. 合并后的不可变交付清单

受信任的 Merge CI 读取平台的最终 PR merge event（兼容 squash/rebase/merge），**重新查询远端最终 commit SHA**，生成 Manifest。CI 读取已合并的 proposal artifact hash，不反向修改被哈希定位的提交内容。Manifest 作为外部 Release Artifact 或后续独立提交可追溯存储；它的身份是 `(repo,finalCommitSha,proposalDigest,buildDigest)`，按 deliveryId 幂等。

合并 CI 验证 final commit 所包含关键文件的 Git blob hash/内容 hash 对应 proposal 中申明的版本；若 Rebase 导致变更，记录 `anchorResolution` 并重新校验，必要时阻止发布而不是编造已经匹配。

CI 接着将 Manifest + Proposal + AKP delta（尚未批准）送入 Self Project 的 `Import Proposal`。当平台尚未上线，暂存于 Git/CI artifact 可恢复账本，待自举服务上线后批量重放；重放不应产生重复。

## 4. 代码、部署、知识是三条有联系但独立的状态轴

- **Code**: `pr_open → pr_checks_pass → merged`。
- **Deployment**: `build_verified → staged → deployed → observed/rolled_back`。
- **Knowledge**: `proposed → staged → reviewed → approved_baseline` 或 `rejected/needs_evidence`。

不能只有一个 `done=true`。开发任务 `implementationDone` 要求合并与 CI 证据；`knowledgeComplete` 要求工程事实进入可查询的 Self Project，真正业务规范要有独立 BA 审核；`releaseReady` 要求核心知识没有未授权的关键漂移。

**紧急修复**：只允许有权限负责人登记有到期时间的 KnowledgeDebt、影响范围、关联任务和补偿测试后临时允许部署。过期未修复、关键业务规范仍不一致，阻断最终产品验收；知识债不能凭开发 Agent 自行关闭。

## 5. 对账器（必须开发，不只是文档）

**输入**：Git/PR merge events、Manifest、Deployment Manifest、Self Project 的 Proposal/Review/Baseline、Schema versions。

**输出**（按 repository/service/build）：

| 状态 | 判定 | 必须操作 |
|---|---|---|
| `aligned` | 部署的构建对应已核验 Manifest，知识对应当前批准/明确适用的实现 | 保持索引，提供双向来源 |
| `pending_review` | 工程观察包已进入提案，尚未批准业务规范 | 显示待确认，需 BA/owner 处理 |
| `divergent` | 实际部署与已批准规范或源码锚点冲突 | 产生 Issue/Task，安全重要则阻断发布 |
| `rolled_back` | 代码/部署回退到旧提交，但批准知识未同步变化 | 标明实现版本变化，重新评估当前适用基线；不删除历史 |
| `evidence_missing` | 缺 Manifest/测试/源哈希或来源失效 | 阻断 final Done 和必要发布 |

每次 deploy/rollback、知识 publish、权限撤销、来源失效时触发对账。不得仅在前端仪表盘贴标签而不改变交付 Gate。

## 6. 原型到正式系统的自举

Layer0 从**第一个 PR**就维护 `knowledge/bootstrap/project.akp.json`、`knowledge/changes/*.json`、`knowledge/adr/*.md`、`knowledge/errors/*.yaml` 和相应合同测试。

Layer1 一旦导入/草稿/审批/基线 API 可用，创建 Self Project，重放 Layer0 的所有**已校验** Delivery，审核形成第一个自有工程知识 Baseline。此后每个真实 PR 产生 ChangeSet 或 Proposal，代码和知识保持双向跳转。初始 Layer0 允许作为离线恢复输入，但不是批准业务事实的第二权威库。

## 7. 撤销、失败、重复执行和安全

- 重复 Git webhook/outbox 以 `(provider,deliveryId)` 与 proposalDigest 去重。
- Manifest 生成一半失败：从 durable job checkpoint 重试；不重复产生 Self Proposal。
- 合并后发现 blob 不匹配：标记 `evidence_missing`，停止后续合规发布，保留错误诊断。
- 部署回滚：生成新的 Deployment Event，再对账；旧 Baseline 不原位回退。
- 源代码重命名：新锚点需映射旧 identity/Blob，变更后仍能查看历史源码来源。
- Agent Tool 的敏感参数/Token 不进入候选知识或 Manifest，需在 CI 上传前脱敏。

## 8. 必须真实跑通的演练

使用 AKP 导入 API 的一条真实 PR：提交源代码/测试/OpenAPI + Proposal（无最终 SHA）→ CI 验证 → squash/rebase merge → 真实 Merge Manifest（最终 SHA）→ Self 项目待审提案 → 人工确认 → Baseline → 同一个部署产品打开来源和 API → 部署回滚 → 对账器正确显示旧实现与当前规范差异。

**不可验收的替代**：只放一份示例 JSON、用截图模拟“已同步”、直接手改数据库发布知识、只在某次演示完成闭环而其他 PR 不执行。
