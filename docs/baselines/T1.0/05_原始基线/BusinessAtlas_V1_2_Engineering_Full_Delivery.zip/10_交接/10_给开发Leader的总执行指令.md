# Business Atlas V1.2｜开发 Leader 的最终交付指令

你负责 **Business Atlas 完整正式产品**，不是只产出架构报告，也不是只交一个 MVP。目标基于 V9.2 原型实现全部经确认的产品范围：前端、ASP.NET Core API/应用服务、PostgreSQL、权限与版本治理、AKP 输入、知识认知与局部图形、真实 AI/MCP、多人协作、任务/交付/反馈、可部署与恢复系统，且**边开发边沉淀 Business Atlas 自身知识**。

## 读取与优先级

- 先读本包 `00_交付入口/README_从这里开始.md`、BA V1.0 原始需求、Engineering V1.1、V9.2 源码、V1.2 的 02–08 及机器 Schema/DAG。
- V1.2 新版 KnowledgeChangeProposal/MergeManifest **替换 V1.1 commitSha 自引用合同**。领域不变量、产品完整范围、角色分离继续有效；V9.2 现有 DEF-001..008 不得复刻。
- 研究成熟开源参考与官方文件时，按照 V1.1 的参考方向验证 Backstage/DataHub/OpenMetadata/OpenFGA/Temporal 等的具体取舍、许可证、维护与集成成本；不得拿它们任何一个直接当最终产品骨架，也不能仅凭知名度换栈。

## 一次性最终开发执行

1. 对目标运行环境、现有仓库与可访问工具做 **真实事实调查**；记录 SSH/权限/依赖/网络不可用的事实，不伪造检查结果。只有凭据/重大不可逆生产动作才请求必要许可。
2. 以 .NET 10 + React/TypeScript + PostgreSQL 模块化单体作为首选，经重要风险 POC 和 ADR 冻结 M01–M12 的共享领域/接口/事件合同；允许因可靠证据替换具体适配器，不得无记录改变领域语义。
3. 初始化实际 Git 仓库、CI、知识账本、持久化任务执行账本，并加载 V1.2 68 叶任务 DAG。架构线设计与审查，开发线只按确认合同实施；公共 DB 迁移和 API 合同单一 owner，独立 QA 执行反向测试。
4. 对全部任务按依赖并行推进，设计、开发、测试、集成、部署连续进行，不要每完成一个工作包就停止等待新指令。每个 Task 交付实际代码、迁移、OpenAPI、测试、真实 PR、候选知识和运行证据。
5. PR 阶段只产生 KnowledgeChangeProposal（无最终 SHA）；合并后由受信任 CI 生成 DeliveryManifest（包含最终 commit、构建 digest 与已验证来源）；自动导入 Self Project 待审，规范由 BA/授权人批准，部署与知识持续对账。
6. 真实模块端到端贯通，G0–G7 全部通过、116 条需求逐条拥有可核查证据、DEF-001..008 关闭、真实环境部署、灾备演练与自身知识闭环完成，才可宣布系统最终完成。
7. 对 Agent 协调过程中的真实错误收集 rootCause、触发、detector、regressionTest，并在后续相关 Task preflight 自动执行，禁止只堆聊天记录。

## 错误应对与继续执行

- 发现设计冲突，提出 ADR/Issue 并由 Leader 修订合同和受影响 Task，**继续不相关模块**，不能让模型越权假设业务规范。
- Agent Session 丢失、PR 失败、合并后依赖失效，从外部 TaskLedger、Git、CI artifact 恢复；错误不应因重启被遗忘。
- 开发 Agent 不得自批最终规范；部分已部署功能不代表全量交付。
- 如果真实依赖无法访问，应交付已实现和已验证成果、明确阻断原因，不得用 Mock 冒充完成。

## 最终交付标准

可重复构建的完整代码仓库、真实前后端/Worker/MCP、完整 OpenAPI/SDK/JSON Schema、数据库迁移、AuthN/AuthZ、AI Provider 接入、真实多人协作、可运行部署、监控与恢复、全部需求-任务-代码-测试-知识-部署矩阵、Self Project 的批准知识和 Git 来源双向引用、全部 GOLD/INV/安全与故障回归，以及可独立复现的运维/验收记录。

架构报告、POC、某一纵切、演示页面都只是中间结果。最终的唯一评价是：**真实用户和 Agent 能否在正式系统中完成 Business Atlas 的完整目标工作，同时知识与代码能够持续一致并可审计。**
