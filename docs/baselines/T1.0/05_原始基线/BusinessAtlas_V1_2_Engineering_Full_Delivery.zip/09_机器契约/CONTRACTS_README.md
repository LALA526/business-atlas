# V1.2 机器合同与本地验证

**直接运行：**

```bash
python 09_机器契约/validate_v12.py --root .
python -m unittest discover -s 09_机器契约/tests -v
```

依赖 `jsonschema`；YAML 语法检查在存在 `PyYAML` 时执行。`openapi-core-v1.2.yaml` 只是核心骨架，**不表示 V1.1 API 总清单全部合同已落实**。正式仓库要由 Contract Owner 补完并跑生成 SDK/Provider-Consumer Test 后才能签 G1。

- `knowledge-change-proposal-v1.2.schema.json`：PR 中的知识候选，不含最终 merge sha。
- `knowledge-delivery-manifest-v1.2.schema.json`：CI 外部 artifact，合并后固定真实 commit/build/test/source。
- `deployment-reconciliation-v1.2.schema.json`：部署/知识批准/代码一致性状态。
- `agent-task-v1.2.schema.json`：候选可执行任务数据格式。
- `domain-event-v1.2.schema.json`：Outbox 事件 Envelope。
- `mcp-tool-contract-v1.2.schema.json`：MCP tools 申明 scope/input/output/audit。
- `error-pattern-v1.2.schema.json`：可执行预防错误模式。
- `agent_task_ledger_reference.py`：可持久化 SQLite 任务状态、依赖、租约与资源锁的**示范代码**，不是完整 Agent 编排服务，未接真实 CI/Board/LLM。

示例中的 `example.invalid`、`aaaa...`、`PR-123`、`CI-EXAMPLE-123` 都是**纯示例**，不能作为正式实现事实或真实测试证据。验证器通过代表合同与静态规划的一致性，通过后仍必须由真实 PR/合并/部署进行 G5 验收。

**注意**：V1.1 原始机器合同中 `repo.commitSha` 必填已被本包协议取代，开发 Agent 不得混用 V1.1 的 sample 与 V1.2 Proposal。
