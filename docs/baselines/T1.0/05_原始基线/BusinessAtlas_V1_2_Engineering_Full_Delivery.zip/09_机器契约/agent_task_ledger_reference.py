#!/usr/bin/env python3
"""Local reference ledger for durable agent task states; NOT an Agent executor or production scheduler.
Includes SQLite task leases, fencing, dependency gates, resource locks, event log.
Integration CI/PR gates must be wired before deployment use.
"""
import sqlite3, time, json, sys, pathlib, argparse
ALLOWED={
 'queued':{'ready','blocked','blocked_external','cancelled'},
 'ready':{'leased','blocked','blocked_external','cancelled'},
 'leased':{'running','retryable','blocked','cancelled'},
 'running':{'verifying','retryable','failed','blocked','blocked_external','cancelled','stale_contract'},
 'verifying':{'review_pending','retryable','failed','stale_contract'},
 'review_pending':{'integrating','review_rejected','stale_contract'},
 'review_rejected':{'retryable','blocked'},
 'integrating':{'done','integration_conflict','retryable','stale_contract'},
 'integration_conflict':{'retryable','stale_contract'},
 'stale_contract':{'retryable','blocked'},
 'failed':{'retryable','blocked','cancelled'},
 'retryable':{'ready','blocked','cancelled'},
 'blocked':{'ready','cancelled'},
 'blocked_external':{'ready','cancelled'},
 'done':set(), 'cancelled':set()
}
class Ledger:
 def __init__(self,path):
  self.db=sqlite3.connect(str(path), isolation_level=None, timeout=10)
  self.db.row_factory=sqlite3.Row
  self.db.execute('PRAGMA journal_mode=WAL')
  self.db.execute('CREATE TABLE IF NOT EXISTS tasks(task_id TEXT PRIMARY KEY, status TEXT NOT NULL, rev INTEGER NOT NULL, deps_json TEXT NOT NULL, locks_json TEXT NOT NULL, holder TEXT, lease_until REAL, fence INTEGER NOT NULL DEFAULT 0, attempt INTEGER NOT NULL DEFAULT 0)')
  self.db.execute('CREATE TABLE IF NOT EXISTS locks(resource TEXT PRIMARY KEY, task_id TEXT NOT NULL, lease_until REAL NOT NULL, fence INTEGER NOT NULL)')
  self.db.execute('CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, at REAL NOT NULL, action TEXT NOT NULL, actor TEXT NOT NULL, detail_json TEXT NOT NULL)')
 def event(self,task,action,actor,detail):self.db.execute('INSERT INTO events(task_id,at,action,actor,detail_json) VALUES(?,?,?,?,?)',(task,time.time(),action,actor,json.dumps(detail,ensure_ascii=False)))
 def init(self,dag):
  self.db.execute('BEGIN IMMEDIATE')
  try:
   for t in dag['tasks']:
    self.db.execute('INSERT OR IGNORE INTO tasks(task_id,status,rev,deps_json,locks_json) VALUES(?,?,?,?,?)',(t['taskId'],'queued',t['taskRevision'],json.dumps(t['dependencyTaskIds']),json.dumps(t['resourceLocks'])))
   self.db.execute('COMMIT')
  except: self.db.execute('ROLLBACK');raise
 def _deps_done(self,row):
  for dep in json.loads(row['deps_json']):
   r=self.db.execute('SELECT status FROM tasks WHERE task_id=?',(dep,)).fetchone()
   if not r or r['status']!='done': return False
  return True
 def claim(self,task_id,holder,lease_seconds=180):
  if lease_seconds<=0:raise ValueError('positive lease_seconds required')
  self.db.execute('BEGIN IMMEDIATE')
  try:
   r=self.db.execute('SELECT * FROM tasks WHERE task_id=?',(task_id,)).fetchone()
   if not r:raise ValueError('unknown task')
   if r['status'] not in ('queued','ready','retryable'):raise ValueError('not claimable '+r['status'])
   if not self._deps_done(r):raise ValueError('dependencies not done')
   now=time.time();res=json.loads(r['locks_json'])
   for resource in res:
    lock=self.db.execute('SELECT * FROM locks WHERE resource=?',(resource,)).fetchone()
    if lock and lock['lease_until']>now and lock['task_id']!=task_id:raise ValueError('resource lock held '+resource)
   newf=r['fence']+1;ex=now+lease_seconds
   for resource in res:
    self.db.execute('INSERT INTO locks(resource,task_id,lease_until,fence) VALUES(?,?,?,?) ON CONFLICT(resource) DO UPDATE SET task_id=excluded.task_id,lease_until=excluded.lease_until,fence=excluded.fence',(resource,task_id,ex,newf))
   self.db.execute('UPDATE tasks SET status=?,holder=?,lease_until=?,fence=?,attempt=attempt+1 WHERE task_id=?',('leased',holder,ex,newf,task_id))
   self.event(task_id,'leased',holder,{'fencingToken':newf,'expiresAtEpoch':ex})
   self.db.execute('COMMIT');return newf
  except:self.db.execute('ROLLBACK');raise
 def heartbeat(self,task_id,holder,token,lease_seconds=180):
  self.db.execute('BEGIN IMMEDIATE')
  try:
   r=self.db.execute('SELECT * FROM tasks WHERE task_id=?',(task_id,)).fetchone()
   if not r or r['holder']!=holder or r['fence']!=token or not r['lease_until'] or r['lease_until']<time.time():raise ValueError('lease revoked or expired')
   until=time.time()+lease_seconds
   self.db.execute('UPDATE tasks SET lease_until=? WHERE task_id=?',(until,task_id))
   for resource in json.loads(r['locks_json']):
    self.db.execute('UPDATE locks SET lease_until=? WHERE resource=? AND task_id=? AND fence=?',(until,resource,task_id,token))
   self.event(task_id,'heartbeat',holder,{'expiresAtEpoch':until});self.db.execute('COMMIT')
  except:self.db.execute('ROLLBACK');raise
 def transition(self,task_id,to_status,actor,token=None,detail=None):
  if to_status not in ALLOWED:raise ValueError('unknown state')
  self.db.execute('BEGIN IMMEDIATE')
  try:
   r=self.db.execute('SELECT * FROM tasks WHERE task_id=?',(task_id,)).fetchone()
   if not r:raise ValueError('unknown task')
   if to_status not in ALLOWED[r['status']]:raise ValueError(f'invalid transition {r["status"]}->{to_status}')
   if r['status'] in ('leased','running','verifying','review_pending','integrating'):
    if token!=r['fence'] or not r['holder'] or not r['lease_until'] or r['lease_until']<time.time():raise ValueError('fencing mismatch/expired lease')
   if to_status=='done' and not (detail or {}).get('gateEvidenceRefs'):
    raise ValueError('done requires linked CI/PR/review evidence references')
   self.db.execute('UPDATE tasks SET status=? WHERE task_id=?',(to_status,task_id))
   if to_status in ('done','failed','retryable','blocked','blocked_external','cancelled','stale_contract','integration_conflict'):
    for resource in json.loads(r['locks_json']): self.db.execute('DELETE FROM locks WHERE resource=? AND task_id=? AND fence=?',(resource,task_id,r['fence']))
    self.db.execute('UPDATE tasks SET holder=NULL, lease_until=NULL WHERE task_id=?',(task_id,))
   self.event(task_id,to_status,actor,detail or {});self.db.execute('COMMIT')
  except:self.db.execute('ROLLBACK');raise
 def recover_expired(self):
  # conservative reference: do NOT mark automatic retry until human/CI checks external PR/side effects
  now=time.time()
  self.db.execute('BEGIN IMMEDIATE')
  try:
   rows=self.db.execute("SELECT * FROM tasks WHERE status IN ('leased','running','verifying','review_pending','integrating') AND lease_until < ?",(now,)).fetchall()
   for r in rows:
    self.db.execute("UPDATE tasks SET status='blocked',holder=NULL,lease_until=NULL WHERE task_id=?",(r['task_id'],))
    self.db.execute('DELETE FROM locks WHERE task_id=?',(r['task_id'],))
    self.event(r['task_id'],'lease_expired_requires_reconciliation','scheduler',{'previousState':r['status'],'fence':r['fence']})
   self.db.execute('COMMIT');return [r['task_id'] for r in rows]
  except:self.db.execute('ROLLBACK');raise
 def status(self,task):
  r=self.db.execute('SELECT * FROM tasks WHERE task_id=?',(task,)).fetchone();return dict(r) if r else None
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--db',default='atlas-agent-ledger.sqlite');sp=p.add_subparsers(dest='action',required=True)
 a=sp.add_parser('init');a.add_argument('--dag',required=True)
 a=sp.add_parser('claim');a.add_argument('task');a.add_argument('holder');a.add_argument('--seconds',type=int,default=180)
 a=sp.add_parser('transition');a.add_argument('task');a.add_argument('status');a.add_argument('actor');a.add_argument('--token',type=int);a.add_argument('--evidence',nargs='*',default=[])
 a=sp.add_parser('status');a.add_argument('task')
 sp.add_parser('recover')
 a=p.parse_args();x=Ledger(a.db)
 if a.action=='init':x.init(json.load(open(a.dag)));print('initialized')
 elif a.action=='claim':print('fencing token:',x.claim(a.task,a.holder,a.seconds))
 elif a.action=='transition':x.transition(a.task,a.status,a.actor,a.token,{'gateEvidenceRefs':a.evidence});print('ok')
 elif a.action=='status':print(json.dumps(x.status(a.task),ensure_ascii=False,indent=2))
 else:print(x.recover_expired())
