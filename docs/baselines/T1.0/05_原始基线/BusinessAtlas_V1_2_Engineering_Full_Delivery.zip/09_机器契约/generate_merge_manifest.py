#!/usr/bin/env python3
"""Reference post-merge artifact generator. Does not write manifest back into its own commit.
Requires actual Git repo, proposal bytes, CI build digest and test artifact references.
A mismatched anchor creates evidence_missing rather than a false verified delivery.
"""
import pathlib,subprocess,hashlib,json,argparse,datetime,sys
from jsonschema import Draft202012Validator
HERE=pathlib.Path(__file__).resolve().parent

def git(repo,*args):return subprocess.run(['git','-C',str(repo),*args],check=True,capture_output=True,text=True,encoding='utf8').stdout.strip()

def generate(repo,proposal,merge_ref,build_id,build_digest,ci_run_id):
 raw=pathlib.Path(proposal).read_bytes();obj=json.loads(raw);hashp=hashlib.sha256(raw).hexdigest()
 sha=git(repo,'rev-parse',merge_ref+'^{commit}');anchors=[];bad=False
 for a in obj['sourceAnchors']:
  path=a['path']
  try:
   blob=git(repo,'rev-parse',sha+':'+path)
   status='matched' if not a.get('blobSha') or a['blobSha']==blob else 'mismatch'
  except subprocess.CalledProcessError:
   blob='0'*40;status='missing'
  if status!='matched':bad=True
  anchors.append({'path':path,'locator':a['locator'],'resolvedBlobSha':blob,'verification':status})
 out={'schemaVersion':'1.2.0','deliveryId':f'KDEL-{obj["proposalId"]}-{sha[:12]}','proposalId':obj['proposalId'],'proposalSha256':hashp,'projectId':obj['projectId'],'taskId':obj['taskId'],'repo':{'url':obj['repo']['url'],'pullRequestId':obj['repo']['pullRequestId']},'finalCommitSha':sha,'mergeStrategy':'squash', 'buildId':build_id,'buildDigest':build_digest,'verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testEvidence':obj['testEvidence'],'anchorResolutions':anchors,'status':'evidence_missing' if bad else 'verified','ciRunId':ci_run_id}
 schema=json.loads((HERE/'schemas/knowledge-delivery-manifest-v1.2.schema.json').read_text('utf8'));e=list(Draft202012Validator(schema).iter_errors(out))
 if e:raise ValueError('; '.join(x.message for x in e))
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--proposal',required=True);p.add_argument('--merged-ref',required=True);p.add_argument('--build-id',required=True);p.add_argument('--build-digest',required=True);p.add_argument('--ci-run-id',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 data=generate(a.repo,a.proposal,a.merged_ref,a.build_id,a.build_digest,a.ci_run_id)
 pathlib.Path(a.output).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8');print(data['status'],data['finalCommitSha'],a.output)
 if data['status']!='verified':sys.exit(2)
