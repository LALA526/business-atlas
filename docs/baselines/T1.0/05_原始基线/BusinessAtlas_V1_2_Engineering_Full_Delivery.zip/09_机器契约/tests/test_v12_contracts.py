import unittest,json,subprocess,sys,pathlib
from jsonschema import Draft202012Validator
ROOT=pathlib.Path(__file__).resolve().parents[2]
SCHEMAS=ROOT/'09_机器契约/schemas'; EX=ROOT/'09_机器契约/examples'
class V12ContractsTests(unittest.TestCase):
    def test_proposal_has_no_final_sha(self):
        obj=json.loads((EX/'knowledge-change-proposal.example.json').read_text('utf8'))
        self.assertNotIn('commitSha',obj['repo'])
        self.assertNotIn('finalCommitSha',obj)
    def test_proposal_rejects_circular_sha(self):
        schema=json.loads((SCHEMAS/'knowledge-change-proposal-v1.2.schema.json').read_text('utf8'))
        obj=json.loads((EX/'knowledge-change-proposal.example.json').read_text('utf8'))
        obj['repo']['commitSha']='b'*40
        self.assertFalse(Draft202012Validator(schema).is_valid(obj))
    def test_manifest_binds_merged_sha(self):
        schema=json.loads((SCHEMAS/'knowledge-delivery-manifest-v1.2.schema.json').read_text('utf8'))
        obj=json.loads((EX/'knowledge-delivery-manifest.example.json').read_text('utf8'))
        self.assertTrue(Draft202012Validator(schema).is_valid(obj))
        obj.pop('finalCommitSha')
        self.assertFalse(Draft202012Validator(schema).is_valid(obj))
    def test_requirements_all_mapped_and_not_fake_done(self):
        tasks=json.loads((ROOT/'06_全量执行计划/agent-task-dag-v1.2.json').read_text('utf8'))['tasks']
        req=json.loads((ROOT/'06_全量执行计划/requirements-trace-v1.2.json').read_text('utf8'))['requirements']
        self.assertEqual(116,len(req))
        self.assertEqual(set(r['id'] for r in req),set(i for t in tasks for i in t['requirementIds']))
        self.assertTrue(all(t['status']=='queued' for t in tasks))
    def test_dag_acyclic(self):
        ts=json.loads((ROOT/'06_全量执行计划/agent-task-dag-v1.2.json').read_text('utf8'))['tasks']
        rem={t['taskId']:set(t['dependencyTaskIds']) for t in ts}
        while rem:
            ready={x for x,d in rem.items() if not d}
            self.assertTrue(ready)
            for k in ready:del rem[k]
            for v in rem.values():v.difference_update(ready)
    def test_golden_scope_is_explicit(self):
        x=json.loads((ROOT/'07_认知黄金样本/semantic-golden-v1.2.json').read_text('utf8'))
        self.assertFalse(x['formalImplementationHasPassed'])
        self.assertEqual((7,12,14),(x['expected']['stageCount'],x['expected']['flowNodeCount'],x['expected']['flowEdgeCount']))
if __name__=='__main__':unittest.main()
