import unittest,tempfile,pathlib,sys,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from agent_task_ledger_reference import Ledger
class TaskLedgerTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.db=pathlib.Path(self.temp.name)/'ledger.sqlite';self.x=Ledger(self.db)
  self.x.init({'tasks':[{'taskId':'T1','taskRevision':1,'dependencyTaskIds':[],'resourceLocks':['db-global']},{'taskId':'T2','taskRevision':1,'dependencyTaskIds':['T1'],'resourceLocks':['db-global']} ]})
 def tearDown(self):self.x.db.close();self.temp.cleanup()
 def test_deps_and_fencing(self):
  with self.assertRaises(ValueError): self.x.claim('T2','agentB')
  tok=self.x.claim('T1','agentA')
  with self.assertRaises(ValueError):self.x.claim('T1','agentB')
  with self.assertRaises(ValueError):self.x.transition('T1','running','agentA',tok+1)
  self.x.transition('T1','running','agentA',tok)
  self.x.transition('T1','verifying','agentA',tok)
  self.x.transition('T1','review_pending','reviewer',tok)
  self.x.transition('T1','integrating','integrator',tok)
  with self.assertRaises(ValueError):self.x.transition('T1','done','integrator',tok)
  self.x.transition('T1','done','integrator',tok,{'gateEvidenceRefs':['ci://test','pr://merged']})
  self.assertEqual(self.x.status('T1')['status'],'done')
  self.assertEqual(self.x.claim('T2','agentB'),1)
 def test_persistent_resume(self):
  self.x.claim('T1','agentA');self.x.db.close()
  y=Ledger(self.db);self.assertEqual(y.status('T1')['status'],'leased');y.db.close()
if __name__=='__main__':unittest.main()
