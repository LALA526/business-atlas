#!/usr/bin/env python3
"""Reference pre-merge PR gate. Requires an actual Git repo and SHA-valid source anchors.
Assumes caller supplies base/head from trusted CI, not from untrusted PR text.
"""
import pathlib,subprocess,hashlib,json,argparse,sys
from jsonschema import Draft202012Validator
HERE=pathlib.Path(__file__).resolve().parent

def git(repo,*args):
 r=subprocess.run(['git','-C',str(repo),*args],capture_output=True,text=True,encoding='utf8',check=True)
 return r.stdout.strip()

def check(repo,proposal,base,head,req_file):
 errors=[]
 obj=json.loads(pathlib.Path(proposal).read_text('utf8'))
 schema=json.loads((HERE/'schemas/knowledge-change-proposal-v1.2.schema.json').read_text('utf8'))
 errors += [f'JSON schema: {x.message}' for x in Draft202012Validator(schema).iter_errors(obj)]
 if errors:return errors
 req=json.loads(pathlib.Path(req_file).read_text('utf8'))
 allowed={r['id'] for r in req['requirements']}
 for i in obj['requirementIds']:
  if i not in allowed:errors.append('unknown requirement '+i)
 try:
  base=git(repo,'rev-parse',base+'^{commit}');head=git(repo,'rev-parse',head+'^{commit}')
  changed=set(git(repo,'diff','--name-only',base,head).splitlines())
  declared={x['path'] for x in obj['changedFiles']}
  if changed != declared:errors.append('changedFiles do not match git diff; missing='+str(sorted(changed-declared))+' excess='+str(sorted(declared-changed)))
  for f in obj['changedFiles']:
   if f['changeType']=='removed':continue
   path=f['path']
   try:
    actualblob=git(repo,'rev-parse',head+':'+path)
    if f.get('blobSha') and actualblob!=f['blobSha']:errors.append('blobSha mismatch '+path)
    content=subprocess.run(['git','-C',str(repo),'show',head+':'+path],capture_output=True,check=True).stdout
    if f.get('contentSha256') and hashlib.sha256(content).hexdigest()!=f['contentSha256']:errors.append('contentSha256 mismatch '+path)
   except subprocess.CalledProcessError:errors.append('file missing in HEAD '+path)
  for anchor in obj['sourceAnchors']:
   path=anchor['path']
   try:
    actualblob=git(repo,'rev-parse',head+':'+path)
    if anchor.get('blobSha') and anchor['blobSha']!=actualblob:errors.append('sourceAnchor blob mismatch '+path)
   except subprocess.CalledProcessError:errors.append('sourceAnchor missing '+path)
  if not any(x['result']=='passed' for x in obj['testEvidence']):errors.append('no passed test evidence')
  if any(x['path'].startswith('contracts/openapi/') for x in obj['changedFiles']) and not obj['apiChanges']: errors.append('OpenAPI changed without apiChanges')
  if any(x['path'].startswith(('migrations/','deploy/migrations/')) for x in obj['changedFiles']) and not obj['dataChanges']:errors.append('migration changed without dataChanges')
 except subprocess.CalledProcessError as e: errors.append('git repository error '+str(e))
 return errors
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--proposal',required=True);p.add_argument('--base',required=True);p.add_argument('--head',required=True);p.add_argument('--requirements',default=str(HERE.parent/'06_全量执行计划/requirements-trace-v1.2.json'));args=p.parse_args()
 errors=check(args.repo,args.proposal,args.base,args.head,args.requirements)
 print(json.dumps({'status':'PASS' if not errors else 'FAIL','errors':errors},ensure_ascii=False,indent=2));sys.exit(bool(errors))
