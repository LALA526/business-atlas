#!/usr/bin/env python3
"""V1.2 deliverables self-check. Does NOT validate a deployed Business Atlas implementation."""
import json,sys,argparse,pathlib,collections
try:
    from jsonschema import Draft202012Validator, FormatChecker
except ImportError as e:
    raise SystemExit('缺少依赖 jsonschema：python -m pip install jsonschema') from e

def validate(root:pathlib.Path):
    machine=root/'09_机器契约'; errors=[];schemas={}
    for f in sorted((machine/'schemas').glob('*.schema.json')):
        schema=json.loads(f.read_text('utf8'));Draft202012Validator.check_schema(schema);schemas[f.name]=schema
    pairs=[('knowledge-change-proposal-v1.2.schema.json','knowledge-change-proposal.example.json'),('knowledge-delivery-manifest-v1.2.schema.json','knowledge-delivery-manifest.example.json'),('deployment-reconciliation-v1.2.schema.json','deployment-reconciliation.example.json'),('domain-event-v1.2.schema.json','domain-event.example.json'),('mcp-tool-contract-v1.2.schema.json','mcp-tool-contract.example.json'),('error-pattern-v1.2.schema.json','error-pattern.example.json'),('agent-task-v1.2.schema.json','agent-task.example.json')]
    for sc,ex in pairs:
        x=json.loads((machine/'examples'/ex).read_text('utf8'))
        v=Draft202012Validator(schemas[sc],format_checker=FormatChecker())
        for err in v.iter_errors(x): errors.append(f'{ex}: {err.message}')
    proposal=json.loads((machine/'examples/knowledge-change-proposal.example.json').read_text('utf8'))
    manifest=json.loads((machine/'examples/knowledge-delivery-manifest.example.json').read_text('utf8'))
    if 'commitSha' in proposal['repo'] or 'finalCommitSha' in proposal:
        errors.append('PR 提案不得自引用最终 commitSha')
    if not manifest.get('finalCommitSha'):
        errors.append('Merge Manifest 需要 finalCommitSha')
    if not manifest.get('proposalSha256'):
        errors.append('Manifest 缺少 Proposal digest')
    dag=json.loads((root/'06_全量执行计划/agent-task-dag-v1.2.json').read_text('utf8'))
    req=json.loads((root/'06_全量执行计划/requirements-trace-v1.2.json').read_text('utf8'))
    ids=[r['id'] for r in req['requirements']]
    if len(ids)!=116 or len(set(ids))!=116:errors.append('全量需求不是116唯一ID')
    tasks=dag['tasks'];tids=[t['taskId'] for t in tasks]
    if len(tids)!=len(set(tids)):errors.append('Task ID重复')
    for task in tasks:
        for e in Draft202012Validator(schemas['agent-task-v1.2.schema.json']).iter_errors(task):errors.append(f'{task.get("taskId")}: {e.message}')
        for d in task['dependencyTaskIds']:
            if d not in tids:errors.append(f'{task["taskId"]} 依赖不存在的 {d}')
    mapped=set(k for t in tasks for k in t['requirementIds'])
    if mapped != set(ids): errors.append('需求覆盖失败: missing='+str(sorted(set(ids)-mapped)))
    rem={t['taskId']:set(t['dependencyTaskIds']) for t in tasks};order=[]
    while rem:
        ready=[k for k,v in rem.items() if not v]
        if not ready:
            errors.append('DAG 存在循环依赖');break
        for k in ready:
            order.append(k);del rem[k]
        for v in rem.values():v.difference_update(ready)
    fixture=json.loads((root/'07_认知黄金样本/semantic-golden-v1.2.json').read_text('utf8'))
    expected=fixture['expected']
    if (expected['stageCount'],expected['flowNodeCount'],expected['flowEdgeCount']) != (7,12,14): errors.append('制造金样本7/12/14预期丢失')
    if 'GROUP-undefined' not in expected['forbiddenGroupIds']:errors.append('缺少错误阶段聚合反例')
    # verify OpenAPI YAML syntax if yaml available, but do not count this as contract completeness
    try:
        import yaml
        op=yaml.safe_load((machine/'openapi-core-v1.2.yaml').read_text('utf8'))
        if op.get('openapi')!='3.1.0':errors.append('OpenAPI 版本不是3.1.0')
    except ImportError:
        print('WARNING: PyYAML 不在环境，跳过 YAML 语法检查（不影响 JSON 验证）')
    except Exception as e:errors.append(f'OpenAPI YAML 解析失败: {e}')
    print(json.dumps({'schemas':len(schemas),'examples':len(pairs),'requirements':len(ids),'tasks':len(tasks),'topologicalTasks':len(order),'errors':errors,'status':'PASS' if not errors else 'FAIL'},ensure_ascii=False,indent=2))
    return not errors
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',default=str(pathlib.Path(__file__).resolve().parent.parent));a=parser.parse_args()
    sys.exit(0 if validate(pathlib.Path(a.root)) else 1)
