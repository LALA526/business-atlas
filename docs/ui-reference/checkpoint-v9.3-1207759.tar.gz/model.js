/* Business Atlas V3 — shared demonstration knowledge. Business vocabulary lives here, not in views. */
(function (root, factory) {
  const engine = typeof module === 'object' && module.exports ? require('./engine.js') : root.AtlasEngine;
  const api = factory(engine);
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.AtlasModel = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (E) {
  'use strict';
  const clone = E.clone;
  const input = (id, label, options, defaultValue) => ({ id, label, kind: 'enum', default: defaultValue ?? options[0][0], options: options.map(([value, text]) => ({ value, label: text })) });
  const outcome = (id, label, actorIds = [], description = label) => ({ id, label, actorIds, description });
  const row = (id, priority, when, outcomeId) => ({ id, priority, when, outcomeId });
  const published = (version, data) => {
    const value = { version, status: 'published', effective: '2026-11-12 起生效', source: '已批准业务规范', supportsEvaluation: true, inputs: [], outcomes: [], rows: [], exceptions: [], ...data };
    value.summary = E.summarizeRule(value);
    return value;
  };
  const change = (objectId, before, after, constraint) => ({ objectId, before, after, constraint });
  const impl = (trigger, api, reads, writes, decision, event, external, failure, transaction, test, status = '已核验') => ({ trigger, api, reads, writes, decision, event, external, failure, transaction, test, status });
  const base = (id, name, goal) => ({
    meta: { id, name, version: 'draft', status: 'draft', desc: goal, goal, created: '2026-11-14', counters: {} },
    actors: [], objects: [], domains: [], capabilities: [], rules: [], scenarios: [], stages: [], steps: [], actions: [],
    exceptions: [], surfaces: [], facts: [], relations: [], flows: [], changes: [], issues: [], deliveries: [], archives: {},
    scale: { actions: 0, surfaces: 0, note: '仅展示已建立的业务知识。' }
  });

  function createMatureProject() {
    const m = base('PRJ-00001', '业务申请与审批', '让跨部门申请在可控风险下完成决策、生效和安全修订，同时保留每一次业务判断的依据。');
    m.meta.version = 'v2.4'; m.meta.status = 'published'; m.meta.desc = '跨部门申请、审批、生效与后续修订';
    m.actors = [
      { id: 'ACTOR-01', name: '申请人', concern: '减少往返，清楚知道修订影响' },
      { id: 'ACTOR-02', name: '原审批人', concern: '只复核必要变化，保留决策依据' },
      { id: 'ACTOR-03', name: '预算负责人', concern: '成本归属和额度变化必须重新判断' },
      { id: 'ACTOR-04', name: '财务系统', concern: '预算校验可靠、失败可补偿' },
      { id: 'ACTOR-05', name: '业务管理员', concern: '规则、术语与版本一致' },
      { id: 'ACTOR-06', name: '合规负责人', concern: '高风险资金变化必须独立复核' },
      { id: 'ACTOR-07', name: '系统', concern: '可靠执行规则并保留不可变历史' }
    ];
    m.objects = [
      { id: 'OBJ-0008', name: '业务申请', aliases: ['采购单', '审批单'], desc: '需要组织做出资源或责任承诺的业务意图。', states: ['草稿', '审批中', '已批准', '修订中', '已生效', '已失效'], props: ['申请目标', '金额', '成本中心', '收款方'] },
      { id: 'OBJ-0012', name: '修订', aliases: ['变更申请'], desc: '基于某一已批准版本形成的独立业务变化。', states: ['草稿', '待判断', '审批中', '已批准', '已生效', '已驳回', '已撤回'], props: ['基线版本', '修订原因', '变化字段', '重审范围'] },
      { id: 'OBJ-0015', name: '审批决策', aliases: ['审批记录'], desc: '参与者在固定规则版本下作出的不可变业务判断。', states: ['未创建', '待处理', '通过', '驳回', '已取消'], props: ['决策人', '结论', '规则版本'] },
      { id: 'OBJ-0021', name: '预算占用', aliases: ['额度占用'], desc: '申请对特定成本中心预算额度的资源承诺。', states: ['待校验', '已占用', '待重占', '已释放'], props: ['成本中心', '占用金额', '占用状态'] }
    ];
    const domainData = [
      ['DOM-01', '申请与受理', '将业务意图转化为完整、可判断的申请。', ['OBJ-0008'], ['ACTOR-01']],
      ['DOM-03', '审批与决策', '依据业务规则形成清晰、可追溯的审批决策。', ['OBJ-0008', 'OBJ-0015'], ['ACTOR-02', 'ACTOR-03', 'ACTOR-06']],
      ['DOM-04', '预算与校验', '确认资源额度，保留预算占用与释放依据。', ['OBJ-0021'], ['ACTOR-03', 'ACTOR-04']],
      ['DOM-07', '变更与撤回', '在不绕过既有决策的前提下完成修订、撤回与失效。', ['OBJ-0008', 'OBJ-0012'], ['ACTOR-01', 'ACTOR-05']],
      ['DOM-08', '合同与生效', '确认条款并衔接后续履约和生效事件。', ['OBJ-0008'], ['ACTOR-05']],
      ['DOM-11', '协作与通知', '让参与者及时获得待办、冲突和结果通知。', ['OBJ-0015'], ['ACTOR-01', 'ACTOR-02', 'ACTOR-03']]
    ];
    const capNames = ['申请起草', '完整性校验', '提交受理', '规则判断', '分级审批', '决策记录', '额度检查', '预算占用', '额度释放', '申请修订', '重审判定', '撤回失效', '条款确认', '版本生效', '履约衔接', '待办催办', '冲突升级', '结果通知'];
    m.domains = domainData.map(([id, name, desc, objects, actorIds], index) => ({ id, name, icon: name[0], desc, goal: desc, caps: capNames.slice(index * 3, index * 3 + 3).map((_, i) => `CAP-${String(index * 3 + i + 1).padStart(2, '0')}`), objects, actorIds, depends: index ? [domainData[index - 1][0]] : [] }));
    m.capabilities = capNames.map((name, i) => ({ id: `CAP-${String(i + 1).padStart(2, '0')}`, name, domainId: m.domains[Math.floor(i / 3)].id, desc: `${name}是可独立确认和追踪的业务能力。` }));
    const reviewInputs = [
      input('amount', '金额', [['unchanged', '不变'], ['changed', '变化']]),
      input('cost', '成本中心', [['unchanged', '不变'], ['changed', '变化']]),
      input('payee', '收款方', [['unchanged', '不变'], ['changed', '变化']]),
      input('conflict', '版本冲突', [['no', '不存在'], ['yes', '存在']])
    ];
    const reviewOutcomes = [
      outcome('FULL_REVIEW', '完整重审', ['ACTOR-02', 'ACTOR-03', 'ACTOR-06'], '原审批人、预算负责人和合规负责人分别确认'),
      outcome('BUDGET_REVIEW', '预算负责人和原审批人重审', ['ACTOR-02', 'ACTOR-03'], '原审批人与预算负责人并行确认'),
      outcome('ORIGINAL_REVIEW', '原审批人复核', ['ACTOR-02'], '仅原审批人复核一般变化'),
      outcome('BLOCK_CONFLICT', '停止提交并处理版本冲突', ['ACTOR-01', 'ACTOR-07'], '保留输入，合并最新版本后重新比较')
    ];
    const reviewV24 = published('v2.4', {
      name: '重新审批适用范围', scope: '业务申请处于已批准或修订中，且基于最新已批准版本提出修订。',
      inputs: clone(reviewInputs), outcomes: clone(reviewOutcomes),
      rows: [
        row('RR-01', 10, { payee: 'changed' }, 'FULL_REVIEW'),
        row('RR-02', 20, { amount: 'changed', payee: 'unchanged' }, 'FULL_REVIEW'),
        row('RR-03', 30, { amount: 'unchanged', cost: 'changed', payee: 'unchanged' }, 'BUDGET_REVIEW'),
        row('RR-04', 40, { amount: 'unchanged', cost: 'unchanged', payee: 'unchanged' }, 'ORIGINAL_REVIEW')
      ],
      exceptions: [row('RR-X1', 0, { conflict: 'yes' }, 'BLOCK_CONFLICT')],
      effective: '2026-11-12 起生效；不追溯改变历史审批决策。', source: 'DEC-2026-1112 · 业务负责人陈屿批准'
    });
    const conflictV24 = published('v2.4', {
      name: '并发修订保护', scope: '所有基于已批准版本的修订提交和发布。',
      inputs: [input('conflict', '版本冲突', [['no', '不存在'], ['yes', '存在']])],
      outcomes: [outcome('ALLOW_SUBMIT', '允许继续', ['ACTOR-07']), outcome('BLOCK_CONFLICT', '阻止覆盖并合并版本', ['ACTOR-01', 'ACTOR-07'])],
      rows: [row('CR-01', 10, { conflict: 'no' }, 'ALLOW_SUBMIT'), row('CR-02', 20, { conflict: 'yes' }, 'BLOCK_CONFLICT')],
      source: 'DEC-2026-1112 · 并发与版本决策'
    });
    const aggregateV24 = published('v2.4', {
      name: '审批汇总与终止', scope: '必要审批任务已经发起且申请人仍可撤回修订。',
      inputs: [input('decisionStatus', '任务汇总情况', [['allPassed', '全部通过'], ['rejected', '存在驳回'], ['withdrawn', '申请人撤回']])],
      outcomes: [outcome('COMPLETE', '形成通过结论', ['ACTOR-07']), outcome('REJECT', '形成驳回结论', ['ACTOR-07']), outcome('CANCEL', '取消未终结任务', ['ACTOR-07'])],
      rows: [row('AR-01', 10, { decisionStatus: 'allPassed' }, 'COMPLETE'), row('AR-02', 20, { decisionStatus: 'rejected' }, 'REJECT'), row('AR-03', 30, { decisionStatus: 'withdrawn' }, 'CANCEL')],
      source: 'DEC-2026-1112 · 审批汇总规范'
    });
    m.rules = [
      { id: 'RULE-0017', name: '重新审批适用范围', owner: '陈屿', currentVersion: 'v2.4', versions: { 'v2.4': reviewV24 } },
      { id: 'RULE-0021', name: '并发修订保护', owner: '陈屿', currentVersion: 'v2.4', versions: { 'v2.4': conflictV24 } },
      { id: 'RULE-0022', name: '审批汇总与终止', owner: '陈屿', currentVersion: 'v2.4', versions: { 'v2.4': aggregateV24 } }
    ];
    const stageData = [
      ['STG-01', '提出修订', 'DOM-07', '形成意图明确的修订请求', '已批准申请 v2.4', '修订意图与变化内容', ['ACTOR-01'], ['提出修订', '选择修订基线', '填写修订原因', '修改业务字段', '添加修订附件', '提交修订意图']],
      ['STG-02', '建立修订基线', 'DOM-07', '锁定可比较的原始业务事实', '修订意图', '唯一修订基线与草稿', ['ACTOR-01', 'ACTOR-07'], ['锁定原版本', '校验申请人权限', '读取原审批链', '创建修订草稿', '记录字段快照', '检查并发修订']],
      ['STG-03', '比较与判断', 'DOM-07', '识别变化并确定必要审批范围', '原版本与修订草稿', '变化清单与重审范围', ['ACTOR-07', 'ACTOR-05'], ['比较关键字段', '识别金额变化', '识别成本中心变化', '识别收款方变化', '计算重审范围', '确认判断依据']],
      ['STG-04', '重新审批', 'DOM-03', '仅让必要角色完成有依据的判断', '重审范围与修订草稿', '各角色审批决定', ['ACTOR-02', 'ACTOR-03', 'ACTOR-04'], ['发起重新审批', '校验预算可用额度', '发起原审批人复核', '并行发起预算审批', '处理审批退回补充', '处理审批超时升级']],
      ['STG-05', '汇总决策', 'DOM-03', '汇总并行结果并处理不一致', '各角色审批决定', '唯一汇总结论', ['ACTOR-07', 'ACTOR-02'], ['汇总审批决策', '检查部分通过', '处理审批驳回', '处理申请人撤回', '再次检查并发修订', '确认最终决策']],
      ['STG-06', '生效与发布', 'DOM-08', '形成不可混淆的新业务版本', '通过的汇总结论', '新版本与生效事件', ['ACTOR-07', 'ACTOR-04'], ['更新并发布事件', '生成新业务版本', '重占或释放预算', '保留原审批记录', '通知相关参与者', '衔接后续履约']],
      ['STG-07', '归档与后续', 'DOM-11', '保留可追踪历史并完成后续工作', '新业务版本与事件', '完整版本链和待办闭环', ['ACTOR-07', 'ACTOR-05'], ['归档修订版本', '记录规则适用版本', '更新界面操作权限', '关闭相关确认问题', '生成验收证据', '完成业务故事']]
    ];
    const fixed = { '提出修订': 'ACT-00421', '锁定原版本': 'ACT-00422', '比较关键字段': 'ACT-00423', '发起重新审批': 'ACT-00424', '汇总审批决策': 'ACT-00425', '更新并发布事件': 'ACT-00426' };
    let next = 427;
    m.stages = stageData.map(([id, name, domainId, goal, inputText, result, actorIds, names]) => ({ id, name, domainId, goal, input: inputText, result, actorIds, names, stepIds: [] }));
    const stageCapabilities = { 'STG-01': ['CAP-10'], 'STG-02': ['CAP-10'], 'STG-03': ['CAP-11'], 'STG-04': ['CAP-05', 'CAP-11'], 'STG-05': ['CAP-06'], 'STG-06': ['CAP-14'], 'STG-07': ['CAP-18'] };
    m.stages.forEach(stage => { stage.capabilityIds = stageCapabilities[stage.id] || []; });
    m.stages.forEach((stage, stageIndex) => stage.names.forEach((name, stepIndex) => {
      const id = fixed[name] || `ACT-${String(next++).padStart(5, '0')}`;
      const number = stageIndex * 6 + stepIndex + 1, stepId = `STEP-${String(number).padStart(3, '0')}`;
      const actorId = stage.actorIds[stepIndex % stage.actorIds.length];
      m.steps.push({ id: stepId, number, stageId: stage.id, actionId: id, name, actorId, kind: 'action', result: '概要步骤，独立结果待完善' });
      m.actions.push({ id, name, version: 'v2.4', status: 'published', actorId, stageId: stage.id, scenarioId: 'SCN-00126', stepId, domainId: stage.domainId, capabilityIds: clone(stage.capabilityIds), depth: 'summary', purpose: null, pre: [], input: [], output: [], objectChanges: [], exceptions: [], evidence: [], implementation: null });
      stage.stepIds.push(stepId);
    }));
    const detailed = {
      'ACT-00421': { actorId: 'ACTOR-01', purpose: '允许申请人在不覆盖原批准事实的前提下表达修订意图。', pre: ['申请处于已批准', '申请人本人或有效代理人'], input: ['申请 ID', '修订原因'], output: ['修订意图'], objectChanges: [change('OBJ-0008', '已批准 v2.4', '修订意图已记录', '原版本不变')], exceptions: ['E02'], evidence: ['FACT-SPEC-002'], implementation: impl('申请详情 / 修订按钮', 'POST /applications/{id}/revision-intents', ['application', 'actor_grant'], ['revision_intent（新增）'], '权限与申请状态通过后才创建意图', 'RevisionIntentCreated', '无', '权限或状态失败时不写入；重复请求去重', '意图与审计同事务', 'EVT-ACT421-01 · 已通过') },
      'ACT-00422': { actorId: 'ACTOR-07', ruleIds: ['RULE-0021'], purpose: '建立唯一、不可漂移的比较基线。', pre: ['修订意图存在', '当前版本可读'], input: ['申请 ID', '预期基线版本'], output: ['锁定基线 v2.4'], objectChanges: [change('OBJ-0012', '未建立', '基线 v2.4', '只能指向一个已批准版本')], exceptions: ['E01'], evidence: ['FACT-SPEC-002', 'FACT-IMPL-002'], implementation: impl('修订申请 / 自动进入', 'POST /revisions/baselines', ['application', 'latest_revision'], ['revision.baseline_version'], 'latest_version == expected_version', 'RevisionBaselineLocked', '无', '版本不一致返回 409，保留用户输入', '基线写入与版本比对同一事务', 'EVT-ACT422-01 · 已通过') },
      'ACT-00423': { actorId: 'ACTOR-07', purpose: '逐字段比较锁定基线与修订草稿，形成绑定两个版本的标准化变化清单。', pre: ['修订基线已锁定', '草稿字段完整'], input: ['原版本字段快照', '修订字段'], output: ['标准化变化清单', '字段比较证据'], objectChanges: [change('OBJ-0012', '变化未判断', '变化清单已生成', '比较结果绑定基线和草稿版本')], exceptions: ['E01', 'E03'], evidence: ['FACT-SPEC-001', 'FACT-IMPL-003', 'FACT-HIST-001'], implementation: impl('修订申请 / 保存并比较', 'POST /revisions/{id}/compare', ['revision_snapshot', 'revision_draft'], ['revision.change_set'], '标准化后逐字段比较，空值与 0 不等价', 'RevisionChangesCompared', '主数据字典服务', '字典不可用时保留未标准化状态，不进入后续判断', '只写比较结果，不更新申请主记录', '对比测试 18 条 · 2 条待核验', '待核验') },
      'ACT-00437': { actorId: 'ACTOR-07', purpose: '将基线金额与修订金额按币种和精度标准化，判断资金承诺是否变化。', pre: ['变化清单包含金额快照'], input: ['基线金额与币种', '修订金额与币种'], output: ['金额变化标记', '标准化差值'], objectChanges: [], exceptions: ['E03'], evidence: ['FACT-IMPL-003'] },
      'ACT-00438': { actorId: 'ACTOR-07', purpose: '比较成本归属，并保留成本中心有效期的核验结果。', pre: ['两个版本的成本中心均可读取'], input: ['基线成本中心', '修订成本中心'], output: ['成本中心变化标记', '主数据核验状态'], objectChanges: [], exceptions: ['E03'], evidence: ['FACT-IMPL-003'] },
      'ACT-00439': { actorId: 'ACTOR-07', purpose: '比较资金接收主体，避免账户别名掩盖实际收款方变化。', pre: ['收款方已完成主体归一化'], input: ['基线收款主体', '修订收款主体'], output: ['收款方变化标记'], objectChanges: [], exceptions: ['E03'], evidence: ['FACT-IMPL-003'] },
      'ACT-00440': { actorId: 'ACTOR-07', ruleIds: ['RULE-0017'], purpose: '系统根据修订字段的变化范围执行重审规则，确定必要角色并记录命中决策行。', pre: ['变化清单已生成', '无未解决版本冲突'], input: ['金额变化标记', '成本中心变化标记', '收款方变化标记', 'RULE-0017@v2.4'], output: ['重审范围', '命中规则与理由'], objectChanges: [change('OBJ-0012', '待判断', '重审范围已确定', '范围必须绑定规则版本与变化清单')], exceptions: ['E01'], evidence: ['FACT-SPEC-001', 'FACT-IMPL-003'] },
      'ACT-00441': { actorId: 'ACTOR-05', purpose: '把变化字段、命中规则版本和参与角色组成可复核的判断依据。', pre: ['重审范围已计算'], input: ['变化清单', '规则命中结果'], output: ['可追踪判断依据'], objectChanges: [change('OBJ-0012', '内部计算结果', '判断依据已确认', '依据确认后不可随草稿静默变化')], exceptions: [], evidence: ['FACT-SPEC-001'] },
      'ACT-00424': { actorId: 'ACTOR-07', ruleIds: ['RULE-0017', 'RULE-0021'], purpose: '服务端重新执行重审与并发规则，按结果创建互不覆盖的审批任务，并记录判断依据。', pre: ['变化清单已生成', '无未解决版本冲突', '申请仍处于可修订状态'], input: ['变化清单', '原审批链', 'RULE-0017@v2.4'], output: ['审批任务集合', '修订审批中状态', '任务创建事件'], objectChanges: [change('OBJ-0012', '待判断', '审批中', '重审范围必须记录规则版本'), change('OBJ-0015', '原审批记录只读', '新增审批任务，不修改历史', '原审批记录不可覆盖')], exceptions: ['E01', 'E04', 'E05', 'E06'], evidence: ['FACT-SPEC-001', 'FACT-IMPL-003', 'FACT-HIST-001'], implementation: impl('重审范围确认 / 确认发起', 'POST /revisions/{id}/review-tasks', ['revision.change_set', 'approval_chain', 'rule_definition'], ['review_task（按角色新增）', 'revision.review_scope'], '服务端重新执行 RULE-0017，前端试算不得直接决定写入', 'ReviewTasksCreated', '财务预算服务仅校验额度，不替代人工决策', '任一任务失败撤销本批；预算超时进入待重试，不标记通过', '审批任务批量创建同一事务；外部调用使用补偿', 'REV-424-01…12 · 12 条通过') },
      'ACT-00442': { actorId: 'ACTOR-04', purpose: '在创建预算审批任务前核验成本中心额度；额度不足不会被解释为审批通过。', pre: ['重审范围包含预算负责人'], input: ['成本中心', '修订金额', '现有预算占用'], output: ['额度校验结论', '失败原因（如有）'], objectChanges: [change('OBJ-0021', '已占用', '待重占或校验失败', '校验失败不改变原占用')], exceptions: ['E04'], evidence: ['FACT-SPEC-003'], implementation: impl('系统 / 发起预算任务前', 'POST /budget/validations', ['budget_account', 'reservation'], ['budget_validation（新增）'], '可用额度覆盖修订差额才通过', 'BudgetValidated', '财务预算服务', '超时产生待重试记录；明确拒绝进入异常', '校验记录可幂等重试', 'BUD-442-03 · 待补偿用例', '待核验') },
      'ACT-00443': { actorId: 'ACTOR-02', ruleIds: ['RULE-0017'], purpose: '为原审批人创建独立复核任务，保留其对原业务事实的判断上下文。', pre: ['审批任务集合已获准创建'], input: ['修订差异', '原审批记录', '命中规则版本'], output: ['原审批人待办', '通过或退回意见'], objectChanges: [change('OBJ-0015', '未创建', '原审批人任务待处理', '新任务不覆盖原审批记录')], exceptions: ['E05', 'E06'], evidence: ['FACT-SPEC-001'] },
      'ACT-00444': { actorId: 'ACTOR-03', ruleIds: ['RULE-0017'], purpose: '成本归属或资金风险命中时，与原审批复核并行创建预算责任确认任务。', pre: ['规则结果包含预算负责人', '额度校验未明确失败'], input: ['成本中心变化', '金额变化', '额度校验结论'], output: ['预算负责人待办', '预算审批意见'], objectChanges: [change('OBJ-0015', '未创建', '预算任务待处理', '只有规则要求时才创建')], exceptions: ['E04', 'E05', 'E06'], evidence: ['FACT-SPEC-001'] },
      'ACT-00445': { actorId: 'ACTOR-02', purpose: '审批事实不足时暂停当前任务并创建补充待办，已完成的其他意见仍然保留。', pre: ['审批人选择退回补充而非驳回'], input: ['补充说明', '当前任务集合'], output: ['补充待办', '暂停状态'], objectChanges: [change('OBJ-0012', '审批中', '待补充', '补充后必须重新比较变化')], exceptions: ['E05'], evidence: ['FACT-SPEC-003'] },
      'ACT-00446': { actorId: 'ACTOR-07', purpose: '任务超过处理时限时生成升级待办，但不自动把超时解释为通过。', pre: ['任务未终结且超过角色时限'], input: ['任务创建时间', '角色处理时限'], output: ['升级待办', '催办事件'], objectChanges: [change('OBJ-0015', '待处理', '已升级待处理', '升级不改变任务结论')], exceptions: ['E08'], evidence: [] },
      'ACT-00425': { actorId: 'ACTOR-07', ruleIds: ['RULE-0022'], purpose: '等待必要并行任务全部终结后形成唯一汇总结论；部分通过不等于整体通过。', pre: ['所有必要任务已终结', '无新提交修订'], input: ['审批任务集合', '撤回标记'], output: ['通过、驳回或已撤回结论'], objectChanges: [change('OBJ-0015', '任务审批中', '形成汇总结论', '部分通过不等于整体通过'), change('OBJ-0012', '审批中', '已批准、已驳回或已撤回', '结论绑定完整任务集合')], exceptions: ['E05', 'E06', 'E07', 'E08'], evidence: ['FACT-SPEC-003'], implementation: impl('审批工作台 / 自动汇总', 'POST /revisions/{id}/decision/aggregate', ['review_task', 'revision'], ['revision.decision'], '全部必要任务通过才通过；任一驳回即驳回；撤回优先取消任务', 'RevisionDecisionAggregated', '通知服务', '汇总失败可重试；revision_id 保证一个有效结论', '决策与未完成任务取消同事务', '并行汇总测试 · 撤回竞争待补充', '待核验') },
      'ACT-00447': { actorId: 'ACTOR-07', ruleIds: ['RULE-0022'], purpose: '逐项核验必要任务是否全部通过，并把驳回与撤回路由到不同业务终点。', pre: ['汇总结论候选已生成'], input: ['必要任务清单', '各任务结论', '撤回标记'], output: ['可发布、驳回或撤回路由'], objectChanges: [], exceptions: ['E06', 'E07'], evidence: ['FACT-SPEC-003'] },
      'ACT-00448': { actorId: 'ACTOR-07', ruleIds: ['RULE-0022'], purpose: '任一必要角色明确驳回时形成驳回终点，取消剩余任务并保留所有意见。', pre: ['至少一个必要任务为驳回'], input: ['驳回意见', '未终结任务'], output: ['驳回结论', '任务取消事件'], objectChanges: [change('OBJ-0012', '审批中', '已驳回', '原批准申请保持有效')], exceptions: ['E06'], evidence: ['FACT-SPEC-003'] },
      'ACT-00449': { actorId: 'ACTOR-01', ruleIds: ['RULE-0022'], purpose: '审批完成前接受申请人撤回，取消未终结任务并释放临时资源承诺。', pre: ['修订尚未形成最终通过事实'], input: ['撤回原因', '当前修订'], output: ['已撤回终点', '资源释放待办'], objectChanges: [change('OBJ-0012', '审批中', '已撤回', '不回到正常发布路径')], exceptions: ['E07'], evidence: ['FACT-SPEC-003'] },
      'ACT-00450': { actorId: 'ACTOR-07', ruleIds: ['RULE-0021'], purpose: '最终确认前再次比较基线与最新版本，防止审批期间发生静默覆盖。', pre: ['必要任务全部通过'], input: ['锁定基线', '最新申请版本'], output: ['可发布确认或冲突异常'], objectChanges: [], exceptions: ['E01'], evidence: ['FACT-SPEC-002'] },
      'ACT-00451': { actorId: 'ACTOR-07', ruleIds: ['RULE-0021', 'RULE-0022'], purpose: '将通过结论、完整任务集合和未漂移基线组合成唯一可发布决策。', pre: ['全部必要任务通过', '基线未漂移', '申请人未撤回'], input: ['任务集合', '汇总结论', '版本核验结果'], output: ['最终通过决策'], objectChanges: [change('OBJ-0012', '审批中', '已批准', '决策绑定完整任务和固定规则版本')], exceptions: ['E01'], evidence: ['FACT-SPEC-002', 'FACT-SPEC-003'] },
      'ACT-00426': { actorId: 'ACTOR-07', ruleIds: ['RULE-0021'], purpose: '将已批准修订形成新业务版本，并通过可靠事件向后续业务发布事实。', pre: ['汇总结论为通过', '版本仍未变化'], input: ['通过结论', '修订草稿'], output: ['申请 v2.5', 'RevisionPublished 事件'], objectChanges: [change('OBJ-0008', '修订中 v2.4 基线', '已批准 v2.5', '生成新版本，不覆盖历史'), change('OBJ-0012', '已批准', '已生效', '事件与版本引用一致')], exceptions: ['E01', 'E09'], evidence: ['FACT-SPEC-002', 'FACT-IMPL-004'], implementation: impl('系统 / 决策通过后自动执行', 'POST /revisions/{id}/publish', ['revision', 'decision'], ['application_version（新增）', 'outbox_event（新增）'], '决策有效且基线未漂移才写入', 'RevisionPublished', '通知、预算与履约系统订阅 outbox', '主事务失败不发布；订阅方失败独立重试', '新版本与 outbox 同事务', 'PUB-426-08 · 幂等与重试通过') }
    };
    Object.entries(detailed).forEach(([id, data]) => Object.assign(m.actions.find(action => action.id === id), { depth: 'detailed' }, clone(data)));
    m.exceptions = [
      { id: 'E01', name: '并发版本冲突', stepId: 'STEP-019', stepIds: ['STEP-012', 'STEP-013', 'STEP-019', 'STEP-030', 'STEP-031'], trigger: '提交或发布前发现基线已不是最新版本。', handling: ['阻止覆盖', '保留当前输入', '加载最新版本', '由申请人合并或退出'], recovery: '合并后回到比较关键字段。', actorId: 'ACTOR-01' },
      { id: 'E02', name: '申请人无修订权限', stepId: 'STEP-001', trigger: '当前用户不是申请人本人或有效代理人。', handling: ['拒绝创建修订', '说明权限依据', '记录访问审计'], recovery: '获得有效授权后重新提出修订。', actorId: 'ACTOR-07' },
      { id: 'E03', name: '字段无法标准化', stepId: 'STEP-013', trigger: '成本中心或收款方引用失效，无法可靠比较。', handling: ['标记待补充', '不发起审批', '保留原始输入'], recovery: '补充有效主数据后重新比较。', actorId: 'ACTOR-01' },
      { id: 'E04', name: '预算校验失败', stepId: 'STEP-020', trigger: '额度不足或预算服务明确拒绝。', handling: ['预算任务标记未通过', '保留其他审批意见', '通知相关参与者'], recovery: '调整金额或成本中心后重新比较。', actorId: 'ACTOR-03' },
      { id: 'E05', name: '审批退回补充', stepId: 'STEP-023', trigger: '审批人认为修订事实不足，但尚未作出驳回。', handling: ['暂停当前审批链', '保留已完成意见', '创建补充待办'], recovery: '补充后重新比较并判断是否扩大范围。', actorId: 'ACTOR-02' },
      { id: 'E06', name: '审批驳回', stepId: 'STEP-027', trigger: '任一必要审批角色明确驳回。', handling: ['汇总结论为驳回', '取消未终结任务', '保留全部决策记录'], recovery: '结束修订或修改后新建修订。', actorId: 'ACTOR-07' },
      { id: 'E07', name: '申请人撤回', stepId: 'STEP-028', trigger: '审批完成前申请人主动撤回。', handling: ['取消未终结任务', '释放临时预算占用', '记录撤回原因'], recovery: '进入已撤回终点，不回到正常发布。', actorId: 'ACTOR-01' },
      { id: 'E08', name: '审批超时升级', stepId: 'STEP-024', trigger: '任务超过角色对应处理时限。', handling: ['提醒原审批人', '生成升级待办', '增加授权升级人'], recovery: '升级审批完成后回到汇总。', actorId: 'ACTOR-07' },
      { id: 'E09', name: '事件发布失败', stepId: 'STEP-031', trigger: '新版本已提交，但某一外部订阅方暂时不可用。', handling: ['保留 outbox 事件', '按策略重试', '不回滚已生效版本'], recovery: '订阅方确认后关闭异常，重复事件按 ID 去重。', actorId: 'ACTOR-07' }
    ];
    m.surfaces = [
      { id: 'UI-00128', name: '申请详情', domainId: 'DOM-07', type: '普通页面', actorId: 'ACTOR-01', sceneIds: ['SCN-00126'], operations: [{ name: '提出修订', actionId: 'ACT-00421', states: ['已批准'] }], objectIds: ['OBJ-0008', 'OBJ-0012'], api: 'GET /applications/{id}' },
      { id: 'UI-00131', name: '修订申请', domainId: 'DOM-07', type: '普通页面', actorId: 'ACTOR-01', sceneIds: ['SCN-00126'], operations: [{ name: '保存并比较', actionId: 'ACT-00423', states: ['已批准', '修订中'] }], objectIds: ['OBJ-0012'], api: 'PATCH /revisions/{id}' },
      { id: 'UI-00079', name: '重审范围确认', domainId: 'DOM-03', type: '弹窗', actorId: 'ACTOR-02', sceneIds: ['SCN-00126'], operations: [{ name: '确认并发起重审', actionId: 'ACT-00424', states: ['修订中'] }], objectIds: ['OBJ-0012', 'OBJ-0015'], api: 'POST /revisions/{id}/review-tasks' },
      { id: 'UI-00074', name: '审批工作台', domainId: 'DOM-03', type: '普通页面', actorId: 'ACTOR-02', sceneIds: ['SCN-00126'], operations: [{ name: '汇总审批决策', actionId: 'ACT-00425', states: ['修订中'] }], objectIds: ['OBJ-0015'], api: 'POST /approvals/{id}/decision' },
      { id: 'UI-00224', name: '版本冲突提示', domainId: 'DOM-07', type: '弹窗', actorId: 'ACTOR-01', sceneIds: ['SCN-00126'], operations: [{ name: '检查并发修订', actionId: 'ACT-00450', states: ['修订中'] }], objectIds: ['OBJ-0012'], api: 'GET /revisions/{id}/conflicts' },
      { id: 'UI-00206', name: '预算占用结果', domainId: 'DOM-04', type: '嵌入式外部系统', actorId: 'ACTOR-04', sceneIds: ['SCN-00126'], operations: [{ name: '校验预算可用额度', actionId: 'ACT-00442', states: ['修订中'] }], objectIds: ['OBJ-0021'], api: 'POST /budget/validations' }
    ];
    m.facts = [
      { id: 'FACT-HIST-001', kind: 'history', source: '历史需求 PRD v1.6', conclusion: '历史资料仅记录金额变化需要完整重审，不能覆盖当前批准规范。', status: '历史事实', date: '2025-08-21', owner: '旧需求记录', targetId: 'RULE-0017@v1.6' },
      { id: 'FACT-SPEC-001', kind: 'specification', source: '已批准规范 RULE-0017@v2.4', conclusion: reviewV24.summary, status: '已批准', date: '2026-11-12', owner: '陈屿', targetId: 'RULE-0017@v2.4' },
      { id: 'FACT-SPEC-002', kind: 'specification', source: '并发与版本决策 DEC-2026-1112', conclusion: '基线漂移时禁止覆盖；发布形成新版本并保留历史。', status: '已批准', date: '2026-11-12', owner: '陈屿', targetId: 'RULE-0021@v2.4' },
      { id: 'FACT-SPEC-003', kind: 'specification', source: '审批汇总规范 v2.4', conclusion: '全部必要任务通过才整体通过；部分通过不是最终通过。', status: '已批准', date: '2026-11-12', owner: '陈屿', targetId: 'RULE-0022@v2.4' },
      { id: 'FACT-IMPL-002', kind: 'implementation', source: 'RevisionBaselineService · commit 8ac31e', conclusion: '版本不一致返回 409，前端保留输入。', status: '已核验', date: '2026-11-13', owner: '周宇', targetId: 'ACT-00422' },
      { id: 'FACT-IMPL-003', kind: 'implementation', source: 'RevisionService.compareCriticalFields', conclusion: '实现比较三个关键字段；空值标准化仍有 2 条待核验。', status: '待核验', date: '2026-11-13', owner: '周宇', targetId: 'ACT-00423' },
      { id: 'FACT-IMPL-004', kind: 'implementation', source: 'OutboxPublisher · 测试 PUB-426-08', conclusion: '版本与 outbox 同事务，订阅失败独立重试。', status: '已核验', date: '2026-11-13', owner: '周宇', targetId: 'ACT-00426' }
    ];
    m.scenarios = [
      { id: 'SCN-00126', name: '修订已批准申请', version: 'v2.4', status: 'published', goal: '允许修正已批准内容，并根据关键字段变化确定最小必要重审范围。', trigger: '已批准申请的业务事实需要调整，且原审批事实必须保留。', participants: ['ACTOR-01', 'ACTOR-02', 'ACTOR-03', 'ACTOR-04', 'ACTOR-05'], result: '形成可追踪的新业务版本；驳回或撤回时不改变原批准事实。', stageIds: m.stages.map(stage => stage.id), exceptionIds: m.exceptions.map(exception => exception.id), full: true, explore: { ruleIds: ['RULE-0021', 'RULE-0017'] } },
      { id: 'SCN-00118', name: '提交并完成审批', version: 'v2.4', status: 'published', goal: '从申请提交到完成首次审批。', trigger: '申请人形成新的业务意图。', participants: ['ACTOR-01', 'ACTOR-02'], result: '申请获得审批结论。', stageIds: [], exceptionIds: [], full: false },
      { id: 'SCN-00131', name: '审批冲突与升级', version: 'v2.4', status: 'published', goal: '处理角色冲突和审批超时。', trigger: '审批角色冲突或任务超时。', participants: ['ACTOR-02', 'ACTOR-05'], result: '形成合法有效的审批结论。', stageIds: [], exceptionIds: [], full: false },
      { id: 'SCN-00142', name: '生效与归档', version: 'v2.4', status: 'published', goal: '发布生效事件并归档固定版本。', trigger: '申请审批通过。', participants: ['ACTOR-07', 'ACTOR-05'], result: '业务生效且证据完整。', stageIds: [], exceptionIds: [], full: false }
    ];
    m.flows = [buildMatureFlow(m)];
    m.changes = [
      { id: 'CHG-00318', title: '调整重新审批适用范围', ruleId: 'RULE-0017', baseVersion: 'v2.4', targetVersion: 'v2.5', status: 'draft', reason: '明确成本归属变化所需的重审范围。', draftRule: null, checks: { actions: false, scenarios: false, acceptance: false, technical: false }, history: [{ at: '2026-11-14 10:42', by: '林岚', text: '创建变更意图' }] },
      { id: 'CHG-00319', title: '澄清并发修订保护', ruleId: 'RULE-0021', baseVersion: 'v2.4', targetVersion: 'v2.5', status: 'draft', reason: '独立核验冲突处理范围，不与重审范围草稿混用。', draftRule: null, checks: { actions: false, scenarios: false, acceptance: false, technical: false }, history: [{ at: '2026-11-14 10:48', by: '林岚', text: '创建第二张变更单' }] }
    ];
    m.issues = [
      { id: 'Q-00218', title: '成本中心变化是否必须由预算负责人重审？', why: '决定低风险修订能否缩减审批范围。', status: 'replied', owner: '陈屿', objectId: 'RULE-0017', changeId: 'CHG-00318', blocked: ['ACT-00424', 'DLV-00086'], replies: [{ by: '周宇', text: '当前实现包含成本中心比较，但是否必须人工审批仍需业务确认。', time: '今天 09:42' }], evidenceIds: ['FACT-HIST-001', 'FACT-SPEC-001', 'FACT-IMPL-003'], requiresChange: true, decision: null },
      { id: 'Q-00204', title: '撤回后资源承诺应在何时释放？', why: '影响额度和验收条件。', status: 'confirming', owner: '陈屿', objectId: 'ACT-00449', changeId: null, blocked: ['ACT-00449'], replies: [{ by: '周宇', text: '当前实现异步释放，通常在 2 分钟内完成。', time: '昨天 16:20' }], evidenceIds: [], requiresChange: false, decision: '接受异步释放，但必须提供可追踪补偿任务。' }
    ];
    m.deliveries = [{ id: 'DLV-00086', requirementId: 'REQ-00042', scenarioId: 'SCN-00126', actionIds: ['ACT-00424', 'ACT-00425'], ruleId: 'RULE-0017', ruleVersion: 'v2.5', surfaceIds: ['UI-00079', 'UI-00131'], technicalReview: false, packageVersion: null, snapshot: null, stage: 0,
      acceptance: [
        { id: 'ACC-01', ruleId: 'RULE-0017', ruleVersion: 'v2.4', sample: { amount: 'changed', cost: 'unchanged', payee: 'unchanged', conflict: 'no' }, expectedOutcomeId: 'FULL_REVIEW', status: 'active', checked: false },
        { id: 'ACC-02', ruleId: 'RULE-0017', ruleVersion: 'v2.4', sample: { amount: 'unchanged', cost: 'changed', payee: 'unchanged', conflict: 'no' }, expectedOutcomeId: 'BUDGET_REVIEW', status: 'active', checked: false },
        { id: 'ACC-03', ruleId: 'RULE-0017', ruleVersion: 'v2.4', sample: { amount: 'unchanged', cost: 'unchanged', payee: 'changed', conflict: 'no' }, expectedOutcomeId: 'FULL_REVIEW', status: 'active', checked: false }
      ], agentIssueCreated: false }];
    m.scale = { actions: 500, surfaces: 1024, note: '42 个场景动作中具有独立业务剖面的条目已标注；其余为概要。500 动作与 1024 界面规模中额外条目仅为索引，不参与语义关联统计。' };
    return finalize(m);
  }

  function buildMatureFlow(m) {
    const nodes = m.actions.map(action => ({ id: `N-${action.id}`, actionId: action.id, stageId: action.stageId, type: ['ACT-00440', 'ACT-00447'].includes(action.id) ? 'decision' : action.id === 'ACT-00426' ? 'event' : 'action' }));
    nodes.find(node => node.actionId === 'ACT-00440').ruleId = 'RULE-0017';
    nodes.find(node => node.actionId === 'ACT-00447').ruleId = 'RULE-0022';
    const aux = [
      ['N-START', 'start', '开始修订', 'STG-01'], ['N-VERSION', 'decision', '是否存在版本冲突？', 'STG-03', 'RULE-0021'],
      ['N-BLOCK', 'exception', '阻止提交并保留输入', 'STG-03'], ['N-MERGE', 'action', '合并最新版本', 'STG-03'],
      ['N-FORK', 'parallel', '按命中角色并行发起', 'STG-04'], ['N-COMPLIANCE', 'action', '合规负责人独立复核', 'STG-04', null, 'ACTOR-06'],
      ['N-JOIN', 'join', '等待全部必要任务终结', 'STG-05'], ['N-REJECT-END', 'end', '修订驳回终点', 'STG-05'], ['N-CANCEL-END', 'end', '修订撤回终点', 'STG-05']
    ];
    aux.forEach(([id, type, name, stageId, ruleId, actorId]) => nodes.push({ id, type, name, stageId, ruleId, actorId }));
    const edges = []; let edgeNo = 1;
    const connect = (from, to, type = 'next', extra = {}) => edges.push({ id: `E-${String(edgeNo++).padStart(3, '0')}`, from: from.startsWith('N-') ? from : `N-${from}`, to: to.startsWith('N-') ? to : `N-${to}`, type, ...extra });
    for (let i = 0; i < m.actions.length - 1; i++) connect(m.actions[i].id, m.actions[i + 1].id);
    connect('N-START', 'ACT-00421');
    const key = new Set(['ACT-00423', ...Array.from({ length: 15 }, (_, i) => `ACT-${String(437 + i).padStart(5, '0')}`), 'ACT-00424', 'ACT-00425']);
    for (let i = edges.length - 1; i >= 0; i--) if (key.has(edges[i].from.replace('N-', '')) || key.has(edges[i].to.replace('N-', ''))) edges.splice(i, 1);
    connect('ACT-00436', 'ACT-00423'); connect('ACT-00423', 'N-VERSION');
    connect('N-VERSION', 'N-BLOCK', 'error', { when: { ruleId: 'RULE-0021', outcomeId: 'BLOCK_CONFLICT' }, label: '存在冲突' });
    connect('N-BLOCK', 'N-MERGE', 'next'); connect('N-MERGE', 'ACT-00423', 'return', { label: '重新比较' });
    connect('N-VERSION', 'ACT-00437', 'when', { when: { ruleId: 'RULE-0021', outcomeId: 'ALLOW_SUBMIT' }, label: '无冲突' });
    connect('ACT-00437', 'ACT-00438'); connect('ACT-00438', 'ACT-004439'.replace('ACT-004439', 'ACT-00439')); connect('ACT-00439', 'ACT-00440');
    connect('ACT-00440', 'ACT-00441');
    connect('ACT-00441', 'ACT-00442', 'when', { when: { ruleId: 'RULE-0017', outcomeId: 'BUDGET_REVIEW' }, label: '预算 + 原审批人' });
    connect('ACT-00441', 'ACT-00442', 'when', { when: { ruleId: 'RULE-0017', outcomeId: 'FULL_REVIEW' }, label: '完整重审' });
    connect('ACT-00441', 'ACT-00424', 'when', { when: { ruleId: 'RULE-0017', outcomeId: 'ORIGINAL_REVIEW' }, label: '原审批人复核' });
    connect('ACT-00442', 'ACT-00424'); connect('ACT-00424', 'N-FORK');
    ['BUDGET_REVIEW', 'ORIGINAL_REVIEW', 'FULL_REVIEW'].forEach(outcomeId => connect('N-FORK', 'ACT-00443', 'parallel', { when: { ruleId: 'RULE-0017', outcomeId }, label: '原审批任务' }));
    ['BUDGET_REVIEW', 'FULL_REVIEW'].forEach(outcomeId => connect('N-FORK', 'ACT-00444', 'parallel', { when: { ruleId: 'RULE-0017', outcomeId }, label: '预算任务' }));
    connect('N-FORK', 'N-COMPLIANCE', 'parallel', { when: { ruleId: 'RULE-0017', outcomeId: 'FULL_REVIEW' }, label: '合规任务' });
    connect('ACT-00443', 'N-JOIN', 'join'); connect('ACT-00444', 'N-JOIN', 'join'); connect('N-COMPLIANCE', 'N-JOIN', 'join'); connect('N-JOIN', 'ACT-00425'); connect('ACT-00425', 'ACT-00447');
    connect('ACT-00447', 'ACT-00450', 'when', { when: { ruleId: 'RULE-0022', outcomeId: 'COMPLETE' }, label: '全部通过' });
    connect('ACT-00447', 'ACT-00448', 'when', { when: { ruleId: 'RULE-0022', outcomeId: 'REJECT' }, label: '存在驳回' });
    connect('ACT-00447', 'ACT-00449', 'when', { when: { ruleId: 'RULE-0022', outcomeId: 'CANCEL' }, label: '申请人撤回' });
    connect('ACT-00448', 'N-REJECT-END', 'terminate'); connect('ACT-00449', 'N-CANCEL-END', 'terminate'); connect('ACT-00450', 'ACT-00451'); connect('ACT-00451', 'ACT-00426');
    connect('ACT-00443', 'ACT-00445', 'error', { defaultCollapsed: true, label: '退回补充' }); connect('ACT-00445', 'ACT-00423', 'return', { defaultCollapsed: true, label: '补充后重判' });
    connect('ACT-00443', 'ACT-00446', 'error', { defaultCollapsed: true, label: '处理超时' }); connect('ACT-00446', 'N-JOIN', 'return', { defaultCollapsed: true, label: '升级后汇总' });
    return { id: 'FLOW-00126', scenarioId: 'SCN-00126', nodes, edges };
  }

  function createBookingProject() {
    const m = base('PRJ-00002', '预约服务平台', '让用户选择服务与时间，系统依据服务能力和资源占用完成预约，并支持改期、取消与资源释放。');
    m.meta.version = 'v1.0'; m.meta.status = 'published'; m.meta.desc = '服务预约、资源占用、改期与取消';
    m.actors = [
      { id: 'ACTOR-B01', name: '预约用户', concern: '快速找到可约时间并得到明确结果' },
      { id: 'ACTOR-B02', name: '调度系统', concern: '避免超卖和重复占用' },
      { id: 'ACTOR-B03', name: '服务资源', concern: '容量与可服务时间保持一致' },
      { id: 'ACTOR-B04', name: '通知服务', concern: '可靠送达预约结果' }
    ];
    m.objects = [
      { id: 'OBJ-B01', name: '服务', aliases: ['服务项目'], desc: '定义时长、所需资源类型和单次服务容量。', states: ['可预约', '暂停预约'], props: ['服务时长', '资源类型', '服务容量'] },
      { id: 'OBJ-B02', name: '资源时段', aliases: ['可约时段'], desc: '某项资源在特定时间范围内可被占用的容量。', states: ['可用', '已占用', '已释放', '不可用'], props: ['开始时间', '结束时间', '剩余容量'] },
      { id: 'OBJ-B03', name: '预约单', aliases: ['预订记录'], desc: '用户对一个服务与时段形成的可追踪预约事实。', states: ['待确认', '已确认', '改期中', '已取消', '预约失败'], props: ['用户', '服务', '预约时段', '占用数量'] }
    ];
    m.domains = [
      { id: 'DOM-B01', name: '服务与查询', icon: '查', desc: '展示服务内容并计算真实可约时间。', goal: '让用户基于有效服务能力选择时间', caps: ['CAP-B01', 'CAP-B02'], objects: ['OBJ-B01', 'OBJ-B02'], actorIds: ['ACTOR-B01', 'ACTOR-B02'], depends: [] },
      { id: 'DOM-B02', name: '预约与占用', icon: '约', desc: '以原子方式确认预约并占用资源时段。', goal: '形成不超额、不重复的预约事实', caps: ['CAP-B03', 'CAP-B04'], objects: ['OBJ-B02', 'OBJ-B03'], actorIds: ['ACTOR-B01', 'ACTOR-B02', 'ACTOR-B04'], depends: ['DOM-B01'] },
      { id: 'DOM-B03', name: '改期与取消', icon: '改', desc: '在变更预约时正确保留、替换或释放资源。', goal: '让预约变化与资源占用始终一致', caps: ['CAP-B05', 'CAP-B06'], objects: ['OBJ-B02', 'OBJ-B03'], actorIds: ['ACTOR-B01', 'ACTOR-B02'], depends: ['DOM-B02'] }
    ];
    [['CAP-B01', '服务选择', 'DOM-B01'], ['CAP-B02', '可用性计算', 'DOM-B01'], ['CAP-B03', '预约确认', 'DOM-B02'], ['CAP-B04', '时段占用', 'DOM-B02'], ['CAP-B05', '预约改期', 'DOM-B03'], ['CAP-B06', '取消与释放', 'DOM-B03']].forEach(([id, name, domainId]) => m.capabilities.push({ id, name, domainId, desc: `${name}对应的独立业务能力。` }));
    const availability = published('v1.0', {
      name: '资源可预约判定', scope: '用户已选择服务、资源类型与一个候选时间。',
      inputs: [input('capacity', '服务剩余容量', [['sufficient', '充足'], ['insufficient', '不足']]), input('slot', '目标时段', [['free', '可用'], ['occupied', '冲突或不可用']])],
      outcomes: [outcome('BOOKABLE', '允许确认预约', ['ACTOR-B01', 'ACTOR-B02']), outcome('UNAVAILABLE', '保留查询并提示更换时间', ['ACTOR-B01', 'ACTOR-B02'])],
      rows: [row('BR-01', 10, { capacity: 'insufficient' }, 'UNAVAILABLE'), row('BR-02', 20, { capacity: 'sufficient', slot: 'occupied' }, 'UNAVAILABLE'), row('BR-03', 30, { capacity: 'sufficient', slot: 'free' }, 'BOOKABLE')],
      source: '预约业务负责人确认 · 2026-11-14'
    });
    const changeRule = published('v1.0', {
      name: '改期与取消资源处理', scope: '预约单已确认且尚未完成服务。',
      inputs: [input('changeType', '变更方式', [['none', '不变更'], ['reschedule', '改期'], ['cancel', '取消']]), input('targetSlot', '目标新时段', [['free', '可用'], ['occupied', '不可用']])],
      outcomes: [outcome('KEEP_BOOKING', '保留原预约', ['ACTOR-B01', 'ACTOR-B02']), outcome('RESCHEDULE', '占用新时段并释放原时段', ['ACTOR-B02']), outcome('CANCEL_BOOKING', '取消预约并释放原时段', ['ACTOR-B02'])],
      rows: [row('BC-01', 10, { changeType: 'cancel' }, 'CANCEL_BOOKING'), row('BC-02', 20, { changeType: 'reschedule', targetSlot: 'occupied' }, 'KEEP_BOOKING'), row('BC-03', 30, { changeType: 'reschedule', targetSlot: 'free' }, 'RESCHEDULE'), row('BC-04', 40, { changeType: 'none' }, 'KEEP_BOOKING')],
      source: '预约业务负责人确认 · 2026-11-14'
    });
    const invariant = published('v1.0', { name: '时段占用原子性', scope: '预约确认、改期与取消的资源写入。', supportsEvaluation: false, constraint: '预约事实与资源占用必须在同一原子操作中成功；任一方失败均不得留下部分结果。', rows: [], outcomes: [], inputs: [], source: '资源一致性评审 · 2026-11-14' });
    m.rules = [{ id: 'RULE-B001', name: '资源可预约判定', owner: '许言', currentVersion: 'v1.0', versions: { 'v1.0': availability } }, { id: 'RULE-B002', name: '改期与取消资源处理', owner: '许言', currentVersion: 'v1.0', versions: { 'v1.0': changeRule } }, { id: 'RULE-B003', name: '时段占用原子性', owner: '许言', currentVersion: 'v1.0', versions: { 'v1.0': invariant } }];
    m.stages = [
      { id: 'STG-B01', name: '选择与可用性', goal: '选择服务并判断候选时间是否可用', domainId: 'DOM-B01', input: '服务目录与资源日历', result: '可预约结论或更换时间提示', actorIds: ['ACTOR-B01', 'ACTOR-B02'], stepIds: [] },
      { id: 'STG-B02', name: '确认与占用', goal: '形成预约事实并可靠占用资源', domainId: 'DOM-B02', input: '可预约候选时段', result: '已确认预约与占用结果', actorIds: ['ACTOR-B01', 'ACTOR-B02', 'ACTOR-B04'], stepIds: [] },
      { id: 'STG-B03', name: '变更与释放', goal: '处理改期或取消并维持资源一致', domainId: 'DOM-B03', input: '已确认预约', result: '新预约或释放结果', actorIds: ['ACTOR-B01', 'ACTOR-B02'], stepIds: [] }
    ];
    m.stages[0].capabilityIds = ['CAP-B01', 'CAP-B02']; m.stages[1].capabilityIds = ['CAP-B03', 'CAP-B04']; m.stages[2].capabilityIds = ['CAP-B05', 'CAP-B06'];
    const specs = [
      ['选择服务', 'STG-B01', 'ACTOR-B01', '用户选择具体服务，系统加载该服务的时长、资源类型和容量要求。', ['服务目录可用'], ['服务 ID'], ['所选服务与容量需求'], []],
      ['查看可用时间', 'STG-B01', 'ACTOR-B02', '按服务时长读取资源日历，排除已经过去或暂停开放的时间。', ['服务处于可预约'], ['服务时长', '资源日历', '当前时间'], ['候选时段及剩余容量'], ['OBJ-B02']],
      ['判断资源可用性', 'STG-B01', 'ACTOR-B02', '同时判断服务剩余容量与目标时段冲突，任何一项不满足都允许用户重新选择。', ['候选时段已生成'], ['服务剩余容量', '目标时段状态'], ['可预约或不可用结论', '命中规则依据'], ['OBJ-B03'], ['RULE-B001']],
      ['确认预约', 'STG-B02', 'ACTOR-B01', '用户确认服务与时间后提交预约，服务端重新核验可用性而不是信任页面旧结果。', ['最近判定为可预约', '用户已确认'], ['服务 ID', '时段 ID', '占用数量'], ['待写入预约请求'], ['OBJ-B03'], ['RULE-B001']],
      ['占用资源时段', 'STG-B02', 'ACTOR-B02', '在同一原子操作中创建预约单并扣减时段容量，失败时不留下单边占用。', ['服务端复核仍可预约'], ['预约请求', '时段剩余容量'], ['已确认预约单', '已占用时段', '预约事件'], ['OBJ-B02', 'OBJ-B03'], ['RULE-B003']],
      ['接收预约结果', 'STG-B02', 'ACTOR-B04', '向用户展示预约编号和时间；通知失败不回滚已经确认的预约。', ['预约与占用已提交'], ['预约确认事件', '用户通知方式'], ['预约结果通知'], ['OBJ-B03']],
      ['申请改期或取消', 'STG-B03', 'ACTOR-B01', '用户选择改期或取消；改期必须先验证新时段，取消则无需新时段可用。', ['预约已确认且服务未完成'], ['变更方式', '目标新时段'], ['变更处理分支'], ['OBJ-B03'], ['RULE-B002']],
      ['重新分配或释放资源', 'STG-B03', 'ACTOR-B02', '改期成功时占用新时段并释放原时段，取消时释放原时段，新时段不可用时保留原预约。', ['变更分支已确定'], ['原时段', '目标新时段', '变更结论'], ['更新后的预约与资源占用'], ['OBJ-B02', 'OBJ-B03'], ['RULE-B002', 'RULE-B003']]
    ];
    specs.forEach((spec, i) => {
      const [name, stageId, actorId, purpose, pre, inputs, outputs, objectIds, ruleIds = []] = spec, id = `ACT-B${String(i + 1).padStart(4, '0')}`, stepId = `STEP-B${String(i + 1).padStart(3, '0')}`;
      const stage = m.stages.find(item => item.id === stageId); stage.stepIds.push(stepId);
      m.steps.push({ id: stepId, number: i + 1, stageId, actionId: id, name, actorId, kind: i === 2 || i === 6 ? 'decision' : i === 5 ? 'event' : 'action', result: outputs[0] });
      const changes = [];
      if (i === 2) changes.push(change('OBJ-B03', '待确认', '可确认或预约失败', '失败结论不占用资源'));
      if (i === 4) changes.push(change('OBJ-B03', '待确认', '已确认', '预约与资源写入同时成功'), change('OBJ-B02', '可用', '已占用', '剩余容量不得小于零'));
      if (i === 5) changes.push(change('OBJ-B03', '已确认未通知', '已确认且结果已展示', '通知失败不改变预约事实'));
      if (i === 7) changes.push(change('OBJ-B03', '已确认或改期中', '已确认新时段、已取消或保持原预约', '不可用新时段不得破坏原预约'), change('OBJ-B02', '原时段已占用', '新时段已占用或原时段已释放', '资源变化与预约结论一致'));
      m.actions.push({ id, name, version: 'v1.0', status: 'published', actorId, stageId, scenarioId: 'SCN-B001', stepId, domainId: stage.domainId, capabilityIds: clone(stage.capabilityIds), depth: 'detailed', purpose, pre, input: inputs, output: outputs, ruleIds, objectChanges: changes, exceptions: i === 4 || i === 7 ? ['BE-01'] : [], evidence: i === 4 ? ['FACT-B002'] : ['FACT-B001'], implementation: i === 4 ? impl('预约确认页 / 确认', 'POST /bookings', ['service_capacity', 'resource_slot'], ['booking（新增）', 'slot_reservation（新增）', 'outbox_event（新增）'], '数据库约束与容量复核同时通过', 'BookingConfirmed', '通知服务订阅预约事件', '容量不足返回 409，预约与占用均不写入；通知异步重试', '预约、占用与 outbox 在同一事务', 'BOOK-105-08 · 并发占用测试通过') : null });
    });
    m.exceptions = [{ id: 'BE-01', name: '并发占用导致容量不足', stepId: 'STEP-B005', trigger: '确认前时段可用，但提交时剩余容量已被其他预约占用。', handling: ['回滚预约与占用写入', '保留用户所选服务', '刷新可选时间'], recovery: '返回可用性判断，用户选择其他时段。', actorId: 'ACTOR-B02' }];
    m.scenarios = [{ id: 'SCN-B001', name: '用户预约一项服务', version: 'v1.0', status: 'published', goal: '根据服务容量与时段占用完成可靠预约，并支持后续改期和取消。', trigger: '用户需要在一个可服务时间使用指定服务。', participants: m.actors.map(actor => actor.id), result: '形成已确认预约及一致的资源占用，或明确失败且不留下占用。', stageIds: m.stages.map(stage => stage.id), exceptionIds: ['BE-01'], full: true, explore: { ruleIds: ['RULE-B001'] } }];
    const nodes = [{ id: 'BN-START', type: 'start', name: '开始选择', stageId: 'STG-B01' }];
    m.actions.forEach(action => nodes.push({ id: `BN-${action.id}`, actionId: action.id, stageId: action.stageId, type: action.id === 'ACT-B0003' ? 'decision' : action.id === 'ACT-B0007' ? 'decision' : action.id === 'ACT-B0006' ? 'event' : 'action', ruleId: action.id === 'ACT-B0003' ? 'RULE-B001' : action.id === 'ACT-B0007' ? 'RULE-B002' : undefined }));
    nodes.push({ id: 'BN-UNAVAILABLE', type: 'end', name: '更换时间或稍后再试', stageId: 'STG-B01' }, { id: 'BN-END', type: 'end', name: '预约结果完成', stageId: 'STG-B03' });
    const edges = []; let n = 1; const connect = (from, to, type = 'next', extra = {}) => edges.push({ id: `BE-${String(n++).padStart(3, '0')}`, from, to, type, ...extra });
    connect('BN-START', 'BN-ACT-B0001'); connect('BN-ACT-B0001', 'BN-ACT-B0002'); connect('BN-ACT-B0002', 'BN-ACT-B0003');
    connect('BN-ACT-B0003', 'BN-ACT-B0004', 'when', { when: { ruleId: 'RULE-B001', outcomeId: 'BOOKABLE' }, label: '容量充足且时段可用' });
    connect('BN-ACT-B0003', 'BN-UNAVAILABLE', 'when', { when: { ruleId: 'RULE-B001', outcomeId: 'UNAVAILABLE' }, label: '不可预约' });
    connect('BN-UNAVAILABLE', 'BN-ACT-B0002', 'return', { label: '重新选择' });
    for (let i = 3; i < 6; i++) connect(`BN-ACT-B${String(i + 1).padStart(4, '0')}`, `BN-ACT-B${String(i + 2).padStart(4, '0')}`);
    connect('BN-ACT-B0007', 'BN-ACT-B0008', 'when', { when: { ruleId: 'RULE-B002', outcomeId: 'RESCHEDULE' }, label: '改期成功' });
    connect('BN-ACT-B0007', 'BN-ACT-B0008', 'when', { when: { ruleId: 'RULE-B002', outcomeId: 'CANCEL_BOOKING' }, label: '取消并释放' });
    connect('BN-ACT-B0007', 'BN-END', 'when', { when: { ruleId: 'RULE-B002', outcomeId: 'KEEP_BOOKING' }, label: '保留原预约' });
    connect('BN-ACT-B0008', 'BN-END'); connect('BN-ACT-B0005', 'BN-ACT-B0002', 'error', { defaultCollapsed: true, label: '并发占用失败' });
    m.flows = [{ id: 'FLOW-B001', scenarioId: 'SCN-B001', nodes, edges }];
    m.surfaces = [
      { id: 'UI-B001', name: '服务与时间选择', domainId: 'DOM-B01', type: '普通页面', actorId: 'ACTOR-B01', sceneIds: ['SCN-B001'], operations: [{ name: '查询可用时间', actionId: 'ACT-B0002', states: ['可预约'] }], objectIds: ['OBJ-B01', 'OBJ-B02'], api: 'GET /availability' },
      { id: 'UI-B002', name: '预约确认页', domainId: 'DOM-B02', type: '普通页面', actorId: 'ACTOR-B01', sceneIds: ['SCN-B001'], operations: [{ name: '确认预约', actionId: 'ACT-B0005', states: ['待确认'] }], objectIds: ['OBJ-B02', 'OBJ-B03'], api: 'POST /bookings' },
      { id: 'UI-B003', name: '我的预约', domainId: 'DOM-B03', type: '普通页面', actorId: 'ACTOR-B01', sceneIds: ['SCN-B001'], operations: [{ name: '申请改期或取消', actionId: 'ACT-B0007', states: ['已确认'] }], objectIds: ['OBJ-B03'], api: 'POST /bookings/{id}/changes' }
    ];
    m.facts = [
      { id: 'FACT-B001', kind: 'specification', source: '预约服务规范 v1.0', conclusion: '容量或时间任一不满足时不可确认；预约变更换新时段失败时保留原预约。', status: '已批准', date: '2026-11-14', owner: '许言', targetId: 'RULE-B001@v1.0' },
      { id: 'FACT-B002', kind: 'implementation', source: 'BookingService · 并发测试 BOOK-105-08', conclusion: '预约、资源占用与 outbox 在同一事务，容量冲突返回 409。', status: '已核验', date: '2026-11-14', owner: '唐星', targetId: 'ACT-B0005' }
    ];
    m.scale = { actions: m.actions.length, surfaces: m.surfaces.length, note: '当前项目的动作、规则、对象和界面均来自预约业务模型。' };
    return finalize(m);
  }

  function finalize(m) {
    let relationNo = 1; const add = (from, type, to, kind = 'knowledge', extra = {}) => m.relations.push({ id: `REL-${m.meta.id}-${String(relationNo++).padStart(4, '0')}`, from, type, to, kind, ...extra });
    m.scenarios.forEach(scenario => scenario.stageIds.forEach(stageId => add(scenario.id, 'contains', stageId, 'structure')));
    m.stages.forEach(stage => stage.stepIds.forEach(stepId => add(stage.id, 'contains', stepId, 'structure')));
    m.actions.forEach(action => {
      add(action.id, 'belongsTo', action.scenarioId, 'structure');
      action.ruleVersions = {};
      (action.ruleIds || []).forEach(ruleId => { add(action.id, 'uses', ruleId); action.ruleVersions[ruleId] = action.version; });
      (action.objectChanges || []).forEach(objectChange => add(action.id, 'changes', objectChange.objectId, 'causal'));
      delete action.ruleIds;
    });
    m.surfaces.forEach(surface => surface.operations.forEach(operation => add(surface.id, 'triggers', operation.actionId)));
    m.facts.forEach(fact => { if (fact.targetId && !fact.targetId.includes('@v1.6')) add(fact.id, 'supports', fact.targetId); });
    m.domains.forEach(domain => domain.caps.forEach(capId => add(domain.id, 'contains', capId, 'structure')));
    return m;
  }

  function createEmptyProject(id, name, desc = '') {
    const m = base(id, name, desc || '从业务目标开始建立可探索的项目知识。');
    m.meta.created = '刚刚';
    m.scale.note = '新项目中的内容均由用户创建，首次发布会生成 v1.0。';
    return m;
  }

  function nextId(project, prefix) {
    project.meta.counters ||= {};
    let number = project.meta.counters[prefix] || 1, candidate;
    const used = new Set(E.validateProject ? (function () { return []; })() : []);
    const collections = ['domains', 'capabilities', 'actors', 'objects', 'rules', 'scenarios', 'stages', 'steps', 'actions', 'exceptions', 'surfaces', 'facts', 'changes', 'issues', 'deliveries'];
    do {
      const width = ['ACT', 'STEP'].includes(prefix) ? 5 : ['SCN'].includes(prefix) ? 5 : ['RULE'].includes(prefix) ? 4 : 3;
      candidate = `${prefix}-${String(number++).padStart(width, '0')}`;
    } while (collections.some(key => (project[key] || []).some(item => item.id === candidate)));
    project.meta.counters[prefix] = number;
    return candidate;
  }

  function firstPublish(project, approver = '业务负责人') {
    const errors = [];
    if (!project.domains.length) errors.push('至少建立一个业务领域');
    if (!project.scenarios.length) errors.push('至少建立一个业务场景');
    if (!project.actions.length) errors.push('至少建立一个业务动作');
    if (!project.rules.length) errors.push('至少建立一条业务规则');
    project.rules.forEach(rule => {
      const initialChange = project.changes.find(change => change.ruleId === rule.id && !change.baseVersion && change.draftRule);
      const versions = initialChange ? [initialChange.draftRule] : Object.values(rule.versions);
      versions.forEach(version => {
        const validation = E.validateRuleVersion(version);
        if (validation.errors.length && version.supportsEvaluation !== false) errors.push(...validation.errors);
        if (validation.uncovered.length) errors.push(`${rule.id} 存在 ${validation.uncovered.length} 个未覆盖输入组合`);
      });
    });
    if (errors.length) return { ok: false, errors };
    const version = 'v1.0', at = new Date().toISOString();
    project.changes.filter(change => !change.ruleId && change.baseVersion === 'draft' && change.draftDefinition).forEach(change => {
      const collection = { action: 'actions', scenario: 'scenarios', object: 'objects' }[change.objectType];
      const target = collection ? E.byId(project[collection], change.objectId) : null;
      if (target) Object.assign(target, clone(change.draftDefinition));
    });
    project.rules.forEach(rule => {
      const initialChange = project.changes.find(change => change.ruleId === rule.id && !change.baseVersion && change.draftRule);
      const draft = initialChange?.draftRule || rule.versions.draft || rule.versions[rule.currentVersion];
      if (!draft) return;
      delete rule.versions.draft;
      draft.version = version; draft.status = 'published'; draft.summary = E.summarizeRule(draft); draft.source = `${approver}首次批准`; draft.publishedAt = at;
      rule.versions[version] = draft; rule.currentVersion = version;
    });
    ['actions', 'scenarios', 'objects', 'domains'].forEach(key => project[key].forEach(item => { item.version = version; item.status = 'published'; }));
    project.actions.forEach(action => {
      action.ruleVersions = {};
      project.relations.filter(relation => relation.from === action.id && relation.type === 'uses').forEach(relation => { action.ruleVersions[relation.to] = version; });
    });
    project.meta.version = version; project.meta.status = 'published'; project.meta.publishedAt = at;
    return { ok: true, version };
  }

  function scaleIndex(project, type) {
    const fullCount = type === 'actions' ? project.actions.length : project.surfaces.length;
    const target = project.scale?.[type] || fullCount, count = Math.max(0, target - fullCount);
    if (!count) return [];
    const prefix = type === 'actions' ? 'ACT' : 'UI';
    return Array.from({ length: count }, (_, i) => ({
      id: `IDX-${prefix}-${String(i + 1).padStart(5, '0')}`, name: `规模测试${type === 'actions' ? '动作' : '界面'}索引 ${String(i + 1).padStart(4, '0')}`,
      indexOnly: true, depth: 'index', domainId: project.domains[i % Math.max(1, project.domains.length)]?.id,
      actorId: project.actors[i % Math.max(1, project.actors.length)]?.id, status: 'index'
    }));
  }

  return { createMatureProject, createBookingProject, createEmptyProject, firstPublish, nextId, scaleIndex, deepClone: clone };
});
