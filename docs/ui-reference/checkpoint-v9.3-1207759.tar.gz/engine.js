/* Business Atlas V3 — project-agnostic rule, relation, flow and version engine. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.AtlasEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const clone = value => value == null ? value : JSON.parse(JSON.stringify(value));
  const byId = (list, id) => (list || []).find(item => item.id === id);
  const optionLabel = (version, inputId, value) => {
    const input = (version.inputs || []).find(item => item.id === inputId);
    return input?.options?.find(option => option.value === value)?.label || value;
  };
  const outcomeFor = (version, id) => (version.outcomes || []).find(item => item.id === id);
  const matches = (when, values) => Object.entries(when || {}).every(([key, expected]) =>
    expected === 'any' || values[key] === expected
  );
  const matchingRows = (version, values) => [
    ...(version.exceptions || []).map(row => ({ ...row, exception: true })),
    ...(version.rows || []).map(row => ({ ...row, exception: false }))
  ].filter(row => matches(row.when, values)).sort((a, b) => (a.priority || 0) - (b.priority || 0));

  function evaluateRule(version, values = {}) {
    if (!version) return { outcome: null, code: 'VERSION_UNAVAILABLE', explanation: '指定规则版本不可用。', matched: [] };
    if (version.supportsEvaluation === false) {
      return { outcome: null, code: 'MANUAL_RULE', explanation: '此约束不支持自动试算，需要按说明人工核验。', matched: [] };
    }
    const matched = matchingRows(version, values);
    const row = matched[0];
    if (!row) return { outcome: null, code: 'NO_MATCH', explanation: '当前结构化条件没有覆盖此输入组合。', matched };
    const outcome = outcomeFor(version, row.outcomeId);
    if (!outcome) return { outcome: null, code: 'OUTCOME_MISSING', explanation: `决策行引用了不存在的结果 ${row.outcomeId}。`, matched, row };
    const samePriority = matched.filter(item => (item.priority || 0) === (row.priority || 0));
    const conflict = samePriority.some(item => item.outcomeId !== row.outcomeId);
    return {
      outcome: clone(outcome), row: clone(row), matched, code: conflict ? 'CONFLICT' : outcome.id,
      actors: clone(outcome.actorIds || []),
      explanation: `${row.exception ? '例外' : '决策行'} ${row.id || ''}（优先级 ${row.priority}）命中：${describeWhen(version, row.when)}，结果为“${outcome.label}”。${conflict ? ' 同优先级存在冲突结果。' : ''}`
    };
  }

  function describeWhen(version, when = {}) {
    const entries = Object.entries(when).filter(([, value]) => value !== 'any');
    if (!entries.length) return '其他已覆盖条件';
    return entries.map(([key, value]) => {
      const input = (version.inputs || []).find(item => item.id === key);
      return `${input?.label || key} = ${optionLabel(version, key, value)}`;
    }).join('，');
  }

  function summarizeRule(version) {
    if (!version) return '';
    if (version.supportsEvaluation === false) return version.constraint || version.summary || '此规则为人工核验约束，不支持自动试算。';
    const exceptions = (version.exceptions || []).slice().sort((a, b) => a.priority - b.priority).map(row =>
      `${describeWhen(version, row.when)}时，${outcomeFor(version, row.outcomeId)?.label || row.outcomeId}（例外优先）`
    );
    const rows = (version.rows || []).slice().sort((a, b) => a.priority - b.priority).map(row =>
      `${describeWhen(version, row.when)}时，${outcomeFor(version, row.outcomeId)?.label || row.outcomeId}`
    );
    return [...exceptions, ...rows].join('；') + ([...exceptions, ...rows].length ? '。' : '尚未定义可试算决策行。');
  }

  function valueCombinations(inputs = []) {
    const finite = inputs.filter(input => input.options?.length && input.options.length <= 8);
    if (!finite.length || finite.length > 8) return [];
    return finite.reduce((combinations, input) => combinations.flatMap(values =>
      input.options.map(option => ({ ...values, [input.id]: option.value }))
    ), [{}]);
  }

  function validateRuleVersion(version) {
    const errors = [], warnings = [];
    if (!version) return { errors: ['规则版本不存在'], warnings, uncovered: [] };
    const outcomeIds = new Set((version.outcomes || []).map(outcome => outcome.id));
    const rows = [...(version.exceptions || []), ...(version.rows || [])];
    const priorities = new Set();
    rows.forEach(row => {
      if (priorities.has(row.priority)) errors.push(`优先级 ${row.priority} 被多个决策行使用，命中顺序不明确`);
      priorities.add(row.priority);
      if (!outcomeIds.has(row.outcomeId)) errors.push(`${row.id || '决策行'} 引用了不存在的结果 ${row.outcomeId}`);
      Object.keys(row.when || {}).forEach(inputId => {
        if (!(version.inputs || []).some(input => input.id === inputId)) errors.push(`${row.id || '决策行'} 引用了未定义条件 ${inputId}`);
      });
    });
    const combinations = valueCombinations(version.inputs);
    const uncovered = [];
    combinations.forEach(values => {
      const result = evaluateRule(version, values);
      if (result.code === 'NO_MATCH') uncovered.push(values);
      if (result.code === 'CONFLICT') errors.push(`输入 ${JSON.stringify(values)} 命中互相冲突的同优先级结果`);
      if (result.code === 'OUTCOME_MISSING') errors.push(result.explanation);
    });
    if (version.supportsEvaluation !== false && !rows.length) errors.push('可试算规则至少需要一个决策行或例外');
    if (version.summary && version.summary !== summarizeRule(version)) errors.push('自然语言摘要与结构化决策不一致；请从结构化内容重新生成摘要');
    const uniqueErrors = [...new Set(errors)];
    if (uncovered.length) warnings.push(`还有 ${uncovered.length} 个有限输入组合未覆盖`);
    return { errors: uniqueErrors, warnings, uncovered };
  }

  function compareRuleVersions(before, after, samples) {
    const combinations = samples?.length ? samples : valueCombinations(after?.inputs || before?.inputs || []);
    return combinations.map(values => {
      const oldResult = evaluateRule(before, values), newResult = evaluateRule(after, values);
      return {
        values: clone(values), before: oldResult.outcome?.label || oldResult.code,
        after: newResult.outcome?.label || newResult.code,
        changed: (oldResult.outcome?.id || oldResult.code) !== (newResult.outcome?.id || newResult.code)
      };
    });
  }

  function nextVersion(current) {
    if (!current || current === 'draft') return 'v1.0';
    const match = /^v(\d+)\.(\d+)$/.exec(current);
    if (!match) return 'v1.0';
    return `v${match[1]}.${Number(match[2]) + 1}`;
  }

  function relationIndex(project) {
    const relations = project.relations || [];
    return {
      all: relations,
      from: (id, type) => relations.filter(relation => relation.from === id && (!type || relation.type === type)),
      to: (id, type) => relations.filter(relation.relationTo !== undefined ? false : relation.to === id && (!type || relation.type === type)),
      targets: (id, type) => relations.filter(relation => relation.from === id && (!type || relation.type === type)).map(relation => relation.to),
      sources: (id, type) => relations.filter(relation => relation.to === id && (!type || relation.type === type)).map(relation => relation.from)
    };
  }

  function ruleUsage(project, ruleId) {
    const index = relationIndex(project);
    const actionIds = [...new Set(index.sources(ruleId, 'uses'))];
    const actions = actionIds.map(id => byId(project.actions, id)).filter(Boolean);
    const scenarioIds = [...new Set(actions.map(action => action.scenarioId).filter(Boolean))];
    const scenarios = scenarioIds.map(id => byId(project.scenarios, id)).filter(Boolean);
    const surfaceIds = [...new Set(actions.flatMap(action => index.sources(action.id, 'triggers')))];
    const surfaces = surfaceIds.map(id => byId(project.surfaces, id)).filter(Boolean);
    const acceptance = (project.deliveries || []).flatMap(delivery => (delivery.acceptance || [])
      .filter(item => item.ruleId === ruleId).map(item => ({ ...item, deliveryId: delivery.id })));
    const evidenceIds = index.sources(ruleId, 'supports');
    const evidence = evidenceIds.map(id => byId(project.facts, id)).filter(Boolean);
    return { actions, scenarios, surfaces, acceptance, evidence, actionIds, scenarioIds, surfaceIds };
  }

  function actionRules(project, actionId, version) {
    return relationIndex(project).targets(actionId, 'uses').map(id => byId(project.rules, id)).filter(Boolean).map(rule => ({
      rule, version: version ? rule.versions?.[version] : rule.versions?.[rule.currentVersion] || rule.versions?.draft
    }));
  }

  function defaultValues(version) {
    return Object.fromEntries((version?.inputs || []).map(input => [input.id, input.default ?? input.options?.[0]?.value ?? '']));
  }

  function flowFor(project, scenarioId) {
    return (project.flows || []).find(flow => flow.scenarioId === scenarioId) || { nodes: [], edges: [] };
  }

  function evaluateFlow(project, scenarioId, values = {}) {
    const flow = flowFor(project, scenarioId), decisions = {}, explanations = [];
    (flow.nodes || []).filter(node => node.ruleId).forEach(node => {
      const rule = byId(project.rules, node.ruleId);
      const version = rule?.versions?.[rule.currentVersion];
      if (!version) return;
      const result = evaluateRule(version, { ...defaultValues(version), ...values });
      result.ruleId = rule.id; result.ruleVersion = version.version;
      decisions[node.id] = result;
      explanations.push({ nodeId: node.id, ruleId: rule.id, version: version.version, ...result });
    });
    const nodeIds = new Set(), edgeIds = new Set(), queue = [];
    const starts = flow.nodes.filter(node => node.type === 'start');
    starts.forEach(node => queue.push(node.id));
    if (!starts.length && flow.nodes[0]) queue.push(flow.nodes[0].id);
    const visits = new Set();
    while (queue.length && visits.size < flow.edges.length + flow.nodes.length + 10) {
      const nodeId = queue.shift();
      if (visits.has(`${nodeId}:${queue.length}`) && visits.has(nodeId)) continue;
      visits.add(nodeId); nodeIds.add(nodeId);
      const outgoing = flow.edges.filter(edge => edge.from === nodeId).filter(edge => {
        if (['error', 'return', 'terminate'].includes(edge.type) && edge.defaultCollapsed) return false;
        if (!edge.when) return true;
        const result = decisions[edge.from] || Object.values(decisions).find(decision => decision.ruleId === edge.when.ruleId);
        return result?.outcome?.id === edge.when.outcomeId;
      });
      outgoing.forEach(edge => {
        if (edgeIds.has(edge.id)) return;
        edgeIds.add(edge.id);
        if (!visits.has(edge.to)) queue.push(edge.to);
      });
    }
    const actionIds = flow.nodes.filter(node => nodeIds.has(node.id) && node.actionId).map(node => node.actionId);
    const actions = actionIds.map(id => byId(project.actions, id)).filter(Boolean);
    return {
      nodeIds, edgeIds, decisions, explanations, actions,
      actorIds: [...new Set(explanations.flatMap(result => result.outcome?.actorIds || []))],
      objectChanges: actions.flatMap(action => (action.objectChanges || []).map(change => ({ ...change, actionId: action.id })))
    };
  }

  function layoutFlow(flow, selectedStageId, includeExceptions = false) {
    const local = new Set(flow.nodes.filter(node => !selectedStageId || node.stageId === selectedStageId).map(node => node.id));
    const neighbor = new Set(local), connectionEdges = flow.edges.filter(edge => includeExceptions || !edge.defaultCollapsed);
    let frontier = new Set(local);
    for (let depth = 0; depth < 2; depth++) {
      const nextFrontier = new Set();
      connectionEdges.forEach(edge => {
        if (frontier.has(edge.from) || frontier.has(edge.to)) {
          [edge.from, edge.to].forEach(id => { if (!neighbor.has(id)) nextFrontier.add(id); neighbor.add(id); });
        }
      });
      frontier = nextFrontier;
    }
    let nodes = flow.nodes.filter(node => neighbor.has(node.id));
    if (!includeExceptions) {
      const exceptionIds = new Set(flow.edges.filter(edge => edge.defaultCollapsed).map(edge => edge.to));
      const normalIncoming = new Set(flow.edges.filter(edge => !edge.defaultCollapsed).map(edge => edge.to));
      nodes = nodes.filter(node => !exceptionIds.has(node.id) || normalIncoming.has(node.id));
    }
    const visible = new Set(nodes.map(node => node.id));
    const edges = flow.edges.filter(edge => visible.has(edge.from) && visible.has(edge.to));
    const ranks = Object.fromEntries(nodes.map(node => [node.id, 0]));
    for (let pass = 0; pass < nodes.length; pass++) {
      let changed = false;
      edges.filter(edge => !['return', 'error', 'terminate'].includes(edge.type)).forEach(edge => {
        const rank = Math.min(nodes.length, ranks[edge.from] + 1);
        if (rank > ranks[edge.to]) { ranks[edge.to] = rank; changed = true; }
      });
      if (!changed) break;
    }
    const columns = [];
    nodes.forEach(node => { const rank = ranks[node.id] || 0; (columns[rank] ||= []).push(node); });
    const width = 190, gapX = 86, gapY = 42, height = 112;
    const positions = {};
    columns.forEach((column, x) => column.forEach((node, y) => {
      positions[node.id] = { x: x * (width + gapX) + 18, y: y * (height + gapY) + 20, width, height, rank: x };
    }));
    return {
      nodes: nodes.map(node => ({ ...node, ...positions[node.id] })), edges, positions,
      width: Math.max(500, columns.length * (width + gapX) + 30),
      height: Math.max(300, Math.max(...columns.map(column => column.length), 1) * (height + gapY) + 40)
    };
  }

  function allEntities(project) {
    const collections = ['domains', 'capabilities', 'actors', 'objects', 'rules', 'scenarios', 'stages', 'steps', 'actions', 'exceptions', 'surfaces', 'facts', 'changes', 'issues', 'deliveries', 'knowledge', 'workflowDefinitions', 'workflowInstances'];
    const entities = collections.flatMap(key => project[key] || []);
    (project.flows || []).forEach(flow => entities.push(...flow.nodes, ...flow.edges));
    return entities;
  }

  function validateProject(project) {
    const errors = [], warnings = [];
    const entities = allEntities(project), ids = new Set();
    entities.forEach(entity => {
      if (!entity.id) return;
      if (ids.has(entity.id)) errors.push(`重复 ID：${entity.id}`);
      ids.add(entity.id);
    });
    const exists = id => ids.has(id) || id?.includes('@');
    (project.relations || []).forEach(relation => {
      if (!exists(relation.from)) errors.push(`关系 ${relation.id} 的起点不存在：${relation.from}`);
      if (!exists(relation.to.split?.('@')[0] || relation.to)) errors.push(`关系 ${relation.id} 的终点不存在：${relation.to}`);
    });
    (project.scenarios || []).forEach(scenario => {
      scenario.stageIds.forEach(id => { if (!byId(project.stages, id)) errors.push(`${scenario.id} 引用了无效阶段 ${id}`); });
      const flow = flowFor(project, scenario.id);
      flow.nodes.forEach(node => {
        if (node.actionId && !byId(project.actions, node.actionId)) errors.push(`流程节点 ${node.id} 引用了无效动作 ${node.actionId}`);
        if (node.ruleId && !byId(project.rules, node.ruleId)) errors.push(`流程节点 ${node.id} 引用了无效规则 ${node.ruleId}`);
      });
      flow.edges.forEach(edge => {
        if (!flow.nodes.some(node => node.id === edge.from) || !flow.nodes.some(node => node.id === edge.to)) errors.push(`流程边 ${edge.id} 的节点引用无效`);
      });
    });
    (project.stages || []).forEach(stage => stage.stepIds.forEach(stepId => {
      const step = byId(project.steps, stepId);
      if (!step) errors.push(`${stage.id} 引用了无效步骤 ${stepId}`);
      else if (!byId(project.actions, step.actionId)) errors.push(`${step.id} 引用了无效动作 ${step.actionId}`);
    }));
    (project.rules || []).forEach(rule => Object.values(rule.versions || {}).forEach(version => {
      const validation = validateRuleVersion(version);
      if (version.status === 'published') validation.errors.forEach(error => errors.push(`${rule.id}@${version.version}：${error}`));
      validation.warnings.forEach(warning => warnings.push(`${rule.id}@${version.version}：${warning}`));
    }));
    (project.changes || []).forEach(change => {
      if (change.ruleId) {
        const rule = byId(project.rules, change.ruleId);
        if (!rule) errors.push(`${change.id} 引用了无效规则 ${change.ruleId}`);
        else if (change.baseVersion && !rule.versions[change.baseVersion]) errors.push(`${change.id} 的基线版本不可用`);
      } else {
        const collection = { action: 'actions', scenario: 'scenarios', object: 'objects' }[change.objectType];
        const target = collection ? byId(project[collection], change.objectId) : null;
        if (!target) errors.push(`${change.id} 引用了无效业务对象 ${change.objectType}:${change.objectId}`);
        else if (change.baseVersion && target.version !== change.baseVersion && !project.archives?.[`${change.objectType}:${change.objectId}@${change.baseVersion}`]) errors.push(`${change.id} 的基线版本不可用`);
      }
    });
    (project.deliveries || []).forEach(delivery => {
      const rule = byId(project.rules, delivery.ruleId);
      if (delivery.packageVersion) {
        if (delivery.ruleId && (!rule?.versions?.[delivery.ruleVersion] || !['published', 'historical'].includes(rule.versions[delivery.ruleVersion].status))) errors.push(`${delivery.id} 交接包未引用已批准规则版本`);
        if (!delivery.snapshot) errors.push(`${delivery.id} 交接包缺少不可变快照`);
      }
      (delivery.acceptance || []).forEach(acceptance => {
        if (acceptance.status === 'active' && acceptance.ruleVersion !== rule?.currentVersion) warnings.push(`${acceptance.id} 需要按当前规则重新核验`);
      });
    });
    return { errors: [...new Set(errors)], warnings: [...new Set(warnings)], ok: !errors.length };
  }

  function publishRuleChange(project, changeId, approver = '业务负责人') {
    const change = byId(project.changes, changeId);
    if (!change) return { ok: false, errors: ['变更单不存在'] };
    if (change.status !== 'pending') return { ok: false, errors: ['变更必须先提交审批'] };
    const rule = byId(project.rules, change.ruleId);
    if (!rule || !change.draftRule) return { ok: false, errors: ['变更对象或草稿不存在'] };
    if (change.baseVersion !== rule.currentVersion) return { ok: false, errors: [`基线已变化：变更基于 ${change.baseVersion}，当前为 ${rule.currentVersion}，请重新基于最新版本`] };
    if (Object.values(change.checks || {}).some(value => !value)) return { ok: false, errors: ['影响检查尚未全部确认'] };
    const openIssues = (project.issues || []).filter(issue => issue.changeId === change.id && !['resolved', 'cancelled'].includes(issue.status));
    if (openIssues.some(issue => !issue.decision)) return { ok: false, errors: ['仍有未形成业务结论的核验问题'] };
    const validation = validateRuleVersion(change.draftRule);
    if (openIssues.some(issue => !['confirming', 'resolved'].includes(issue.status))) return { ok: false, errors: ['关联问题尚未完成业务确认状态'] };
    if (validation.errors.length || validation.uncovered.length) return { ok: false, errors: [...validation.errors, ...(validation.uncovered.length ? [`存在 ${validation.uncovered.length} 个未覆盖输入组合`] : [])] };
    const previous = rule.versions[rule.currentVersion];
    const differences = compareRuleVersions(previous, change.draftRule);
    const published = clone(change.draftRule);
    published.version = change.targetVersion; published.status = 'published';
    published.summary = summarizeRule(published); published.source = `${change.id} · ${approver}批准`;
    published.publishedAt = new Date().toISOString();
    if (previous) previous.status = 'historical';
    rule.versions[change.targetVersion] = published; rule.currentVersion = change.targetVersion;
    const factId = `FACT-${change.id}-${rule.id}`;
    const approvedFact = { id: factId, kind: 'specification', source: `已批准规范 ${rule.id}@${change.targetVersion}`, conclusion: published.summary, status: '已批准', date: published.publishedAt.slice(0, 10), owner: approver, targetId: `${rule.id}@${change.targetVersion}` };
    if (!byId(project.facts, factId)) {
      project.facts.push(approvedFact);
      project.relations.push({ id: `REL-${change.id}-${rule.id}`, from: factId, type: 'supports', to: approvedFact.targetId, kind: 'knowledge' });
    }
    relationIndex(project).sources(rule.id, 'uses').forEach(actionId => {
      const action = byId(project.actions, actionId); if (!action) return;
      /* A referenced rule revision does not revise the action or its scenario.
         Keep their content versions immutable and mark only the semantic reference for review. */
      action.referenceReviews ||= {};
      action.referenceReviews[rule.id] = { from: change.baseVersion, to: change.targetVersion, status: 'requires-review', changedAt: published.publishedAt };
    });
    change.status = 'approved'; change.publishedVersion = change.targetVersion;
    change.history ||= []; change.history.push({ at: new Date().toISOString(), by: approver, text: `批准并发布 ${change.targetVersion}` });
    (project.deliveries || []).forEach(delivery => (delivery.acceptance || []).forEach(acceptance => {
      if (acceptance.ruleId !== rule.id || acceptance.ruleVersion !== change.baseVersion) return;
      const changed = differences.some(diff => diff.changed && Object.entries(diff.values).every(([key, value]) => acceptance.sample?.[key] === undefined || acceptance.sample[key] === value));
      acceptance.beforeOutcomeId = acceptance.expectedOutcomeId;
      acceptance.afterOutcomeId = evaluateRule(published, acceptance.sample || {}).outcome?.id || null;
      acceptance.behaviorChanged = changed;
      acceptance.status = 'stale'; acceptance.checked = false; acceptance.requiresReview = true;
    }));
    openIssues.filter(issue => issue.status === 'confirming').forEach(issue => { issue.status = 'resolved'; issue.decidedVersion = change.targetVersion; });
    project.meta.version = change.targetVersion;
    return { ok: true, version: published, differences };
  }

  function publishObjectChange(project, changeId, approver = '业务负责人') {
    const change = byId(project.changes, changeId);
    if (!change) return { ok: false, errors: ['变更单不存在'] };
    if (change.status !== 'pending') return { ok: false, errors: ['变更必须先提交审批'] };
    const collection = { action: 'actions', scenario: 'scenarios', object: 'objects' }[change.objectType];
    const target = collection ? byId(project[collection], change.objectId) : null;
    if (!target || !change.draftDefinition) return { ok: false, errors: ['变更对象或独立草稿不存在'] };
    if (target.version !== change.baseVersion) return { ok: false, errors: [`基线已变化：当前为 ${target.version}，请重新基于最新版本`] };
    if (Object.values(change.checks || {}).some(value => !value)) return { ok: false, errors: ['影响检查尚未全部确认'] };
    const openIssues = (project.issues || []).filter(issue => issue.changeId === change.id && !['resolved', 'cancelled'].includes(issue.status));
    if (openIssues.some(issue => !issue.decision || !['confirming', 'resolved'].includes(issue.status))) return { ok: false, errors: ['关联问题尚未完成业务确认'] };
    project.archives ||= {};
    project.archives[`${change.objectType}:${target.id}@${target.version}`] ||= clone(target);
    const published = clone(change.draftDefinition);
    published.id = target.id; published.version = change.targetVersion; published.status = 'published'; published.publishedAt = new Date().toISOString();
    Object.keys(target).forEach(key => { if (!(key in published)) delete target[key]; });
    Object.assign(target, published);
    change.status = 'approved'; change.publishedVersion = change.targetVersion; change.history ||= [];
    change.history.push({ at: new Date().toISOString(), by: approver, text: `批准并发布 ${change.targetVersion}` });
    openIssues.filter(issue => issue.status === 'confirming').forEach(issue => { issue.status = 'resolved'; issue.decidedVersion = change.targetVersion; });
    project.meta.version = change.targetVersion;
    return { ok: true, version: published };
  }

  return {
    clone, byId, evaluateRule, summarizeRule, describeWhen, validateRuleVersion, compareRuleVersions,
    valueCombinations, defaultValues, nextVersion, relationIndex, ruleUsage, actionRules,
    flowFor, evaluateFlow, layoutFlow, validateProject, publishRuleChange, publishObjectChange
  };
});
