/* Business Atlas V4 — project enrichment, typed knowledge and executable demonstration projects. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const model = commonjs ? require('./model.js') : root.AtlasModel;
  const engine = commonjs ? require('./engine.js') : root.AtlasEngine;
  const core = commonjs ? require('./v4-core.js') : root.AtlasCore;
  const api = factory(model, engine, core);
  if (commonjs) module.exports = api;
  root.AtlasV4Model = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (M, E, C) {
  'use strict';

  const clone = E.clone;
  const RELATION_ID_PREFIX = 'REL-V4-';

  function defaultProfile(m) {
    const profiles = {
      'PRJ-00001': {
        positioning: '面向跨部门业务申请的可追溯审批与修订知识底座。',
        audience: '申请人、审批与合规角色、产品及交付人员',
        value: '把重审范围、并发保护和审批证据连接到具体动作与系统实现。',
        inScope: ['申请修订', '重审判定', '预算校验', '决策汇总', '版本生效'],
        outScope: ['财务总账记账', '合同履约执行', '组织人事管理'],
        background: '既有申请已投入运行，后续修订不能覆盖原审批事实，也不能扩大不必要的人工审批。',
        stage: '已发布 v2.4，正在评估下一版规则变更。',
        stakeholders: ['业务负责人陈屿', '产品负责人林岚', '交付工程师周宇', '合规负责人'],
        mainlines: ['提出修订并锁定基线', '比较变化并计算重审范围', '并行审批与汇总', '发布新版本并归档'],
        technology: '申请服务、修订服务、预算服务与 outbox 事件协同；AI 辅助交付必须保留人工审查。',
        conventions: ['历史审批不可覆盖', '服务端重新执行规则', '所有发布绑定固定规则版本'],
        known: ['三个关键字段的重审规则', '审批汇总条件', '版本与事件同事务写入'],
        unknown: ['成本中心变化的下一版人工审批范围'],
        conflicts: ['历史 PRD 仅按金额判断，与当前 v2.4 规范不完全一致']
      },
      'PRJ-00002': {
        positioning: '以真实资源容量约束预约、改期和取消的服务平台。',
        audience: '预约用户、服务运营及平台维护人员',
        value: '避免超卖和单边占用，让用户获得明确的预约结果。',
        inScope: ['服务查询', '可用性计算', '预约确认', '改期取消', '资源释放'],
        outScope: ['服务履约现场管理', '支付清结算', '资源采购'],
        background: '预约页面展示的可用结果可能过期，确认时必须由服务端再次核验。',
        stage: '传统开发流程已发布 v1.0。',
        stakeholders: ['业务负责人许言', '工程师唐星', '服务资源运营人员'],
        mainlines: ['选择服务与时间', '确认预约并原子占用', '接收结果', '改期或取消'],
        technology: '预约服务、资源日历、事务写入与异步通知；采用常规需求、设计、编码、验证和发布流程。',
        conventions: ['预约与占用原子提交', '通知失败不回滚预约', '改期失败保留原预约'],
        known: ['容量与时段判定', '改期取消分支', '并发冲突返回 409'],
        unknown: ['高峰期资源日历的扩容阈值'],
        conflicts: []
      },
      'PRJ-00003': {
        positioning: '面向离散制造现场的质量异常隔离、处置和批次放行模型。',
        audience: '现场质检、生产质量、设备及制造系统人员',
        value: '让缺陷判断、返工回边、报废终止和放行证据保持一致。',
        inScope: ['生产批次质量异常', '批次隔离', '原因调查', '返工与报废', '复检放行'],
        outScope: ['供应商采购结算', '产品售后维修', '完整排产优化'],
        background: '现场异常需要快速止损，但任何放行都必须有复检依据和明确规则版本。',
        stage: '质量异常处置 v1.0 已发布，覆盖一条示范生产线。',
        stakeholders: ['质量负责人赵衡', '生产负责人孙岚', '设备负责人吴工'],
        mainlines: ['发现并隔离异常', '调查原因并确定处置', '返工或报废', '复检后放行或终止'],
        technology: 'MES 记录批次状态，QMS 留存缺陷与复检证据，设备采集服务提供调查上下文。',
        conventions: ['隔离批次不得继续流转', '严重缺陷直接终止放行', '返工后必须重新复检'],
        known: ['缺陷等级与返工可行性的有限决策矩阵', '批次状态变化', '复检失败回边'],
        unknown: ['其他工厂产线的差异化处置时限'],
        conflicts: []
      },
      'PRJ-00004': {
        positioning: '面向行政许可办理的材料受理、法规审查和跨部门协同知识模型。',
        audience: '申请主体、受理审查、会签及安全评估人员',
        value: '明确办理终点，同时允许补正和多部门核查按实际案件动态展开。',
        inScope: ['申请受理', '材料补正', '法规审查', '业务会签', '安全评估', '实施与验收'],
        outScope: ['行政处罚裁决', '司法诉讼', '部门内部人事审批'],
        background: '固定主线提供可理解的办理预期，案件模型承载不固定顺序的动态任务。',
        stage: '示范事项 v1.0 已发布，法规引用和案件证据持续维护。',
        stakeholders: ['事项负责人周宁', '法规处审查员', '业务会签部门', '安全评估机构'],
        mainlines: ['核验申请主体与材料', '开展法规和协同审查', '形成办理决定', '实施并验收'],
        technology: '政务服务事项库、案件任务引擎、电子材料库和法规资源索引。',
        conventions: ['同名术语按 context 区分', '补正不预设核查顺序', '办理结论必须引用证据'],
        known: ['受理条件', '必需材料', '完成条件和动态任务集合'],
        unknown: ['特殊行业事项的附加核查清单'],
        conflicts: ['“申请”在主体资格与内部文书两个语境中的含义不同，禁止直接合并术语']
      }
    };
    return profiles[m.meta.id] || {
      positioning: m.meta.goal || '从业务目标开始建立项目知识。',
      audience: '项目参与者', value: '逐步形成可追踪、可验证的业务与系统知识。',
      inScope: [], outScope: [], background: m.meta.desc || '', stage: '草稿',
      stakeholders: [], mainlines: [], technology: '尚未记录技术概况。',
      conventions: [], known: [], unknown: ['项目范围与知识仍待补充'], conflicts: []
    };
  }

  function defaultReadingPaths(m) {
    const pathEntities = {
      'PRJ-00001': {
        newcomer: [['先理解修订业务主线', 'SCN-00126'], ['认识独立修订对象', 'OBJ-0012'], ['阅读重审适用范围', 'RULE-0017']],
        developer: [['追踪重审任务创建', 'ACT-00424'], ['核对并发保护规则', 'RULE-0021'], ['查看重审操作入口', 'UI-00079']]
      },
      'PRJ-00002': {
        newcomer: [['理解预约完整场景', 'SCN-B001'], ['认识预约单生命周期', 'OBJ-B03'], ['阅读资源可预约判定', 'RULE-B001']],
        developer: [['检查原子确认动作', 'ACT-B0005'], ['理解资源时段状态', 'OBJ-B02'], ['查看预约确认入口', 'UI-B002']]
      },
      'PRJ-00003': {
        newcomer: [['理解质量异常七阶段', 'SCN-M001'], ['认识生产批次状态', 'OBJ-M01'], ['阅读质量处置判断', 'RULE-M001']],
        developer: [['追踪处置判断动作', 'ACT-M005'], ['理解缺陷业务对象', 'OBJ-M02'], ['查看批次质量处置台', 'UI-M002']]
      },
      'PRJ-00004': {
        newcomer: [['理解行政许可办理主线', 'SCN-G001'], ['认识许可案件状态', 'OBJ-G01'], ['阅读受理条件与材料', 'RULE-G001']],
        developer: [['追踪受理核验动作', 'ACT-G002'], ['理解审查意见对象', 'OBJ-G03'], ['查看协同审查工作台', 'UI-G002']]
      }
    }[m.meta.id];
    if (!pathEntities) return [];
    const path = (role, name, steps) => ({
      id: `PATH-${m.meta.id}-${role.toUpperCase()}`, role,
      steps: steps.map(([label, entityId]) => ({ label, entityId })), name
    });
    return [
      path('newcomer', '新成员先理解业务主线', pathEntities.newcomer),
      path('developer', '开发者沿规则与实现追踪', pathEntities.developer)
    ];
  }

  function ensureV4(m) {
    m.knowledge ||= [];
    m.resources ||= [];
    m.workflowDefinitions ||= [];
    m.workflowInstances ||= [];
    m.relations ||= [];
    m.facts ||= [];
    m.schemaRegistry ||= {};
    return m;
  }

  function enrichProject(m) {
    ensureV4(m);
    m.schemaRegistry = { ...clone(C.coreSchemas() || {}), ...m.schemaRegistry };
    m.profile = { ...defaultProfile(m), ...(m.profile || {}) };
    const workspace = m.workspace || {};
    m.workspace = {
      homeSections: ['intro', 'business', 'systems', 'assets', 'concerns'],
      readingPaths: defaultReadingPaths(m),
      layout: 'balanced',
      activeRole: 'newbie',
      ...workspace
    };
    m.workspace.homeSections = ['intro', 'business', 'systems', 'assets', 'concerns'];
    if (!m.workspace.readingPaths?.length) m.workspace.readingPaths = defaultReadingPaths(m);
    const code = { 'PRJ-00001': 'A', 'PRJ-00002': 'B', 'PRJ-00003': 'M', 'PRJ-00004': 'G' }[m.meta.id] || m.meta.id;
    m.versionLayers = {
      baseline: `BL-${code}-2026-11-14`,
      release: m.meta.version,
      config: `CFG-${code}-BASELINE`,
      deployments: [{
        id: `DEP-${code}-PROD`, environment: 'production',
        release: m.meta.version, config: `CFG-${code}-BASELINE`, baseline: `BL-${code}-2026-11-14`
      }],
      ...(m.versionLayers || {})
    };
    m.governancePolicy = {
      defaultScope: 'project', publishRequires: 'owner', editRoles: ['admin'],
      approveRoles: ['owner'], inheritance: '项目策略可被实体显式权限覆盖',
      relationTrust: ['confirmed', 'inferred'], requireEvidenceForPublish: true,
      ...(m.governancePolicy || {})
    };
    m.sensitivity = {
      default: 'internal', levels: ['public', 'internal', 'confidential', 'restricted'],
      permissionFields: ['read', 'edit', 'approve'], inheritFrom: 'project',
      ...(m.sensitivity || {})
    };
    if (m.scale) m.scale.note ||= '仅统计已建立的业务知识，不以外推数量代替实际内容。';
    return m;
  }

  /* Engine validates knowledge directly; legacy facts remain genuine evidence only. */
  function indexKnowledgeForLegacyValidation(m, entity) { /* intentionally no-op */ }

  function addKnowledge(m, typeId, data = {}) {
    ensureV4(m);
    if (!typeId) throw new Error('knowledge.typeId 不能为空');
    if (!data.id) throw new Error(`${typeId} 知识必须提供稳定 ID`);
    if (m.knowledge.some(item => item.id === data.id)) throw new Error(`重复知识 ID：${data.id}`);
    const entity = C.entity(typeId, {
      revision: 'r1', status: 'published', scope: 'project', sourceIds: [],
      sensitivity: 'internal',
      permissions: { read: ['*'], edit: ['admin'], approve: ['owner'] },
      desc: '', props: {}, ...data
    });
    entity.typeId ||= typeId;
    entity.revision ||= 'r1';
    entity.status ||= 'published';
    entity.scope ||= 'project';
    entity.sourceIds ||= [];
    entity.sensitivity ||= 'internal';
    entity.permissions = {
      read: ['*'], edit: ['admin'], approve: ['owner'], ...(entity.permissions || {})
    };
    entity.props ||= {};
    m.knowledge.push(entity);
    indexKnowledgeForLegacyValidation(m, entity);
    return entity;
  }

  function addRelation(m, from, type, to, extra = {}) {
    ensureV4(m);
    if (!from || !type || !to) throw new Error('关系必须包含 from、type、to');
    const duplicate = m.relations.find(relation => relation.from === from && relation.type === type && relation.to === to &&
      relation.scope === extra.scope && relation.version === extra.version && relation.sourceId === extra.sourceId);
    if (duplicate) return duplicate;
    const used = new Set(m.relations.map(relation => relation.id));
    let number = m.relations.filter(relation => relation.id?.startsWith(`${RELATION_ID_PREFIX}${m.meta.id}-`)).length + 1;
    let id;
    do {
      id = `${RELATION_ID_PREFIX}${m.meta.id}-${String(number++).padStart(4, '0')}`;
    } while (used.has(id));
    const relation = { id, from, type, to, ...extra };
    m.relations.push(relation);
    return relation;
  }

  function addResource(m, data) {
    const props = {
      resourceType: 'document', uri: '', locator: { path: '', section: '' }, sourceVersion: 'v1.0',
      summary: data.description || data.desc || '', parseStatus: 'structured',
      owner: '项目知识管理员', trust: 'confirmed', ...(data.props || {})
    };
    if (typeof props.locator === 'string') props.locator = { path: props.locator };
    delete props.version;
    if (props.parseStatus === 'parsed') props.parseStatus = 'structured';
    const entity = addKnowledge(m, 'Resource', { ...data, props });
    m.resources.push(entity);
    return entity;
  }

  function finalizeLegacy(m) {
    (m.scenarios || []).forEach(scenario => (scenario.stageIds || []).forEach(stageId =>
      addRelation(m, scenario.id, 'contains', stageId, { kind: 'structure' })));
    (m.stages || []).forEach(stage => (stage.stepIds || []).forEach(stepId =>
      addRelation(m, stage.id, 'contains', stepId, { kind: 'structure' })));
    (m.actions || []).forEach(action => {
      addRelation(m, action.id, 'belongsTo', action.scenarioId, { kind: 'structure' });
      action.ruleVersions = { ...(action.ruleVersions || {}) };
      (action.ruleIds || []).forEach(ruleId => {
        addRelation(m, action.id, 'uses', ruleId);
        action.ruleVersions[ruleId] = action.version;
      });
      (action.objectChanges || []).forEach(change =>
        addRelation(m, action.id, 'changes', change.objectId, { kind: 'causal' }));
      delete action.ruleIds;
    });
    (m.surfaces || []).forEach(surface => (surface.operations || []).forEach(operation =>
      addRelation(m, surface.id, 'triggers', operation.actionId)));
    (m.facts || []).forEach(fact => {
      if (fact.targetId && !fact.targetId.includes('@v1.6')) addRelation(m, fact.id, 'supports', fact.targetId);
    });
    (m.domains || []).forEach(domain => (domain.caps || []).forEach(capId =>
      addRelation(m, domain.id, 'contains', capId, { kind: 'structure' })));
    return m;
  }

  function defineWorkflow(m, data) {
    return C.createWorkflow(m, {
      projectId: m.meta.id, ...data,
      stages: data.stages.map(stage => ({ required: stage.required !== false, ...stage }))
    });
  }

  function instantiateWorkflow(m, definition, data) {
    const finished = data.status === 'completed';
    const currentIndex = Math.max(0, definition.stages.findIndex(stage => stage.id === data.currentStageId));
    const completedStages = finished ? definition.stages : definition.stages.slice(0, currentIndex);
    const supplied = data.completed || [];
    const completed = completedStages.map((stage, index) => supplied.find(item => item.stageId === stage.id) || {
      stageId: stage.id, at: `2026-11-14T${String(9 + Math.floor(index / 4)).padStart(2, '0')}:${String((index * 11) % 60).padStart(2, '0')}:00.000Z`,
      by: '示范项目执行人', note: `${stage.name}已完成并留存记录`, optional: !stage.required
    });
    const records = [...(data.records || [])];
    completed.forEach(item => {
      if (!records.some(record => record.type === 'complete' && record.stageId === item.stageId)) {
        records.push({ at: item.at, by: item.by, type: 'complete', stageId: item.stageId, note: item.note });
      }
    });
    const instance = C.instantiateWorkflow(m, definition.id, {
      ...data, currentStageId: finished ? definition.stages.at(-1)?.id : data.currentStageId,
      completed, records
    });
    if (finished) instance.currentStageId = null;
    return instance;
  }

  function addApprovalKnowledge(m) {
    addKnowledge(m, 'Project', { id: 'KN-A-PROJECT', name: '业务申请与审批项目', desc: '连接审批规则、修订动作、技术资产和 AI 辅助交付。' });
    addKnowledge(m, 'Feature', { id: 'FEAT-A01', name: '最小必要重审', desc: '根据金额、成本中心和收款方变化发起必要审批。', props: { scenarioId: 'SCN-00126', deliveryId: 'DLV-00086' } });
    addKnowledge(m, 'Term', {
      id: 'TERM-A001', name: '修订基线', desc: '用于比较变化且不可漂移的已批准申请版本。',
      props: { shortDefinition: '修订比较所依据的固定已批准版本。', context: '已批准申请修订', applicableVersion: 'v2.4' }
    });
    addKnowledge(m, 'System', { id: 'SYS-A01', name: '申请审批系统', desc: '承载申请、修订、审批和版本发布。', props: { owner: '业务应用组' } });
    addKnowledge(m, 'Module', { id: 'MOD-A01', name: '修订判断模块', desc: '比较字段、执行规则并生成审批任务。', props: { systemId: 'SYS-A01', responsibility: '标准化变化、执行重审规则并可靠创建任务。' } });
    addKnowledge(m, 'API', {
      id: 'API-A01', name: '创建重审任务接口', desc: '按固定规则版本批量创建审批任务。',
      props: {
        method: 'POST', path: '/revisions/{id}/review-tasks', providerId: 'MOD-A01', actionId: 'ACT-00424',
        input: { revisionId: '修订 ID', changeSet: '标准化变化清单', expectedVersion: '预期基线版本' },
        output: { taskIds: '新审批任务 ID 集合', reviewScope: '服务端重审范围' },
        failure: '版本冲突返回 409；任务批量写入失败时整体回滚，预算超时进入待重试。', contractVersion: '2026-11'
      }
    });
    addKnowledge(m, 'DataEntity', {
      id: 'DATA-A01', name: '重审任务创建数据', desc: '包含变化清单、规则版本、审批角色和幂等键。',
      props: {
        tableName: 'revision_review_task', lifecycle: '任务终结后转为只读审批历史。', implementationVersion: 'v2.4',
        fields: [
          { name: 'revisionId', type: 'text', description: '被审批的修订 ID' },
          { name: 'changeSet', type: 'json', description: '基线与草稿之间的标准化变化' },
          { name: 'ruleVersion', type: 'text', description: '服务端实际执行的规则版本' },
          { name: 'idempotencyKey', type: 'text', description: '防止重复创建审批任务的幂等键' }
        ]
      }
    });
    addKnowledge(m, 'Configuration', {
      id: 'CFG-A01', name: '重审规则运行配置', desc: '生产环境固定 RULE-0017 的发布版本和字段比较精度。',
      props: {
        source: 'SRC-A01', moduleId: 'MOD-A01', dataType: 'json',
        allowedValues: { ruleVersion: ['v2.4'], moneyScale: [2] }, defaultValue: { ruleVersion: 'v2.4', moneyScale: 2 },
        effectiveWhen: '修订服务启动且生产发布基线为 v2.4 时生效。', environments: ['ENV-A-PROD'], regions: ['华东主区'],
        risk: '错误规则版本或金额精度会改变重审范围，必须由业务负责人和交付负责人共同复核。',
        configVersion: 'CFG-A-2026.11', verified: true, ruleId: 'RULE-0017', ruleVersion: 'v2.4', moneyScale: 2
      }
    });
    addKnowledge(m, 'Environment', { id: 'ENV-A-PROD', name: '审批生产环境', desc: '运行已批准规则并要求发布证据完整。', props: { environment: 'production', region: '华东主区', release: 'v2.4', configVersion: 'CFG-A-2026.11' } });
    addResource(m, {
      id: 'SRC-A01', name: '修订服务实现说明', desc: '记录字段比较、规则执行和 outbox 发布约束。',
      props: {
        resourceType: 'repository', uri: 'atlas://approval/revision-service',
        locator: { path: 'services/revision/README.md', section: 'review-task-creation' },
        sourceVersion: 'commit-8ac31e', summary: '重审任务创建与版本发布实现索引', owner: '周宇', parseStatus: 'structured'
      }
    });
    addRelation(m, 'TERM-A001', 'references', 'OBJ-0012', { trust: 'confirmed', verified: true, explanation: '修订对象通过基线版本锁定比较范围。' });
    addRelation(m, 'TERM-A001', 'derivedFrom', 'SRC-A01', { trust: 'confirmed', verified: true });
    addRelation(m, 'SYS-A01', 'contains', 'MOD-A01', { trust: 'confirmed', verified: true });
    addRelation(m, 'MOD-A01', 'contains', 'API-A01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-A01', 'implements', 'ACT-00424', { trust: 'confirmed', verified: true, sourceId: 'SRC-A01' });
    addRelation(m, 'ACT-00424', 'reads', 'DATA-A01', { trust: 'confirmed', verified: true });
    addRelation(m, 'ACT-00424', 'writes', 'DATA-A01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-A01', 'reads', 'DATA-A01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-A01', 'writes', 'DATA-A01', { trust: 'confirmed', verified: true });
    addRelation(m, 'CFG-A01', 'affects', 'RULE-0017', { version: 'v2.4', trust: 'confirmed', verified: true });
    addRelation(m, 'CFG-A01', 'references', 'ENV-A-PROD', { trust: 'confirmed', verified: true });
    const definition = defineWorkflow(m, {
      id: 'WFD-AI-DELIVERY', name: 'AI 辅助开发交付', version: 'v1.0', purpose: 'delivery',
      stages: [
        { id: 'WFS-A01', name: '意图与验收澄清', role: '业务产品负责人', description: '形成可验证需求，AI 不替代业务确认。' },
        { id: 'WFS-A02', name: '知识检索与方案生成', role: '产品负责人与 AI 助手', description: '生成带来源的实现草案。' },
        { id: 'WFS-A03', name: '人机协同实现', role: '交付工程师与 AI 助手', description: '形成代码与规则变更草稿。' },
        { id: 'WFS-A04', name: '验证与风险审查', role: '业务与合规审查人', description: '完成试算、测试和影响审查。' },
        { id: 'WFS-A05', name: '发布与反馈', role: '发布负责人', description: '形成可追溯交付并收集反馈。' }
      ]
    });
    const instance = instantiateWorkflow(m, definition, {
      id: 'WFI-A-DLV-00086', name: 'DLV-00086 的 AI 辅助交付实例', status: 'active',
      subjectId: 'DLV-00086', currentStageId: 'WFS-A04'
    });
    instance.deliveryId = 'DLV-00086';
    m.deliveries.find(item => item.id === 'DLV-00086').workflowInstanceId = instance.id;
    const historicalRule = m.rules.find(rule => rule.id === 'RULE-0017').versions['v2.4'];
    m.deliveries.push({
      id: 'DLV-HIST-01', requirementId: 'REQ-HIST-01', scenarioId: 'SCN-00126', actionIds: ['ACT-00424'], ruleId: 'RULE-0017', ruleVersion: 'v2.4', surfaceIds: ['UI-00079'],
      technicalReview: true, packageVersion: 'DLV-HIST-01@RULE-0017-v2.4', acceptance: [],
      snapshot: { id: 'DLV-HIST-01', rule: clone(historicalRule), actions: [clone(m.actions.find(action => action.id === 'ACT-00424'))], baseline: 'BL-A-2026-11-12', note: '历史交接固定引用 RULE-0017@v2.4，后续发布不得覆盖。' }
    });
    addKnowledge(m, 'KnownIssue', {
      id: 'SEC-A01', name: '生产金额精度差异（受限）', desc: '仅限项目内部角色查看的生产配置核验事项；外部 Agent 视角不可读取。',
      sensitivity: 'restricted', permissions: { read: ['reader', 'developer', 'admin'], edit: ['admin'], approve: ['owner'] },
      props: { environment: 'production', owner: '周宇' }, status: 'draft'
    });
    addRelation(m, 'SEC-A01', 'affects', 'CFG-A01', { trust: 'inferred', verified: false, explanation: '未核验推断：金额精度差异可能影响此配置，需要人工核对生产证据。' });
    m.workspace.readingPaths.find(path => path.role === 'newcomer').steps.push({ label: '理解修订基线术语', entityId: 'TERM-A001' });
    m.workspace.readingPaths.find(path => path.role === 'developer').steps.push(
      { label: '检查重审接口契约', entityId: 'API-A01' },
      { label: '阅读修订服务实现资源', entityId: 'SRC-A01' }
    );
    return m;
  }

  function addBookingKnowledge(m) {
    addKnowledge(m, 'Project', { id: 'KN-B-PROJECT', name: '预约服务平台项目', desc: '传统开发流程维护的预约与资源一致性项目。' });
    addKnowledge(m, 'Feature', { id: 'FEAT-B01', name: '可靠预约确认', desc: '服务端复核容量并在同一事务中写入预约与占用。', props: { scenarioId: 'SCN-B001' } });
    addKnowledge(m, 'Term', {
      id: 'TERM-B001', name: '资源时段', desc: '某项服务资源在一段时间内可占用的容量。',
      props: { shortDefinition: '服务资源在指定时间范围内的可用容量。', context: '服务预约与资源调度', applicableVersion: 'v1.0' }
    });
    addKnowledge(m, 'System', { id: 'SYS-B01', name: '预约调度系统', desc: '提供可用性计算、预约确认和资源释放。', props: { owner: '预约平台组' } });
    addKnowledge(m, 'Module', { id: 'MOD-B01', name: '资源占用模块', desc: '维护预约单和资源时段的事务一致性。', props: { systemId: 'SYS-B01', responsibility: '复核容量并原子写入预约、时段占用和事件。' } });
    addKnowledge(m, 'API', {
      id: 'API-B01', name: '预约确认接口', desc: '服务端重新核验可用性并创建预约。',
      props: {
        method: 'POST', path: '/bookings', providerId: 'MOD-B01',
        input: { serviceId: '服务 ID', slotId: '资源时段 ID', quantity: '占用数量' },
        output: { bookingId: '预约单 ID', status: '预约状态', confirmationEvent: '预约确认事件' },
        failure: '提交时容量不足返回 409，预约与占用均不写入；通知异步重试。', contractVersion: 'v1.0'
      }
    });
    addKnowledge(m, 'DataEntity', {
      id: 'DATA-B01', name: '预约与时段占用数据', desc: '在同一事务中记录预约事实和资源容量变化。',
      props: {
        tableName: 'booking_reservation', lifecycle: '取消或改期后保留原占用历史。', implementationVersion: 'v1.0',
        fields: [
          { name: 'bookingId', type: 'text', description: '预约单稳定 ID' },
          { name: 'slotId', type: 'text', description: '被占用的资源时段' },
          { name: 'quantity', type: 'number', description: '本次占用容量' },
          { name: 'status', type: 'enum', description: '预约单当前状态' }
        ]
      }
    });
    addKnowledge(m, 'Configuration', {
      id: 'CFG-B01', name: '预约确认配置', desc: '启用服务端复核、容量约束和通知异步重试。',
      props: {
        source: 'SRC-B01', moduleId: 'MOD-B01', dataType: 'json',
        allowedValues: { recheckOnSubmit: [true], notificationRetries: [3, 5] },
        defaultValue: { recheckOnSubmit: true, notificationRetries: 5 },
        effectiveWhen: '预约确认与改期请求进入服务端时生效。', environments: ['ENV-B-PROD'], regions: ['默认服务区域'],
        risk: '关闭提交复核或错误调整重试会造成超卖或结果通知丢失。', configVersion: 'CFG-B-2026.11', verified: true,
        recheckOnSubmit: true, notificationRetries: 5, ruleId: 'RULE-B001'
      }
    });
    addKnowledge(m, 'Environment', { id: 'ENV-B-PROD', name: '预约生产环境', desc: '运行预约服务与通知消费者。', props: { environment: 'production', region: '默认服务区域', release: 'v1.0', configVersion: 'CFG-B-2026.11' } });
    addResource(m, {
      id: 'SRC-B01', name: '预约并发占用测试记录', desc: '记录容量竞争、事务回滚与通知重试验证。',
      props: {
        resourceType: 'test-report', uri: 'atlas://booking/test-reports/BOOK-105-08',
        locator: { path: 'booking-service/src/test/BookingConcurrencyTest.md', section: 'BOOK-105-08' },
        sourceVersion: 'v1.0', summary: '预约与占用原子性验证', owner: '唐星', parseStatus: 'structured'
      }
    });
    addRelation(m, 'TERM-B001', 'references', 'OBJ-B02', { trust: 'confirmed', verified: true });
    addRelation(m, 'TERM-B001', 'derivedFrom', 'SRC-B01', { trust: 'confirmed', verified: true });
    addRelation(m, 'SYS-B01', 'contains', 'MOD-B01', { trust: 'confirmed', verified: true });
    addRelation(m, 'MOD-B01', 'contains', 'API-B01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-B01', 'implements', 'ACT-B0005', { trust: 'confirmed', verified: true, sourceId: 'SRC-B01' });
    addRelation(m, 'ACT-B0005', 'reads', 'DATA-B01', { trust: 'confirmed', verified: true });
    addRelation(m, 'ACT-B0005', 'writes', 'DATA-B01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-B01', 'reads', 'DATA-B01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-B01', 'writes', 'DATA-B01', { trust: 'confirmed', verified: true });
    addRelation(m, 'CFG-B01', 'affects', 'RULE-B001', { version: 'v1.0', trust: 'confirmed', verified: true });
    addRelation(m, 'CFG-B01', 'references', 'ENV-B-PROD', { trust: 'confirmed', verified: true });
    const definition = defineWorkflow(m, {
      id: 'WFD-B-TRADITIONAL', name: '预约平台传统开发流程', version: 'v1.0', purpose: 'delivery',
      stages: [
        { id: 'WFS-B01', name: '需求确认', role: '产品负责人', description: '确认预约与资源一致性验收条件。' },
        { id: 'WFS-B02', name: '技术设计', role: '系统设计师', description: '设计事务边界和接口契约。' },
        { id: 'WFS-B03', name: '编码实现', role: '开发工程师', description: '实现预约、占用和通知。' },
        { id: 'WFS-B04', name: '测试验证', role: '测试工程师', description: '验证并发竞争和失败回滚。' },
        { id: 'WFS-B05', name: '发布复盘', role: '发布负责人', description: '发布 v1.0 并记录验证结果。' }
      ]
    });
    instantiateWorkflow(m, definition, {
      id: 'WFI-B-V10', name: '预约平台 v1.0 交付实例', status: 'completed',
      subjectId: 'SCN-B001', currentStageId: null
    });
    m.workspace.readingPaths.find(path => path.role === 'newcomer').steps.push({ label: '理解资源时段术语', entityId: 'TERM-B001' });
    m.workspace.readingPaths.find(path => path.role === 'developer').steps.push(
      { label: '检查预约确认接口', entityId: 'API-B01' },
      { label: '阅读并发测试资源', entityId: 'SRC-B01' }
    );
    return m;
  }

  function createManufacturingProject() {
    const m = M.createEmptyProject('PRJ-00003', '制造质量异常处置', '隔离质量异常批次，依据有限处置规则完成返工或报废，并以复检证据决定放行或终止。');
    m.meta.version = 'v1.0'; m.meta.status = 'published'; m.meta.desc = '生产批次质量异常、返工、复检与放行';
    m.actors = [
      { id: 'ACTOR-M01', name: '质检员', concern: '及时记录缺陷并阻止异常批次继续流转' },
      { id: 'ACTOR-M02', name: '质量工程师', concern: '处置判断有规则依据，复检证据完整' },
      { id: 'ACTOR-M03', name: '生产班组长', concern: '隔离、返工和放行状态清晰' },
      { id: 'ACTOR-M04', name: '设备工程师', concern: '设备原因与维修记录可追踪' },
      { id: 'ACTOR-M05', name: '制造执行系统', concern: '批次状态和规则版本一致' }
    ];
    m.objects = [
      { id: 'OBJ-M01', name: '生产批次', aliases: ['制造批次'], desc: '在同一生产指令下形成并可独立追踪的产品集合。', states: ['生产中', '质量隔离', '待处置', '返工中', '待复检', '已放行', '已报废'], props: ['批次号', '数量', '产线', '是否放行', '检验时间'] },
      { id: 'OBJ-M02', name: '缺陷', aliases: ['质量异常'], desc: '检验发现的产品特性偏离及其严重程度。', states: ['已发现', '调查中', '待处置', '返工处理中', '已关闭', '已终止'], props: ['缺陷等级', '缺陷位置', '发现时间', '返工可行性'] },
      { id: 'OBJ-M03', name: '设备', aliases: ['生产设备'], desc: '参与批次加工并可能提供原因线索的生产设备。', states: ['运行', '待核查', '停机', '已恢复'], props: ['设备编号', '运行参数', '点检状态'] }
    ];
    m.domains = [
      { id: 'DOM-M01', name: '质量发现与隔离', icon: '检', desc: '发现异常并冻结受影响批次。', goal: '防止不合格品继续流转', caps: ['CAP-M01', 'CAP-M02'], objects: ['OBJ-M01', 'OBJ-M02'], actorIds: ['ACTOR-M01', 'ACTOR-M03'], depends: [] },
      { id: 'DOM-M02', name: '调查与处置', icon: '查', desc: '调查缺陷和设备上下文并确定处置。', goal: '形成有依据的返工或报废决定', caps: ['CAP-M03', 'CAP-M04'], objects: ['OBJ-M01', 'OBJ-M02', 'OBJ-M03'], actorIds: ['ACTOR-M02', 'ACTOR-M04'], depends: ['DOM-M01'] },
      { id: 'DOM-M03', name: '复检与放行', icon: '放', desc: '执行返工、复检并控制最终状态。', goal: '只有复检合格的批次才能放行', caps: ['CAP-M05', 'CAP-M06'], objects: ['OBJ-M01', 'OBJ-M02'], actorIds: ['ACTOR-M01', 'ACTOR-M02', 'ACTOR-M05'], depends: ['DOM-M02'] }
    ];
    [
      ['CAP-M01', '异常登记', 'DOM-M01'], ['CAP-M02', '批次隔离', 'DOM-M01'],
      ['CAP-M03', '原因调查', 'DOM-M02'], ['CAP-M04', '质量处置判断', 'DOM-M02'],
      ['CAP-M05', '返工与复检', 'DOM-M03'], ['CAP-M06', '批次放行', 'DOM-M03']
    ].forEach(([id, name, domainId]) => m.capabilities.push({ id, name, domainId, desc: `${name}是制造质量处置中的可追踪能力。` }));

    const version = {
      version: 'v1.0', status: 'published', effective: '2026-11-14 起生效',
      source: '制造质量委员会处置规范 QD-2026-014', supportsEvaluation: true,
      scope: '已隔离批次，缺陷等级、返工可行性和最近一次复检结论均已确认。',
      inputs: [
        { id: 'defect', label: '缺陷等级', kind: 'enum', default: 'critical', options: [{ value: 'critical', label: '严重' }, { value: 'minor', label: '一般' }] },
        { id: 'rework', label: '返工可行性', kind: 'enum', default: 'feasible', options: [{ value: 'feasible', label: '可返工' }, { value: 'unfeasible', label: '不可返工' }] },
        { id: 'recheck', label: '复检结论', kind: 'enum', default: 'pass', options: [{ value: 'pass', label: '合格' }, { value: 'fail', label: '不合格' }] }
      ],
      outcomes: [
        { id: 'SCRAP', label: '报废并终止批次', actorIds: ['ACTOR-M02', 'ACTOR-M03'], description: '严重缺陷或不可返工时终止放行' },
        { id: 'REWORK', label: '返工后重新调查与复检', actorIds: ['ACTOR-M02', 'ACTOR-M03'], description: '一般缺陷复检不合格时回到处置判断' },
        { id: 'RELEASE', label: '允许复检放行', actorIds: ['ACTOR-M01', 'ACTOR-M02'], description: '一般缺陷可返工且复检合格时放行' }
      ],
      rows: [
        { id: 'MR-01', priority: 10, when: { defect: 'critical' }, outcomeId: 'SCRAP' },
        { id: 'MR-02', priority: 20, when: { defect: 'minor', rework: 'unfeasible' }, outcomeId: 'SCRAP' },
        { id: 'MR-03', priority: 30, when: { defect: 'minor', rework: 'feasible', recheck: 'fail' }, outcomeId: 'REWORK' },
        { id: 'MR-04', priority: 40, when: { defect: 'minor', rework: 'feasible', recheck: 'pass' }, outcomeId: 'RELEASE' }
      ],
      exceptions: []
    };
    version.summary = E.summarizeRule(version);
    m.rules = [{ id: 'RULE-M001', name: '质量处置判断', owner: '赵衡', currentVersion: 'v1.0', versions: { 'v1.0': version } }];
    const stageSpecs = [
      ['STG-M01', '发现质量异常', 'DOM-M01'], ['STG-M02', '隔离批次', 'DOM-M01'],
      ['STG-M03', '调查原因', 'DOM-M02'], ['STG-M04', '确定处理', 'DOM-M02'],
      ['STG-M05', '返工或报废', 'DOM-M02'], ['STG-M06', '复检', 'DOM-M03'],
      ['STG-M07', '放行或终止', 'DOM-M03']
    ];
    m.stages = stageSpecs.map(([id, name, domainId], index) => ({
      id, name, domainId, goal: `${name}并形成可追踪的制造质量记录`,
      input: index ? '上一阶段质量记录' : '检验发现的异常信号', result: `${name}结果`,
      actorIds: domainId === 'DOM-M01' ? ['ACTOR-M01', 'ACTOR-M03'] : domainId === 'DOM-M02' ? ['ACTOR-M02', 'ACTOR-M04'] : ['ACTOR-M01', 'ACTOR-M02'],
      stepIds: [], capabilityIds: m.domains.find(domain => domain.id === domainId).caps
    }));
    const actionSpecs = [
      ['ACT-M001', '登记质量异常', 'STG-M01', 'ACTOR-M01', '记录缺陷等级、位置和检验证据。', ['OBJ-M02'], []],
      ['ACT-M002', '冻结异常批次', 'STG-M02', 'ACTOR-M03', '将受影响批次转为质量隔离并停止向下游流转。', ['OBJ-M01'], []],
      ['ACT-M003', '采集设备与工艺上下文', 'STG-M03', 'ACTOR-M04', '读取异常时段的设备参数和工艺批次记录。', ['OBJ-M03'], []],
      ['ACT-M004', '分析缺陷原因', 'STG-M03', 'ACTOR-M02', '综合缺陷与设备信息，记录根因和返工可行性。', ['OBJ-M02', 'OBJ-M03'], []],
      ['ACT-M005', '执行质量处置判断', 'STG-M04', 'ACTOR-M02', '按缺陷等级、返工可行性和复检状态命中处置结果。', ['OBJ-M01', 'OBJ-M02'], ['RULE-M001']],
      ['ACT-M006', '执行返工并记录工艺', 'STG-M05', 'ACTOR-M03', '仅对可返工的一般缺陷执行返工，并保留工艺记录。', ['OBJ-M01', 'OBJ-M02'], []],
      ['ACT-M007', '报废并隔离物料', 'STG-M05', 'ACTOR-M03', '严重或不可返工批次执行报废，保留数量和去向。', ['OBJ-M01', 'OBJ-M02'], ['RULE-M001']],
      ['ACT-M008', '复检返工批次', 'STG-M06', 'ACTOR-M01', '重新检验返工批次并写入复检结论和时间。', ['OBJ-M01', 'OBJ-M02'], ['RULE-M001']],
      ['ACT-M009', '放行合格批次', 'STG-M07', 'ACTOR-M02', '复检合格后解除隔离并记录放行人和依据。', ['OBJ-M01', 'OBJ-M02'], ['RULE-M001']],
      ['ACT-M010', '终止批次并归档', 'STG-M07', 'ACTOR-M05', '归档报废或无法继续处置的批次，关闭异常。', ['OBJ-M01', 'OBJ-M02'], []]
    ];
    actionSpecs.forEach(([id, name, stageId, actorId, purpose, objectIds, ruleIds], index) => {
      const stepId = `STEP-M${String(index + 1).padStart(3, '0')}`;
      const stage = m.stages.find(item => item.id === stageId);
      stage.stepIds.push(stepId);
      m.steps.push({ id: stepId, number: index + 1, stageId, actionId: id, name, actorId, kind: ['ACT-M005', 'ACT-M008'].includes(id) ? 'decision' : 'action', result: `${name}完成` });
      const objectChanges = objectIds.map(objectId => ({
        objectId,
        before: objectId === 'OBJ-M01' ? '生产中或质量隔离' : objectId === 'OBJ-M02' ? '已发现或调查中' : '运行',
        after: id === 'ACT-M009' && objectId === 'OBJ-M01' ? '已放行' : id === 'ACT-M007' && objectId === 'OBJ-M01' ? '已报废' : id === 'ACT-M006' && objectId === 'OBJ-M01' ? '待复检' : `${name}后的受控状态`,
        constraint: '变化必须保留批次、缺陷和处置规则版本的可追踪关系。'
      }));
      m.actions.push({
        id, name, version: 'v1.0', status: 'published', actorId, stageId, scenarioId: 'SCN-M001', stepId,
        domainId: stage.domainId, capabilityIds: clone(stage.capabilityIds), depth: 'detailed', purpose,
        pre: ['异常批次已建立且当前用户具备处置权限'], input: ['批次号', '缺陷记录', '质量处置上下文'],
        output: [`${name}记录`], ruleIds, objectChanges, exceptions: [], evidence: ['FACT-M001'], implementation: null
      });
    });
    m.scenarios = [{
      id: 'SCN-M001', name: '质量异常处置', version: 'v1.0', status: 'published',
      goal: '完整执行发现质量异常→隔离批次→调查原因→确定处理→返工或报废→复检→放行或终止。',
      trigger: '在线或离线检验发现生产批次存在质量异常。',
      participants: m.actors.map(actor => actor.id), result: '合格批次有证据放行，或不合格批次报废终止。',
      stageIds: m.stages.map(stage => stage.id), exceptionIds: [], full: true, explore: { ruleIds: ['RULE-M001'] }
    }];
    const nodes = [{ id: 'MN-START', type: 'start', name: '发现异常信号', stageId: 'STG-M01' }];
    m.actions.forEach(action => nodes.push({
      id: `MN-${action.id}`, actionId: action.id, stageId: action.stageId,
      type: ['ACT-M005', 'ACT-M008'].includes(action.id) ? 'decision' : 'action',
      ruleId: ['ACT-M005', 'ACT-M008'].includes(action.id) ? 'RULE-M001' : undefined
    }));
    nodes.push({ id: 'MN-END', type: 'end', name: '质量异常处置完成', stageId: 'STG-M07' });
    const edges = [];
    const connect = (id, from, to, type = 'next', extra = {}) => edges.push({ id, from, to, type, ...extra });
    connect('ME-001', 'MN-START', 'MN-ACT-M001');
    for (let index = 1; index < 5; index++) connect(`ME-${String(index + 1).padStart(3, '0')}`, `MN-ACT-M${String(index).padStart(3, '0')}`, `MN-ACT-M${String(index + 1).padStart(3, '0')}`);
    connect('ME-006', 'MN-ACT-M005', 'MN-ACT-M006', 'when', { when: { ruleId: 'RULE-M001', outcomeId: 'RELEASE' }, label: '一般缺陷可返工，先执行返工' });
    connect('ME-007', 'MN-ACT-M005', 'MN-ACT-M006', 'when', { when: { ruleId: 'RULE-M001', outcomeId: 'REWORK' }, label: '需要返工' });
    connect('ME-008', 'MN-ACT-M005', 'MN-ACT-M007', 'when', { when: { ruleId: 'RULE-M001', outcomeId: 'SCRAP' }, label: '严重或不可返工' });
    connect('ME-009', 'MN-ACT-M006', 'MN-ACT-M008');
    connect('ME-010', 'MN-ACT-M008', 'MN-ACT-M009', 'when', { when: { ruleId: 'RULE-M001', outcomeId: 'RELEASE' }, label: '复检合格' });
    connect('ME-011', 'MN-ACT-M008', 'MN-ACT-M005', 'return', { when: { ruleId: 'RULE-M001', outcomeId: 'REWORK' }, defaultCollapsed: true, label: '复检不合格，重新确定返工处置' });
    connect('ME-012', 'MN-ACT-M007', 'MN-ACT-M010');
    connect('ME-013', 'MN-ACT-M009', 'MN-END');
    connect('ME-014', 'MN-ACT-M010', 'MN-END');
    m.flows = [{ id: 'FLOW-M001', scenarioId: 'SCN-M001', nodes, edges }];
    m.surfaces = [
      { id: 'UI-M001', name: '质量异常登记台', domainId: 'DOM-M01', type: '普通页面', actorId: 'ACTOR-M01', sceneIds: ['SCN-M001'], operations: [{ name: '登记质量异常', actionId: 'ACT-M001', states: ['生产中'] }], objectIds: ['OBJ-M01', 'OBJ-M02'], api: 'POST /quality/defects' },
      { id: 'UI-M002', name: '批次质量处置台', domainId: 'DOM-M02', type: '普通页面', actorId: 'ACTOR-M02', sceneIds: ['SCN-M001'], operations: [{ name: '执行质量处置判断', actionId: 'ACT-M005', states: ['质量隔离', '待处置'] }, { name: '复检返工批次', actionId: 'ACT-M008', states: ['待复检'] }], objectIds: ['OBJ-M01', 'OBJ-M02'], api: 'POST /quality/batches/{id}/disposition' }
    ];
    m.facts = [
      { id: 'FACT-M001', kind: 'specification', source: '制造质量委员会 QD-2026-014', conclusion: '严重缺陷或不可返工批次不得放行；一般缺陷返工后必须复检。', status: '已批准', date: '2026-11-14', owner: '赵衡', targetId: 'RULE-M001@v1.0' },
      { id: 'FACT-M002', kind: 'implementation', source: 'MES 质量处置接口核验 MQ-101', conclusion: '批次隔离、处置和复检记录使用同一批次号，放行记录包含检验时间。', status: '已核验', date: '2026-11-14', owner: '孙岚', targetId: 'ACT-M009' }
    ];
    m.scale = { actions: m.actions.length, surfaces: m.surfaces.length, note: '10 个动作与 2 个界面均为本次建立的真实制造质量内容。' };
    finalizeLegacy(m);
    enrichProject(m);
    C.registerType(m, {
      id: 'ManufacturingBatch', name: '生产批次', dimension: '制造业务扩展',
      fields: [
        { id: 'batchNo', label: '批次号', dataType: 'text', required: true },
        { id: 'quantity', label: '数量', dataType: 'number', required: false },
        { id: 'line', label: '产线', dataType: 'enum', required: false, options: ['L1', 'L2', 'L3'] },
        { id: 'released', label: '是否放行', dataType: 'boolean', required: false },
        { id: 'qualityState', label: '质量状态', dataType: 'enum', required: true, options: ['生产中', '质量隔离', '待复检', '已放行', '已报废'] },
        { id: 'inspectedAt', label: '检验时间', dataType: 'date', required: false }
      ]
    });
    addKnowledge(m, 'Project', { id: 'KN-M-PROJECT', name: '制造质量异常处置项目', desc: '覆盖七阶段质量主线和可试算处置矩阵。' });
    addKnowledge(m, 'Feature', { id: 'FEAT-M01', name: '批次质量闭环', desc: '从异常发现到放行或报废的完整闭环。', props: { scenarioId: 'SCN-M001' } });
    addKnowledge(m, 'Term', {
      id: 'TERM-M001', name: '质量异常', desc: '产品或过程特性偏离批准要求，需要隔离和处置的状态。',
      props: { shortDefinition: '产品或过程偏离批准要求并需受控处置的状态。', context: '制造现场批次质量管理', synonyms: ['制造质量偏差'], applicableVersion: 'v1.0' }
    });
    addKnowledge(m, 'System', { id: 'SYS-M01', name: '制造执行与质量系统', desc: '协同维护批次状态、缺陷记录与检验证据。', props: { products: ['MES', 'QMS'] } });
    addKnowledge(m, 'Module', { id: 'MOD-M01', name: '质量处置模块', desc: '执行批次隔离、质量处置和复检放行。', props: { responsibility: '按受控规则计算处置结果并保存批次质量证据。' } });
    addKnowledge(m, 'API', {
      id: 'API-M01', name: '批次质量处置接口', desc: '提交质量上下文并获取受控处置结果。',
      props: {
        method: 'POST', path: '/quality/batches/{id}/disposition', providerId: 'MOD-M01',
        input: { batchNo: '批次号', defect: '缺陷等级', rework: '返工可行性', recheck: '复检结论' },
        output: { disposition: '处置结果', ruleVersion: '命中的规则版本', evidenceId: '处置证据 ID' },
        failure: '输入缺失时拒绝处置；写入证据失败时不改变批次放行状态。', contractVersion: 'QD-2026-014/v1.0'
      }
    });
    addKnowledge(m, 'Configuration', {
      id: 'CFG-M01', name: '质量处置生产配置', desc: '生产环境启用 QD-2026-014 处置矩阵和复检回边。',
      props: {
        source: 'SRC-M01', moduleId: 'MOD-M01', dataType: 'json',
        allowedValues: { ruleVersion: ['v1.0'], requireRecheck: [true] }, defaultValue: { ruleVersion: 'v1.0', requireRecheck: true },
        effectiveWhen: '华东一厂生产环境执行质量处置和复检时生效。', environments: ['ENV-M-PROD'], regions: ['华东一厂'],
        risk: '关闭强制复检或选择错误规则版本可能放行不合格批次。', configVersion: 'CFG-M-2026.11', verified: true,
        ruleId: 'RULE-M001', ruleVersion: 'v1.0', requireRecheck: true
      }
    });
    addKnowledge(m, 'Environment', { id: 'ENV-M-PROD', name: '制造生产环境', desc: '连接 MES、QMS 与设备采集服务的正式环境。', props: { environment: 'production', plant: '华东一厂', region: '华东一厂', release: 'v1.0', configVersion: 'CFG-M-2026.11' } });
    addKnowledge(m, 'DataEntity', {
      id: 'DATA-M01', name: '质量处置输入数据', desc: '向处置动作提供批次、缺陷、返工可行性和复检结论。',
      props: {
        tableName: 'quality_disposition_context', lifecycle: '每次处置和复检形成不可覆盖的上下文快照。', implementationVersion: 'v1.0',
        fields: [
          { name: 'batchNo', type: 'text', description: '受影响生产批次号' },
          { name: 'defect', type: 'enum', description: '严重或一般缺陷等级' },
          { name: 'rework', type: 'enum', description: '缺陷是否具备返工可行性' },
          { name: 'recheck', type: 'enum', description: '最近一次复检是否合格' },
          { name: 'ruleVersion', type: 'text', description: '本次处置使用的规则版本' }
        ]
      }
    });
    addKnowledge(m, 'ManufacturingBatch', {
      id: 'BATCH-M-001', name: '批次 M-20261114-001', desc: '一号装配线的示范在制批次，当前处于复检合格待放行状态。',
      props: { batchNo: 'M-20261114-001', quantity: 240, line: 'L1', released: false, qualityState: '待复检', inspectedAt: '2026-11-14' }
    });
    addResource(m, {
      id: 'SRC-M01', name: '质量异常处置作业指导书', desc: '规定缺陷分级、隔离、返工和复检的证据要求。',
      props: {
        resourceType: 'controlled-document', uri: 'atlas://manufacturing/quality/QD-2026-014',
        locator: { path: 'qms/controlled-documents/QD-2026-014.md', section: 'disposition-matrix' },
        sourceVersion: 'QD-2026-014/v1.0', summary: 'RULE-M001 的受控作业依据', owner: '赵衡', trust: 'confirmed', parseStatus: 'structured'
      }
    });
    addRelation(m, 'TERM-M001', 'references', 'SCN-M001', { trust: 'confirmed', verified: true });
    addRelation(m, 'TERM-M001', 'explains', 'OBJ-M02', { trust: 'confirmed', verified: true, explanation: '质量异常在业务对象层记录为缺陷及其处置状态。' });
    addRelation(m, 'TERM-M001', 'derivedFrom', 'SRC-M01', { trust: 'confirmed', verified: true });
    addRelation(m, 'SYS-M01', 'contains', 'MOD-M01', { trust: 'confirmed', verified: true });
    addRelation(m, 'MOD-M01', 'contains', 'API-M01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-M01', 'implements', 'ACT-M005', { trust: 'confirmed', verified: true, sourceId: 'SRC-M01' });
    addRelation(m, 'ACT-M005', 'reads', 'DATA-M01', { trust: 'confirmed', verified: true });
    addRelation(m, 'ACT-M008', 'writes', 'DATA-M01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-M01', 'reads', 'DATA-M01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-M01', 'writes', 'DATA-M01', { trust: 'confirmed', verified: true });
    addRelation(m, 'CFG-M01', 'affects', 'RULE-M001', { version: 'v1.0', trust: 'confirmed', verified: true, sourceId: 'SRC-M01' });
    addRelation(m, 'CFG-M01', 'references', 'ENV-M-PROD', { trust: 'confirmed', verified: true });
    addRelation(m, 'BATCH-M-001', 'subjectOf', 'SCN-M001', { trust: 'confirmed', verified: true });
    addRelation(m, 'RULE-M001', 'cites', 'SRC-M01', { trust: 'confirmed', verified: true });
    const definition = defineWorkflow(m, {
      id: 'WFD-M-QUALITY', name: '制造质量问题处理', version: 'v1.0', purpose: 'business',
      stages: [
        { id: 'WFS-M01', name: '发现质量异常', role: '质检员', activityId: 'ACT-M001' },
        { id: 'WFS-M02', name: '隔离批次', role: '生产班组长', activityId: 'ACT-M002' },
        { id: 'WFS-M03', name: '调查原因', role: '质量与设备工程师', activityId: 'ACT-M004' },
        { id: 'WFS-M04', name: '确定处理', role: '质量工程师', activityId: 'ACT-M005' },
        { id: 'WFS-M05', name: '返工或报废', role: '生产班组长', activityIds: ['ACT-M006', 'ACT-M007'] },
        { id: 'WFS-M06', name: '复检', role: '质检员', activityId: 'ACT-M008', returnTo: 'WFS-M04', description: '复检不合格时退回重新确定处理。' },
        { id: 'WFS-M07', name: '放行或终止', role: '质量负责人', activityIds: ['ACT-M009', 'ACT-M010'] }
      ]
    });
    instantiateWorkflow(m, definition, {
      id: 'WFI-M-BATCH-001', name: '批次 M-20261114-001 质量处理', status: 'active',
      subjectId: 'BATCH-M-001', currentStageId: 'WFS-M07'
    });
    m.workspace.readingPaths.find(path => path.role === 'newcomer').steps.push({ label: '理解质量异常术语', entityId: 'TERM-M001' });
    m.workspace.readingPaths.find(path => path.role === 'developer').steps.push(
      { label: '检查质量处置接口', entityId: 'API-M01' },
      { label: '核对生产配置与输入数据', entityId: 'CFG-M01' },
      { label: '阅读受控作业指导书', entityId: 'SRC-M01' }
    );
    return m;
  }

  function createGovernmentProject() {
    const m = M.createEmptyProject('PRJ-00004', '政务许可协同办理', '明确行政许可受理主线，以动态案件任务完成补正、多部门核查、安全评估、实施和验收。');
    m.meta.version = 'v1.0'; m.meta.status = 'published'; m.meta.desc = '行政许可受理、法规审查、协同核查和验收';
    m.actors = [
      { id: 'ACTOR-G01', name: '申请主体', concern: '清楚提交材料、补正要求和办理结果' },
      { id: 'ACTOR-G02', name: '窗口受理人员', concern: '依法核验主体和材料，不擅自增加条件' },
      { id: 'ACTOR-G03', name: '法规审查人员', concern: '办理依据和审查意见可引用' },
      { id: 'ACTOR-G04', name: '会签部门', concern: '按职责独立核查并保留意见' },
      { id: 'ACTOR-G05', name: '安全评估人员', concern: '风险结论和整改证据完整' },
      { id: 'ACTOR-G06', name: '事项负责人', concern: '动态任务最终汇聚为明确办理结论' }
    ];
    m.objects = [
      { id: 'OBJ-G01', name: '许可案件', aliases: ['办件'], desc: '申请主体针对一个行政事项形成的办理实例。', states: ['已提交', '受理审查中', '待补正', '协同核查中', '决定已作出', '实施中', '已验收', '已办结'], props: ['事项编码', '申请主体', '材料清单', '办理期限'] },
      { id: 'OBJ-G02', name: '申请材料', aliases: ['申报资料'], desc: '证明主体资格、事实条件和安全能力的提交材料。', states: ['已提交', '待补正', '已核验', '已失效'], props: ['材料类型', '出具主体', '有效期', '电子凭证'] },
      { id: 'OBJ-G03', name: '审查意见', aliases: ['核查结论'], desc: '审查或会签部门基于职责和证据形成的独立意见。', states: ['待形成', '通过', '需补正', '不通过'], props: ['审查部门', '法规依据', '结论', '证据'] }
    ];
    m.domains = [
      { id: 'DOM-G01', name: '受理与材料', icon: '受', desc: '核验申请主体和法定材料。', goal: '形成明确受理或补正结论', caps: ['CAP-G01', 'CAP-G02'], objects: ['OBJ-G01', 'OBJ-G02'], actorIds: ['ACTOR-G01', 'ACTOR-G02'], depends: [] },
      { id: 'DOM-G02', name: '审查与会签', icon: '审', desc: '完成法规、业务和安全审查。', goal: '保留各部门独立审查依据', caps: ['CAP-G03', 'CAP-G04'], objects: ['OBJ-G01', 'OBJ-G03'], actorIds: ['ACTOR-G03', 'ACTOR-G04', 'ACTOR-G05'], depends: ['DOM-G01'] },
      { id: 'DOM-G03', name: '实施与验收', icon: '验', desc: '执行办理决定并核验实施结果。', goal: '满足完成条件后办结', caps: ['CAP-G05', 'CAP-G06'], objects: ['OBJ-G01', 'OBJ-G03'], actorIds: ['ACTOR-G06'], depends: ['DOM-G02'] }
    ];
    [
      ['CAP-G01', '申请受理', 'DOM-G01'], ['CAP-G02', '材料补正', 'DOM-G01'],
      ['CAP-G03', '法规审查', 'DOM-G02'], ['CAP-G04', '跨部门会签', 'DOM-G02'],
      ['CAP-G05', '实施管理', 'DOM-G03'], ['CAP-G06', '结果验收', 'DOM-G03']
    ].forEach(([id, name, domainId]) => m.capabilities.push({ id, name, domainId, desc: `${name}是政务事项办理的独立职责。` }));
    const version = {
      version: 'v1.0', status: 'published', effective: '2026-11-14 起生效',
      source: '行政许可受理审查规范与中华人民共和国行政许可法第三十二条',
      supportsEvaluation: false,
      constraint: '窗口人员必须人工核验申请主体适格、事项属于本机关职权、材料齐全且符合法定形式；需要补正时一次性告知全部补正内容，不得以内部会签代替法定受理判断。',
      acceptanceConditions: ['申请主体具有相应资格或有效授权', '申请事项属于本机关职权范围', '法定材料齐全且形式有效'],
      requiredMaterials: ['主体身份证明或统一社会信用代码材料', '许可事项申请表', '授权委托书（委托办理时）', '安全能力说明'],
      inputs: [], outcomes: [], rows: [], exceptions: []
    };
    version.summary = E.summarizeRule(version);
    m.rules = [{ id: 'RULE-G001', name: '受理条件与材料', owner: '周宁', currentVersion: 'v1.0', versions: { 'v1.0': version } }];
    const stageSpecs = [
      ['STG-G01', '提交与受理', 'DOM-G01'], ['STG-G02', '法规与协同审查', 'DOM-G02'],
      ['STG-G03', '形成办理决定', 'DOM-G02'], ['STG-G04', '实施', 'DOM-G03'], ['STG-G05', '验收办结', 'DOM-G03']
    ];
    m.stages = stageSpecs.map(([id, name, domainId], index) => ({
      id, name, domainId, goal: `${name}并保留案件证据`, input: index ? '上一环节案件记录' : '申请主体提交的事项申请',
      result: `${name}结果`, actorIds: index === 0 ? ['ACTOR-G01', 'ACTOR-G02'] : index === 1 ? ['ACTOR-G03', 'ACTOR-G04', 'ACTOR-G05'] : ['ACTOR-G06'],
      stepIds: [], capabilityIds: m.domains.find(domain => domain.id === domainId).caps
    }));
    const actionSpecs = [
      ['ACT-G001', '接收事项申请', 'STG-G01', 'ACTOR-G01', '提交主体身份、事项申请和法定材料。', []],
      ['ACT-G002', '核验受理条件与材料', 'STG-G01', 'ACTOR-G02', '依法核验主体、职权和材料形式，形成受理或补正意见。', ['RULE-G001']],
      ['ACT-G003', '开展法规审查', 'STG-G02', 'ACTOR-G03', '审查事项设定和办理条件的法规依据。', ['RULE-G001']],
      ['ACT-G004', '组织多部门业务会签', 'STG-G02', 'ACTOR-G04', '按案件职责并行发起部门核查，汇聚独立意见。', []],
      ['ACT-G005', '开展安全评估', 'STG-G02', 'ACTOR-G05', '评估实施风险并记录整改或接受结论。', []],
      ['ACT-G006', '作出决定并组织实施', 'STG-G04', 'ACTOR-G06', '汇总必要审查意见，作出决定并进入实施。', []],
      ['ACT-G007', '核验实施结果并办结', 'STG-G05', 'ACTOR-G06', '满足全部完成条件后验收办结。', []],
      ['ACT-G008', '一次性告知并完成补正', 'STG-G01', 'ACTOR-G02', '列明补正材料和期限，收到补正后重新受理核验。', ['RULE-G001']]
    ];
    actionSpecs.forEach(([id, name, stageId, actorId, purpose, ruleIds], index) => {
      const stepId = `STEP-G${String(index + 1).padStart(3, '0')}`;
      const stage = m.stages.find(item => item.id === stageId); stage.stepIds.push(stepId);
      m.steps.push({ id: stepId, number: index + 1, stageId, actionId: id, name, actorId, kind: id === 'ACT-G002' ? 'decision' : 'action', result: `${name}记录` });
      m.actions.push({
        id, name, version: 'v1.0', status: 'published', actorId, stageId, scenarioId: 'SCN-G001', stepId,
        domainId: stage.domainId, capabilityIds: clone(stage.capabilityIds), depth: 'detailed', purpose,
        pre: ['许可案件已建立且办理人员具备相应职责'], input: ['案件材料', '事项规范', '既有审查意见'],
        output: [`${name}结果与证据`], ruleIds,
        objectChanges: [{ objectId: 'OBJ-G01', before: '办理中', after: id === 'ACT-G007' ? '已验收并办结' : id === 'ACT-G008' ? '待补正或重新受理' : `${name}后的案件状态`, constraint: '状态变化必须保留案件任务和证据链。' }],
        exceptions: [], evidence: ['FACT-G001'], implementation: null
      });
    });
    m.facts = [
      { id: 'FACT-G001', kind: 'specification', source: '行政许可受理审查规范', conclusion: '依法核验主体、职权和材料，补正内容应一次性告知。', status: '已批准', date: '2026-11-14', owner: '周宁', targetId: 'RULE-G001@v1.0' },
      { id: 'FACT-G002', kind: 'implementation', source: '示范办件 G-2026-041 验收记录', conclusion: '法规审查、两个部门会签和安全评估证据均已归档，实施结果满足完成条件。', status: '已核验', date: '2026-11-14', owner: '周宁', targetId: 'ACT-G007' }
    ];
    m.scenarios = [{
      id: 'SCN-G001', name: '行政许可协同办理', version: 'v1.0', status: 'published',
      goal: '沿明确主线完成受理、审查、决定、实施和验收，同时按案件需要动态补正和核查。',
      trigger: '申请主体向有权机关提交行政许可事项申请。',
      participants: m.actors.map(actor => actor.id), result: '全部完成条件满足且证据齐备后验收办结。',
      stageIds: m.stages.map(stage => stage.id), exceptionIds: [], full: true, explore: { ruleIds: ['RULE-G001'] },
      caseModel: {
        completionConditions: [
          '法定受理结论有效',
          '必要法规审查与部门会签意见已形成',
          '安全风险结论及整改要求已处理',
          '实施结果通过验收且全部证据归档'
        ],
        dynamicTasks: [
          '材料补正：材料不齐全或不符合法定形式时按需创建（ACT-G008）',
          '行业主管部门核查：涉及行业准入条件时创建，可与其他核查并行（ACT-G004）',
          '属地部门核查：涉及属地事实确认时创建，不预设先后顺序（ACT-G004）',
          '专项安全核查：实施内容触及安全风险条件时创建（ACT-G005）'
        ],
        evidenceIds: ['FACT-G001', 'FACT-G002', 'SRC-G01'],
        availableActivityIds: ['ACT-G003', 'ACT-G004', 'ACT-G005', 'ACT-G008']
      }
    }];
    const nodes = [{ id: 'GN-START', type: 'start', name: '接收许可申请', stageId: 'STG-G01' }];
    m.actions.forEach(action => nodes.push({ id: `GN-${action.id}`, actionId: action.id, stageId: action.stageId, type: action.id === 'ACT-G002' ? 'decision' : 'action' }));
    nodes.push({ id: 'GN-END', type: 'end', name: '许可案件办结', stageId: 'STG-G05' });
    const main = ['ACT-G001', 'ACT-G002', 'ACT-G003', 'ACT-G004', 'ACT-G005', 'ACT-G006', 'ACT-G007'];
    const edges = [{ id: 'GE-001', from: 'GN-START', to: 'GN-ACT-G001', type: 'next' }];
    main.forEach((actionId, index) => {
      if (index < main.length - 1) edges.push({ id: `GE-${String(index + 2).padStart(3, '0')}`, from: `GN-${actionId}`, to: `GN-${main[index + 1]}`, type: 'next' });
    });
    edges.push({ id: 'GE-009', from: 'GN-ACT-G007', to: 'GN-END', type: 'next' });
    edges.push({ id: 'GE-010', from: 'GN-ACT-G002', to: 'GN-ACT-G008', type: 'error', defaultCollapsed: true, label: '材料需要补正' });
    edges.push({ id: 'GE-011', from: 'GN-ACT-G008', to: 'GN-ACT-G002', type: 'return', defaultCollapsed: true, label: '补正后重新核验' });
    m.flows = [{ id: 'FLOW-G001', scenarioId: 'SCN-G001', nodes, edges }];
    m.surfaces = [
      { id: 'UI-G001', name: '政务受理窗口', domainId: 'DOM-G01', type: '普通页面', actorId: 'ACTOR-G02', sceneIds: ['SCN-G001'], operations: [{ name: '核验受理条件与材料', actionId: 'ACT-G002', states: ['已提交'] }], objectIds: ['OBJ-G01', 'OBJ-G02'], api: 'POST /administrative-cases/{id}/acceptance-review' },
      { id: 'UI-G002', name: '协同审查工作台', domainId: 'DOM-G02', type: '普通页面', actorId: 'ACTOR-G03', sceneIds: ['SCN-G001'], operations: [{ name: '开展法规审查', actionId: 'ACT-G003', states: ['协同核查中'] }, { name: '组织多部门业务会签', actionId: 'ACT-G004', states: ['协同核查中'] }], objectIds: ['OBJ-G01', 'OBJ-G03'], api: 'POST /administrative-cases/{id}/reviews' }
    ];
    m.scale = { actions: m.actions.length, surfaces: m.surfaces.length, note: '8 个动作与 2 个界面均为实际建立的政务办理内容，动态任务不另算固定主线动作。' };
    finalizeLegacy(m);
    enrichProject(m);
    C.registerType(m, {
      id: 'AdministrativeMatter', name: '行政事项', dimension: '政务事项扩展',
      fields: [
        { id: 'matterCode', label: '事项编码', dataType: 'text', required: true },
        { id: 'authority', label: '办理机关', dataType: 'text', required: true },
        { id: 'legalBasis', label: '法规依据', dataType: 'text', required: true },
        { id: 'timeLimitDays', label: '法定办理时限（日）', dataType: 'number', required: false }
      ]
    });
    C.registerType(m, {
      id: 'LegalMaterial', name: '法定材料', dimension: '政务事项扩展',
      fields: [
        { id: 'materialCode', label: '材料编码', dataType: 'text', required: true },
        { id: 'required', label: '是否必需', dataType: 'boolean', required: true },
        { id: 'legalBasis', label: '材料依据', dataType: 'text', required: true },
        { id: 'validDays', label: '有效天数', dataType: 'number', required: false }
      ]
    });
    addKnowledge(m, 'Project', { id: 'KN-G-PROJECT', name: '政务许可协同办理项目', desc: '以明确主线和动态案件任务共同表达行政许可办理。' });
    addKnowledge(m, 'Feature', { id: 'FEAT-G01', name: '动态协同核查', desc: '按案件事实启动补正和多部门任务，不强制彼此先后顺序。', props: { scenarioId: 'SCN-G001' } });
    addKnowledge(m, 'Term', {
      id: 'TERM-G001', name: '申请', desc: '此处指申请主体向有权机关提出许可办理请求及其主体资格语境。',
      props: {
        shortDefinition: '行政相对人向有权机关提出的许可办理请求。', context: '申请主体与受理条件',
        meaning: '申请主体提出办理请求', confusedWith: ['TERM-G002'], applicableVersion: 'v1.0',
        nameSources: [
          { name: '申请', source: 'SRC-G01 · 中华人民共和国行政许可法第三十二条' },
          { name: '许可申请', source: '行政许可受理审查规范 · 受理条件' }
        ]
      }
    });
    addKnowledge(m, 'Term', {
      id: 'TERM-G002', name: '申请', desc: '此处指承办部门在内部流转中形成的业务申请文书，不代表行政相对人主体资格。',
      props: {
        shortDefinition: '承办部门内部流转使用的业务申请文书。', context: '部门内部文书流转',
        meaning: '内部申请文书', confusedWith: ['TERM-G001'], applicableVersion: 'v1.0',
        nameSources: [
          { name: '申请', source: '政务协同办理内部流转规范 · 文书目录' },
          { name: '业务申请单', source: '办件 G-2026-041 · 内部会签卷宗' }
        ]
      }
    });
    addKnowledge(m, 'System', { id: 'SYS-G01', name: '政务服务协同办理系统', desc: '管理事项、案件、动态任务和电子证据。', props: { owner: '政务服务管理处' } });
    addKnowledge(m, 'Module', { id: 'MOD-G01', name: '协同审查模块', desc: '组织法规审查、部门会签和意见归档。', props: { responsibility: '按案件条件创建审查任务并汇聚有依据的独立意见。' } });
    addKnowledge(m, 'API', {
      id: 'API-G01', name: '许可协同审查接口', desc: '提交部门审查意见并读取案件审查上下文。',
      props: {
        method: 'POST', path: '/administrative-cases/{id}/reviews', providerId: 'MOD-G01',
        input: { caseId: '许可案件 ID', reviewType: '审查类型', opinion: '独立审查意见', evidenceIds: '证据 ID 集合' },
        output: { reviewId: '审查记录 ID', status: '审查结论', outstandingTasks: '尚未完成的必要任务' },
        failure: '证据或职责缺失时拒绝提交；任务服务不可用时不生成虚假通过结论。', contractVersion: 'v1.0'
      }
    });
    addKnowledge(m, 'DataEntity', {
      id: 'DATA-G01', name: '许可案件审查数据', desc: '保存案件材料、审查任务和部门意见的证据链。',
      props: {
        tableName: 'administrative_case_review', lifecycle: '案件办结后审查记录与证据转入只读卷宗。', implementationVersion: 'v1.0',
        fields: [
          { name: 'caseId', type: 'text', description: '许可案件稳定 ID' },
          { name: 'matterCode', type: 'text', description: '行政事项编码' },
          { name: 'materials', type: 'json', description: '申请材料及补正版本' },
          { name: 'reviewOpinions', type: 'json', description: '法规、会签与安全审查意见' }
        ]
      }
    });
    addKnowledge(m, 'Configuration', {
      id: 'CFG-G01', name: '许可受理与会签配置', desc: '启用法定受理约束和按职责开展的动态会签。',
      props: {
        source: 'SRC-G01', moduleId: 'MOD-G01', dataType: 'json',
        allowedValues: { requireLegalBasis: [true], countersignMode: ['dynamic-parallel'] },
        defaultValue: { requireLegalBasis: true, countersignMode: 'dynamic-parallel' },
        effectiveWhen: '受理审查和协同审查任务创建时生效。', environments: ['ENV-G-PROD'], regions: ['市级政务服务区'],
        risk: '关闭法规依据核验或将会签固定化会导致违法受理或遗漏必要部门。', configVersion: 'CFG-G-2026.11', verified: true,
        ruleId: 'RULE-G001', ruleVersion: 'v1.0'
      }
    });
    addKnowledge(m, 'Environment', { id: 'ENV-G-PROD', name: '政务办理生产环境', desc: '运行事项库、案件任务引擎和电子材料库。', props: { environment: 'production', region: '市级政务服务区', release: 'v1.0', configVersion: 'CFG-G-2026.11' } });
    addKnowledge(m, 'AdministrativeMatter', {
      id: 'MATTER-G-001', name: '公共文化设施临时使用许可',
      desc: '用于演示主体受理、部门核查、安全评估和验收闭环的行政事项。',
      props: { matterCode: 'GGWH-LS-001', authority: '市公共文化服务管理局', legalBasis: '行政许可法及公共文化设施管理规定', timeLimitDays: 20 }
    });
    addKnowledge(m, 'LegalMaterial', {
      id: 'MATERIAL-G-001', name: '申请主体资格证明',
      desc: '证明申请主体身份、资格和授权关系的法定受理材料。',
      props: { materialCode: 'MAT-SUBJECT-01', required: true, legalBasis: '行政许可受理审查规范第 4 条', validDays: 365 }
    });
    addResource(m, {
      id: 'SRC-G01', name: '中华人民共和国行政许可法', desc: '受理、补正告知和依法审查的法规依据。',
      sensitivity: 'public', permissions: { read: ['*'], edit: ['admin'], approve: ['owner'] },
      props: {
        resourceType: 'legislation', uri: 'https://flk.npc.gov.cn/',
        locator: { path: '中华人民共和国行政许可法', section: '第三十二条' },
        sourceVersion: '现行有效文本', summary: '申请材料处理与一次性告知依据', parseStatus: 'structured', owner: '法规审查处', trust: 'confirmed'
      }
    });
    addRelation(m, 'TERM-G001', 'references', 'MATTER-G-001', { trust: 'confirmed', verified: true });
    addRelation(m, 'TERM-G001', 'references', 'SCN-G001', { trust: 'confirmed', verified: true });
    addRelation(m, 'TERM-G001', 'references', 'RULE-G001', { trust: 'confirmed', verified: true, explanation: '受理规则中的申请采用行政相对人语境。' });
    addRelation(m, 'TERM-G001', 'cites', 'SRC-G01', { trust: 'confirmed', verified: true });
    addRelation(m, 'TERM-G002', 'references', 'SCN-G001', { trust: 'confirmed', verified: true, explanation: '内部申请文书是协同办理中的辅助卷宗，不改变法定受理含义。' });
    addRelation(m, 'RULE-G001', 'explains', 'TERM-G001', { trust: 'confirmed', verified: true, explanation: '规则中的申请指行政相对人提出的办理请求及主体资格。' });
    addRelation(m, 'RULE-G001', 'cites', 'SRC-G01', { trust: 'confirmed', verified: true, explanation: '第三十二条规定申请材料处理与补正告知。' });
    addRelation(m, 'SYS-G01', 'contains', 'MOD-G01', { trust: 'confirmed', verified: true });
    addRelation(m, 'MOD-G01', 'contains', 'API-G01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-G01', 'implements', 'ACT-G003', { trust: 'confirmed', verified: true, sourceId: 'SRC-G01' });
    addRelation(m, 'ACT-G002', 'reads', 'DATA-G01', { trust: 'confirmed', verified: true });
    addRelation(m, 'ACT-G003', 'writes', 'DATA-G01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-G01', 'reads', 'DATA-G01', { trust: 'confirmed', verified: true });
    addRelation(m, 'API-G01', 'writes', 'DATA-G01', { trust: 'confirmed', verified: true });
    addRelation(m, 'CFG-G01', 'affects', 'RULE-G001', { version: 'v1.0', trust: 'confirmed', verified: true });
    addRelation(m, 'CFG-G01', 'references', 'ENV-G-PROD', { trust: 'confirmed', verified: true });
    addRelation(m, 'MATTER-G-001', 'requires', 'MATERIAL-G-001', { trust: 'confirmed', verified: true, sourceId: 'SRC-G01' });
    const definition = defineWorkflow(m, {
      id: 'WFD-G-PERMIT', name: '行政许可审查与实施工作流', version: 'v1.0', purpose: 'case',
      stages: [
        { id: 'WFS-G01', name: '受理审查', role: '窗口受理人员', activityId: 'ACT-G002' },
        { id: 'WFS-G02', name: '法规审查', role: '法规审查人员', parallelGroup: 'legal-review', activityId: 'ACT-G003', required: true },
        { id: 'WFS-G03', name: '业务会签', role: '业务会签部门', parallelGroup: 'legal-review', activityId: 'ACT-G004', participants: ['行业主管部门', '属地管理部门'], description: '必要部门可并行形成独立意见，动态案件不预设部门核查先后。' },
        { id: 'WFS-G04', name: '安全评估', role: '安全评估人员', activityId: 'ACT-G005', required: true },
        { id: 'WFS-G05', name: '实施', role: '事项实施负责人', activityId: 'ACT-G006' },
        { id: 'WFS-G06', name: '验收', role: '事项验收负责人', activityId: 'ACT-G007', description: '全部完成条件满足且证据归档后办结。' }
      ]
    });
    instantiateWorkflow(m, definition, {
      id: 'WFI-G-CASE-041', name: '办件 G-2026-041 协同办理', status: 'completed',
      subjectId: 'MATTER-G-001', currentStageId: null
    });
    m.workspace.readingPaths.find(path => path.role === 'newcomer').steps.push({ label: '区分两种“申请”语境', entityId: 'TERM-G001' });
    m.workspace.readingPaths.find(path => path.role === 'developer').steps.push(
      { label: '检查协同审查接口', entityId: 'API-G01' },
      { label: '核对行政事项类型与法规资源', entityId: 'MATTER-G-001' },
      { label: '阅读行政许可法受理依据', entityId: 'SRC-G01' }
    );
    return m;
  }

  function createBlankProject(id, name, goal, template = 'blank') {
    if (!id || !name) throw new Error('空白项目必须提供 id 和 name');
    const allowed = ['blank', 'software', 'approval', 'manufacturing', 'government'];
    if (!allowed.includes(template)) throw new Error(`未知空白项目模板：${template}`);
    const m = M.createEmptyProject(id, name, goal || '从业务目标开始建立可探索的项目知识。');
    enrichProject(m);
    m.meta.template = template;
    m.workspace.homeSections = {
      blank: ['intro', 'concerns'],
      software: ['intro', 'systems', 'assets', 'concerns'],
      approval: ['intro', 'business', 'assets', 'concerns'],
      manufacturing: ['intro', 'business', 'systems', 'assets', 'concerns'],
      government: ['intro', 'business', 'assets', 'concerns']
    }[template];
    m.workspace.readingPaths = [];
    m.versionLayers = { baseline: `BL-${id}-DRAFT`, release: null, config: null, deployments: [] };
    m.scale = { actions: 0, surfaces: 0, knowledge: 0, note: '模板只调整首页配置；项目没有预填业务、行业知识、资源或固定工作流。' };
    return m;
  }

  function createProjectSet() {
    const approval = enrichProject(M.createMatureProject());
    addApprovalKnowledge(approval);
    const booking = enrichProject(M.createBookingProject());
    addBookingKnowledge(booking);
    return {
      'PRJ-00001': approval,
      'PRJ-00002': booking,
      'PRJ-00003': createManufacturingProject(),
      'PRJ-00004': createGovernmentProject()
    };
  }

  return {
    createProjectSet, enrichProject, createManufacturingProject, createGovernmentProject,
    createBlankProject, addKnowledge, addRelation
  };
});
