/* V9.3 real Chrome file:// business journeys, screenshots, offline and responsive acceptance. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn } = require('node:child_process');
const { pathToFileURL } = require('node:url');
const root = path.join(__dirname, '..'), out = path.join(root, 'artifacts/v9-3-browser');
fs.mkdirSync(out, { recursive: true });
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const chromePath = process.env.CHROME_PATH || ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', path.join(os.homedir(), 'AppData/Local/Google/Chrome/Application/chrome.exe')].find(file => fs.existsSync(file));
if (!chromePath) throw new Error('Set CHROME_PATH to a local Chrome executable');
const profile = path.join(os.tmpdir(), 'opencode', 'atlas-v9-3-chrome-profile');
fs.rmSync(profile, { recursive: true, force: true }); fs.mkdirSync(profile, { recursive: true });
const url = pathToFileURL(path.join(root, 'dist/business-atlas-v9.3.html')).href;
const chrome = spawn(chromePath, ['--headless=new', '--remote-debugging-port=9226', `--user-data-dir=${profile}`, '--no-first-run', '--disable-extensions', '--disable-background-networking', '--window-size=1440,900', url], { stdio: 'ignore' });
const journeys = [], assertions = [];
function check(journey, condition, evidence) { assertions.push({ journey, condition, passed: !!condition, evidence }); if (!condition) throw new Error(`${journey}: ${condition} :: ${JSON.stringify(evidence)}`); }
async function main() {
  let pages;
  for (let attempt = 0; attempt < 100; attempt++) { try { pages = await (await fetch('http://127.0.0.1:9226/json/list')).json(); if (pages?.some(item => item.url.includes('business-atlas-v9.3.html'))) break; } catch (_) { /* Chrome is starting */ } await sleep(100); }
  const page = pages?.find(item => item.type === 'page' && item.url.includes('business-atlas-v9.3.html'));
  if (!page) throw new Error('Chrome V9.3 page did not start');
  const ws = new WebSocket(page.webSocketDebuggerUrl), pending = new Map(), errors = [], requests = [];
  let sequence = 0;
  await new Promise((resolve, reject) => { ws.addEventListener('open', resolve, { once: true }); ws.addEventListener('error', reject, { once: true }); });
  ws.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) { const item = pending.get(message.id); pending.delete(message.id); message.error ? item.reject(new Error(JSON.stringify(message.error))) : item.resolve(message.result); }
    if (message.method === 'Runtime.exceptionThrown') errors.push(message.params.exceptionDetails);
    if (message.method === 'Runtime.consoleAPICalled' && message.params.type === 'error') errors.push(message.params);
    if (message.method === 'Network.requestWillBeSent') requests.push(message.params.request.url);
  });
  const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++sequence; pending.set(id, { resolve, reject }); ws.send(JSON.stringify({ id, method, params })); });
  const evaluate = async expression => {
    const response = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (response.exceptionDetails) throw new Error(JSON.stringify(response.exceptionDetails));
    return response.result.value;
  };
  const waitFor = async expression => { const started = Date.now(); while (Date.now() - started < 15000) { if (await evaluate(`!!(${expression})`)) return; await sleep(50); } throw new Error(`Timed out: ${expression} :: ${await evaluate("location.hash + ' :: ' + document.body.innerText.slice(0,800)")}`); };
  const metrics = (width, height) => send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false });
  const capture = async name => { await evaluate("document.querySelectorAll('.v5-toast').forEach(el=>el.remove())"); const shot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false, fromSurface: true }); fs.writeFileSync(path.join(out, name), Buffer.from(shot.data, 'base64')); };
  const captureElement = async (name, selector) => {
    await evaluate("document.querySelectorAll('.v5-toast').forEach(el=>el.remove())");
    const clip = await evaluate(`(()=>{const r=document.querySelector(${JSON.stringify(selector)}).getBoundingClientRect();return {x:Math.max(0,r.left+scrollX-20),y:Math.max(0,r.top+scrollY-16),width:r.width+40,height:Math.min(r.height+32,1800),scale:1}})()`);
    const shot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true, fromSurface: true, clip }); fs.writeFileSync(path.join(out, name), Buffer.from(shot.data, 'base64'));
  };
  let navigationSequence = 0;
  const go = async (hash, wait) => { const destination = new URL(url); destination.searchParams.set('acceptance', String(++navigationSequence)); destination.hash = hash; await send('Page.navigate', { url: destination.href }); await waitFor(wait); };
  const click = selector => evaluate(`document.querySelector(${JSON.stringify(selector)}).click()`);
  const set = (id, value) => evaluate(`(()=>{const el=document.getElementById(${JSON.stringify(id)});el.value=${JSON.stringify(value)};el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));return el.value})()`);
  await send('Runtime.enable'); await send('Page.enable'); await send('Network.enable'); await metrics(1440, 900);
  await send('Page.reload', { ignoreCache: true }); await waitFor("window.AtlasV93UI && document.querySelectorAll('.v5-nav').length === 6");

  // A · Understand an existing business feature without knowing its Rule ID.
  await go('PRJ-00003/studio/FEAT-M02', "document.querySelector('.v93-decision-card[data-rule=\"RULE-M002\"]')");
  const a = await evaluate("({rules:[...document.querySelectorAll('.v93-decision-card')].map(x=>x.dataset.rule),purpose:document.querySelector('.v93-purpose').innerText,cases:document.querySelectorAll('[data-v93-case]').length,conformance:document.querySelector('.v93-conformance').innerText,types:[...document.querySelectorAll('.v93-decision-table td:nth-child(3) small')].map(x=>x.textContent)})");
  check('A', a.rules.length === 1 && a.rules[0] === 'RULE-M002' && a.purpose.includes('质检员、生产班组长') && a.cases === 4 && a.conformance.includes('已确认一致') && a.types.includes('拒绝或阻止'), a);
  journeys.push({ id: 'A', name: '理解已有业务功能', evidence: a, screenshot: 'A-feature-decision.png' }); await capture('A-feature-decision.png');

  // B · Positive, negative and missing-input cases evaluated by the actual decision engine.
  await go('PRJ-00003/studio/RULE-M002', "document.querySelector('[data-v93-case=\"CASE-M-REG-POS\"]')");
  await click('[data-v93-case="CASE-M-REG-POS"]'); await waitFor("document.querySelector('.v93-evaluation-result header code')?.textContent === 'REGISTER'");
  const positive = await evaluate("document.querySelector('.v93-evaluation-result').innerText"); check('B', positive.includes('允许登记并隔离') && positive.includes('执行业务动作'), positive);
  await evaluate("document.querySelector('.v93-case-section').scrollIntoView({block:'start',behavior:'instant'})"); await capture('B-rule-positive.png');
  await click('[data-v93-case="CASE-M-REG-NEG"]'); await waitFor("document.querySelector('.v93-evaluation-result header code')?.textContent === 'REJECT'");
  const negative = await evaluate("document.querySelector('.v93-evaluation-result').innerText"); check('B', negative.includes('拒绝保存') && negative.includes('拒绝或阻止'), negative);
  await click('[data-v93-case="CASE-M-REG-UNKNOWN"]'); await waitFor("document.querySelector('.v93-evaluation-result header code')?.textContent === 'MISSING_INPUT'");
  const unknown = await evaluate("document.querySelector('.v93-evaluation-result').innerText"); check('B', unknown.includes('无法判断') && unknown.includes('检验依据') && !unknown.includes('允许登记并隔离</'), unknown);
  await evaluate("document.querySelector('.v93-case-section').scrollIntoView({block:'start',behavior:'instant'})"); await capture('B-rule-unknown.png');
  journeys.push({ id: 'B', name: '验证一条业务规则', evidence: { positive, negative, unknown }, screenshot: 'B-rule-unknown.png' });

  // C · Current behavior and mechanism must not become an approved target automatically.
  await go('PRJ-COG93/studio/FEAT-COG-SEARCH', "document.querySelector('.v93-decision-chain .v93-missing')");
  const cTarget = await evaluate("document.querySelector('.v93-conformance').innerText"); check('C', cTarget.includes('缺少已批准目标规范'), cTarget);
  await click('[data-perspective="observed"]'); await waitFor("document.querySelector('.v93-observation-io')");
  const observed = await evaluate("document.querySelector('.v93-observed-list').innerText"); check('C', observed.includes('DOC-123') && observed.includes('DOC-1234') && observed.includes('只能说明当前行为'), observed.slice(0, 500));
  await capture('C-search-observed.png');
  await click('[data-perspective="mechanism"]'); await waitFor("document.querySelector('.v93-mechanism-list')");
  const mechanism = await evaluate("document.querySelector('.v93-mechanism-list').innerText"); check('C', mechanism.includes('full-text token matching') && mechanism.includes('未批准，不得当作目标规则'), mechanism);
  await capture('C-search-mechanism.png');
  journeys.push({ id: 'C', name: '目标与实现差异', evidence: { cTarget, observed: observed.slice(0, 600), mechanism }, screenshot: 'C-search-mechanism.png' });

  // D · Create a requirement, inspect approved knowledge, propose a decision and impact candidates.
  await go('PRJ-00003/tasks', "document.querySelector('[data-action=\"create-task\"]')"); await click('[data-action="create-task"]'); await waitFor("document.querySelector('#v93-task-root')");
  await set('v93-task-root', 'FEAT-M02'); await set('v93-task-title', '调整质量异常登记的批次版本判断'); await set('v93-task-goal', '防止并发批次状态被旧版本异常登记覆盖');
  await set('v93-task-problem', '允许登记分支还需要显式核对预期批次版本，不能只修改接口参数'); await set('v93-task-target', '既有条件成立且预期批次版本匹配时才允许登记并隔离，其他分支保持原规范'); await set('v93-task-source', 'REQ-M93-BROWSER-001');
  await click('[data-action="save-task"]'); await waitFor("document.querySelector('.v93-task-intent') && document.querySelector('.v93-impact-list')");
  const created = await evaluate("({title:document.querySelector('.v6-task-head h2').textContent,current:document.querySelector('.v93-current-target').innerText,impacts:document.querySelectorAll('.v93-impact-list>article').length})");
  check('D', created.title.includes('批次版本') && created.current.includes('异常登记与隔离前置校验') && !created.current.includes('批次放行当前实现观察') && created.impacts > 10, created);
  await click('[data-action="propose-v93-decision"]'); await waitFor("document.querySelector('#v93-change-row')"); await set('v93-change-row', 'MR2-03'); await set('v93-condition-input', 'expectedVersionMatch'); await set('v93-condition-op', 'equals'); await set('v93-condition-value', 'true'); await set('v93-change-outcome', 'REGISTER');
  await set('v93-change-narrative', '生产中、检验依据完整且预期版本匹配时才允许登记并隔离；未命中与异常沿用原规范'); await click('[data-action="save-v93-decision"]'); await waitFor("document.querySelector('.v93-proposal')");
  const proposed = await evaluate("({proposal:document.querySelector('.v93-proposal').innerText,difference:document.querySelector('.v93-difference-grid').innerText,stored:JSON.parse(localStorage.getItem('business-atlas-v9')).projects['PRJ-00003'].tasks[0].semanticContract.targetBehavior.decisionChanges[0]})");
  check('D', proposed.stored.approvalStatus === 'proposed' && proposed.stored.baseVersion && proposed.difference.includes('且 expectedVersionMatch') && proposed.difference.includes('其他判断行、默认分支和异常必须继续成立'), proposed);
  await evaluate("document.querySelector('.v93-task-intent').scrollIntoView({block:'start',behavior:'instant'})"); await capture('D-task-semantic-contract.png');
  await evaluate("document.querySelector('.v93-difference-grid').scrollIntoView({block:'start',behavior:'instant'})"); await capture('D-task-difference-impact.png');
  journeys.push({ id: 'D', name: '新需求与 Task Semantic Contract', evidence: { created, proposed }, screenshot: 'D-task-difference-impact.png' });

  // E · Simulated PR/test/knowledge records remain separate from business approval.
  await click('[data-task="TASK-M93-DELIVERY"]'); await go('PRJ-00003/contracts', "document.querySelector('.v93-delivery') && document.querySelector('.v93-delivery>header').innerText.includes('知识待审批')");
  const delivery = await evaluate("({state:document.querySelector('.v93-delivery>header').innerText,chain:document.querySelector('.v93-delivery-chain').innerText,simulation:document.querySelector('.v93-delivery .v5-note').innerText})");
  check('E', delivery.chain.includes('PR-SIM-M93-REG') && delivery.chain.includes('TEST-SIM-M93-REG') && delivery.chain.includes('KDM-SIM-M93-REG') && delivery.chain.includes('KC-SIM-M93-REG · proposed') && delivery.simulation.includes('模拟交付记录'), delivery);
  await captureElement('E-delivery-knowledge-pending.png', '.v93-delivery');
  await click('[data-action="complete-v93-task"]'); await waitFor("document.querySelector('.v5-modal')?.innerText.includes('尚不能宣称完整交付')");
  const blocked = await evaluate("document.querySelector('.v5-modal').innerText"); check('E', blocked.includes('知识提案和批准基线仍未完成'), blocked);
  await capture('E-completion-blocked.png'); await click('.v5-modal [data-action="close"]');
  journeys.push({ id: 'E', name: '开发完成与知识交付', evidence: { delivery, blocked }, screenshot: 'E-delivery-knowledge-pending.png' });

  // F · Seven real stages, decision references, branches and return flow.
  await go('PRJ-00003/studio/SCN-M001', "document.querySelectorAll('.v93-stage-path>button').length === 7");
  const flow = await evaluate("({stages:[...document.querySelectorAll('.v93-stage-path>button b')].map(x=>x.textContent),rules:[...document.querySelectorAll('.v93-decision-card h3')].map(x=>x.textContent)})");
  check('F', flow.stages.join('、') === '发现质量异常、隔离批次、调查原因、确定处理、返工或报废、复检、放行或终止' && flow.rules.includes('质量处置判断'), flow);
  await click('[data-flow-stage="STG-M06"]'); await waitFor("document.querySelector('.v93-stage-detail')?.innerText.includes('复检不合格，重新确定返工处置')");
  await click('.v93-full-flow>summary');
  const full = await evaluate("({edges:document.querySelectorAll('.v93-flow-edge-table>div').length,text:document.querySelector('.v93-full-flow').innerText,undefinedGroup:document.querySelector('.v93-full-flow').innerText.includes('GROUP-undefined')})");
  check('F', full.edges === 14 && full.text.includes('复检不合格，重新确定返工处置') && !full.undefinedGroup, { edges: full.edges, undefinedGroup: full.undefinedGroup });
  await evaluate("document.querySelector('.v93-flow-explanation').scrollIntoView({block:'start',behavior:'instant'})"); await capture('F-seven-stage-flow.png');
  journeys.push({ id: 'F', name: '真实复杂流程与图形', evidence: { flow, edges: full.edges, returnPreserved: true, undefinedGroup: full.undefinedGroup }, screenshot: 'F-seven-stage-flow.png' });

  const widths = [];
  for (const [width, height] of [[1440, 900], [1280, 800], [1024, 720], [800, 600]]) {
    await metrics(width, height); await evaluate("scrollTo({top:0,behavior:'instant'})");
    const measurement = await evaluate("({documentWidth:document.documentElement.scrollWidth,bodyWidth:document.body.scrollWidth,viewport:innerWidth,graphBounds:[...document.querySelectorAll('.v92-local-diagram')].map(svg=>{const r=svg.getBoundingClientRect();return {left:r.left,right:r.right,width:r.width}})})");
    check('RESPONSIVE', measurement.documentWidth <= width && measurement.bodyWidth <= width, { width, measurement }); widths.push({ width, height, ...measurement });
    if (width === 800) await capture('R-flow-800.png');
  }
  const result = { acceptedAt: new Date().toISOString(), browser: 'Local Google Chrome CDP headless', mode: 'file://', offlineHtml: url, journeys, assertions, widths, externalRequests: requests.filter(value => /^https?:/.test(value)), consoleErrors: errors, screenshots: fs.readdirSync(out).filter(file => file.endsWith('.png')).sort(), independentHumanTester: false };
  check('OFFLINE', result.externalRequests.length === 0, result.externalRequests); check('CONSOLE', errors.length === 0, errors);
  fs.writeFileSync(path.join(out, 'layout-results.json'), JSON.stringify(result, null, 2));
  fs.writeFileSync(path.join(root, 'artifacts/v9-3-browser-results.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ journeys: journeys.map(item => `${item.id}:PASS`), assertions: `${assertions.filter(item => item.passed).length}/${assertions.length}`, widths: widths.map(item => `${item.width}:doc=${item.documentWidth}`), consoleErrors: errors.length, externalRequests: result.externalRequests.length, screenshots: result.screenshots.length }, null, 2));
  ws.close();
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; }).finally(() => { chrome.kill(); });
