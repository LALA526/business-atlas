/* External analysis agent extraction: actual Business Atlas source -> AKP/0.1 + Agent Run evidence. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const root = path.join(__dirname, '..');
const EXTRACTION_TIME = process.env.ATLAS_BUILD_TIME || '2026-11-15T00:00:00.000Z';
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
let gitStart = process.env.ATLAS_GIT_START || 'unknown';
if (gitStart === 'auto') {
  try { gitStart = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim(); } catch (_) { gitStart = 'unknown'; }
}
const sourceDefinitions = {};
function source(sourceId, file, anchor, sourceType = 'source-file') {
  sourceDefinitions[sourceId] = { sourceId, file, anchor, sourceType };
  return sourceId;
}
const S = {
  readme: source('SRC-SELF-README', 'README.md', '# Business Atlas V9'),
  design: source('SRC-SELF-DESIGN', 'docs/v8-design.md', '## 3. Baseline Invariant', 'design-document'),
  dimensions: source('SRC-SELF-DIMENSIONS', 'src/v7-framework.js', 'const DIMENSIONS'),
  schema: source('SRC-SELF-SCHEMA', 'v4-core.js', 'function registerType'),
  commands: source('SRC-SELF-COMMANDS', 'src/v6-core.js', 'const COMMANDS'),
  transaction: source('SRC-SELF-TRANSACTION', 'src/v6-core.js', 'function mutate'),
  publish: source('SRC-SELF-PUBLISH', 'src/v6-core.js', 'function publishRevision'),
  read: source('SRC-SELF-READ', 'src/v8-read.js', 'function context'),
  catalog: source('SRC-SELF-CATALOG', 'src/v8-read.js', 'function resolveCatalog'),
  projection: source('SRC-SELF-PROJECTION', 'src/v6-projection.js', 'function projectKnowledge'),
  access: source('SRC-SELF-ACCESS', 'src/v9-access.js', 'function readEntity'),
  applicability: source('SRC-SELF-APPLICABILITY', 'src/v9-applicability.js', 'function evaluate'),
  akp: source('SRC-SELF-AKP', 'src/v9-akp.js', 'function commitImport'),
  services: source('SRC-SELF-SERVICES', 'src/v9-services.js', 'function ask'),
  feedback: source('SRC-SELF-FEEDBACK', 'src/v9-services.js', 'function createFeedback'),
  agent: source('SRC-SELF-AGENT', 'src/v9-services.js', 'function parseAgentRun'),
  visual: source('SRC-SELF-VISUAL', 'src/v9-services.js', 'function projectView'),
  app: source('SRC-SELF-APP', 'src/v6-app.js', 'function v9Api'),
  ui: source('SRC-SELF-UI', 'src/v9-ui.js', 'function renderImports'),
  model: source('SRC-SELF-MODEL', 'src/v9-model.js', 'const TYPES'),
  build: source('SRC-SELF-BUILD', 'build.js', 'const files ='),
  test8: source('SRC-SELF-TEST-V8', 'tests/v8-acceptance.test.js', "test('V8-07"),
  test9: source('SRC-SELF-TEST-V9', 'tests/v9-acceptance.test.js', "test('V9-19"),
  schemaAkp: source('SRC-SELF-AKP-SCHEMA', 'packages/schema/akp-v0.1.schema.json', '"title": "Atlas Knowledge Package v0.1"', 'json-schema'),
  storage: source('SRC-SELF-STORAGE', 'src/v9-access.js', 'function safePersist'),
  decision93: source('SRC-SELF-DECISION-V93', 'src/v9-3-decision.js', 'function evaluateRule'),
  reading93: source('SRC-SELF-READING-V93', 'src/v9-3-reading.js', 'function decisionProjection'),
  task93: source('SRC-SELF-TASK-V93', 'src/v9-3-task.js', 'function evaluateDelivery'),
  model93: source('SRC-SELF-MODEL-V93', 'src/v9-3-model.js', 'function initProject'),
  ui93: source('SRC-SELF-UI-V93', 'src/v9-3-ui.js', 'function readingWorkbench'),
  test93: source('SRC-SELF-TEST-V93', 'tests/v9-3-acceptance.test.js', "test('V9.3-01")
};
const sources = Object.values(sourceDefinitions).map(definition => {
  const content = read(definition.file), lines = content.split(/\r?\n/), index = lines.findIndex(line => line.includes(definition.anchor));
  if (index < 0) throw new Error(`Source anchor not found: ${definition.file} :: ${definition.anchor}`);
  const start = Math.max(0, index - 1), end = Math.min(lines.length, index + 3);
  return { sourceId: definition.sourceId, sourceType: definition.sourceType, path: definition.file, uri: `workspace://${definition.file}`, revision: `git-start:${gitStart};content-sha256:${sha(content)}`, contentHash: `sha256:${sha(content)}`, lineRange: { start: start + 1, end }, anchor: definition.anchor, excerpt: lines.slice(start, end).join('\n'), captureMethod: 'OpenCode read/grep; Node.js anchor and SHA-256 verification', sensitive: false };
});
const sourceById = Object.fromEntries(sources.map(item => [item.sourceId, item]));
const entities = [], assertions = [];
function entity(stableExternalId, typeId, name, description, categoryAssignments, sourceIds, extra = {}) {
  entities.push({ stableExternalId, typeId, name, description, properties: extra.properties || {}, categoryAssignments, applicableContext: extra.applicableContext || {}, verificationStatus: extra.level || 'observed', sourceIds, sensitivity: extra.sensitivity || 'internal', extra: { ...(extra.extra || {}), ...(typeId === 'Feature' ? { acceptance: extra.acceptance || ['可通过关联测试和真实源码定位复核'], maturity: 'prototype' } : {}) } });
}
function relation(stableExternalId, subject, predicate, object, sourceId, explanation, level = 'observed', qualifiers = {}) {
  const source = sourceById[sourceId]; assertions.push({ stableExternalId, subject, predicate, object, qualifiers: { ...qualifiers, applicableContext: qualifiers.applicableContext || {} }, sourceRefs: [{ sourceId, locator: { path: source.path, lineRange: source.lineRange, anchor: source.anchor } }], verificationStatus: level, explanation });
}
entity('SELF-PROJECT', 'Project', 'Business Atlas — Self Knowledge', '一个实际存在的离线前端原型代码库；以统一认知语法帮助人和 AI 建立、理解、维护和使用复杂软件项目知识，不是生产系统。', ['project.introduction', 'project.scope'], [S.readme, S.design], { level: 'documented_intent', properties: { maturity: 'offline-front-end-prototype', production: false } });
const features = [
  ['SELF-FEAT-WORKSPACE', '统一项目认知工作空间', '项目目录、认知工作台、投影、协作和阅读围绕同一知识身份。', S.app],
  ['SELF-FEAT-CATALOG', '五维项目知识目录', '项目、业务、系统、知识资产、协作治理五个维度及可配置分类解析。', S.dimensions],
  ['SELF-FEAT-SCHEMA', 'Schema 驱动知识创建', '稳定类型、字段校验、通用表单与自定义知识类型复用统一 Command。', S.schema],
  ['SELF-FEAT-COMMAND', '原子知识命令与草稿', 'Command 在暂存工作区校验并一次提交，失败回滚并支持 Undo。', S.transaction],
  ['SELF-FEAT-READ', '统一知识访问边界', '实体、关系、治理记录、问答、图形与契约按项目、版本、权限和适用性读取。', S.access],
  ['SELF-FEAT-APPLICABILITY', '环境与组织适用性判断', '适用、不适用、未知和冲突分离，支持项目自定义维度。', S.applicability],
  ['SELF-FEAT-AKP', '老项目知识包接入', '外部 Agent 整理老项目业务知识并生成 AKP；平台校验、预览、人工确认后进入草稿，不自动逆向仓库。', S.akp],
  ['SELF-FEAT-QA', '角色化可追溯问答', '新人、BA、开发、测试、售前与 Agent 通过确定性查询获得带版本、适用条件和来源的解释。', S.services],
  ['SELF-FEAT-FEEDBACK', '项目反馈处理闭环', '反馈从实际上下文进入分流、Change Set 或任务、实施验收和关闭。', S.feedback],
  ['SELF-FEAT-AGENT', 'Agent 执行证据与知识提案', '导入外部 JSON/JSONL 工具调用、观察、推断、来源和提案，人工复核前不成为批准事实。', S.agent],
  ['SELF-FEAT-VISUAL', '统一知识图文阅读', '业务流程、状态、架构、数据、时序和界面热点从统一模型投影，Mermaid/ASCII 仅作表达。', S.visual],
  ['SELF-FEAT-BASELINE', '不可变知识基线', '对象、断言和流程修订绑定批准快照；后续活动不回写旧基线。', S.publish],
  ['SELF-FEAT-BUILD', '离线单文件构建', '全部运行脚本和样式内联，无外部网络资源，可通过 file:// 打开并校验重建一致性。', S.build],
  ['SELF-FEAT-DECISION', '业务决策链与确定性案例评估', 'Context、Inputs、Preconditions、Evaluation、Priority、Branch、Outcome、Default、Exception、Evidence 共用同一规则语义；缺失和冲突不默认成功。', S.decision93],
  ['SELF-FEAT-CONFORMANCE', '目标规范、当前观察与技术机制对照', '三类事实独立关联，符合性绑定规则、观察、代码版本和证据；技术行为不自动成为批准目标。', S.reading93],
  ['SELF-FEAT-TASK-SEMANTIC', 'Task 业务语义合同与完整影响调查', '新需求引用批准规则版本形成候选变化，逐项记录影响路径、证据、确认状态和处理决定。', S.task93],
  ['SELF-FEAT-DELIVERY-V12', '开发知识同步交付与版本对账', 'PR 候选知识、合并后 Delivery Manifest、测试、批准基线和部署版本分别关联，代码合并不等于知识批准。', S.task93]
];
features.forEach(([id, name, description, src]) => entity(id, 'Feature', name, description, ['business.features'], [src], { acceptance: ['对应实现模块与测试可定位', '能力边界不冒充生产系统'] }));
entity('SELF-SYSTEM', 'System', 'Business Atlas 离线前端原型', '浏览器内运行的模块化 JavaScript 原型，构建为单文件 HTML；没有生产后台。', ['system.systems', 'project.system-overview'], [S.app, S.build]);
const components = [
  ['SELF-COMP-FRAMEWORK', '目录框架模块', 'src/v7-framework.js：五维目录、分类、覆盖与可信状态。', S.dimensions],
  ['SELF-COMP-SCHEMA', 'Schema Registry 模块', 'v4-core.js：核心类型、注册、字段校验与通用知识身份。', S.schema],
  ['SELF-COMP-COMMAND', 'Knowledge Command 模块', 'src/v6-core.js：命令、暂存事务、Change Set、发布与协作。', S.commands],
  ['SELF-COMP-DRAFT', 'Draft Workspace 与版本模块', 'src/v6-core.js：实体/断言/流程草稿、Undo、不可变修订和基线。', S.transaction],
  ['SELF-COMP-READ', 'Read Context 与 Catalog Resolver', 'src/v8-read.js：统一上下文、目录解析、覆盖和上下文缓存。', S.read],
  ['SELF-COMP-ACCESS', 'Knowledge Access Boundary', 'src/v9-access.js：结果协议、授权记录、契约视图、修订事件与安全持久化。', S.access],
  ['SELF-COMP-APPLICABILITY', 'Applicability Evaluator', 'src/v9-applicability.js：维度组合、缺失上下文、冲突和两种使用模式。', S.applicability],
  ['SELF-COMP-PROJECTION', 'Projection Engine', 'src/v6-projection.js：必要依赖闭包、焦点事实和正式任务契约。', S.projection],
  ['SELF-COMP-AKP', 'AKP 导入模块', 'src/v9-akp.js：真实解析、校验、稳定映射、预览、原子草稿提交和撤销。', S.akp],
  ['SELF-COMP-QA', '确定性知识问答模块', 'src/v9-services.js：五类意图、角色化解释、引用、限制与追问。', S.services],
  ['SELF-COMP-FEEDBACK', '反馈闭环模块', 'src/v9-services.js：反馈、分流、转变更/任务与结果关闭。', S.feedback],
  ['SELF-COMP-AGENT', 'Agent Run 记录模块', 'src/v9-services.js：JSON/JSONL、工具摘要、来源、脱敏与待确认问题。', S.agent],
  ['SELF-COMP-VISUAL', '语义图形投影模块', 'src/v9-services.js 与 src/v9-ui.js：模型驱动 SVG、同步焦点、热点与文本导出。', S.visual],
  ['SELF-COMP-APP', '单页工作空间模块', 'src/v6-app.js 与 src/v9-ui.js：项目、目录、导入、问答、反馈、Agent 与图形交互。', S.app],
  ['SELF-COMP-BUILD', '单文件构建模块', 'build.js：按固定模块顺序内联源码与样式并拒绝外部资源。', S.build],
  ['SELF-COMP-TESTS', '自动化验收模块', 'tests：V3–V9 规则、权限、版本、导入、反馈、图形和破坏性回归。', S.test9],
  ['SELF-COMP-DECISION-V93', '业务决策评估器', 'src/v9-3-decision.js：授权、批准状态、适用性、类型化条件、三值逻辑、冲突和来源轨迹。', S.decision93],
  ['SELF-COMP-READING-V93', '业务认知投影模块', 'src/v9-3-reading.js：决策、符合性、Flow 语义守恒和三视角受控投影。', S.reading93],
  ['SELF-COMP-TASK-V93', 'Task 语义与交付闭环模块', 'src/v9-3-task.js：Task Semantic Contract、Impact Investigation 和 V1.2 交付核对。', S.task93],
  ['SELF-COMP-UI-V93', '决策优先阅读与任务交互', 'src/v9-3-ui.js：条件—判断—结果、案例模拟、三视角、影响调查和版本对账。', S.ui93]
];
components.forEach(([id, name, description, src]) => entity(id, 'Component', name, description, ['system.modules', 'system.architecture'], [src], { properties: { responsibility: description, codePaths: [sourceById[src].path] } }));
entity('SELF-TECH-JS', 'Technology', 'JavaScript（无前端框架）', 'UMD 风格内部模块、DOM 和 SVG；未使用 React/Vue 等前端框架。', ['system.technology'], [S.app], { properties: { version: '浏览器 ES2022 子集' } });
entity('SELF-TECH-HTML-CSS', 'Technology', 'HTML / CSS / 内置 SVG', '单文件页面、样式和图形，无外部字体、CDN 或图形运行库。', ['system.technology'], [S.ui, S.visual]);
entity('SELF-RUNTIME-BROWSER', 'Runtime', 'Chromium 浏览器运行时', '实际浏览器验收目标；file:// 离线打开，localStorage 持久化。', ['system.environments', 'system.technology'], [S.storage], { properties: { version: 'OpenCode Chromium / local Chrome' } });
entity('SELF-RUNTIME-NODE', 'Runtime', 'Node.js 构建与测试运行时', '仅使用 Node 内置 fs/path/assert/crypto 等模块；当前实测 v24.21.0。', ['system.technology'], [S.build, S.test9], { properties: { version: '24.21.0' } });
entity('SELF-FRAMEWORK-NONE', 'Framework', '无应用前端框架', '项目刻意保持无 npm 运行依赖的原生 JavaScript 原型。', ['system.technology'], [S.app, S.build], { properties: { version: 'none', runtime: 'browser' } });
entity('SELF-DEP-NODE-BUILTIN', 'Dependency', 'Node.js 内置模块', '构建与测试使用 node:fs、node:path、node:crypto、node:assert；无第三方包。', ['system.technology'], [S.build, S.test9], { properties: { packageName: 'node:*', version: 'Node.js 24.21.0', compatibility: '构建和测试，不是浏览器运行依赖' } });
entity('SELF-BUILD-PIPELINE', 'BuildPipeline', 'Node 单文件重建流水线', '源码提取 → Self AKP → 实际导入器生成 Self 项目 → 模块内联 → SHA-256 重建比对。', ['system.build'], [S.build], { properties: { entry: 'node scripts/extract-self-knowledge.js && node scripts/prepare-self-project.js && node build.js', output: 'dist/business-atlas-v9.3.html' } });
entity('SELF-DEPLOY-FILE', 'DeploymentUnit', '离线 HTML 浏览器运行单元', 'dist/business-atlas-v9.3.html 的本地 file:// 运行；不是生产部署拓扑。', ['system.environments', 'system.deployment'], [S.build, S.storage], { properties: { release: 'prototype-v9', topology: 'single HTML + browser local storage; no server' } });
entity('SELF-DATA-STORE', 'DataEntity', '浏览器本地项目快照', 'store.projects、contexts 和 storageVersion 保存在 business-atlas-v9 localStorage；容量失败显式提示并允许导出备份。', ['system.data', 'system.data-flow'], [S.storage], { properties: { tableName: 'localStorage:business-atlas-v9', fields: [{ name: 'projects', type: 'object', description: '项目、草稿、历史、反馈与执行记录' }], lifecycle: '浏览器本地，非生产数据库' } });
entity('SELF-DATA-AKP', 'DataEntity', 'AKP JSON 知识包文件', '外部交换数据，经非可信输入检查、Schema/引用校验和人工预览后才进入草稿。', ['system.data'], [S.schemaAkp, S.akp], { properties: { tableName: 'file:AKP/0.1 JSON', fields: [{ name: 'manifest', type: 'object', description: '项目与提取 provenance' }] } });
entity('SELF-API-ACCESS', 'API', 'Knowledge Access JavaScript API', '内部 readEntity/listEntities/readRelations/readRecord/readContract 接口；不是 HTTP 或 MCP Server。', ['system.apis'], [S.access], { properties: { method: 'JS', path: 'AtlasV9Access.read*(project, readContext, id)', failure: 'OK/NOT_FOUND/FORBIDDEN/VERSION_UNAVAILABLE/CONTEXT_INSUFFICIENT/APPLICABILITY_UNKNOWN/DATA_INTEGRITY_ERROR' } });
entity('SELF-API-AKP', 'API', 'AKP Import JavaScript API', 'stagePackage → previewImport → commitImport → 既有 ProposeChange/PublishRevision；不是 HTTP 服务。', ['system.apis'], [S.akp], { properties: { method: 'JS', path: 'AtlasV9AKP.stagePackage/commitImport', failure: '校验失败或任一命令失败时原子回滚' } });
const decisions = [
  ['SELF-ADR-UNIFIED', '统一知识而非多套事实库', '目录、问答、反馈、Agent 提案、图形和导入共享实体、断言、来源与版本。', S.projection],
  ['SELF-ADR-COMMAND', '所有知识写入遵守 Command Transaction', '导入和反馈转变更复用暂存工作区与 Change Set，失败原子回滚。', S.transaction],
  ['SELF-ADR-BASELINE', '批准基线不可变且协作历史分离', '旧基线保存当时知识快照，后续反馈、导入和 Agent 活动不能回写。', S.design],
  ['SELF-ADR-FACT-LEVEL', '源码观察不自动升级为批准业务规范', 'Observed、Documented Intent、Inferred、Unknown、Conflicting 分别保存。', S.akp],
  ['SELF-ADR-OFFLINE', '离线单文件与零运行依赖', '原型验证交互与工程约束，不在本轮引入后台、前端框架或外部图形引擎。', S.build],
  ['SELF-ADR-MODULES', '模块化原型边界为未来模块化单体保留', '访问、适用性、导入、协作、投影和 UI 分文件；本轮不开发微服务或生产后台。', S.app],
  ['SELF-ADR-THREE-FACTS', '目标规范、当前行为与技术机制不可混同', '技术观察和源码机制只能支持实现符合性判断，未经业务 Owner 批准不得成为目标规范。', S.reading93],
  ['SELF-ADR-TASK-REFS', 'Task 引用规则版本而不复制规范', 'Task Semantic Contract 保存基线引用与候选差异，历史基线保持不可变，候选决策必须独立批准。', S.task93]
];
decisions.forEach(([id, name, description, src]) => entity(id, 'ArchitectureDecision', name, description, ['system.decisions', 'assets.decisions'], [src], { level: 'documented_intent', properties: { status: 'accepted', decision: name, rationale: description, consequences: '正式开发必须保留对应不变量并验证真实系统边界。' } }));
entity('SELF-CONV-OFFLINE', 'EngineeringConvention', '无外部运行资源与可重复构建', '核心脚本和样式内联；构建产物 SHA-256 必须与干净重建一致。', ['system.decisions', 'assets.conventions'], [S.build], { level: 'documented_intent', properties: { scope: '全部单文件交付', verification: 'node build.js + clean rebuild SHA-256' } });
entity('SELF-CONV-TESTS', 'EngineeringConvention', '既有测试继续执行且不得删除失败检查', 'V3–V8 回归与 V9 权限、破坏性导入和浏览器旅程共同验收。', ['system.decisions', 'governance.acceptance'], [S.test8, S.test9], { level: 'documented_intent', properties: { scope: '每次交付', verification: 'Node 全量测试 + Chromium 五条旅程' } });
entity('SELF-TEST-BASELINE', 'Test', '历史基线不可变回归', 'V8 SHA-256 基线测试与 V9 后续活动测试验证旧批准快照不被修改。', ['governance.acceptance'], [S.test8], { properties: { command: 'node tests/v8-acceptance.test.js && node tests/v9-acceptance.test.js', coverageScope: '初始化、发布、反馈、Agent、导入和布局', expected: '旧基线 digest 不变' } });
entity('SELF-TEST-AKP', 'Test', 'AKP 重复导入与原子失败回归', '验证稳定外部 ID、无效引用、危险输入、无部分草稿和人工发布。', ['governance.acceptance'], [S.test9], { properties: { command: 'node tests/v9-acceptance.test.js', coverageScope: 'AKP 解析、预览、提交、撤销、发布', expected: '重复不重复、失败无部分写入' } });
entity('SELF-TEST-ACCESS', 'Test', '跨入口权限与适用性回归', '验证直接 ID、关系、契约、问答和图形的授权，以及生产/测试/未知条件。', ['governance.acceptance'], [S.access, S.applicability], { properties: { command: 'node tests/v9-acceptance.test.js', coverageScope: '权限、环境、版本与用途', expected: '无衍生泄露，未知不默认适用' } });
entity('SELF-TEST-V93', 'Test', 'V9.3 业务认知与交付闭环回归', '覆盖条件求值、符合性、Task 语义、影响闭合、Flow 图形、权限、版本与导出。', ['governance.acceptance'], [S.test93], { properties: { command: 'node tests/v9-3-acceptance.test.js', coverageScope: '55 项指定语义验收及浏览器旅程', expected: '明确条件可判断，未知不伪造；实现、测试、知识与审批相互追溯' } });
entity('SELF-CONFIG-STORAGE', 'Configuration', '浏览器本地存储配置', 'business-atlas-v9；仅存少量项目数据，图片和大型日志受容量限制。', ['system.config'], [S.storage], { applicableContext: { environment: 'browser-local', systemVersion: 'v9' }, properties: { dataType: 'text', defaultValue: 'business-atlas-v9', effectiveWhen: '离线浏览器原型', configVersion: 'v9' } });
entity('SELF-ENV-BROWSER', 'Environment', '本地浏览器原型环境', '唯一明确实现的运行环境；生产部署环境未知。', ['system.environments'], [S.storage, S.build], { applicableContext: { environment: 'browser-local' }, properties: { region: 'local-user-browser', release: 'v9-prototype', configVersion: 'v9' } });
relation('SELF-REL-SYSTEM-PROJECT', 'SELF-SYSTEM', 'references', 'SELF-PROJECT', S.app, '离线前端原型承载 Self Knowledge 项目认知');
relation('SELF-REL-SYSTEM-CATALOG', 'SELF-SYSTEM', 'contains', 'SELF-COMP-FRAMEWORK', S.dimensions, '五维目录属于同一系统');
relation('SELF-REL-SYSTEM-COMMAND', 'SELF-SYSTEM', 'contains', 'SELF-COMP-COMMAND', S.commands, 'Command 属于同一系统');
relation('SELF-REL-SYSTEM-READ', 'SELF-SYSTEM', 'contains', 'SELF-COMP-READ', S.read, 'Read Context 与目录读取');
relation('SELF-REL-SYSTEM-ACCESS', 'SELF-SYSTEM', 'contains', 'SELF-COMP-ACCESS', S.access, '统一访问边界');
relation('SELF-REL-SYSTEM-AKP', 'SELF-SYSTEM', 'contains', 'SELF-COMP-AKP', S.akp, 'AKP 导入组件');
relation('SELF-REL-SYSTEM-APP', 'SELF-SYSTEM', 'contains', 'SELF-COMP-APP', S.app, '工作空间 UI');
relation('SELF-REL-SYSTEM-BUILD', 'SELF-SYSTEM', 'contains', 'SELF-COMP-BUILD', S.build, '构建组件');
const componentFeature = {
  'SELF-COMP-FRAMEWORK': 'SELF-FEAT-CATALOG', 'SELF-COMP-SCHEMA': 'SELF-FEAT-SCHEMA', 'SELF-COMP-COMMAND': 'SELF-FEAT-COMMAND', 'SELF-COMP-DRAFT': 'SELF-FEAT-COMMAND', 'SELF-COMP-READ': 'SELF-FEAT-READ', 'SELF-COMP-ACCESS': 'SELF-FEAT-READ', 'SELF-COMP-APPLICABILITY': 'SELF-FEAT-APPLICABILITY', 'SELF-COMP-PROJECTION': 'SELF-FEAT-WORKSPACE', 'SELF-COMP-AKP': 'SELF-FEAT-AKP', 'SELF-COMP-QA': 'SELF-FEAT-QA', 'SELF-COMP-FEEDBACK': 'SELF-FEAT-FEEDBACK', 'SELF-COMP-AGENT': 'SELF-FEAT-AGENT', 'SELF-COMP-VISUAL': 'SELF-FEAT-VISUAL', 'SELF-COMP-APP': 'SELF-FEAT-WORKSPACE', 'SELF-COMP-BUILD': 'SELF-FEAT-BUILD', 'SELF-COMP-TESTS': 'SELF-FEAT-BASELINE', 'SELF-COMP-DECISION-V93': 'SELF-FEAT-DECISION', 'SELF-COMP-READING-V93': 'SELF-FEAT-CONFORMANCE', 'SELF-COMP-TASK-V93': 'SELF-FEAT-TASK-SEMANTIC', 'SELF-COMP-UI-V93': 'SELF-FEAT-DECISION'
};
Object.entries(componentFeature).forEach(([component, feature], index) => relation(`SELF-REL-IMPLEMENT-${index}`, component, 'implements', feature, entities.find(entity => entity.stableExternalId === component).sourceIds[0], '组件职责支撑对应原型功能'));
['SELF-COMP-ACCESS', 'SELF-COMP-AKP', 'SELF-COMP-QA', 'SELF-COMP-FEEDBACK', 'SELF-COMP-AGENT', 'SELF-COMP-VISUAL', 'SELF-COMP-APP', 'SELF-COMP-DECISION-V93', 'SELF-COMP-READING-V93', 'SELF-COMP-TASK-V93', 'SELF-COMP-UI-V93'].forEach((component, index) => relation(`SELF-REL-USES-JS-${index}`, component, 'uses', 'SELF-TECH-JS', entities.find(entity => entity.stableExternalId === component).sourceIds[0], '直接由 JavaScript 模块实现'));
relation('SELF-REL-FRAMEWORK-DEP', 'SELF-FRAMEWORK-NONE', 'dependsOn', 'SELF-DEP-NODE-BUILTIN', S.build, '仅构建和测试依赖 Node 内置模块；浏览器无第三方运行依赖');
relation('SELF-REL-DEPLOY-HOSTS', 'SELF-DEPLOY-FILE', 'hosts', 'SELF-COMP-APP', S.build, '离线 HTML 承载工作空间，不代表生产部署');
relation('SELF-REL-ACCESS-EXPOSES', 'SELF-COMP-ACCESS', 'exposes', 'SELF-API-ACCESS', S.access, '内部 JavaScript 读取接口');
relation('SELF-REL-AKP-EXPOSES', 'SELF-COMP-AKP', 'exposes', 'SELF-API-AKP', S.akp, '内部 JavaScript 导入接口');
relation('SELF-REL-APP-WRITES', 'SELF-COMP-APP', 'writes', 'SELF-DATA-STORE', S.storage, '浏览器本地快照写入');
relation('SELF-REL-APP-READS', 'SELF-COMP-APP', 'reads', 'SELF-DATA-STORE', S.storage, '刷新后恢复项目快照');
relation('SELF-REL-AKP-READS', 'SELF-COMP-AKP', 'reads', 'SELF-DATA-AKP', S.akp, '读取非可信 AKP JSON 文件');
relation('SELF-REL-BUILD-OUTPUT', 'SELF-BUILD-PIPELINE', 'contains', 'SELF-DEPLOY-FILE', S.build, '构建产物为离线 HTML 运行单元');
decisions.forEach(([id, , , src], index) => relation(`SELF-REL-ADR-${index}`, id, 'constrains', index === 2 ? 'SELF-COMP-DRAFT' : index === 3 ? 'SELF-COMP-AKP' : index === 4 ? 'SELF-COMP-BUILD' : 'SELF-COMP-APP', src, '已记录设计决策约束对应实现'));
relation('SELF-REL-TEST-BASELINE', 'SELF-TEST-BASELINE', 'verifies', 'SELF-FEAT-BASELINE', S.test8, '测试验证基线不可变');
relation('SELF-REL-TEST-AKP', 'SELF-TEST-AKP', 'verifies', 'SELF-FEAT-AKP', S.test9, '测试验证知识导入');
relation('SELF-REL-TEST-ACCESS', 'SELF-TEST-ACCESS', 'verifies', 'SELF-FEAT-READ', S.access, '测试验证统一访问与适用性');
relation('SELF-REL-TEST-V93-DECISION', 'SELF-TEST-V93', 'verifies', 'SELF-FEAT-DECISION', S.test93, 'V9.3 测试验证业务决策与案例');
relation('SELF-REL-TEST-V93-TASK', 'SELF-TEST-V93', 'verifies', 'SELF-FEAT-TASK-SEMANTIC', S.test93, 'V9.3 测试验证任务语义与完整影响');
relation('SELF-REL-TEST-V93-DELIVERY', 'SELF-TEST-V93', 'verifies', 'SELF-FEAT-DELIVERY-V12', S.test93, 'V9.3 测试验证知识交付与版本对账');
relation('SELF-REL-CONFIG-APP', 'SELF-CONFIG-STORAGE', 'affects', 'SELF-COMP-APP', S.storage, '浏览器存储键与容量策略影响应用持久化', 'observed', { environment: 'browser-local', businessScope: 'offline-prototype', configVersion: 'v9', applicableContext: { environment: 'browser-local', businessScope: 'offline-prototype', configurationVersion: 'v9' } });
const treeDigest = sha(sources.map(item => `${item.path}:${item.contentHash}`).sort().join('\n'));
const pack = { manifest: { formatVersion: 'AKP/0.1', packageId: 'AKP-BUSINESS-ATLAS-SELF-001', sourceProjectId: 'BUSINESS-ATLAS-SELF', projectName: 'Business Atlas — Self Knowledge', generatedAt: EXTRACTION_TIME, producer: { kind: 'external-agent', identity: 'OpenCode Kimi K3.1 Pro source analysis', model: 'k3.1-pro', provider: 'kimi-code-plan-cn' }, sourceRevision: `git-start:${gitStart};working-tree-sha256:${treeDigest}`, importPurpose: '以 Business Atlas 自身真实源码验证最小知识接入、阅读、问答和工程追踪', declaredScope: ['当前工作区实际前端源码', 'V3–V9 测试与构建', '明确未实现的生产能力边界'] }, entities, assertions, businessStructures: { actions: [], decisions: [], events: [], flows: [], transitions: [], rules: [], constraints: decisions.map(item => item[0]) }, technicalStructures: { systems: ['SELF-SYSTEM'], components: components.map(item => item[0]), frameworks: ['SELF-FRAMEWORK-NONE'], dependencies: ['SELF-DEP-NODE-BUILTIN'], apis: ['SELF-API-ACCESS', 'SELF-API-AKP'], dataEntities: ['SELF-DATA-STORE', 'SELF-DATA-AKP'], configurations: ['SELF-CONFIG-STORAGE'], environments: ['SELF-ENV-BROWSER'], architectureDecisions: decisions.map(item => item[0]), architectureRevision: `arch-working:${treeDigest.slice(0, 16)}`, codeRevision: `working:${treeDigest}`, dependencyVersions: { node: '24.21.0', npmRuntimeDependencies: '0' }, deploymentVersion: null, runtimeConfiguration: { storageKey: 'business-atlas-v9', production: false } }, sources, unknownsAndConflicts: [
  { id: 'UNK-SELF-BACKEND', kind: 'unknown', title: '生产后台与生产数据库未实现', description: '当前只有浏览器 localStorage；正式存储、并发、事务和审计需要后续开发。', relatedExternalIds: ['SELF-DATA-STORE'], status: 'open', blocksFormal: false },
  { id: 'UNK-SELF-AUTH', kind: 'unknown', title: '企业身份认证与正式权限系统未实现', description: '当前权限是前端模拟访问规则，不是生产安全边界。', relatedExternalIds: ['SELF-COMP-ACCESS'], status: 'open', blocksFormal: false },
  { id: 'UNK-SELF-MCP', kind: 'unknown', title: '真实 MCP Server、MCP Client 和 LLM 推理未实现', description: '当前仅导入外部 Agent 记录并进行确定性问答。', relatedExternalIds: ['SELF-COMP-AGENT', 'SELF-COMP-QA'], status: 'open', blocksFormal: false },
  { id: 'UNK-SELF-REPO', kind: 'unknown', title: '任意老项目自动逆向和真实仓库同步未实现', description: 'Self 包来自本次受控外部分析，不代表通用自动逆向引擎。', relatedExternalIds: ['SELF-FEAT-AKP'], status: 'open', blocksFormal: false },
  { id: 'UNK-SELF-DEPLOY', kind: 'unknown', title: '生产部署架构与运行监控未知', description: '源码只证明离线 HTML 运行，没有生产基础设施、部署版本或监控资料。', relatedExternalIds: ['SELF-DEPLOY-FILE'], status: 'open', blocksFormal: false },
  { id: 'UNK-SELF-MULTIUSER', kind: 'unknown', title: '多人实时协作与生产级审计未实现', description: '反馈和 Agent 记录为单浏览器原型，需正式系统验证并发与审计。', relatedExternalIds: ['SELF-COMP-FEEDBACK'], status: 'open', blocksFormal: false }
], importProvenance: { agentRunId: 'RUN-SELF-ANALYSIS-001', toolExecutionRefs: ['TC-SELF-READ', 'TC-SELF-GREP', 'TC-SELF-TEST', 'TC-SELF-HASH'], sourceFileRevisions: Object.fromEntries(sources.map(item => [item.path, item.revision])), extractedAt: EXTRACTION_TIME, extractionStrategy: '外部分析 Agent 使用 read/grep/shell 定位真实源码，再以锚点、行范围、内容哈希和显式未知生成 AKP；不按名称猜测业务规范' } };
const run = { runId: 'RUN-SELF-ANALYSIS-001', projectId: 'PRJ-SELF', taskId: 'TASK-SELF-KNOWLEDGE', agentIdentity: 'OpenCode Kimi K3.1 Pro source analysis', model: 'k3.1-pro', provider: 'kimi-code-plan-cn', startTime: pack.manifest.generatedAt, endTime: pack.importProvenance.extractedAt, status: 'completed', simulated: false, evidenceClassification: 'reconstructed-analysis-record', rawCaptured: false, verification: { scriptExecution: true, sourceHashVerified: true, rawToolLogsAvailable: false, note: '真实源码、定位与哈希可验证；部分工具摘要由脚本事后组织，不冒充原始运行时工具日志。' }, userInstructions: '阅读当前 Business Atlas 工作区真实源码，形成可核验 AKP，明确观察、设计意图与未实现能力。', executionEvents: [
  { eventId: 'EV-SELF-PLAN', at: pack.manifest.generatedAt, type: 'plan', recordType: 'reconstructed-analysis-record', content: '定位 V8 基线 → 阅读模型/Core/Read/Projection/UI/测试 → 运行基线 → 提取 V9 技术与协作知识 → 生成并验证 AKP。' },
  { eventId: 'EV-SELF-OBSERVE', at: pack.manifest.generatedAt, type: 'observation', recordType: 'verified-source-observation', content: `直接观察 ${sources.length} 份源码/文档/测试来源，${entities.length} 个知识对象；所有来源锚点均由脚本定位。`, sourceRefs: [{ resourceId: 'SRC-SELF-ACCESS', locator: sourceById['SRC-SELF-ACCESS'].lineRange }] },
  { eventId: 'EV-SELF-INFER', at: pack.manifest.generatedAt, type: 'inference', recordType: 'reconstructed-analysis-record', content: '架构职责映射是根据模块导出、调用与文档作出的受控分析；不将代码存在自动视为批准业务规范。' },
  { eventId: 'EV-SELF-PROPOSAL', at: pack.manifest.generatedAt, type: 'proposal', recordType: 'knowledge-proposal', content: `形成 ${assertions.length} 条关系提案与 ${pack.unknownsAndConflicts.length} 项明确未知，等待导入预览和人工审核。` },
  { eventId: 'EV-SELF-OUTCOME', at: pack.importProvenance.extractedAt, type: 'outcome', recordType: 'verified-script-execution', content: 'AKP JSON 与执行记录已生成；后续由同一 AtlasV9AKP 导入器写入 Self Knowledge 草稿。' }
], toolCalls: [
  { toolCallId: 'TC-SELF-READ', recordType: 'reconstructed-analysis-record', rawCaptured: false, provider: 'opencode', server: 'local-workspace', toolName: 'functions.read', startedAt: pack.manifest.generatedAt, completedAt: pack.manifest.generatedAt, status: 'completed', inputSummary: 'README, model, core, read, projection, UI, tests', outputSummary: `读取并核对 ${sources.length} 个来源定位`, referencedResources: sources.map(item => ({ resourceId: item.sourceId, path: item.path, lineRange: item.lineRange })), sourceAnchors: sources.map(item => ({ path: item.path, lineRange: item.lineRange })) },
  { toolCallId: 'TC-SELF-GREP', recordType: 'reconstructed-analysis-record', rawCaptured: false, provider: 'opencode', server: 'local-workspace', toolName: 'functions.grep', startedAt: pack.manifest.generatedAt, completedAt: pack.manifest.generatedAt, status: 'completed', inputSummary: '定位 Schema、Command、Read Context、Baseline、测试和视觉对象锚点', outputSummary: '锚点存在性验证通过', sourceAnchors: sources.map(item => ({ path: item.path, anchor: item.anchor })) },
  { toolCallId: 'TC-SELF-TEST', recordType: 'verified-script-execution', rawCaptured: false, provider: 'opencode', server: 'local-shell', toolName: 'functions.shell', startedAt: pack.manifest.generatedAt, completedAt: pack.manifest.generatedAt, status: 'completed', inputSummary: 'node acceptance.test.js / V4–V9 tests', outputSummary: 'V3–V8 基线 198/198；V9 结果以最终 artifacts/v9-test-results.json 为准', sourceAnchors: [{ path: 'artifacts/v9-test-results.json' }] },
  { toolCallId: 'TC-SELF-HASH', recordType: 'verified-script-execution', rawCaptured: false, provider: 'opencode', server: 'local-shell', toolName: 'node:crypto', startedAt: pack.manifest.generatedAt, completedAt: pack.importProvenance.extractedAt, status: 'completed', inputSummary: 'SHA-256 source files and sorted source revision set', outputSummary: treeDigest, sourceAnchors: sources.map(item => ({ path: item.path, contentHash: item.contentHash })) }
], sourceRefs: sources.map(item => ({ resourceId: item.sourceId, locator: { path: item.path, lineRange: item.lineRange } })), proposedKnowledge: [...entities.map(entity => ({ entityId: entity.stableExternalId, name: entity.name, verificationStatus: entity.verificationStatus, recordType: 'knowledge-proposal', explanation: entity.description })), ...assertions.map(assertion => ({ assertionId: assertion.stableExternalId, subject: assertion.subject, predicate: assertion.predicate, object: assertion.object, verificationStatus: assertion.verificationStatus, recordType: 'knowledge-proposal', explanation: assertion.explanation }))], unresolvedQuestions: pack.unknownsAndConflicts.map(item => ({ title: item.title, impact: item.description, relatedIds: item.relatedExternalIds })), outcome: '真实源码 AKP 已生成，尚未由工具记录本身批准任何事实。', reviewStatus: 'pending', importProposalId: null };
fs.mkdirSync(path.join(root, 'packages'), { recursive: true });
fs.writeFileSync(path.join(root, 'packages/business-atlas-self.akp.json'), JSON.stringify(pack, null, 2));
fs.writeFileSync(path.join(root, 'packages/agent-run-self-analysis.json'), JSON.stringify(run, null, 2));
fs.writeFileSync(path.join(root, 'src/v9-self-package.js'), `/* Generated by scripts/extract-self-knowledge.js from actual workspace sources. */\nglobalThis.AtlasV9SelfPackage = ${JSON.stringify(pack)};\n`);
console.log(`Extracted ${entities.length} entities, ${assertions.length} assertions, ${sources.length} actual sources; tree ${treeDigest}`);
