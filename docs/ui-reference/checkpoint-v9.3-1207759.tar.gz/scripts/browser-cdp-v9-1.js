/* V9.1 real Chrome file:// screenshots and two-width layout acceptance, no npm dependencies. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const out = path.join(__dirname, '../artifacts/v9-1-browser');
fs.mkdirSync(out, { recursive: true });
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function main() {
  const pages = await (await fetch('http://localhost:9224/json/list')).json();
  const page = pages.find(item => item.type === 'page' && item.url.includes('business-atlas-v9.1.html'));
  if (!page) throw new Error('Open V9.1 in Chrome with --remote-debugging-port=9224');
  const ws = new WebSocket(page.webSocketDebuggerUrl), pending = new Map(), errors = [], requests = [];
  let sequence = 0;
  await new Promise((resolve, reject) => { ws.addEventListener('open', resolve, { once: true }); ws.addEventListener('error', reject, { once: true }); });
  ws.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) { const item = pending.get(message.id); pending.delete(message.id); message.error ? item.reject(new Error(JSON.stringify(message.error))) : item.resolve(message.result); }
    if (message.method === 'Runtime.exceptionThrown') errors.push(message.params.exceptionDetails);
    if (message.method === 'Runtime.consoleAPICalled' && message.params.type === 'error') errors.push(message.params);
    if (message.method === 'Network.requestWillBeSent') requests.push(message.params.request.url);
  });
  const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++sequence; pending.set(id, { resolve, reject }); ws.send(JSON.stringify({ id, method, params })); });
  const evaluate = async expression => (await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })).result.value;
  const waitFor = async expression => { const started = Date.now(); while (Date.now() - started < 10000) { if (await evaluate(`!!(${expression})`)) return; await sleep(50); } throw new Error(`Timed out: ${expression} :: ${await evaluate("location.hash + ' :: ' + document.body.innerText.slice(0,700)")}`); };
  const metrics = (width, height) => send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false });
  const capture = async name => { const shot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false }); fs.writeFileSync(path.join(out, name), Buffer.from(shot.data, 'base64')); };
  await send('Runtime.enable'); await send('Page.enable'); await send('Network.enable'); await metrics(1440, 900);
  await send('Page.reload', { ignoreCache: true }); await waitFor("window.AtlasV91UI && document.querySelectorAll('.v5-nav').length === 8");
  await evaluate("location.hash='PRJ-SELF/home'"); await waitFor("document.querySelector('.v91-home-grid')");
  await capture('A-G-self-home-desktop.png');
  await evaluate("location.hash='PRJ-00003/home'"); await waitFor("document.querySelector('[data-action=\"open-assistant\"]')");
  await evaluate("document.querySelector('[data-action=\"open-assistant\"]').click();document.querySelector('#assistant-input').value='这个系统的质量异常登记功能有什么使用限制？';document.querySelector('#assistant-form button').click()");
  await waitFor("document.querySelector('.v91-answer-card')?.innerText.includes('质量异常登记与批次隔离')"); await capture('B-assistant-desktop.png');
  await evaluate("location.hash='PRJ-SELF/tasks'"); await waitFor("document.querySelector('[data-collab-tab=\"activity\"]')");
  await evaluate("document.querySelector('[data-collab-tab=\"activity\"]').click()"); await waitFor("document.querySelector('.v9-agent-run')");
  await capture('E-task-activity.png');
  await evaluate("document.querySelector('[data-action=\"close-assistant\"]')?.click();location.hash='PRJ-00003/studio/SCN-M001'"); await waitFor("document.querySelector('[data-studio-presentation=\"VIEW-M-FLOW\"]')");
  await evaluate("document.querySelector('[data-studio-presentation=\"VIEW-M-FLOW\"]').click();document.querySelector('[data-visual-focus=\"ACT-M005\"]').click()");
  await waitFor("document.querySelector('.v6-inspector')?.innerText.includes('执行质量处置判断')"); await capture('F-visual-workbench.png');
  await evaluate("location.hash='PRJ-00003/home';document.querySelector('[data-action=\"open-assistant\"]').click()");
  await metrics(1024, 720); await capture('B-assistant-1024.png');
  await metrics(800, 600); await capture('B-assistant-800.png');
  const layout = await evaluate(`(()=>{const panel=document.querySelector('.v91-assistant').getBoundingClientRect(),close=document.querySelector('[data-action="close-assistant"]').getBoundingClientRect();return {viewport:{width:innerWidth,height:innerHeight},panel:{left:panel.left,right:panel.right,top:panel.top,bottom:panel.bottom},close:{left:close.left,right:close.right,top:close.top,bottom:close.bottom},navCount:document.querySelectorAll('.v5-nav').length,assistantOpen:!!document.querySelector('.v91-assistant')}})()`);
  if (layout.close.left < 0 || layout.close.right > layout.viewport.width || layout.close.top < 0 || layout.close.bottom > layout.viewport.height) throw new Error('Assistant close action is not recoverable at 800px');
  const result = { acceptedAt: new Date().toISOString(), browser: 'Local Google Chrome CDP', mode: 'file://', desktop: [1440, 900], laptop: [1024, 720], narrow: [800, 600], layout, externalRequests: requests.filter(url => /^https?:/.test(url)), consoleErrors: errors, screenshots: ['A-G-self-home-desktop.png', 'B-assistant-desktop.png', 'E-task-activity.png', 'F-visual-workbench.png', 'B-assistant-1024.png', 'B-assistant-800.png'] };
  fs.writeFileSync(path.join(out, 'layout-results.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ mode: result.mode, layout, consoleErrors: errors.length, externalRequests: result.externalRequests.length }, null, 2));
  ws.close(); if (errors.length) process.exitCode = 1;
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; });
