/* Optional real-Chrome file:// acceptance over CDP, no npm dependencies. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const outputDir = path.join(__dirname, '../artifacts/v9-browser');
fs.mkdirSync(outputDir, { recursive: true });
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function main() {
  const pages = await (await fetch('http://localhost:9223/json/list')).json();
  const page = pages.find(item => item.type === 'page' && item.url.startsWith('file:///') && item.url.includes('business-atlas-v9.html'));
  if (!page) throw new Error('Open business-atlas-v9.html in Chrome with --remote-debugging-port=9223 first');
  const ws = new WebSocket(page.webSocketDebuggerUrl), pending = new Map(), errors = [], requests = [];
  let sequence = 0;
  await new Promise((resolve, reject) => { ws.addEventListener('open', resolve, { once: true }); ws.addEventListener('error', reject, { once: true }); });
  ws.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) { const { resolve, reject } = pending.get(message.id); pending.delete(message.id); message.error ? reject(new Error(JSON.stringify(message.error))) : resolve(message.result); }
    if (message.method === 'Runtime.exceptionThrown') errors.push(message.params.exceptionDetails);
    if (message.method === 'Runtime.consoleAPICalled' && message.params.type === 'error') errors.push(message.params);
    if (message.method === 'Network.requestWillBeSent') requests.push(message.params.request.url);
  });
  const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++sequence; pending.set(id, { resolve, reject }); ws.send(JSON.stringify({ id, method, params })); });
  const evaluate = async expression => (await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })).result.value;
  const waitFor = async expression => { const started = Date.now(); while (Date.now() - started < 10000) { if (await evaluate(`!!(${expression})`)) return; await sleep(50); } throw new Error(`Timed out: ${expression}`); };
  await send('Runtime.enable'); await send('Page.enable'); await send('Network.enable');
  await send('Page.reload', { ignoreCache: true });
  await waitFor("document.querySelector('#app')?.innerText.includes('Business Atlas') && window.AtlasV9AKP");
  const initial = await evaluate(`({url:location.href,title:document.title,project:document.querySelector('.v5-project b')?.textContent,storageCharacters:localStorage.getItem('business-atlas-v9')?.length || 0,externalResources:[...document.querySelectorAll('script[src],link[href],img[src]')].map(e=>e.src||e.href).filter(x=>/^https?:/.test(x)),selfProof:AtlasV9SelfProject.proof})`);
  if (!initial.url.startsWith('file:///')) throw new Error('Not file://');
  if (initial.externalResources.length) throw new Error('External resources detected');
  await evaluate("location.hash='PRJ-SELF/ask'"); await waitFor("document.querySelector('#ask-form')");
  await evaluate("document.querySelector('#ask-role').value='presales';document.querySelector('#ask-intent').value='REQUIREMENT';document.querySelector('#ask-input').value='这个系统能否管理老项目的业务知识？';document.querySelector('#ask-form button').click()");
  await waitFor("document.querySelector('.v9-answer')?.innerText.includes('特定条件支持')");
  const question = await evaluate("({answer:document.querySelector('.v9-answer').innerText,answers:JSON.parse(localStorage.getItem('business-atlas-v9')).projects['PRJ-SELF'].questionAnswers.length})");
  const screenshot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  fs.writeFileSync(path.join(outputDir, 'offline-file-presales.png'), Buffer.from(screenshot.data, 'base64'));
  const result = { acceptedAt: new Date().toISOString(), browser: 'Local Google Chrome via CDP', mode: 'file://', initial, question: { answerPreview: question.answer.slice(0, 1800), storedAnswers: question.answers }, networkRequests: requests, consoleErrors: errors, screenshots: ['offline-file-presales.png'] };
  fs.writeFileSync(path.join(outputDir, 'offline-results.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ mode: result.mode, title: initial.title, storageCharacters: initial.storageCharacters, externalResources: initial.externalResources.length, storedAnswers: question.answers, consoleErrors: errors.length }, null, 2));
  ws.close(); if (errors.length) process.exitCode = 1;
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; });
