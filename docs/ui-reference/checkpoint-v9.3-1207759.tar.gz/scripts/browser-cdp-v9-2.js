/* V9.2 real Chrome file:// screenshots and measured responsive acceptance, no npm dependencies. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const out = path.join(__dirname, '../artifacts/v9-2-browser');
fs.mkdirSync(out, { recursive: true });
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function main() {
  const pages = await (await fetch('http://localhost:9225/json/list')).json();
  const page = pages.find(item => item.type === 'page' && item.url.includes('business-atlas-v9.2.html'));
  if (!page) throw new Error('Open V9.2 in Chrome with --remote-debugging-port=9225');
  const ws = new WebSocket(page.webSocketDebuggerUrl), pending = new Map(), errors = [], requests = [];
  let sequence = 0;
  await new Promise((resolve, reject) => { ws.addEventListener('open', resolve, { once: true }); ws.addEventListener('error', reject, { once: true }); });
  ws.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) { const item = pending.get(message.id); pending.delete(message.id); message.error ? item.reject(new Error(JSON.stringify(message.error))) : item.resolve(message.result); }
    if (message.method === 'Runtime.exceptionThrown') errors.push(message.params.exceptionDetails);
    if (message.method === 'Runtime.consoleAPICalled' && message.params.type === 'error') errors.push(message.params);
    if (message.method === 'Network.requestWillBeSent') requests.push(message.params.request.url);
  });
  const send = (method, params = {}) => new Promise((resolve, reject) => { const id = ++sequence; pending.set(id, { resolve, reject }); ws.send(JSON.stringify({ id, method, params })); });
  const evaluate = async expression => (await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })).result.value;
  const waitFor = async expression => { const started = Date.now(); while (Date.now() - started < 10000) { if (await evaluate(`!!(${expression})`)) return; await sleep(50); } throw new Error(`Timed out: ${expression} :: ${await evaluate("location.hash + ' :: ' + document.body.innerText.slice(0,600)")}`); };
  const metrics = (width, height) => send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false });
  const capture = async name => { const shot = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false }); fs.writeFileSync(path.join(out, name), Buffer.from(shot.data, 'base64')); };
  await send('Runtime.enable'); await send('Page.enable'); await send('Network.enable'); await metrics(1440, 900);
  await send('Page.reload', { ignoreCache: true }); await waitFor("window.AtlasV92UI && document.querySelectorAll('.v5-nav').length === 6");
  await evaluate("location.hash='PRJ-SELF/home'"); await waitFor("document.querySelector('.v92-starting-points')"); await capture('A-G-self-home.png');
  await evaluate("location.hash='PRJ-SELF/studio'"); await waitFor("document.querySelector('.v92-business-home')"); await capture('C-business-system-selector.png');
  await evaluate("location.hash='PRJ-00003/studio/FEAT-M02'"); await waitFor("document.querySelector('.v92-reading-main')"); await capture('B-feature-reading.png');
  await evaluate("location.hash='PRJ-00003/studio/RULE-M002'"); await waitFor("document.querySelector('.v6-rule-table')"); await capture('G-rule-decision-table.png');
  await evaluate("location.hash='PRJ-SELF/imports'"); await waitFor("document.querySelector('.v9-proposals')"); await capture('E-import-records.png');
  await evaluate("location.hash='PRJ-00003/home'"); await waitFor("document.querySelector('.v92-starting-points')");
  await evaluate("document.querySelector('[data-action=\"open-assistant\"]').click()"); await waitFor("document.querySelector('.v91-assistant')");
  await evaluate("document.querySelector('#assistant-input').value='这个系统的质量异常登记功能有什么使用限制？';document.querySelector('#assistant-form button').click()"); await waitFor("document.querySelector('.v91-answer-card')");
  const widths = [];
  for (const [width, height] of [[1440, 900], [1280, 800], [1024, 720], [800, 600]]) {
    await metrics(width, height);
    const measurement = await evaluate("({documentWidth:document.documentElement.scrollWidth,bodyWidth:document.body.scrollWidth,viewport:innerWidth,assistant:!!document.querySelector('.v91-assistant'),close:(()=>{const r=document.querySelector('[data-action=\"close-assistant\"]').getBoundingClientRect();return {left:r.left,right:r.right,top:r.top,bottom:r.bottom}})()})");
    if (measurement.documentWidth > width || measurement.bodyWidth > width) throw new Error(`Horizontal overflow at ${width}: ${JSON.stringify(measurement)}`);
    if (measurement.close.left < 0 || measurement.close.right > width || measurement.close.top < 0 || measurement.close.bottom > height) throw new Error(`Assistant close unavailable at ${width}`);
    widths.push({ width, height, ...measurement });
    await capture(`H-assistant-${width}.png`);
  }
  const result = { acceptedAt: new Date().toISOString(), browser: 'Local Google Chrome CDP', mode: 'file://', widths, externalRequests: requests.filter(url => /^https?:/.test(url)), consoleErrors: errors, screenshots: ['A-G-self-home.png', 'C-business-system-selector.png', 'B-feature-reading.png', 'G-rule-decision-table.png', 'E-import-records.png', 'H-assistant-1440.png', 'H-assistant-1280.png', 'H-assistant-1024.png', 'H-assistant-800.png'] };
  fs.writeFileSync(path.join(out, 'layout-results.json'), JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ mode: result.mode, widths: widths.map(item => `${item.width}:doc=${item.documentWidth},body=${item.bodyWidth}`), consoleErrors: errors.length, externalRequests: result.externalRequests.length }, null, 2));
  ws.close(); if (errors.length) process.exitCode = 1;
}
main().catch(error => { console.error(error.stack); process.exitCode = 1; });
