/* Build the exact V9.3 modular runtime into a resource-independent single HTML file. */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = __dirname;
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const files = [
  'engine.js', 'model.js', 'v4-core.js', 'v4-model.js',
  'src/v5-core.js', 'src/v5-model.js', 'src/v5-views.js',
  'src/v9-applicability.js', 'src/v6-core.js', 'src/v6-projection.js', 'src/v6-views.js',
  'src/v7-framework.js', 'src/v7-schema.js', 'src/v7-flow.js', 'src/v8-read.js',
  'src/v9-access.js', 'src/v9-3-decision.js', 'src/v9-model.js', 'src/v9-3-model.js', 'src/v9-akp.js', 'src/v9-services.js',
  'src/v9-self-package.js', 'src/v9-self-project.js', 'src/v9-ui.js', 'src/v9-1-assistant.js', 'src/v9-1-ui.js', 'src/v9-2-reading.js', 'src/v9-3-reading.js', 'src/v9-3-task.js', 'src/v9-2-ui.js', 'src/v9-3-ui.js', 'src/v6-app.js'
];
const scripts = files.map(file => `<script data-source="${file}">\n${read(file).replace(/<\/script/gi, '<\\/script')}\n</script>`).join('\n');
const html = read('src/index.template.html')
  .replace('/* INLINE_V5_CSS */', () => `${read('src/v5.css')}\n${read('src/v6.css')}\n${read('src/v7.css')}\n${read('src/v9.css')}\n${read('src/v9-1.css')}\n${read('src/v9-2.css')}\n${read('src/v9-3.css')}`)
  .replace('<!-- INLINE_V5_SCRIPTS -->', () => scripts)
  .replaceAll('Business Atlas V5', 'Business Atlas V9.3')
  .replace('面向真实软件项目的通用认知、业务解释与协作平台。', '持续维持业务目标、实际行为、技术实现、需求变化与知识交付一致性的工作空间。');
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
const output = path.join(root, 'dist', 'business-atlas-v9.3.html');
fs.writeFileSync(output, html);
if (/<(?:script|link|img)[^>]+(?:src|href)=["'](?:https?:)?\/\//i.test(html) || /@import\s|url\(["']?https?:/i.test(html)) throw new Error('Single HTML contains an external resource reference');
const digest = crypto.createHash('sha256').update(html).digest('hex');
fs.writeFileSync(path.join(root, 'artifacts/v9-3-build.json'), JSON.stringify({ output: path.relative(root, output), sha256: digest, bytes: Buffer.byteLength(html), scripts: files }, null, 2));
console.log(`Built ${path.relative(root, output)} · ${(Buffer.byteLength(html) / 1024).toFixed(1)} KiB · ${files.length} inline scripts · no external resources · sha256 ${digest}`);
