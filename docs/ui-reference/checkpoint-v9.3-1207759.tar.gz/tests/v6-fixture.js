/* Test-only fixture: every business fact is created through the public V6 Command pipeline. */
'use strict';
const C = require('../src/v6-core.js');
function decision(name, scope, inputId, outcomes) {
  return { supportsEvaluation: true, ruleKind: 'decision', scope, inputs: [{ id: inputId, label: inputId === 'result' ? '巡检结果' : '复检结果', kind: 'enum', options: outcomes.map(([value, label]) => ({ value, label })) }], outcomes: outcomes.map(([id, label]) => ({ id, label })), rows: outcomes.map(([id, label], index) => ({ id: `R-${index + 1}`, priority: (index + 1) * 10, when: { [inputId]: id.toLowerCase() }, outcomeId: id })), exceptions: [], summary: `${name}按条件选择结果` };
}
function createEquipmentViaCommands() {
  const p = C.createBlankProject('PRJ-90001', '设备巡检与故障处理', '通过巡检、故障维修和复检保障设备安全运行');
  const domain = C.execute(p, 'CreateEntity', { typeId: 'Domain', name: '巡检执行', description: '计划和执行现场巡检' }).entity;
  C.execute(p, 'CreateEntity', { typeId: 'Domain', name: '故障维修', description: '处理故障并恢复设备' });
  const equipment = C.execute(p, 'CreateEntity', { typeId: 'BusinessObject', name: '设备', description: '需要巡检和维护的生产设备', extra: { props: ['设备编号', '型号', '区域'], states: ['正常', '待维修', '维修中', '待复检', '停用'], transitions: [] } }).entity;
  C.execute(p, 'CreateEntity', { typeId: 'BusinessObject', name: '巡检记录', description: '一次现场巡检的事实和证据', extra: { props: ['巡检人', '巡检时间', '结果'], states: ['草稿', '已提交', '已归档'], transitions: [] } });
  const scenario = C.execute(p, 'CreateEntity', { typeId: 'Scenario', name: '现场设备巡检', goal: '识别设备异常并闭环维修', extra: { goal: '识别设备异常并闭环维修', trigger: '到达计划巡检时间', participants: [], stageIds: [] } }).entity;
  C.execute(p, 'LinkKnowledge', { subject: domain.id, predicate: 'contains', object: scenario.id });
  const inspector = C.execute(p, 'CreateEntity', { typeId: 'Actor', name: '巡检员', description: '执行现场巡检并记录异常' }).entity;
  const repairer = C.execute(p, 'CreateEntity', { typeId: 'Actor', name: '维修员', description: '维修设备并配合复检' }).entity;
  const inspect = C.execute(p, 'AddBehavior', { scenarioId: scenario.id, kind: 'action', name: '提交巡检记录', actorId: inspector.id, inputs: ['设备编号', '巡检结果'], outputs: ['巡检记录'] });
  const abnormal = C.execute(p, 'DefineRule', { name: '巡检异常判断', scope: '现场巡检结果已提交', description: '正常结束，异常进入故障处理', definition: decision('巡检异常判断', '现场巡检结果已提交', 'result', [['normal', '正常'], ['fault', '异常']]) }).entity;
  const judge = C.execute(p, 'AddBehavior', { scenarioId: scenario.id, kind: 'decision', name: '是否异常', ruleId: abnormal.id });
  const complete = C.execute(p, 'AddBehavior', { scenarioId: scenario.id, kind: 'action', name: '完成巡检', actorId: inspector.id });
  const fault = C.execute(p, 'AddBehavior', { scenarioId: scenario.id, kind: 'action', name: '生成故障记录', actorId: inspector.id });
  const repair = C.execute(p, 'AddBehavior', { scenarioId: scenario.id, kind: 'action', name: '维修设备', actorId: repairer.id });
  const recheck = C.execute(p, 'AddBehavior', { scenarioId: scenario.id, kind: 'action', name: '复检设备', actorId: inspector.id });
  const recheckRule = C.execute(p, 'DefineRule', { name: '维修复检判断', scope: '故障设备维修完成', description: '复检通过恢复，失败返回维修', definition: decision('维修复检判断', '故障设备维修完成', 'recheck', [['pass', '通过'], ['fail', '失败']]) }).entity;
  // decision() creates lowercase condition values; make recheck values and outcomes consistent.
  const rv = C.ruleVersion(recheckRule); rv.inputs[0].options = [{ value: 'pass', label: '通过' }, { value: 'fail', label: '失败' }]; rv.rows.forEach(row => { row.when.recheck = row.outcomeId === 'pass' ? 'pass' : 'fail'; });
  const recheckJudge = C.execute(p, 'AddBehavior', { scenarioId: scenario.id, kind: 'decision', name: '复检是否通过', ruleId: recheckRule.id });
  C.execute(p, 'ConnectBehavior', { scenarioId: scenario.id, from: inspect.nodeId, to: judge.nodeId, type: 'next' });
  C.execute(p, 'ConnectBehavior', { scenarioId: scenario.id, from: judge.nodeId, to: complete.nodeId, type: 'when', ruleId: abnormal.id, outcomeId: 'normal', label: '设备正常，完成巡检' });
  C.execute(p, 'ConnectBehavior', { scenarioId: scenario.id, from: judge.nodeId, to: fault.nodeId, type: 'when', ruleId: abnormal.id, outcomeId: 'fault', label: '设备异常，生成故障记录' });
  C.execute(p, 'ConnectBehavior', { scenarioId: scenario.id, from: fault.nodeId, to: repair.nodeId, type: 'next' });
  C.execute(p, 'ConnectBehavior', { scenarioId: scenario.id, from: repair.nodeId, to: recheck.nodeId, type: 'next' });
  C.execute(p, 'ConnectBehavior', { scenarioId: scenario.id, from: recheck.nodeId, to: recheckJudge.nodeId, type: 'next' });
  C.execute(p, 'ConnectBehavior', { scenarioId: scenario.id, from: recheckJudge.nodeId, to: complete.nodeId, type: 'when', ruleId: recheckRule.id, outcomeId: 'pass', label: '复检通过，恢复正常' });
  C.execute(p, 'ConnectBehavior', { scenarioId: scenario.id, from: recheckJudge.nodeId, to: repair.nodeId, type: 'return', ruleId: recheckRule.id, outcomeId: 'fail', label: '复检失败，返回维修' });
  const transitions = [
    ['正常', '待维修', 'FaultConfirmed', '巡检异常且故障记录已生成', fault.entity.id],
    ['待维修', '维修中', 'RepairStarted', '维修员接受故障任务', repair.entity.id],
    ['维修中', '待复检', 'RepairCompleted', '维修记录完整并提交复检', recheck.entity.id],
    ['待复检', '正常', 'RecheckPassed', '复检通过且安全约束满足', complete.entity.id],
    ['待复检', '维修中', 'RecheckFailed', '复检失败且允许再次维修', repair.entity.id]
  ];
  transitions.forEach(([fromState, toState, triggerEvent, guard, actionRef]) => C.execute(p, 'DefineTransition', { objectId: equipment.id, fromState, toState, triggerEvent, guard, actionRef }));
  const constraint = C.execute(p, 'DefineRule', { name: '故障设备禁止投入生产', scope: '设备处于待维修、维修中或待复检', description: '故障未解除前禁止投入生产，巡检和维修记录仍允许提交', definition: { supportsEvaluation: false, ruleKind: 'constraint', constraintType: 'prohibit', constraint: '故障设备禁止投入生产；发现违规立即停机并复核', exception: '经安全负责人批准的隔离测试例外', violationHandling: '停止投放并创建复核任务', scope: '设备处于待维修、维修中或待复检', inputs: [], outcomes: [], rows: [], exceptions: [] } }).entity;
  C.execute(p, 'LinkKnowledge', { subject: constraint.id, predicate: 'constrains', object: inspect.entity.id, qualifiers: { condition: '巡检记录不得被用于解除故障状态' } });
  [abnormal, recheckRule, constraint].forEach(rule => C.execute(p, 'AttachEvidence', { targetId: rule.id, name: `${rule.name}作业依据`, resourceType: 'document', sourceVersion: 'v1.0', uri: `atlas://manual/${rule.id}`, locator: '第 3 节 条件与处理', summary: '由业务负责人确认的规则依据', trust: 'confirmed', confirmedBy: '业务负责人' }));
  const feature = C.execute(p, 'CreateEntity', { typeId: 'Feature', name: '提交巡检记录', description: '巡检员提交现场结果并触发后续故障处理', acceptance: ['正常巡检提交后完成记录', '异常巡检生成故障记录并转为待维修', '复检失败返回维修', '保存冲突不产生部分记录'], extra: { scenarioId: scenario.id, acceptance: ['正常巡检提交后完成记录', '异常巡检生成故障记录并转为待维修', '复检失败返回维修', '保存冲突不产生部分记录'] } }).entity;
  C.execute(p, 'LinkKnowledge', { subject: feature.id, predicate: 'implements', object: inspect.entity.id });
  C.execute(p, 'BindImplementation', { rootId: feature.id, resourceType: 'Surface', name: '巡检记录填写页', operation: '提交巡检记录', extra: { operations: [{ name: '提交巡检记录', actionId: inspect.entity.id }] }, links: [{ subject: 'NEW_RESOURCE', predicate: 'triggers', object: feature.id, qualifiers: { operation: '提交巡检记录' } }] });
  C.execute(p, 'BindImplementation', { rootId: feature.id, resourceType: 'API', name: '提交巡检记录接口', extra: { method: 'POST', path: '/inspections', failure: '版本冲突返回 409，全部回滚' }, links: [{ subject: 'NEW_RESOURCE', predicate: 'implements', object: inspect.entity.id }] });
  C.execute(p, 'BindImplementation', { rootId: feature.id, resourceType: 'DataEntity', name: '巡检记录数据', fields: ['record_id', 'equipment_id', 'result'], transaction: '巡检记录与 outbox 原子提交', extra: { tableName: 'inspection_record', fields: [{ name: 'record_id', type: 'uuid', description: '巡检记录 ID' }, { name: 'equipment_id', type: 'uuid', description: '设备 ID' }, { name: 'result', type: 'enum', description: '正常或异常' }] }, links: [{ subject: inspect.entity.id, predicate: 'writes', object: 'NEW_RESOURCE', qualifiers: { fields: ['record_id', 'equipment_id', 'result'] } }] });
  C.execute(p, 'BindImplementation', { rootId: feature.id, resourceType: 'Event', name: '巡检记录已提交', condition: '巡检记录成功提交后', extra: { eventType: 'InspectionSubmitted', topic: 'inspection.submitted', payload: { recordId: '巡检记录 ID', result: '巡检结果' } }, links: [{ subject: inspect.entity.id, predicate: 'produces', object: 'NEW_RESOURCE', qualifiers: { after: '巡检记录成功提交后' } }] });
  C.execute(p, 'AttachEvidence', { targetId: feature.id, name: '巡检保存接口验收记录', resourceType: 'test-report', sourceVersion: 'TEST-001', uri: 'atlas://manual/test/inspection-save', locator: 'TEST-001 全部用例', summary: '保存、冲突回滚和事件证据', trust: 'confirmed', confirmedBy: '业务负责人' });
  return { p, ids: { domain: domain.id, equipment: equipment.id, scenario: scenario.id, inspect: inspect.entity.id, abnormal: abnormal.id, recheckRule: recheckRule.id, constraint: constraint.id, feature: feature.id, judge: judge.nodeId, repair: repair.entity.id, repairNode: repair.nodeId, recheckJudge: recheckJudge.nodeId, complete: complete.entity.id, fault: fault.entity.id } };
}
function publish(p, reason = '建立完整巡检业务知识') { const proposed = C.proposeChange(p, { reason, title: reason }); if (!proposed.ok) throw new Error(proposed.errors.join('；')); return C.publishRevision(p, { confirmedBy: '业务负责人' }); }
module.exports = { createEquipmentViaCommands, publish };
