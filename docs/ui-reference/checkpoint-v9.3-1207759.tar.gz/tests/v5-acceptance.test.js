/* Business Atlas V5 — semantic, governance, reading and collaboration acceptance checks. */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const K = require('../v4-core.js');
const E = require('../engine.js');
const VM = require('../src/v5-model.js');
const G = require('../src/v5-core.js');
const V = require('../src/v5-views.js');
const results = [];
function test(name, fn) { try { fn(); results.push({ name, status: 'PASS' }); console.log(`✓ ${name}`); } catch (error) { results.push({ name, status: 'FAIL', error: error.message }); console.error(`✗ ${name}\n  ${error.stack}`); } }
const projects = VM.createProjectSet(), manufacturing = projects['PRJ-00003'], booking = projects['PRJ-00002'], government = projects['PRJ-00004'], approval = projects['PRJ-00001'];
const fresh = () => VM.createProjectSet()['PRJ-00003'];
const relation = (p, predicate, subject, object) => p.assertions.find(a => a.predicate === predicate && (!subject || a.subject === subject) && (!object || a.object === object));
function changeConfig(p) { const change = G.createChange(p,{entityId:'CFG-M01',reason:'核验配置治理'}); G.updateDraft(p,change.id,{description:'独立草稿，不污染发布',props:{effectiveWhen:'仅测试范围生效'}}); return change; }

test('V5-01 · 没有转移关系时只显示状态目录，不绘制状态箭头', () => {
  const p = VM.createBlankProject('PRJ-T01','无生命周期'); K.createEntity(p,'BusinessObject',{id:'OBJ-T01',name:'只有状态',states:['甲','乙'],props:{states:['甲','乙']}});
  const graph = G.stateGraph(p,'OBJ-T01'), html = V.StateLifecycle(p,G.getEntity(p,'OBJ-T01'));
  assert.equal(graph.hasLifecycle,false); assert(!html.includes('v5-transition-route')); assert(html.includes('不会按数组顺序连接'));
});
test('V5-02 · 已确认路径只含已确认转移，放行不会流向报废', () => {
  const graph = G.stateGraph(manufacturing,'OBJ-M01'); assert(graph.transitions.every(t=>t.verificationStatus==='confirmed'));
  assert(!graph.transitions.some(t=>t.fromState==='已放行')); assert(!graph.transitions.some(t=>t.fromState==='已报废'));
  const all = G.stateGraph(manufacturing,'OBJ-M01',{includeUnverified:true}); assert.equal(all.transitions.length,8); assert.equal(graph.transitions.length,7);
});
test('V5-03 · 不合法的主宾语关系类型在创建阶段被拒绝', () => {
  assert.throws(()=>G.createAssertion(fresh(),{subject:'CFG-M01',predicate:'constrains',object:'ACT-M001',sourceRefs:[{resourceId:'SRC-M01'}]}),/不能作为 constrains 的主语/);
});
test('V5-04 · 配置影响必须具有环境、业务范围和配置版本', () => {
  assert.throws(()=>G.createAssertion(fresh(),{subject:'CFG-M01',predicate:'affects',object:'RULE-M002',sourceRefs:[{resourceId:'SRC-M01'}]}),/配置影响必须声明/);
  const a=relation(manufacturing,'affects','CFG-M01','RULE-M001'); assert.equal(a.qualifiers.environment,'production'); assert.equal(a.qualifiers.organization,'华东一厂'); assert.equal(a.qualifiers.configVersion,'CFG-M-2026.11');
});
test('V5-05 · 制造决策结果与条件组合一致', () => {
  const r=K.getEntity(manufacturing,'RULE-M001').selectedVersion;
  assert.equal(E.evaluateRule(r,{defect:'critical',rework:'feasible',recheck:'pass'}).outcome.id,'SCRAP');
  assert.equal(E.evaluateRule(r,{defect:'minor',rework:'feasible',recheck:'fail'}).outcome.id,'REWORK');
  assert.equal(E.evaluateRule(r,{defect:'minor',rework:'feasible',recheck:'pass'}).outcome.id,'RELEASE');
});
test('V5-06 · 异常分支和恢复位置来自显式流程边', () => {
  const mf=E.flowFor(manufacturing,'SCN-M001'), bf=E.flowFor(booking,'SCN-B001');
  assert(mf.edges.some(e=>e.type==='return'&&e.from==='MN-ACT-M008'&&e.to==='MN-ACT-M005'));
  assert(bf.edges.some(e=>e.type==='error'&&e.from==='BN-ACT-B0005'&&e.to==='BN-ACT-B0002'));
});
test('V5-07 · 未核验断言不会进入仅批准事实的正式上下文', () => {
  const p=fresh(), a=G.createAssertion(p,{subject:'ACT-M001',predicate:'reads',object:'DATA-M03',verificationStatus:'confirmed'}); assert.equal(a.verificationStatus,'unverified');
  const pack=G.generateContextPackage(p,{requirementId:'REQ-M001',depth:4}); assert(!pack.includedAssertions.includes(a.assertionId));
});
test('V5-08 · 节点或状态列表顺序不会自动产生业务关系', () => {
  const p=VM.createBlankProject('PRJ-T08','顺序测试'); p.scenarios.push({id:'SCN-T08',name:'仅节点',typeId:'Scenario',stageIds:[]}); p.flows=[{id:'FLOW-T08',scenarioId:'SCN-T08',nodes:[{id:'N1',name:'甲'},{id:'N2',name:'乙'}],edges:[]}];
  const html=V.CausalFlow(p,p.scenarios[0]); assert(html.includes('尚未建立因果流程')); assert(!html.includes('v5-flow-arrow'));
});
test('V5-09 · 已发布知识对象冻结，不能直接修改', () => {
  const cfg=G.getEntity(manufacturing,'CFG-M01'); assert(Object.isFrozen(cfg)); assert.throws(()=>{cfg.description='绕过治理';},TypeError); assert.notEqual(G.getEntity(manufacturing,'CFG-M01').description,'绕过治理');
});
test('V5-10 · 配置、术语、接口、数据、动作和规则均可创建统一草稿', () => {
  const p=fresh(); for(const id of ['CFG-M01','TERM-M001','API-M00','DATA-M02','ACT-M001','RULE-M001']) { const c=G.createChange(p,{entityId:id,reason:'统一治理'}); assert.equal(c.status,'draft'); assert.equal(c.entityId,id); assert(c.targetRevision!==c.baseRevision); }
});
test('V5-11 · 草稿编辑与发布版本完全隔离', () => {
  const p=fresh(), before=G.getEntity(p,'CFG-M01').description, c=changeConfig(p); assert.equal(G.getEntity(p,'CFG-M01').description,before); assert.equal(c.draft.description,'独立草稿，不污染发布'); assert(c.baseSnapshot.description===before);
});
test('V5-12 · 变更批准后形成新不可变修订与审阅记录', () => {
  const p=fresh(), c=changeConfig(p); c.impactAcknowledged=true; assert(G.submitChange(p,c.id).ok); const result=G.approveChange(p,c.id); assert(result.ok); assert.equal(result.published.revision,'r2'); assert(Object.isFrozen(result.published)); assert.equal(c.reviewDecisions[0].decision,'approved');
});
test('V5-13 · 项目基线保存具体对象和断言修订', () => {
  const b=manufacturing.baselines[0]; assert.equal(b.entries['CFG-M01'],'r1'); assert.equal(b.entries['RULE-M001'],'v1.0'); assert.equal(b.assertionRevisions['AST-M-CFG-RULE'],'a1'); assert.equal(b.approvalStatus,'approved');
});
test('V5-14 · 新发布不会改写历史基线与历史引用', () => {
  const p=fresh(), old=JSON.stringify(p.baselines[0]), c=changeConfig(p); c.impactAcknowledged=true; G.submitChange(p,c.id); G.approveChange(p,c.id); assert.equal(JSON.stringify(p.baselines[0]),old); assert.equal(G.getEntity(p,'CFG-M01',{baselineId:p.baselines[0].id}).revision,'r1'); assert.equal(G.getEntity(p,'CFG-M01').revision,'r2');
});
test('V5-15 · 无来源的新断言即使请求 confirmed 也强制待核验', () => {
  const a=G.createAssertion(fresh(),{subject:'ACT-M001',predicate:'reads',object:'DATA-M03',verificationStatus:'confirmed',owner:'AI'}); assert.equal(a.verificationStatus,'unverified'); assert.equal(a.sourceRefs.length,0);
});
test('V5-16 · 重要规则变更触发关联知识复核而不提升其版本', () => {
  const p=fresh(), action=G.getEntity(p,'ACT-M009'), c=G.createChange(p,{entityId:'RULE-M001',reason:'规则约束调整'}); G.updateDraft(p,c.id,{description:'新的规则解释'}); const impacts=G.impactFor(p,c); assert(impacts.some(i=>i.entityId==='ACT-M009'&&i.status==='requires-review')); assert.equal(G.getEntity(p,'ACT-M009').version,action.version);
});
test('V5-17 · UI 保存操作可追踪到业务动作与功能全景', () => {
  const pan=G.panorama(manufacturing,'UI-M001'); assert.equal(pan.rootId,'FEAT-M02'); assert(pan.steps.some(s=>s.entityId==='ACT-M001')); assert(relation(manufacturing,'triggers','UI-M001','FEAT-M02'));
});
test('V5-18 · 业务动作可追踪到规则、对象变化和事件', () => {
  assert(relation(manufacturing,'constrains','RULE-M002','ACT-M001')); assert(relation(manufacturing,'produces','ACT-M001','EVT-M01')); assert(relation(manufacturing,'transitions','ACT-M009','OBJ-M01'));
});
test('V5-19 · 技术接口可反向追踪多个业务动作', () => {
  const incoming=G.assertionsFor(manufacturing,'API-M00').filter(a=>a.subject==='API-M00'&&a.predicate==='implements'); assert(incoming.some(a=>a.object==='ACT-M001')); assert(incoming.some(a=>a.object==='ACT-M002'));
});
test('V5-20 · 数据实体可反向追踪读写操作与字段范围', () => {
  const writes=G.assertionsFor(manufacturing,'DATA-M03').filter(a=>a.predicate==='writes'); assert(writes.some(a=>a.subject==='ACT-M002')); assert(writes.some(a=>a.subject==='API-M00')); assert(writes.find(a=>a.subject==='ACT-M002').qualifiers.fields.includes('quality_state'));
});
test('V5-21 · 同名术语跨阅读页面保持稳定独立身份', () => {
  const a=G.getEntity(government,'TERM-G001'),b=G.getEntity(government,'TERM-G002'); assert.equal(a.name,b.name); assert.notEqual(a.id,b.id); assert(a.props.confusedWith.includes(b.id)); assert(V.Term(government,a).some(([id])=>id==='confusions'));
});
test('V5-22 · 关系查询尊重权限与基线版本范围', () => {
  const external={role:'external',clearance:'public'}; assert(!G.permissionAllows(G.getEntity(approval,'SEC-A01'),external));
  const graph=G.collectContext(approval,'CFG-A01',{depth:2,permission:external,baselineId:approval.versionLayers.baseline}); assert(![...graph.included.keys()].includes('SEC-A01')); assert(graph.excluded.some(x=>x.id==='SEC-A01'));
});
test('V5-23 · 不同知识类型使用正确组合式阅读模板', () => {
  const config=V.EntityReader(manufacturing,G.getEntity(manufacturing,'CFG-M01')),data=V.EntityReader(manufacturing,G.getEntity(manufacturing,'DATA-M02')),term=V.EntityReader(government,G.getEntity(government,'TERM-G001'));
  assert(config.includes('生效范围与环境对比')&&config.includes('影响哪些规则与功能')); assert(data.includes('谁读取、谁写入')&&data.includes('quality_defect')); assert(term.includes('易混淆概念'));
});
test('V5-24 · 缺失信息只显示缺口，不生成虚假完整说明', () => {
  const p=VM.createBlankProject('PRJ-T24','尚未研究'); K.registerType(p,{id:'Note',name:'笔记',fields:[]}); const item=K.createEntity(p,'Note',{id:'NOTE-1',name:'只有名称'}); const html=V.EntityReader(p,item); assert(html.includes('业务定义尚未补充')); assert(!html.includes('API / 消息入口')); assert(!html.includes('状态转移'));
});
test('V5-25 · 工作流可用操作完全由当前活动定义决定', () => {
  const i=manufacturing.workflowInstances.find(x=>x.id==='WFI-M-BATCH-001'),stage=K.currentStage(i),caps=G.allowedCapabilities(stage); assert(caps.includes('recordInvestigation')); assert(caps.includes('submitEvidence')); assert(caps.includes('complete')); assert(!caps.includes('generateDelivery'));
});
test('V5-26 · 质量流程执行未声明的开发交接操作会被拒绝', () => {
  const p=fresh(),result=G.executeActivity(p,'WFI-M-BATCH-001','generateDelivery'); assert.equal(result.ok,false); assert(result.errors[0].includes('未声明操作')); assert.equal(p.deliveries.length,0);
});
test('V5-27 · 不使用 Agent 的预约项目可正常执行与完成', () => {
  const p=VM.createProjectSet()['PRJ-00002'],def=p.workflowDefinitions[0]; assert(!JSON.stringify(def).toLowerCase().includes('agent')); const i=K.instantiateWorkflow(p,def.id,{subjectId:'REQ-NO-AGENT'}); let guard=10; while(i.status==='active'&&guard--){const cap=K.currentStage(i).capabilities.at(-1);const r=G.executeActivity(p,i.id,cap);assert(r.ok,r.errors?.join(';'));} assert.equal(i.status,'completed');
});
test('V5-28 · 同一知识模型生成不同角色视图而不复制事实', () => {
  const p=fresh(),dev=G.generateContextPackage(p,{requirementId:'REQ-M001',purpose:'development',depth:4}),test=G.generateContextPackage(p,{requirementId:'REQ-M001',purpose:'testing',depth:4}); assert(dev.ok&&test.ok); assert.notEqual(dev.packageId,test.packageId); assert.equal(dev.versionBinding.baselineId,test.versionBinding.baselineId); assert.deepEqual(dev.includedFacts,test.includedFacts); assert.notEqual(dev.purpose,test.purpose);
});
test('V5-29 · 正式契约绑定批准基线和具体对象修订', () => {
  const pack=G.generateContextPackage(fresh(),{requirementId:'REQ-M001',depth:4}); assert(pack.ok); assert.equal(pack.mode,'formal'); assert.equal(pack.versionBinding.baselineApproved,true); assert.equal(pack.versionBinding.entries['CFG-M01'],'r1'); assert.equal(pack.versionBinding.entries['REQ-M001'],'r1');
});
test('V5-30 · 关键未知阻止正式交接，但明确允许探索上下文', () => {
  const p=fresh(); p.unknowns.push({id:'UNK-CRITICAL',title:'生产回滚行为未知',impact:'无法安全实施',relatedIds:['REQ-M001'],blocksFormal:true,status:'open',owner:'未知'}); const blocked=G.generateContextPackage(p,{requirementId:'REQ-M001'}); assert.equal(blocked.ok,false); assert.equal(blocked.code,'CRITICAL_UNKNOWNS'); const explore=G.generateContextPackage(p,{requirementId:'REQ-M001',mode:'exploration'}); assert(explore.ok); assert(explore.limitations.length>0);
});
test('V5-31 · 执行反馈进入待核验且不会覆盖批准基线', () => {
  const p=fresh(),pack=G.generateContextPackage(p,{requirementId:'REQ-M001'}),before=JSON.stringify(p.baselines),fb=G.recordFeedback(p,pack.packageId,{questions:'旧入口是否共用规则？',deviations:'未覆盖旧入口'}); assert.equal(fb.status,'pending_verification'); assert.equal(JSON.stringify(p.baselines),before); assert(p.issues.some(i=>i.sourceFeedbackId===fb.id&&i.status==='waiting'));
});
test('V5-32 · 多项目知识、变更、契约与执行记录保持隔离', () => {
  const p=fresh(),before=JSON.stringify(booking); G.createAssertion(p,{subject:'ACT-M001',predicate:'reads',object:'DATA-M03'}); G.createChange(p,{entityId:'CFG-M01',reason:'仅制造'}); assert.equal(JSON.stringify(booking),before); assert(!booking.knowledgeChanges.some(c=>c.entityId==='CFG-M01'));
});
test('V5-33 · 历史意图、批准规范与观察实现分别保留', () => {
  const a=relation(manufacturing,'conflictsWith','SRC-M00','RULE-M002'); assert.equal(a.factKind,'historical_intent'); assert.equal(a.verificationStatus,'conflicted'); assert.equal(G.getEntity(manufacturing,'SRC-M02').props.trust,'confirmed'); assert.equal(G.getEntity(manufacturing,'SRC-M03').props.resourceType,'implementation-evidence');
});
test('V5-34 · 配置知识发布不改变软件版本或运行配置版本层', () => {
  const p=fresh(),release=p.versionLayers.release,config=p.versionLayers.config,c=changeConfig(p);c.impactAcknowledged=true;G.submitChange(p,c.id);G.approveChange(p,c.id);assert.equal(p.versionLayers.release,release);assert.equal(p.versionLayers.config,config);assert.notEqual(p.versionLayers.baseline,'BL-M-2026-11-14');
});
test('V5-35 · 单文件 HTML 内联全部运行资源且不依赖网络', () => {
  const html=fs.readFileSync(require.resolve(process.env.ATLAS_SINGLE_HTML ? `../${process.env.ATLAS_SINGLE_HTML}` : '../dist/business-atlas-v5.html'),'utf8');assert(html.includes('AtlasV5'));assert(!/<script[^>]+src=/i.test(html));assert(!/<link[^>]+href=/i.test(html));assert(!/@import\s|url\(["']?https?:/i.test(html));
});
test('V5-36 · 质量调查证据和结论真实阻塞完成条件', () => {
  const p=fresh(),id='WFI-M-BATCH-001';assert.equal(G.executeActivity(p,id,'complete').ok,false);assert(G.executeActivity(p,id,'recordInvestigation',{value:'设备温度波动导致缺陷'}).ok);assert.equal(G.executeActivity(p,id,'complete').ok,false);assert(G.executeActivity(p,id,'submitEvidence',{value:'MQ-118 / inspection-44'}).ok);assert(G.executeActivity(p,id,'complete').ok);assert.equal(K.currentStage(p.workflowInstances.find(i=>i.id===id)).id,'WFS-M04');
});
test('V5-37 · 项目自定义类型沿用通用 Profile，核心组件无行业页面分支', () => {
  const p=VM.createBlankProject('PRJ-T37','能源项目');K.registerType(p,{id:'EnergyMeter',name:'能源表计',fields:[{id:'serial',label:'序列号',dataType:'text'}]});const item=K.createEntity(p,'EnergyMeter',{id:'EM-1',name:'东区表计',props:{serial:'E-1'}});const html=V.EntityReader(p,item);assert(html.includes('能源表计'));assert(html.includes('序列号'));assert(!html.includes('ManufacturingBatchPage'));
});
test('V5-38 · 语义验证发现无效转移、未定义分支和并行无汇合', () => {
  const p=fresh(),object=G.getEntity(p,'OBJ-M01');p.objects.find(o=>o.id==='OBJ-M01').transitions=[...object.transitions,{id:'BAD',fromState:'不存在',toState:'已放行',triggerEvent:'X',guard:'X',actionRef:'ACT-M009',sourceRefs:[],verificationStatus:'unverified'}];p.publishedEntities['OBJ-M01']={...p.objects.find(o=>o.id==='OBJ-M01'),typeId:'BusinessObject'};p.flows.push({id:'BAD-FLOW',scenarioId:'X',nodes:[{id:'D',type:'decision'},{id:'P',type:'parallel'}],edges:[]});const v=G.validateSemantics(p);assert(!v.ok);assert(v.errors.some(e=>e.includes('未定义状态')));assert(v.errors.some(e=>e.includes('未定义结果')));assert(v.errors.some(e=>e.includes('未定义有效汇合')));
});
test('V5-39 · 细粒度来源和定位保留到正常阅读组件', () => {
  const html=V.AssertionList(manufacturing,'CFG-M01',{predicates:['affects']});assert(html.includes('配置键 quality.disposition.ruleVersion'));assert(html.includes('华东一厂'));assert(html.includes('CFG-M-2026.11'));assert(html.includes('QD-2026-014'));
});
test('V5-40 · 与任务无关的关键未知不会误阻当前正式契约', () => {
  const pack=G.generateContextPackage(fresh(),{requirementId:'REQ-M001',depth:4});assert(pack.ok);assert(pack.unknowns.every(u=>u.id!=='UNK-M02'));assert.equal(pack.excluded.every(x=>x.id!=='SRC-M00'),true);
});
test('V5-41 · 语义断言也经过草稿、审阅、发布和基线版本绑定', () => {
  const p=fresh(),a=G.createAssertion(p,{subject:'ACT-M001',predicate:'reads',object:'DATA-M03'}),c=G.createChange(p,{entityId:a.assertionId,reason:'补充实现证据'});G.updateDraft(p,c.id,{explanation:'实现核验后确认读取批次版本',sourceRefs:[{resourceId:'SRC-M03',locator:'register.ts:90'}],verificationStatus:'confirmed'});assert(G.submitChange(p,c.id).ok);const result=G.approveChange(p,c.id);assert(result.ok);assert.equal(result.published.revision,'a2');assert.equal(result.published.verificationStatus,'confirmed');assert.equal(result.baseline.assertionRevisions[a.assertionId],'a2');assert.equal(p.baselines[0].assertionRevisions[a.assertionId],undefined);
});
test('V5-42 · 只有修订号和状态变化、没有内容差异时不能提交空变更', () => {
  const p=fresh(),c=G.createChange(p,{entityId:'CFG-M01',reason:'空变更检查'}),result=G.submitChange(p,c.id);assert.equal(result.ok,false);assert(result.errors.some(e=>e.includes('没有差异')));assert.equal(G.getEntity(p,'CFG-M01').revision,'r1');
});
test('V5-43 · 项目资料也经统一发布并驱动认知地图当前内容', () => {
  const p=fresh(),c=G.createChange(p,{entityId:p.meta.id,reason:'澄清项目边界'});G.updateDraft(p,c.id,{props:{...c.draft.props,positioning:'经批准的新项目定位'}});assert(G.submitChange(p,c.id).ok);const result=G.approveChange(p,c.id);assert(result.ok);assert.equal(result.published.revision,'r2');assert.equal(G.getEntity(p,p.meta.id).props.positioning,'经批准的新项目定位');assert.equal(result.baseline.entries[p.meta.id],'r2');
});

const failed=results.filter(r=>r.status==='FAIL');
console.log(`\n${results.length-failed.length}/${results.length} 项 V5 验收通过。`);
fs.mkdirSync(require('node:path').join(__dirname,'../artifacts'),{recursive:true});fs.writeFileSync(require('node:path').join(__dirname,'../artifacts/v5-test-results.json'),JSON.stringify({generatedAt:new Date().toISOString(),passed:results.length-failed.length,total:results.length,results},null,2));
if(failed.length)process.exitCode=1;
