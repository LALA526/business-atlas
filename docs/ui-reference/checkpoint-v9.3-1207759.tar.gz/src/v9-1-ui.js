/* Business Atlas V9.1 — contextual assistant, activity views, visual presentation and dynamic home composition. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const C = commonjs ? require('./v6-core.js') : root.AtlasV6;
  const P = commonjs ? require('./v6-projection.js') : root.AtlasV6Projection;
  const V = commonjs ? require('./v6-views.js') : root.AtlasV6Views;
  const V9 = commonjs ? require('./v9-ui.js') : root.AtlasV9UI;
  const S = commonjs ? require('./v9-services.js') : root.AtlasV9Services;
  const A = commonjs ? require('./v9-1-assistant.js') : root.AtlasV91Assistant;
  const api = factory(C, P, V, V9, S, A);
  if (commonjs) module.exports = api;
  root.AtlasV91UI = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C, P, V, V9, S, A) {
  'use strict';
  const esc = V.esc, clone = C.clone;
  const NAVIGATION = Object.freeze([
    Object.freeze({ group: '理解项目', route: 'home', icon: '⌂', label: '项目概览' }),
    Object.freeze({ group: '理解项目', route: 'catalog', icon: '⌕', label: '知识目录' }),
    Object.freeze({ group: '理解项目', route: 'studio', icon: '⇢', label: '业务与系统' }),
    Object.freeze({ group: '维护知识', route: 'changes', icon: '◫', label: '变更与审核' }),
    Object.freeze({ group: '项目协作', route: 'tasks', icon: '↻', label: '任务与问题' }),
    Object.freeze({ group: '项目协作', route: 'contracts', icon: '▤', label: '交付与验收' })
  ]);
  function resolveLegacyRoute(route, context = {}, project = null) {
    if (route === 'ask') return { route: context.assistantReturnRoute || 'home', openAssistant: true };
    if (route === 'feedback') return { route: 'tasks', collaborationTab: 'feedback' };
    if (route === 'agents') return { route: 'tasks', collaborationTab: 'activity' };
    if (route === 'visuals') {
      const view = (project?.visualViews || []).find(item => item.viewId === context.visualViewId) || project?.visualViews?.[0];
      return { route: 'studio', rootId: view?.rootKnowledgeId || context.rootId, focusId: context.visualFocusId || view?.rootKnowledgeId || context.focusId, visualViewId: view?.viewId || null, studioPresentation: 'visual', visualFocusMode: true };
    }
    return { route };
  }
  function compactAnswer(answer, format = 'internal') {
    const direct = answer.conclusions.slice(0, format === 'customer' ? 2 : 3);
    return `<article class="v91-answer" data-answer-id="${esc(answer.answerId)}"><div class="v91-user-message">${esc(answer.query)}</div><section class="v91-answer-card"><header><b>基于当前项目知识</b><small>${esc(answer.readContext.applicableContext.environment || '环境未指定')} · ${esc(answer.readContext.baselineId)}</small></header><div class="v91-direct-answer">${direct.map(item => `<section><b>${esc(item.title)}</b><p>${esc(item.text)}</p>${item.applicability ? `<small>适用性：${esc(item.applicability.status)}</small>` : ''}</section>`).join('')}</div>${answer.limitations.length ? `<details class="v91-answer-limits"><summary>使用条件与边界（${answer.limitations.length}）</summary>${answer.limitations.map(item => `<p>${esc(item)}</p>`).join('')}</details>` : ''}<details class="v91-answer-evidence"><summary>业务依据与来源（${answer.citations.length}）</summary>${answer.citations.map(citation => `<button data-open-studio="${esc(citation.sourceId || citation.knowledgeId)}"><b>${esc(citation.sourceId || citation.knowledgeId)}</b><span>${esc(typeof citation.locator === 'object' ? JSON.stringify(citation.locator) : citation.locator || citation.revision || '')}</span><small>${esc(citation.baselineId)}</small></button>`).join('') || '<p>当前没有足够来源。</p>'}</details><details class="v91-query-detail"><summary>查询说明</summary><p>意图 ${esc(answer.intent)} · 角色 ${esc(answer.role)} · 确定性查询组合，未调用 LLM。</p></details><footer><span>当前为知识查询，不是通用 AI 生成。</span><div><button data-action="assistant-feedback" data-kind="helpful" data-id="${answer.answerId}">有帮助</button><button data-action="assistant-feedback" data-kind="inaccurate" data-id="${answer.answerId}">不准确</button><button data-action="new-feedback" data-knowledge="${esc(answer.focusIds[0] || '')}" data-origin="assistant" data-origin-id="${answer.answerId}">提交问题</button></div></footer></section></article>`;
  }
  function AssistantPanel(api) {
    if (api.state.route === 'projects') return '';
    const project = api.M(), state = A.panelState(api.store, project.meta.id), provider = api.assistantProvider, c = api.Ctx();
    if (!state.isOpen) return '';
    const history = provider.listHistory(project, { conversationId: state.activeConversationId, limit: 30, readContext: api.readContext() }), focus = state.contextualFocus || api.workspaceActionContext();
    const focusEntity = focus.knowledgeId ? C.getEntity(project, focus.knowledgeId, api.projectionOptions()) : null;
    return `<aside class="v91-assistant ${state.minimized ? 'minimized' : ''}" aria-label="项目助手" aria-modal="false"><header><div><span class="v91-assistant-mark">✦</span><div><b>项目助手</b><small>随时提问，保留当前工作</small></div></div><div><button data-action="minimize-assistant" aria-label="${state.minimized ? '展开助手' : '收起助手'}">${state.minimized ? '展开' : '收起'}</button><button data-action="close-assistant" aria-label="关闭助手">×</button></div></header>${state.minimized ? '' : `<section class="v91-assistant-context"><span>${esc(project.meta.name)}</span><p>${focusEntity ? `当前聚焦：${esc(focusEntity.name)}` : '当前聚焦：项目整体'} · ${esc(c.baselineId)} · ${esc(c.applicableContext.environment || '未指定环境')}</p></section><div class="v91-messages">${history.length ? history.map(answer => compactAnswer(answer, state.answerFormat)).join('') : `<div class="v91-assistant-empty"><b>从这个项目开始提问</b><p>直接描述你的问题，不需要选择查询类型或知识 ID。</p></div>`}</div><div class="v91-suggestions">${['有什么使用限制？', '为什么要这样处理？', '它怎样运行？'].map(text => `<button data-action="assistant-suggestion" data-text="${text}">${text}</button>`).join('')}</div><details class="v91-query-scope"><summary>查询范围与显示</summary><p>基线 ${esc(c.baselineId)}<br>环境 ${esc(c.applicableContext.environment || '未指定')} · ${esc(c.applicabilityMode)}</p><button data-action="answer-internal">内部理解版</button><button data-action="answer-customer">客户简明版</button></details><form id="assistant-form" class="v91-assistant-form"><textarea id="assistant-input" aria-label="向项目助手提问" placeholder="询问当前项目、规则、功能或限制……" required>${esc(state.draftText)}</textarea><button class="v5-button primary" type="submit">发送</button></form><footer><small>确定性知识查询 · 未连接真实 LLM</small><button data-action="assistant-new-conversation">新会话</button></footer>`}</aside>`;
  }
  function openAssistant(api, options = {}) {
    const state = A.setOpen(api.store, api.M().meta.id, true, { returnRoute: options.returnRoute || api.state.route, minimized: false });
    state.contextualFocus = api.workspaceActionContext();
    api.save(); api.render(); return state;
  }
  function notifyFeedback(api, feedbackId) {
    const toast = document.createElement('div'); toast.className = 'v5-toast success';
    const text = document.createElement('span'); text.textContent = '反馈已提交，已保持当前阅读位置。';
    const action = document.createElement('button'); action.dataset.action = 'view-feedback-progress'; action.dataset.id = feedbackId; action.textContent = '查看处理进度';
    toast.append(text, action); document.querySelector('#toast-root').appendChild(toast); setTimeout(() => toast.remove(), 6500);
  }
  function feedbackWorkspace(api) { return V9.renderFeedback({ ...api, embedded: true }); }
  function activityWorkspace(api) {
    const c = api.Ctx(), runs = api.M().agentRuns || [];
    const selectedRun = runs.find(run => run.runId === c.agentRunId) || runs.find(run => run.taskId && run.taskId === c.selectedTaskId) || runs[0];
    return V9.renderAgents({ ...api, embedded: true, Ctx: () => ({ ...c, agentRunId: selectedRun?.runId || null }) });
  }
  function homeComposition(project, entities) {
    const byType = type => entities.filter(entity => entity.typeId === type), sections = [];
    const domains = byType('Domain'), scenarios = byType('Scenario'), objects = byType('BusinessObject'), features = byType('Feature'), systems = [...byType('System'), ...byType('Subsystem')], components = [...byType('Component'), ...byType('Module')], decisions = [...byType('ArchitectureDecision'), ...byType('EngineeringConvention')], data = byType('DataEntity'), actors = byType('Actor');
    const technicalWeight = systems.length + components.length + byType('API').length + data.length, businessWeight = domains.length + scenarios.length + objects.length;
    const add = (kind, title, subtitle, items, priority) => { if (items.length) sections.push({ kind, title, subtitle, items, priority }); };
    if (technicalWeight >= 3) {
      add('capabilities', '核心软件能力', '从实际功能进入业务与技术认知', features, 10);
      add('architecture', '关键架构与组件', `${systems.length} 个系统 · ${components.length} 个主要组件，查看职责、依赖与来源`, [...systems, ...components], 20);
      if ((project.importProposals || []).length) add('imports', '真实知识接入', '从外部知识包到人工确认、草稿与批准基线', project.importProposals.slice(0, 3).map(proposal => ({ id: proposal.proposalId, name: proposal.package?.manifest?.projectName || proposal.packageId, description: `${proposal.status} · ${proposal.preview?.summary?.unchanged || 0} 项未变化`, typeId: 'ImportProposal', status: proposal.status })), 30);
      add('decisions', '工程约束与关键决策', '架构决策、工程约定和不可突破的实现边界', decisions, 40);
      add('data', '数据与状态', '项目数据、读写关系和本地/运行状态', data, 50);
      add('domains', '业务职责', '项目已建立的实际业务领域', domains, 55);
      add('scenarios', '关键业务场景', '复杂业务与系统实现共享同一认知入口', scenarios, 56);
      add('objects', '核心业务对象', '关键对象、状态和实际变化', objects, 57);
    } else {
      add('domains', '业务职责', '从实际业务领域理解项目负责什么', domains, 10);
      add('scenarios', '关键业务场景', '从参与者、触发条件和结果理解业务如何发生', scenarios, 20);
      add('capabilities', '软件功能与业务支撑', '功能如何支撑业务动作、规则与对象', features, 30);
      add('objects', '核心业务对象', '关键对象、状态和实际变化', objects, 40);
      add('architecture', '系统实现结构', '系统、组件与技术依赖', [...systems, ...components], 50);
      add('actors', '项目参与者', '实际角色与主要职责', actors, 60);
      if (decisions.length) add('decisions', '关键决策与约束', '理解当前实现必须遵守的边界', decisions, 70);
    }
    return { sections: sections.sort((a, b) => a.priority - b.priority).slice(0, 6), composition: technicalWeight >= 3 && businessWeight >= 3 ? 'mixed' : technicalWeight >= 3 ? 'technology-led' : businessWeight ? 'business-led' : 'capability-led', technicalWeight, businessWeight, hasMeaningfulContent: sections.length > 0 };
  }
  function availableVisualViews(project, projection) {
    if (!projection?.ok) return [];
    const ids = new Set(projection.nodes.map(node => node.entity.id));
    return (project.visualViews || []).filter(view => ids.has(view.rootKnowledgeId) && C.getEntity(project, view.rootKnowledgeId, projection.options));
  }
  function studioWorkbench(api, projection, focusId) {
    const c = api.Ctx(), views = availableVisualViews(api.M(), projection);
    if (!views.length || c.mode === 'build') return V.Workbench(api.M(), projection, focusId, { mode: c.mode });
    const selected = views.find(view => view.viewId === c.visualViewId) || views[0]; c.visualViewId = selected.viewId;
    const visualProjection = S.projectView(api.M(), api.readContext(), selected); if (!visualProjection.ok) return V.Workbench(api.M(), projection, focusId, { mode: c.mode });
    const actualFocus = c.visualFocusId || visualProjection.root.id;
    const tabs = [{ id: 'text', title: '文字解释', viewType: 'text' }, ...views.map(view => ({ id: view.viewId, title: view.title, viewType: view.viewType })), { id: 'split', title: '图文并读', viewType: 'split' }];
    const focusFacts = P.focusFacts(api.M(), projection, actualFocus);
    return `<div class="v91-studio-workbench ${c.visualFocusMode ? 'focus-mode' : ''}"><div class="v91-presentation-tabs" role="tablist">${tabs.map(tab => `<button role="tab" data-studio-presentation="${tab.id}" class="${(c.studioPresentation || 'text') === tab.id ? 'active' : ''}">${esc(tab.title)}<small>${esc(tab.viewType)}</small></button>`).join('')}<button class="v91-focus-toggle" data-action="${c.visualFocusMode ? 'exit-focus-mode' : 'visual-focus-mode'}">${c.visualFocusMode ? '返回工作台' : '展开专注画布'}</button></div><div class="v6-workbench v91-visual-workbench"><aside class="v6-structure"><div class="v6-pane-label">局部知识结构 <span>${projection.nodes.length} 个对象</span></div>${V.FlowStructure(api.M(), projection, actualFocus, false)}${V.SemanticStructure(api.M(), projection, actualFocus)}</aside><main class="v6-focus"><div class="v6-pane-label">${c.studioPresentation === 'split' ? '文字与图形共享焦点' : c.studioPresentation === 'text' ? '当前知识解释' : selected.title}</div>${c.studioPresentation === 'text' ? V.FocusCenter(api.M(), projection, focusFacts) : ''}${c.studioPresentation !== 'text' ? V9.renderVisuals(api, { embedded: true, availableViews: views, selectedView: selected, focusId: actualFocus, showInspector: false }) : ''}${c.studioPresentation === 'split' ? `<details class="v91-split-text" open><summary>文字解释</summary>${V.FocusCenter(api.M(), projection, focusFacts)}</details>` : ''}</main><aside class="v6-inspector"><div class="v6-pane-label">焦点检查器 <span>文字 · 图形 · 来源</span></div>${V9.renderVisualInspector(api, visualProjection, actualFocus)}</aside></div></div>`;
  }
  function syncContext(api) {
    if (api.state.route === 'projects') return;
    const state = A.panelState(api.store, api.M().meta.id);
    if (state.isOpen) state.contextualFocus = api.workspaceActionContext();
  }
  function afterRender(api) {
    if (api.state.route === 'projects') return;
    const state = A.panelState(api.store, api.M().meta.id);
    requestAnimationFrame(() => { const messages = document.querySelector('.v91-messages'); if (messages) messages.scrollTop = state.scrollPosition || messages.scrollHeight; });
  }
  function handleAction(action, el, api) {
    const c = api.Ctx(), project = api.M(), state = A.panelState(api.store, project.meta.id);
    const actions = ['close-assistant', 'minimize-assistant', 'assistant-new-conversation', 'assistant-suggestion', 'assistant-feedback', 'view-feedback-progress', 'open-task-activity', 'open-import-activity', 'visual-focus-mode', 'exit-focus-mode', 'toggle-inspector'];
    if (!actions.includes(action)) return false;
    if (action === 'close-assistant') { state.isOpen = false; state.minimized = false; api.save(); api.render(); return true; }
    if (action === 'minimize-assistant') { state.minimized = !state.minimized; api.save(); api.render(); return true; }
    if (action === 'assistant-new-conversation') { state.activeConversationId = null; state.draftText = ''; api.save(); api.render(); return true; }
    if (action === 'assistant-suggestion') { state.draftText = el.dataset.text; api.save(); document.querySelector('#assistant-input')?.focus(); return true; }
    if (action === 'assistant-feedback') {
      const answer = project.questionAnswers.find(item => item.answerId === el.dataset.id), helpful = el.dataset.kind === 'helpful';
      const result = S.createFeedback(project, { category: helpful ? 'product-experience' : 'agent-issue', title: helpful ? '助手回答有帮助' : '助手回答不准确', description: helpful ? `回答 ${el.dataset.id} 对工作有帮助。` : `回答 ${el.dataset.id} 存在不准确或缺少依据，需要复核。`, relatedKnowledgeIds: answer?.focusIds || [], originContext: { route: 'assistant', answerId: el.dataset.id, baselineId: answer?.readContext?.baselineId || c.baselineId, projectId: project.meta.id }, reporterRole: c.askRole || c.role });
      api.save(); notifyFeedback(api, result.feedback.feedbackId); return true;
    }
    if (action === 'view-feedback-progress') { c.feedbackId = el.dataset.id; c.collaborationTab = 'feedback'; api.save(); api.go('tasks'); return true; }
    if (action === 'open-task-activity') { c.selectedTaskId = el.dataset.task || c.selectedTaskId; c.collaborationTab = 'activity'; c.agentRunId = el.dataset.run || null; api.save(); api.go('tasks'); return true; }
    if (action === 'open-import-activity') { const run = project.agentRuns.find(item => item.importProposalId === el.dataset.id); if (run) c.agentRunId = run.runId; c.collaborationTab = 'activity'; api.save(); api.go('tasks'); return true; }
    if (action === 'toggle-inspector') { c.inspectorOpen = !c.inspectorOpen; api.save(); api.render(); return true; }
    if (action === 'visual-focus-mode' || action === 'exit-focus-mode') { c.visualFocusMode = action === 'visual-focus-mode'; if (c.studioPresentation === 'text') c.studioPresentation = 'visual'; api.save(); api.render(); return true; }
    return true;
  }
  function install(api) {
    document.addEventListener('pointerdown', event => {
      if (event.target.closest('[data-action="new-feedback"]')) api.state.feedbackReturnScroll = { x: window.scrollX, y: window.scrollY };
    }, true);
    document.addEventListener('click', event => {
      const el = event.target.closest('[data-studio-presentation]'); if (!el) return;
      const presentation = el.dataset.studioPresentation;
      api.Ctx().studioPresentation = presentation;
      if (!['text', 'split'].includes(presentation)) api.Ctx().visualViewId = presentation;
      api.save(); api.render();
    }, true);
    document.addEventListener('input', event => {
      if (event.target.id === 'assistant-input') { const state = A.updateDraft(api.store, api.M().meta.id, event.target.value); api.save(); }
    });
    document.addEventListener('keydown', event => {
      if (event.target.id !== 'assistant-input' || event.key !== 'Enter' || event.shiftKey || event.isComposing || event.keyCode === 229) return;
      event.preventDefault();
      if (!event.target.value.trim()) return;
      const state = A.panelState(api.store, api.M().meta.id);
      if (state.sending) return;
      document.querySelector('#assistant-form')?.requestSubmit();
    });
    document.addEventListener('scroll', event => {
      if (event.target.classList?.contains('v91-messages')) A.panelState(api.store, api.M().meta.id).scrollPosition = event.target.scrollTop;
    }, true);
    document.addEventListener('submit', event => {
      if (event.target.id !== 'assistant-form') return; event.preventDefault();
      const project = api.M(), state = A.panelState(api.store, project.meta.id), text = document.querySelector('#assistant-input').value.trim(); if (!text) return;
      if (state.sending) return;
      state.sending = true;
      try {
        const previous = project.questionAnswers.at(-1), conversation = state.activeConversationId ? null : api.assistantProvider.createConversation(project, { readContext: api.readContext(), contextualFocus: api.workspaceActionContext() });
        if (conversation) state.activeConversationId = conversation.conversationId;
        state.contextualFocus = api.workspaceActionContext();
        const result = api.assistantProvider.sendMessage(project, { text, role: api.Ctx().askRole || 'newcomer', readContext: api.readContext(), contextualFocus: state.contextualFocus, followUpOf: /^(追问|继续|接着)|^(它|这个(?!系统))/.test(text) ? previous?.answerId : undefined, conversationId: state.activeConversationId });
        if (result.ok) { state.draftText = ''; state.scrollPosition = Number.MAX_SAFE_INTEGER; }
        else { state.draftText = text; api.toast(result.guidance || '当前资料不足或未能定位知识，请补充描述或打开查询范围。', 'error'); }
        api.save(); api.render();
      } finally { state.sending = false; }
    });
  }
  return { NAVIGATION, resolveLegacyRoute, AssistantPanel, openAssistant, notifyFeedback, feedbackWorkspace, activityWorkspace, homeComposition, availableVisualViews, studioWorkbench, syncContext, afterRender, handleAction, install, compactAnswer };
});
