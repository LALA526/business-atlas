/* Business Atlas V7 — Schema-driven creation and editing forms without JSON. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const K = commonjs ? require('../v4-core.js') : root.AtlasCore;
  const C = commonjs ? require('./v6-core.js') : root.AtlasV6;
  const F = commonjs ? require('./v7-framework.js') : root.AtlasV7Framework;
  const V = commonjs ? require('./v5-views.js') : root.AtlasV5Views;
  const api = factory(K, C, F, V);
  if (commonjs) module.exports = api;
  root.AtlasV7Schema = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (K, C, F, V) {
  'use strict';
  const esc = V.esc;
  function fieldsFor(p, typeId) { const schema = F.schemaFor(p, typeId); return (schema?.fields || []).filter(f => !['name', 'description'].includes(f.id)); }
  function fieldControl(p, field, value) {
    const id = `schema-${field.id}`, val = value ?? (field.dataType === 'boolean' ? false : ''), required = field.required ? ' *' : '';
    if (field.dataType === 'boolean') return `<label class="v7-schema-check"><input type="checkbox" id="${esc(id)}" data-schema-field="${esc(field.id)}" data-type="boolean" ${val ? 'checked' : ''}> ${esc(field.label)}${required}</label>`;
    if (field.dataType === 'enum') return `<label>${esc(field.label)}${required}<select id="${esc(id)}" data-schema-field="${esc(field.id)}" data-type="enum"><option value="">请选择</option>${(field.options || []).map(option => { const v = typeof option === 'object' ? option.value : option, label = typeof option === 'object' ? option.label : option; return `<option value="${esc(v)}" ${val === v ? 'selected' : ''}>${esc(label)}</option>`; }).join('')}</select></label>`;
    if (field.dataType === 'ref' || field.dataType === 'resource') return `<label>${esc(field.label)}${required}<select id="${esc(id)}" data-schema-field="${esc(field.id)}" data-type="ref"><option value="">暂不关联</option>${C.allEntities(p, { draft: true }).filter(e => field.dataType === 'resource' ? e.typeId === 'Resource' : true).map(e => `<option value="${e.id}" ${val === e.id ? 'selected' : ''}>${esc(e.name)} · ${esc(e.id)}</option>`).join('')}</select></label>`;
    if (['longtext', 'json', 'refs'].includes(field.dataType)) return `<label>${esc(field.label)}${required}<textarea id="${esc(id)}" data-schema-field="${esc(field.id)}" data-type="${field.dataType}" placeholder="${field.dataType === 'refs' ? '每行一个知识对象 ID' : field.dataType === 'json' ? '每行一项，或 键:值；不需要 JSON' : ''}">${esc(Array.isArray(val) ? val.join('\n') : typeof val === 'object' ? Object.entries(val).map(([k, v]) => `${k}:${v}`).join('\n') : val)}</textarea></label>`;
    return `<label>${esc(field.label)}${required}<input id="${esc(id)}" data-schema-field="${esc(field.id)}" data-type="${field.dataType}" type="${['number', 'money', 'duration', 'unit'].includes(field.dataType) ? 'number' : field.dataType === 'date' ? 'date' : 'text'}" value="${esc(val)}" placeholder="${esc(field.dataType)}"></label>`;
  }
  function formHtml(p, typeId, context = {}) {
    const schema = F.schemaFor(p, typeId); if (!schema) throw new Error(`知识类型 ${typeId} 尚未注册`);
    const fields = fieldsFor(p, typeId);
    return `<div class="v5-note blue">${esc(schema.name)} · 由 Schema Registry 生成表单。保存后进入当前 Change Set，不会直接发布。</div><label>名称 *<input id="schema-entity-name" value="${esc(context.name || '')}"></label><label>业务定义<textarea id="schema-entity-description">${esc(context.description || '')}</textarea></label><div class="v7-schema-fields">${fields.map(field => fieldControl(p, field, context.props?.[field.id])).join('')}</div>${!fields.length ? '<p>此类型只需要名称和业务定义，可在创建后继续建立关联。</p>' : ''}`;
  }
  function parseStructured(text) {
    const lines = String(text || '').split('\n').map(x => x.trim()).filter(Boolean); if (!lines.length) return [];
    if (lines.every(line => line.includes(':'))) return Object.fromEntries(lines.map(line => { const index = line.indexOf(':'); return [line.slice(0, index).trim(), line.slice(index + 1).trim()]; }));
    return lines;
  }
  function readForm(p, typeId) {
    const props = {};
    fieldsFor(p, typeId).forEach(field => {
      const el = document.querySelector(`[data-schema-field="${CSS.escape(field.id)}"]`); if (!el) return;
      if (field.dataType === 'boolean') props[field.id] = el.checked;
      else if (['number', 'money', 'duration', 'unit'].includes(field.dataType)) props[field.id] = el.value === '' ? null : Number(el.value);
      else if (field.dataType === 'refs') props[field.id] = el.value.split(/[、,，\n]/).map(x => x.trim()).filter(Boolean);
      else if (field.dataType === 'json') props[field.id] = parseStructured(el.value);
      else props[field.id] = el.value;
    });
    return { name: document.querySelector('#schema-entity-name').value.trim(), description: document.querySelector('#schema-entity-description').value.trim(), props };
  }
  function createFromForm(p, typeId, context = {}) {
    const data = readForm(p, typeId), extra = {};
    if (typeId === 'BusinessObject') { extra.states = data.props.states || []; extra.props = Array.isArray(data.props.properties) ? data.props.properties : []; }
    if (typeId === 'Scenario') extra.goal = data.description;
    const entity = C.execute(p, 'CreateEntity', { typeId, name: data.name, description: data.description, props: data.props, extra, id: context.id }).entity;
    if (context.categoryId) entity.categoryAssignments = [...(entity.categoryAssignments || []), { categoryId: context.categoryId, origin: 'user', assignmentStatus: 'confirmed', sourceRef: p.draftWorkspace.id, applicableContext: { projectId: p.meta.id } }];
    if (context.link) C.execute(p, 'LinkKnowledge', { ...context.link, object: context.link.object === 'NEW_ENTITY' ? entity.id : context.link.object, subject: context.link.subject === 'NEW_ENTITY' ? entity.id : context.link.subject });
    return entity;
  }
  function registerTypeForm() {
    return `<div class="v5-note blue">类型与分类是配置，不是业务数据副本。注册后即可通过同一 Command 创建、关联、发布和还原。</div><div class="v5-two-col"><label>类型名称 *<input id="new-type-name" placeholder="例如：检验项目"></label><label>稳定类型 ID *<input id="new-type-id" placeholder="InspectionItem（英文）"></label></div><label>显示前缀<input id="new-type-prefix" placeholder="例如：INSP；留空自动处理"></label><label>字段（每行：字段ID | 显示名 | 类型 | 必填 | 枚举候选）<textarea id="new-type-fields" placeholder="code | 检验代码 | text | required |&#10;method | 检验方式 | enum |  | 外观,尺寸,性能&#10;required | 是否必需 | boolean | required |"></textarea></label><div class="v5-two-col"><label>所属一级维度<select id="new-type-dimension"><option value="business">业务认知</option><option value="system">系统认知</option><option value="assets">知识资产</option><option value="project">项目认知</option></select></label><label>二级分类名称<input id="new-type-category" placeholder="例如：检验项目"></label></div>`;
  }
  function registerType(p) {
    const id = document.querySelector('#new-type-id').value.trim(), name = document.querySelector('#new-type-name').value.trim(), prefix = document.querySelector('#new-type-prefix').value.trim();
    if (!id || !name) throw new Error('类型名称和稳定 ID 不能为空');
    const fields = document.querySelector('#new-type-fields').value.split('\n').map(line => line.trim()).filter(Boolean).map(line => {
      const [fieldId, label, dataType = 'text', required, options] = line.split('|').map(x => x.trim());
      return { id: fieldId, label, dataType, required: required === 'required', ...(dataType === 'enum' ? { options: (options || '').split(/[、,，]/).filter(Boolean) } : {}) };
    });
    K.registerType(p, { id, name, fields, idPrefix: prefix || undefined, dimension: document.querySelector('#new-type-dimension').value === 'system' ? '系统认知' : '项目扩展' });
    if (prefix) p.schemaRegistry[id].idPrefix = prefix;
    F.registerCategory(p, { categoryId: `custom.${id}`, dimension: document.querySelector('#new-type-dimension').value, name: document.querySelector('#new-type-category').value.trim() || name, description: `${name}项目自定义知识分类`, applicableTypes: [id], suggestedCreationActions: [`CreateEntity:${id}`] });
    return F.schemaFor(p, id);
  }
  return { fieldsFor, fieldControl, formHtml, readForm, createFromForm, registerTypeForm, registerType, parseStructured };
});
