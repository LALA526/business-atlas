/* Business Atlas V9.1 — Assistant Provider contract and project-local panel state. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const S = commonjs ? require('./v9-services.js') : root.AtlasV9Services;
  const C = commonjs ? require('./v6-core.js') : root.AtlasV6;
  const Access = commonjs ? require('./v9-access.js') : root.AtlasV9Access;
  const api = factory(S, C, Access);
  if (commonjs) module.exports = api;
  root.AtlasV91Assistant = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (S, C, Access) {
  'use strict';
  const clone = C.clone;
  const CAPABILITIES = Object.freeze({ providerId: 'existing-knowledge-query', displayName: '项目知识查询助手', deterministic: true, llmConnected: false, supportsCancellation: true, supportsConversationHistory: true, supportsKnowledgeReferences: true, supportedIntents: ['WHY', 'HOW', 'IMPACT', 'DIFFERENCE', 'REQUIREMENT'], limitations: ['有限自然语言意图识别', '无法可靠定位时要求澄清', '不执行真实 Agent 或 MCP'] });
  function ExistingKnowledgeQueryProvider() {
    const cancelled = new Set();
    return Object.freeze({
      getCapabilities() { return clone(CAPABILITIES); },
      createConversation(project, input = {}) {
        const id = input.conversationId || `CONV-${project.meta.id}-${Date.now().toString(36)}`;
        return { conversationId: id, projectId: project.meta.id, createdAt: C.now(), readContext: clone(input.readContext), contextualFocus: clone(input.contextualFocus || null), messages: [] };
      },
      sendMessage(project, input = {}) {
        if (cancelled.has(input.requestId)) return { ok: false, code: 'CANCELLED', error: '本次查询已取消' };
        const result = S.ask(project, input.readContext, { text: input.text, intent: input.intent, role: input.role || 'newcomer', rootId: input.contextualFocus?.knowledgeId || input.rootId, followUpOf: input.followUpOf, conversationId: input.conversationId });
        if (!result.ok) return { ...result, actions: (result.candidates || []).map(candidate => ({ type: 'select-knowledge', knowledgeId: candidate.id, label: candidate.name })) };
        return { ok: true, answer: result.answer, citations: clone(result.answer.citations), unknowns: clone(result.answer.limitations), actions: result.answer.citations.map(citation => ({ type: 'open-knowledge', knowledgeId: citation.sourceId || citation.knowledgeId, label: '打开引用知识' })) };
      },
      cancelRequest(requestId) { cancelled.add(requestId); return { ok: true, requestId, status: 'cancelled' }; },
      listHistory(project, input = {}) {
        const visible = input.readContext ? new Set(Access.listEntities(project, input.readContext).data.map(entity => entity.id)) : null;
        return (project.questionAnswers || []).filter(answer => !input.conversationId || answer.conversationId === input.conversationId).filter(answer => !input.before || answer.createdAt < input.before).filter(answer => !visible || (answer.focusIds || []).every(id => visible.has(id)) && (answer.citations || []).every(citation => visible.has(citation.knowledgeId) && (!citation.sourceId || visible.has(citation.sourceId)))).slice(-(input.limit || 30)).map(clone);
      },
      resolveKnowledgeReferences(project, input = {}) {
        const ids = new Set((input.answer?.citations || []).flatMap(citation => [citation.sourceId, citation.knowledgeId]).filter(Boolean));
        return [...ids].map(knowledgeId => ({ knowledgeId, action: { type: 'open-studio', knowledgeId, preserveAssistant: true, returnContext: input.returnContext || null } }));
      }
    });
  }
  function migrateStore(store) {
    if (!store || typeof store !== 'object') return store;
    store.assistantByProject ||= {};
    Object.entries(store.projects || {}).forEach(([projectId, project]) => {
      const context = store.contexts?.[projectId] || {}, previous = store.assistantByProject[projectId] || {};
      store.assistantByProject[projectId] = {
        isOpen: previous.isOpen === true,
        minimized: previous.minimized === true,
        activeConversationId: previous.activeConversationId || context.conversationId || project.questionAnswers?.at(-1)?.conversationId || null,
        draftText: previous.draftText ?? context.askDraft ?? '',
        relatedProjectId: projectId,
        contextualFocus: previous.contextualFocus || null,
        scrollPosition: Number(previous.scrollPosition || 0),
        optionalExpandedCitation: previous.optionalExpandedCitation || null,
        answerFormat: previous.answerFormat || context.answerFormat || 'internal',
        returnRoute: previous.returnRoute || 'home'
      };
    });
    return store;
  }
  function panelState(store, projectId) {
    const state = store.assistantByProject[projectId];
    if (!state) throw new Error(`助手项目状态不存在：${projectId}`);
    return state;
  }
  function updateDraft(store, projectId, text) { const state = panelState(store, projectId); state.draftText = String(text ?? ''); return state; }
  function setOpen(store, projectId, isOpen, options = {}) {
    const state = panelState(store, projectId); state.isOpen = !!isOpen; state.minimized = options.minimized ?? false;
    if (isOpen && options.returnRoute) state.returnRoute = options.returnRoute;
    return state;
  }
  function switchProject(store, fromProjectId, toProjectId) {
    if (store.projects[toProjectId]) {
      const previous = panelState(store, fromProjectId); previous.relatedProjectId = fromProjectId;
      const next = panelState(store, toProjectId); next.relatedProjectId = toProjectId;
      return next;
    }
    throw new Error('目标项目不存在');
  }
  function conversationHistory(project, conversationId) { return (project.questionAnswers || []).filter(answer => !conversationId || answer.conversationId === conversationId); }
  function workspaceActionContext(input = {}) {
    return {
      projectId: input.projectId || null, route: input.route || 'home', knowledgeId: input.knowledgeId || input.focusId || input.rootId || null,
      taskId: input.taskId || null, baselineId: input.baselineId || null, versionMode: input.versionMode || 'published', applicableContext: clone(input.applicableContext || {}),
      permissionContext: clone(input.permissionContext || {}), visualViewId: input.visualViewId || null, focusId: input.focusId || null,
      origin: input.origin || input.route || 'workspace', returnContext: clone(input.returnContext || null)
    };
  }
  return { ExistingKnowledgeQueryProvider, CAPABILITIES, migrateStore, panelState, updateDraft, setOpen, switchProject, conversationHistory, workspaceActionContext };
});
