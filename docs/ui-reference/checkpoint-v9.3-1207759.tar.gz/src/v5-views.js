/* Business Atlas V5 — composable, evidence-first reading components. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const core = commonjs ? require('../v4-core.js') : root.AtlasCore;
  const engine = commonjs ? require('../engine.js') : root.AtlasEngine;
  const v5 = commonjs ? require('./v5-core.js') : root.AtlasV5;
  const api = factory(core, engine, v5);
  if (commonjs) module.exports = api;
  root.AtlasV5Views = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (K, E, G) {
  'use strict';
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const badge = (text, tone = '') => `<span class="v5-badge ${tone}">${esc(text)}</span>`;
  const empty = (title, copy) => `<div class="v5-empty"><span>○</span><div><b>${esc(title)}</b><p>${esc(copy)}</p></div></div>`;
  const typeName = (p, id) => p.schemaRegistry?.[id]?.name || K.TYPE_LABELS[id] || id || '知识';
  const status = s => ({ published: '已发布', approved: '已批准', confirmed: '已核验', unverified: '待核验', conflicted: '存在冲突', historical_intent: '历史意图', approved_specification: '批准规范', observed_implementation: '观察实现', draft: '草稿', pending: '待审阅', active: '进行中', completed: '已完成', stale: '待复核', restricted: '受限' }[s] || s || '未知');
  const tone = s => ['published', 'approved', 'confirmed', 'completed'].includes(s) ? 'green' : ['conflicted'].includes(s) ? 'red' : ['unverified', 'pending', 'draft', 'stale', 'historical_intent'].includes(s) ? 'amber' : 'blue';
  function link(p, id, label, extra = '') { const item = G.getEntity(p, id); return item ? `<button class="v5-link" data-open="${esc(id)}" ${extra}>${esc(label || item.name)}<small>${esc(id)}</small></button>` : `<span class="v5-missing">${esc(label || id)} · 未建立</span>`; }
  function section(id, title, subtitle, body, aside = '') { return body ? `<section class="v5-panel" data-section="${esc(id)}"><header class="v5-panel-head"><div><h2>${esc(title)}</h2>${subtitle ? `<p>${esc(subtitle)}</p>` : ''}</div>${aside}</header>${body}</section>` : ''; }
  function kv(label, value) { if (value === undefined || value === null || value === '' || (Array.isArray(value) && !value.length)) return ''; return `<div class="v5-kv"><dt>${esc(label)}</dt><dd>${esc(typeof value === 'object' ? JSON.stringify(value) : value)}</dd></div>`; }
  function sourceRefs(p, refs = []) {
    if (!refs.length) return `<span class="v5-source-missing">未提供来源 · 不得视为已核验</span>`;
    return refs.map(ref => { const item = G.getEntity(p, ref.resourceId); const locator = typeof ref.locator === 'string' ? ref.locator : JSON.stringify(ref.locator || item?.props?.locator || ''); return `<button class="v5-source" data-open="${esc(ref.resourceId)}"><span>↗</span><div><b>${esc(item?.name || ref.resourceId)}</b><small>${esc(locator)} · ${esc(item?.props?.sourceVersion || '版本未记录')}</small></div></button>`; }).join('');
  }
  function summary(p, item) {
    const desc = item.selectedVersion?.summary || item.description || item.goal || item.purpose || item.conclusion;
    return `<div class="v5-summary"><p>${esc(desc || '此对象只有稳定身份，业务定义尚未补充。')}</p><div>${badge(typeName(p, item.typeId), 'blue')}${badge(status(item.status), tone(item.status))}<span class="v5-rev">${esc(item.id)}@${esc(G.currentRevision(item))}</span></div></div>`;
  }
  function properties(p, item) {
    const rows = [];
    const schema = K.schemaFor(p, item.typeId);
    (schema?.fields || []).filter(f => !['name', 'description', 'states', 'fields', 'locator', 'defaultValue', 'allowedValues'].includes(f.id)).forEach(f => {
      const value = item.props?.[f.id]; if (value === undefined || value === null || value === '') return;
      let display = value; if (f.dataType === 'boolean') display = value ? '是' : '否'; else if (Array.isArray(value)) display = value.map(v => typeof v === 'object' ? JSON.stringify(v) : v).join('；'); else if (typeof value === 'object') display = JSON.stringify(value);
      rows.push([f.label, display]);
    });
    const legacy = item.typeId === 'BusinessObject' ? [['别名', (item.aliases || []).join('、')], ['主要属性', (item.props || []).join('、')]] : item.typeId === 'Action' ? [['前置条件', (item.pre || []).join('；')], ['输入', (item.input || []).join('、')], ['输出', (item.output || []).join('、')]] : [];
    legacy.forEach(([label, value]) => { if (value && !rows.some(r => r[0] === label)) rows.push([label, value]); });
    if (!rows.length) return '';
    return `<dl class="v5-kv-grid">${rows.map(([label, value]) => kv(label, value)).join('')}</dl>`;
  }
  function StateLifecycle(p, item, options = {}) {
    const graph = G.stateGraph(p, item.id, { includeUnverified: options.includeUnverified !== false });
    const directory = graph.states.length ? `<div class="v5-state-directory" aria-label="合法状态目录">${graph.states.map(s => `<span>${esc(s)}</span>`).join('')}</div>` : '';
    if (!graph.hasLifecycle) return section('lifecycle', '状态目录，而非生命周期', '只有状态集合，未建立明确转移；不会按数组顺序连接。', `${directory}${empty('尚未建立状态转移', '请补充 fromState、toState、触发事件、守卫、动作与来源后再绘制箭头。')}`);
    const confirmed = graph.transitions.filter(t => t.verificationStatus === 'confirmed'), inferred = graph.transitions.filter(t => t.verificationStatus !== 'confirmed');
    const transition = t => `<article class="v5-transition ${t.verificationStatus !== 'confirmed' ? 'unverified' : ''}"><div class="v5-transition-route"><b>${esc(t.fromState)}</b><span aria-label="转移到">→</span><b>${esc(t.toState)}</b></div><div class="v5-transition-detail"><div>${badge(t.verificationStatus === 'confirmed' ? '已确认转移' : '待核验 · 不属于批准路径', tone(t.verificationStatus))}<code>${esc(t.triggerEvent)}</code></div><p><strong>条件</strong> ${esc(t.guard)}</p><p><strong>动作</strong> ${link(p, t.actionRef)} <strong>结果</strong> ${esc(t.effect)}</p><details><summary>查看转移来源</summary>${sourceRefs(p, t.sourceRefs)}</details></div></article>`;
    return section('lifecycle', '真实状态转移', `${confirmed.length} 条已确认 · ${inferred.length} 条待核验；终态没有虚构出口。`, `${directory}<div class="v5-transition-list">${confirmed.map(transition).join('')}</div>${inferred.length ? `<details class="v5-inferred"><summary>显示 ${inferred.length} 条未核验转移（默认不参与批准路径）</summary>${inferred.map(transition).join('')}</details>` : ''}`, badge('States ≠ Transitions', 'purple'));
  }
  function CausalFlow(p, scenario) {
    const flow = E.flowFor(p, scenario.id);
    if (!flow.nodes.length) return '';
    if (!flow.edges.length) return section('causalFlow', '流程节点目录', '没有明确边，不推断业务先后。', `${flow.nodes.map(n => link(p, n.actionId, n.name)).join('')}${empty('尚未建立因果流程', '节点存在不代表它们之间有业务流转。')}`);
    const node = id => flow.nodes.find(n => n.id === id);
    const name = n => n ? (G.getEntity(p, n.actionId)?.name || n.name || n.id) : '无效节点';
    const edgeType = { next: '正常流转', when: '条件分支', parallel: '并行开始', join: '并行汇合', event: '事件触发', error: '异常处理', return: '恢复回流', terminate: '终止结果' };
    return section('causalFlow', '规范流程定义 · 显式因果边', '以下箭头只来自 Flow.edges；不是阶段或步骤数组顺序，也不是某次实例执行记录。', `<div class="v5-flow-edges">${flow.edges.map(edge => {
      const from = node(edge.from), to = node(edge.to);
      return `<article class="v5-flow-edge ${esc(edge.type)}"><div class="v5-flow-node">${from?.actionId ? link(p, from.actionId, name(from)) : `<b>${esc(name(from))}</b>`}<small>${esc(from?.type || '')}</small></div><div class="v5-flow-arrow"><span>${esc(edgeType[edge.type] || edge.type)}</span><b>→</b>${edge.label || edge.when?.outcomeId ? `<small>${esc(edge.label || edge.when?.outcomeId)}</small>` : ''}</div><div class="v5-flow-node">${to?.actionId ? link(p, to.actionId, name(to)) : `<b>${esc(name(to))}</b>`}<small>${esc(to?.type || '')}</small></div></article>`;
    }).join('')}</div><div class="v5-note">流程定义与执行实例分离。实例路径请到“协作执行”查看，不会回写此规范。</div>`, badge(`${flow.edges.length} 条明确边`, 'blue'));
  }
  function CaseActivities(p, scenario) {
    const model = scenario.caseModel; if (!model) return '';
    return section('caseActivities', '案件型活动与完成条件', '活动按需创建，不把补正、会签和安全核查强制排成线性步骤。', `<div class="v5-two-col"><div><h3>允许终止前必须满足</h3><ul class="v5-checks">${(model.completionConditions || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul><h3>可用活动</h3>${(model.availableActivityIds || []).map(id => link(p, id)).join('')}</div><div><h3>动态任务</h3><ul class="v5-checks open">${(model.dynamicTasks || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul><div class="v5-note amber">多角色会签仅表达定义与独立意见要求；本原型不伪造并行调度状态。</div></div></div>`);
  }
  function AssertionList(p, id, options = {}) {
    let assertions = G.assertionsFor(p, id, { ...options, permission: options.permission || p.viewPermission });
    if (options.predicates) assertions = assertions.filter(a => options.predicates.includes(a.predicate));
    if (!assertions.length) return empty('尚未建立此范围内的语义断言', '相关知识节点的存在不会自动被解释成业务因果。');
    return `<div class="v5-assertions">${assertions.map(a => {
      const outgoing = a.subject === id, other = outgoing ? a.object : a.subject;
      return `<article class="v5-assertion"><div class="v5-assertion-top"><span class="v5-predicate">${outgoing ? '当前对象' : esc(G.getEntity(p, a.subject)?.name || a.subject)} · ${esc(G.PREDICATES[a.predicate]?.label || a.predicate)}</span>${badge(status(a.verificationStatus), tone(a.verificationStatus))}${badge(status(a.factKind), a.factKind === 'historical_intent' ? 'amber' : 'blue')}</div><div class="v5-assertion-body">${other ? link(p, other) : `<code>${esc(JSON.stringify(a.value))}</code>`}<p>${esc(a.explanation || '')}</p>${Object.keys(a.qualifiers || {}).length ? `<dl>${Object.entries(a.qualifiers).filter(([,v]) => v !== undefined && v !== null && v !== '').map(([k,v]) => `<div><dt>${esc(({ environment: '环境', organization: '组织', region: '区域', businessScope: '业务范围', configVersion: '配置版本', version: '适用版本', condition: '条件', operation: '操作', fields: '字段', fromState: '原状态', toState: '目标状态', transaction: '事务' })[k] || k)}</dt><dd>${esc(typeof v === 'object' ? JSON.stringify(v) : v)}</dd></div>`).join('')}</dl>` : ''}</div><details><summary>${esc(a.assertionId)}@${esc(a.revision)} · 来源与确认</summary>${sourceRefs(p, a.sourceRefs)}<p class="v5-meta">责任确认：${esc(a.owner)} · 生效 ${esc(a.validTime?.from || '未记录')}</p><button class="v5-button small" data-action="new-change" data-id="${esc(a.assertionId)}">提出断言修改</button></details></article>`;
    }).join('')}</div>`;
  }
  function Sources(p, item) {
    const refs = [...(item.sourceIds || []).map(id => ({ resourceId: id, locator: '对象级来源' })), ...G.assertionsFor(p, item.id).flatMap(a => a.sourceRefs || [])];
    const unique = [...new Map(refs.map(r => [`${r.resourceId}:${JSON.stringify(r.locator)}`, r])).values()];
    const body = unique.length ? sourceRefs(p, unique) : empty('缺少来源', '此对象可以阅读，但不能把缺失来源的内容自动视为已核验事实。');
    const conflicts = (p.conflictRecords || []).filter(c => c.assertionIds?.some(id => G.assertionsFor(p, item.id).some(a => a.assertionId === id)));
    return section('sources', '证据、事实类别与冲突', '批准规范、观察实现与历史意图分别保留。', `${body}${conflicts.map(c => `<div class="v5-note red"><b>${esc(c.title)}</b><p>${esc(c.resolution)}</p></div>`).join('')}`);
  }
  function Configuration(p, item) {
    const props = item.props || {}, envs = (props.environments || []).map(id => G.getEntity(p, id)).filter(Boolean);
    const valueRows = ['defaultValue', 'allowedValues'].filter(key => props[key] !== undefined).map(key => `<div><h3>${key === 'defaultValue' ? '当前默认取值' : '允许取值与约束'}</h3><pre>${esc(JSON.stringify(props[key], null, 2))}</pre></div>`).join('');
    const scope = props.effectiveWhen || props.regions?.length || envs.length ? `<dl class="v5-kv-grid">${kv('生效条件', props.effectiveWhen)}${kv('组织 / 区域 / 租户', (props.regions || []).join('、'))}${kv('配置版本', props.configVersion)}</dl><div class="v5-envs">${envs.map(env => `<article><b>${esc(env.name)}</b><p>${esc(env.props?.environment || env.id)} · ${esc(env.props?.plant || env.props?.region || '')}</p><span>软件 ${esc(env.props?.release || '未知')} / 配置 ${esc(env.props?.configVersion || '未知')}</span></article>`).join('')}</div>` : '';
    return [
      ['valueConstraints', section('valueConstraints', '取值与约束', '配置值不是完整业务解释，需结合适用范围和影响阅读。', valueRows)],
      ['effectiveScope', section('effectiveScope', '生效范围与环境对比', '只展示实际记录的环境，不虚构测试或灰度环境。', scope)],
      ['impacts', section('impacts', '影响哪些规则与功能', '每条影响都有环境、业务范围、配置版本与证据。', AssertionList(p, item.id, { predicates: ['affects', 'implements', 'references'] }))],
      ['risks', props.risk ? section('risks', '修改风险', '', `<div class="v5-note amber">${esc(props.risk)}</div>`) : '']
    ];
  }
  function DataEntity(p, item) {
    const fields = item.props?.fields || [];
    return [
      ['ownership', section('ownership', '数据归属', '', `<dl class="v5-kv-grid">${kv('物理表', item.props?.tableName)}${kv('业务 / 技术归属', item.props?.owner)}${kv('实现版本', item.props?.implementationVersion)}</dl>`)],
      ['fields', fields.length ? section('fields', '核心字段', `${fields.length} 个已建模字段；字段名不替代完整数据库知识。`, `<div class="v5-table-wrap"><table><thead><tr><th>字段</th><th>类型</th><th>业务含义</th></tr></thead><tbody>${fields.map(f => `<tr><td><code>${esc(f.name)}</code></td><td>${esc(f.type)}</td><td>${esc(f.description || '未记录')}</td></tr>`).join('')}</tbody></table></div>`) : ''],
      ['readersWriters', section('readersWriters', '谁读取、谁写入', '从数据反向追踪动作、接口与功能。', AssertionList(p, item.id, { predicates: ['reads', 'writes'] }))],
      ['constraints', section('constraints', '事务与数据约束', '', `<dl class="v5-kv-grid">${kv('事务 / 一致性', item.props?.transaction)}${kv('生命周期', item.props?.lifecycle)}</dl>${!item.props?.transaction ? '<div class="v5-note amber">事务边界尚未建立；修改前需要技术核验。</div>' : ''}`)],
      ['dataRelations', section('dataRelations', '业务对象与数据映射', '', AssertionList(p, item.id, { predicates: ['references', 'implements', 'explains'] }))]
    ];
  }
  function Rule(p, item) {
    const version = item.selectedVersion || item.versions?.[item.currentVersion] || item.versions?.draft;
    if (!version) return [];
    const decision = version.supportsEvaluation === false ? `<div class="v5-note blue"><b>人工核验约束</b><p>${esc(version.constraint || version.summary)}</p></div>` : `<div class="v5-table-wrap"><table><thead><tr><th>优先级</th>${version.inputs.map(i => `<th>${esc(i.label)}</th>`).join('')}<th>判断结果</th></tr></thead><tbody>${[...(version.exceptions || []), ...(version.rows || [])].sort((a,b) => a.priority - b.priority).map(row => `<tr><td><code>${esc(row.id)}</code> · ${row.priority}</td>${version.inputs.map(input => `<td>${esc(input.options?.find(o => o.value === row.when?.[input.id])?.label || row.when?.[input.id] || '任意')}</td>`).join('')}<td>${badge(version.outcomes.find(o => o.id === row.outcomeId)?.label || row.outcomeId, 'purple')}</td></tr>`).join('')}</tbody></table></div><div class="v5-simulator"><h3>条件试算 <small>只评估当前规则修订，不修改业务事实</small></h3><div>${version.inputs.map(input => `<label>${esc(input.label)}<select data-rule-input="${esc(input.id)}" data-rule="${esc(item.id)}">${input.options.map(o => `<option value="${esc(o.value)}">${esc(o.label)}</option>`).join('')}</select></label>`).join('')}</div><output id="v5-rule-result">${RuleSimulation(p, item, E.defaultValues(version))}</output></div>`;
    return [
      ['ruleContext', section('ruleContext', '适用上下文', '', `<dl class="v5-kv-grid">${kv('规则版本', version.version)}${kv('生效时间', version.effective)}${kv('适用范围', version.scope)}${kv('规范来源', version.source)}</dl>`)],
      ['decision', section('decision', '条件如何决定结果', '结构化决策行是当前修订的定义，不从说明文字推断。', decision)],
      ['exceptions', version.exceptions?.length ? section('exceptions', '例外', '', AssertionList(p, item.id, { predicates: ['blocks', 'constrains'] })) : section('exceptions', '约束与阻止行为', '', AssertionList(p, item.id, { predicates: ['blocks', 'constrains'] }))],
      ['impacts', section('impacts', '影响范围', '', AssertionList(p, item.id, { predicates: ['affects', 'constrains', 'blocks', 'uses', 'implements'] }))]
    ];
  }
  function RuleSimulation(p, item, values) {
    const version = item.selectedVersion || item.versions?.[item.currentVersion] || item.versions?.draft, result = E.evaluateRule(version, values);
    return `<div class="v5-sim-result ${result.outcome ? 'ok' : 'warn'}"><b>${esc(result.outcome?.label || result.code)}</b><p>${esc(result.explanation)}</p><code>${esc(item.id)}@${esc(version.version)}</code></div>`;
  }
  function API(p, item) {
    const props = item.props || {};
    return [
      ['contract', section('contract', '接口契约', '', `<div class="v5-endpoint"><b>${esc(props.method || '')}</b><code>${esc(props.path || '路径未记录')}</code><span>${esc(props.contractVersion || '')}</span></div><div class="v5-two-col"><div><h3>输入</h3><pre>${esc(JSON.stringify(props.input || {}, null, 2))}</pre></div><div><h3>输出</h3><pre>${esc(JSON.stringify(props.output || {}, null, 2))}</pre></div></div>`)],
      ['businessTrace', section('businessTrace', '反向追踪业务', '一个 API 可实现多个动作，一个动作也可由不同入口触发。', AssertionList(p, item.id, { predicates: ['implements', 'triggers', 'constrains'] }))],
      ['dataMappings', section('dataMappings', '数据读取与写入', '', AssertionList(p, item.id, { predicates: ['reads', 'writes'] }))],
      ['failure', section('failure', '事务、失败与恢复', '', `<dl class="v5-kv-grid">${kv('事务 / 一致性', props.transaction)}${kv('失败处理', props.failure)}</dl>`)]
    ];
  }
  function Action(p, item) {
    const changes = item.objectChanges || [];
    return [
      ['behavior', section('behavior', '前置、判断与输出', '', `<dl class="v5-kv-grid">${kv('业务目的', item.purpose)}${kv('前置条件', (item.pre || []).join('；'))}${kv('输入', (item.input || []).join('、'))}${kv('输出', (item.output || []).join('、'))}</dl>${AssertionList(p, item.id, { predicates: ['constrains', 'blocks', 'uses'] })}`)],
      ['objectChanges', changes.length ? section('objectChanges', '业务对象前后变化', '仅呈现明确记录的变化，不推断其他对象也受影响。', changes.map(c => `<article class="v5-object-change"><b>${link(p, c.objectId)}</b><div><span>${esc(c.before)}</span><strong>→</strong><span>${esc(c.after)}</span></div><p>${esc(c.constraint)}</p></article>`).join('')) : section('objectChanges', '对象变化', '', AssertionList(p, item.id, { predicates: ['changes', 'transitions', 'writes', 'produces'] }))],
      ['businessTrace', section('businessTrace', '入口与技术实现', '', AssertionList(p, item.id, { predicates: ['triggers', 'implements', 'reads', 'writes', 'produces'] }))]
    ];
  }
  function Term(p, item) {
    const props = item.props || {};
    return [
      ['names', section('names', '标准定义与名称', '', `<dl class="v5-kv-grid">${kv('标准定义', props.shortDefinition)}${kv('同义词', (props.synonyms || []).join('、'))}${kv('历史名称', (props.historicalNames || []).join('、'))}${kv('缩写', (props.abbreviations || []).join('、'))}</dl>`)],
      ['confusions', props.confusedWith?.length ? section('confusions', '易混淆概念', '同名概念保留独立身份，不自动合并。', props.confusedWith.map(id => link(p, id)).join('')) : ''],
      ['domainContext', section('domainContext', '适用领域', '', `<dl class="v5-kv-grid">${kv('上下文', props.context)}${kv('适用版本', props.applicableVersion)}</dl>`)],
      ['relations', section('relations', '关联业务与技术概念', '', AssertionList(p, item.id))]
    ];
  }
  function Surface(p, item) {
    return [['operations', section('operations', '页面操作与业务功能', '一个界面可包含多个功能；操作只连接明确声明的动作。', (item.operations || []).map(op => `<article class="v5-operation"><div><b>${esc(op.name)}</b><small>${esc((op.states || []).join(' / '))}</small></div>${link(p, op.actionId)}<code>${esc(item.api || '')}</code></article>`).join(''))], ['businessTrace', section('businessTrace', '功能全景入口', '', AssertionList(p, item.id, { predicates: ['triggers', 'references'] }))]];
  }
  function SystemMap(p, item) {
    return [['composition', section('composition', '系统组成与局部依赖', '按需展开当前焦点，不绘制全项目巨图。', AssertionList(p, item.id, { predicates: ['contains', 'dependsOn', 'implements', 'reads', 'writes'] }))], ['businessTrace', section('businessTrace', '系统如何支撑业务', '', AssertionList(p, item.id, { predicates: ['implements', 'references', 'triggers'] }))]];
  }
  function Resource(p, item) {
    const props = item.props || {};
    return [['resource', section('resource', '原始资料与精确定位', '摘要只辅助阅读，不替代原始证据。原型不读取真实文件。', `<div class="v5-resource-uri"><code>${esc(props.uri || '未记录')}</code></div><dl class="v5-kv-grid">${kv('资料类型', props.resourceType)}${kv('原始版本', props.sourceVersion)}${kv('精确定位', props.locator)}${kv('维护责任', props.owner)}${kv('可信状态', status(props.trust))}</dl><p>${esc(props.summary || '尚未整理摘要')}</p>`)], ['supportedFacts', section('supportedFacts', '支持哪些结构化结论', '', AssertionList(p, item.id, { predicates: ['cites', 'supports', 'derivedFrom', 'conflictsWith'] }))]];
  }
  function Versions(p, item) {
    const revisions = Object.keys(p.knowledgeRevisions || {}).filter(key => key.startsWith(`${item.id}@`)).map(key => G.getEntity(p, item.id, { revision: key.slice(item.id.length + 1) })).filter(Boolean);
    if (!revisions.length && item.versions) Object.values(item.versions).forEach(v => revisions.push({ ...item, selectedVersion: v, revision: v.version, status: v.status, description: v.summary }));
    return [['versions', section('versions', '不可变修订历史', '历史引用固定到具体修订，不随当前发布漂移。', `<div class="v5-versions">${revisions.map(r => `<button data-revision="${esc(G.currentRevision(r))}" data-id="${esc(item.id)}"><code>${esc(item.id)}@${esc(G.currentRevision(r))}</code>${badge(status(r.status), tone(r.status))}<p>${esc(r.description || r.selectedVersion?.summary || '')}</p></button>`).join('')}</div>`)] ];
  }
  function BusinessObject(p, item) {
    return [
      ['properties', section('properties', '主要属性', '', properties(p, item))],
      ['lifecycle', StateLifecycle(p, item)],
      ['events', section('events', '关键事件', '', AssertionList(p, item.id, { predicates: ['produces', 'transitions', 'changes', 'triggers'] }))],
      ['features', section('features', '相关功能', '', AssertionList(p, item.id, { predicates: ['implements', 'references', 'subjectOf'] }))],
      ['dataMappings', section('dataMappings', '数据映射', '', AssertionList(p, item.id, { predicates: ['reads', 'writes', 'references'] }))]
    ];
  }
  function componentFor(p, item, name) {
    if (name === 'summary') return summary(p, item);
    if (name === 'properties') return section('properties', '主要属性', '', properties(p, item));
    if (name === 'relations') return section('relations', '局部语义关系', '', AssertionList(p, item.id));
    if (name === 'sources') return Sources(p, item);
    if (name === 'lifecycle') return StateLifecycle(p, item);
    if (name === 'causalFlow') return CausalFlow(p, item);
    if (name === 'caseActivities') return CaseActivities(p, item);
    if (name === 'features') return section('features', '功能全景', '', G.resolvePanorama(p, item.id) ? `<button class="v5-button primary" data-panorama="${esc(item.id)}">打开统一功能剖面 →</button>` : '');
    if (name === 'versions') return Versions(p, item).map(([,html]) => html).join('');
    const groups = { Configuration, DataEntity, Rule, API, Action, Term, Surface, System: SystemMap, Subsystem: SystemMap, Module: SystemMap, Resource, BusinessObject, ManufacturingBatch: BusinessObject }[item.typeId];
    return groups?.(p, item).find(([id]) => id === name)?.[1] || '';
  }
  function profileSections(p, item) {
    const profile = p.presentationProfiles?.[item.typeId] || p.presentationProfiles?.['*'] || ['summary', 'properties', 'relations', 'sources'];
    return profile.map(name => [name, componentFor(p, item, name)]).filter(([,html]) => !!html);
  }
  function EntityReader(p, item, options = {}) {
    const sections = profileSections(p, item);
    return `<div class="v5-reader">${sections.map(([id, html]) => id === 'summary' ? html : html).join('')}</div>`;
  }
  function panoramaStepIcon(kind) { return ({ ui: '▣', api: '⇄', rule: '◇', decision: '◇', action: '→', state: '↻', data: '▤', event: '✦', exception: '!', parallel: 'Ⅱ' })[kind] || '○'; }
  function Panorama(p, profile, selectedStepId, mode = 'business') {
    if (!profile) return empty('尚未建立功能剖面', '此对象具有知识身份，但没有足够明确的因果链；不会生成通用模板冒充完整解释。');
    const selected = profile.steps.find(s => s.id === selectedStepId) || profile.steps[0], index = profile.steps.indexOf(selected), entity = selected.entity;
    const actors = (profile.actorIds || []).map(id => G.getEntity(p, id)).filter(Boolean);
    const context = `<section class="v5-pan-purpose"><div><span class="v5-eyebrow">A · 业务目的与上下文</span><h2>${esc(profile.title)}</h2><p>${esc(profile.purpose)}</p></div><div class="v5-purpose-facts"><div><span>为什么存在</span><b>${esc(profile.why)}</b></div><div><span>谁使用</span><b>${esc(actors.map(a => a.name).join('、') || '后台自动功能 / 未指定')}</b></div><div><span>属于场景</span>${link(p, profile.scenarioId)}</div><div><span>信息状态</span>${badge(status(profile.verificationStatus), tone(profile.verificationStatus))}</div></div></section>`;
    const chain = `<section class="v5-panel v5-trace-panel"><header class="v5-panel-head"><div><span class="v5-eyebrow">B · 用户行为与业务过程</span><h2>选择环节，观察输入、输出与上下游</h2></div><div class="v5-segmented"><button data-pan-mode="business" class="${mode === 'business' ? 'active' : ''}">业务解释</button><button data-pan-mode="implementation" class="${mode === 'implementation' ? 'active' : ''}">实现细节</button></div></header><div class="v5-trace">${profile.steps.map((step, i) => `<button class="v5-trace-step ${step.id === selected.id ? 'active' : ''} ${step.kind}" data-pan-step="${esc(step.id)}"><span class="v5-trace-number">${String(i + 1).padStart(2, '0')}</span><i>${panoramaStepIcon(step.kind)}</i><b>${esc(step.label)}</b><small>${esc(step.entity?.name || step.entityId)}</small></button>${i < profile.steps.length - 1 ? '<span class="v5-trace-arrow" aria-label="显式下一环节">→</span>' : ''}`).join('')}</div><div class="v5-step-inspector"><div class="v5-step-focus"><span class="v5-eyebrow">当前环节 ${index + 1} / ${profile.steps.length}</span><h3>${esc(selected.label)}</h3><p>${esc(entity?.description || entity?.purpose || selected.entityId)}</p>${entity ? link(p, entity.id, `打开${typeName(p, entity.typeId)}完整阅读`) : ''}</div><dl><div><dt>输入</dt><dd>${esc(selected.input || '未知')}</dd></div><div><dt>输出</dt><dd>${esc(selected.output || '未知')}</dd></div><div><dt>上游</dt><dd>${esc(profile.steps[index - 1]?.label || '流程入口')}</dd></div><div><dt>下游</dt><dd>${esc(profile.steps[index + 1]?.label || '当前链路终点')}</dd></div></dl></div>${selected.assertions?.length ? `<div class="v5-inline-evidence"><b>此环节的明确依据</b>${selected.assertions.map(a => sourceRefs(p, a.sourceRefs)).join('')}</div>` : ''}</section>`;
    const rules = (profile.ruleIds || []).map(id => G.getEntity(p, id)).filter(Boolean);
    const business = section('decisions', 'C · 业务判断与对象变化', '条件、规则结果、状态变化和不变量在同一上下文中。', `<div class="v5-pan-grid"><div><h3>决定结果的规则</h3>${rules.map(rule => `<article class="v5-rule-focus"><div>${link(p, rule.id)}${badge(G.currentRevision(rule), 'purple')}</div><p>${esc(rule.selectedVersion?.summary || rule.description)}</p><details><summary>查看条件与结果</summary>${Rule(p, rule).find(([id]) => id === 'decision')?.[1] || ''}</details></article>`).join('') || empty('规则尚未建立', '不会用技术关联推断业务判断。')}</div><div><h3>真实对象变化</h3><div class="v5-mini-transitions">${(profile.objectChanges || []).slice(0, 8).map(t => `<div><b>${esc(t.fromState)} → ${esc(t.toState)}</b><p>${esc(t.guard)}</p><small>${link(p, t.actionRef)}</small></div>`).join('') || '<p>此功能未声明状态变化。</p>'}</div></div></div><div class="v5-invariant"><b>必须保持不变</b><span>${esc(profile.implementation?.transaction || '事务约束尚未确认')}</span></div>`);
    const impl = profile.implementation || {};
    const implGroup = (title, ids) => `<div><h3>${esc(title)}</h3>${(ids || []).map(id => link(p, id)).join('') || '<p class="v5-muted">尚未建立映射</p>'}</div>`;
    const implementation = section('implementation', 'D · 系统与数据实现', mode === 'implementation' ? '当前聚焦技术契约、读写和失败恢复。' : '按需展开技术细节，不离开当前业务上下文。', `<div class="v5-impl-grid">${implGroup('处理模块', impl.moduleIds)}${implGroup('API / 消息入口', impl.apiIds)}${implGroup('数据读取', impl.dataReads)}${implGroup('数据写入', impl.dataWrites)}${implGroup('配置影响', impl.configIds)}${implGroup('产生的事件', impl.eventIds)}</div><div class="v5-two-col"><div class="v5-note blue"><b>事务 / 一致性</b><p>${esc(impl.transaction || '未知')}</p></div><div class="v5-note amber"><b>失败处理与恢复</b><ul>${(impl.failures || []).map(x => `<li>${esc(x)}</li>`).join('') || '<li>未知</li>'}</ul></div></div>`);
    const evidence = section('evidence', 'E · 证据、版本与协作', '规范、实现与历史资料分别呈现；验收指向当前上下文。', `<div class="v5-pan-grid"><div><h3>证据与事实</h3>${(profile.evidenceIds || []).map(id => { const item = G.getEntity(p, id); return item ? `<button class="v5-evidence-row" data-open="${esc(id)}"><div><b>${esc(item.name)}</b><small>${esc(item.props?.sourceVersion || item.source || item.kind || item.typeId)}</small></div>${badge(item.kind === 'implementation' ? '观察实现' : item.kind === 'history' || item.id === 'SRC-M00' ? '历史意图' : item.typeId === 'Resource' ? '原始依据' : status(item.status), item.kind === 'history' || item.id === 'SRC-M00' ? 'amber' : 'green')}</button>` : ''; }).join('')}</div><div><h3>验收条件</h3><ul class="v5-checks">${(profile.acceptance || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul><button class="v5-button" data-contract-root="${esc(profile.entityIds?.find(id => id.startsWith('REQ-')) || profile.rootId)}">生成任务知识契约</button></div></div>`);
    return `${context}${chain}${business}${implementation}${evidence}`;
  }
  return { esc, badge, empty, typeName, status, tone, link, section, kv, sourceRefs, summary, properties, StateLifecycle, CausalFlow, CaseActivities, AssertionList, Sources, Configuration, DataEntity, Rule, RuleSimulation, API, Action, Term, Surface, SystemMap, Resource, Versions, BusinessObject, profileSections, EntityReader, Panorama };
});
