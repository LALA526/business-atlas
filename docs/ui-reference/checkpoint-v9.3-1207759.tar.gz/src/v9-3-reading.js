/* Business Atlas V9.3 — authorized business decision, conformance and flow projections. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const C = commonjs ? require('./v6-core.js') : root.AtlasV6;
  const P = commonjs ? require('./v6-projection.js') : root.AtlasV6Projection;
  const R = commonjs ? require('./v8-read.js') : root.AtlasV8Read;
  const Access = commonjs ? require('./v9-access.js') : root.AtlasV9Access;
  const V92 = commonjs ? require('./v9-2-reading.js') : root.AtlasV92Reading;
  const D = commonjs ? require('./v9-3-decision.js') : root.AtlasV93Decision;
  const api = factory(C, P, R, Access, V92, D);
  if (commonjs) module.exports = api;
  root.AtlasV93Reading = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C, P, R, Access, V92, D) {
  'use strict';
  const clone = C.clone;
  const TECHNICAL_TYPES = new Set(['Surface', 'API', 'Component', 'Module', 'System', 'DataEntity', 'Configuration', 'Framework', 'Dependency', 'DeploymentUnit', 'BuildPipeline', 'Technology', 'Runtime', 'Event']);
  function optionsFor(ctx) { return ctx.versionMode === 'draft' ? { draft: true, permission: ctx.permissionContext, applicableContext: ctx.applicableContext, applicabilityMode: ctx.applicabilityMode, readingTask: ctx.readPurpose } : { baselineId: ctx.baselineId, permission: ctx.permissionContext, applicableContext: ctx.applicableContext, applicabilityMode: ctx.applicabilityMode, readingTask: ctx.readPurpose }; }
  function unique(items) { return [...new Map((items || []).filter(Boolean).map(item => [item.id, item])).values()]; }
  function nameOf(project, ctx, id) { return Access.readEntity(project, ctx, id).data?.name || null; }

  function ruleView(project, ctx, rule) {
    const version = C.ruleVersion(rule), rows = [...(version?.exceptions || []).map(row => ({ ...row, exception: true })), ...(version?.rows || [])];
    return {
      entity: rule, version, factKind: version?.factKind || rule.factKind || 'target_specification', semanticRole: version?.semanticRole || rule.semanticRole || 'business_decision',
      approved: D.isApprovedTarget(rule, version, ctx), completeness: D.semanticCompleteness(rule), priority: D.priorityFor(version, rows),
      rows: rows.map(row => ({ ...clone(row), condition: D.conditionFromRow(row), explanation: D.describeCondition(D.conditionFromRow(row), version), outcome: (() => { const outcome = (version?.outcomes || []).find(outcome => outcome.id === row.outcomeId); return outcome ? { type: 'unknown', ...clone(outcome), ...(version?.outcomeSemantics?.[outcome.id] || {}) } : null; })() })),
      outcomes: (version?.outcomes || []).map(outcome => ({ type: 'unknown', ...clone(outcome), ...(version?.outcomeSemantics?.[outcome.id] || {}) })),
      defaultOutcome: version?.defaultOutcome || version?.default || null,
      exceptionHandling: version?.exceptionHandling || ((version?.exceptions || []).length ? `${version.exceptions.length} 条例外规则` : '未记录专门异常；不能据此推断没有异常'),
      sources: R.getSources(project, ctx, rule.id).map(ref => ({ resourceId: ref.resourceId, name: ref.entity?.name || ref.confirmedBy || '人工确认', locator: ref.locator, sourceVersion: ref.entity?.props?.sourceVersion || null, trust: ref.entity?.props?.trust || 'human-confirmation' }))
    };
  }

  function conformanceFor(project, ctx, root, rules, observations, mechanisms) {
    const currentCodeVersion = project.versionLayers?.codeRevision || null;
    if (!rules.length) return { status: 'missing_target', code: 'MISSING_TARGET_SPECIFICATION', label: '缺少已批准目标规范', explanation: observations.length || mechanisms.length ? '当前只有实现观察或技术机制，不能据此批准目标业务规则。' : '尚未建立目标业务规范，也没有足够实现观察。', observedVersion: observations[0]?.props?.observedVersion || null, currentCodeVersion, targetRefs: [], observationRefs: observations.map(item => item.id), implementationEvidenceRefs: mechanisms.flatMap(item => item.sourceIds || []) };
    const assessments = rules.map(ruleViewItem => {
      const version = ruleViewItem.version?.version, matching = observations.filter(observation => observation.props?.targetDecisionRef?.ruleId === ruleViewItem.entity.id && (!observation.props.targetDecisionRef.version || observation.props.targetDecisionRef.version === version));
      if (!matching.length) return { ruleId: ruleViewItem.entity.id, ruleVersion: version, status: 'missing_observation', code: 'MISSING_OBSERVED_BEHAVIOR', label: '缺少当前实际观察', explanation: '存在目标规范和技术映射，但没有可对应的当前行为观察，尚未验证实现符合性。', currentCodeVersion, observationRefs: [] };
      const details = matching.map(observation => {
        const props = observation.props || {}, observedVersion = props.observedVersion || props.sourceVersion || null;
        if (currentCodeVersion && observedVersion && currentCodeVersion !== observedVersion) return { observationId: observation.id, status: 'requires_reverification', code: 'CODE_VERSION_CHANGED', label: '代码版本变化，需重新核验', explanation: `观察版本 ${observedVersion} 与当前代码版本 ${currentCodeVersion} 不同，旧符合性结论不能自动沿用。`, observedVersion, currentCodeVersion };
        if (props.factKind === 'inferred' || props.confirmationStatus === 'unverified' || props.confidence === 'inferred') return { observationId: observation.id, status: 'unverified', code: 'INFERENCE_NOT_CONFIRMED', label: '观察推断尚未确认', explanation: '推断或技术分析不能显示为已确认业务行为。', observedVersion, currentCodeVersion };
        const explicit = props.conformance || {};
        const status = explicit.status === 'conformant' ? 'consistent' : explicit.status === 'nonconformant' ? 'inconsistent' : explicit.status === 'partial' ? 'partial' : explicit.status === 'missing_target' ? 'missing_target' : 'unverified';
        const labels = { consistent: '已确认一致', inconsistent: '已确认不一致', partial: '仅部分适用', missing_target: '缺少目标规范', unverified: '尚未验证' };
        return { observationId: observation.id, status, code: explicit.status ? explicit.status.toUpperCase() : 'UNVERIFIED', label: labels[status], explanation: explicit.rationale || '尚未记录符合性理由。', observedVersion, currentCodeVersion, targetRef: clone(props.targetDecisionRef), implementationEvidenceRefs: clone(props.implementationEvidenceRefs || []) };
      });
      const rank = { inconsistent: 6, requires_reverification: 5, missing_observation: 4, unverified: 3, partial: 2, missing_target: 1, consistent: 0 };
      const worst = details.slice().sort((a, b) => rank[b.status] - rank[a.status])[0];
      return { ruleId: ruleViewItem.entity.id, ruleVersion: version, ...worst, observations: details, observationRefs: matching.map(item => item.id) };
    });
    const rank = { inconsistent: 6, requires_reverification: 5, missing_observation: 4, unverified: 3, partial: 2, missing_target: 1, consistent: 0 };
    const overall = assessments.slice().sort((a, b) => rank[b.status] - rank[a.status])[0];
    return { ...overall, assessments, targetRefs: rules.map(item => ({ ruleId: item.entity.id, version: item.version?.version, baselineId: ctx.baselineId })), mechanismRefs: mechanisms.map(item => item.id) };
  }

  function decisionProjection(project, ctx, rootId) {
    const rootRead = Access.readEntity(project, ctx, rootId);
    if (!rootRead.ok) return { ok: false, code: rootRead.code, root: null, targetRules: [], observations: [], mechanisms: [], cases: [] };
    const root = rootRead.data, options = optionsFor(ctx), projection = P.projectKnowledge(project, rootId, { ...options, unlimited: true });
    if (!projection.ok) return { ok: false, code: projection.code, root: null, targetRules: [], observations: [], mechanisms: [], cases: [] };
    const referenced = V92.collectRuleReferences(project, projection, root), ruleMap = new Map();
    if (root.typeId === 'Rule') ruleMap.set(root.id, root);
    referenced.forEach(item => ruleMap.set(item.entity.id, item.entity));
    (P.focusFacts(project, projection, root.id)?.rules || []).forEach(rule => ruleMap.set(rule.id, rule));
    const targetRules = [...ruleMap.values()].map(rule => ruleView(project, ctx, rule));
    const targetRuleIds = new Set(targetRules.map(item => item.entity.id));
    const scopedActionIds = new Set(root.typeId === 'Scenario' ? projection.flows.flatMap(flow => flow.nodes.map(node => node.actionId)).filter(Boolean) : P.neighbors(projection, root.id).filter(item => ['implements', 'triggers', 'contains', 'uses'].includes(item.assertion.predicate) && item.entity?.typeId === 'Action').map(item => item.entity.id));
    const semanticIds = new Set([root.id, ...targetRuleIds, ...scopedActionIds]);
    projection.flows.forEach(flow => flow.nodes.filter(node => root.typeId === 'Scenario' || scopedActionIds.has(node.actionId)).forEach(node => ['actionId', 'ruleId', 'eventId'].forEach(key => { if (node[key]) semanticIds.add(node[key]); })));
    const allAuthorized = Access.listEntities(project, ctx).data;
    const observations = allAuthorized.filter(entity => entity.typeId === 'ObservedBehavior').filter(entity => {
      const props = entity.props || {};
      return entity.id === root.id || semanticIds.has(props.subjectId) || targetRuleIds.has(props.targetDecisionRef?.ruleId) || (root.props?.observedBehaviorRefs || []).includes(entity.id);
    });
    observations.forEach(observation => semanticIds.add(observation.id));
    const cases = allAuthorized.filter(entity => entity.typeId === 'BusinessCase').filter(entity => targetRuleIds.has(entity.props?.decisionRef?.ruleId) || entity.props?.subjectId === root.id);
    const scopedIds = new Set([root.id, ...scopedActionIds, ...targetRuleIds]), mechanismIds = new Set();
    const addTechnicalRelations = ids => projection.assertions.forEach(assertion => {
      if (ids.has(assertion.subject) && assertion.object) { const entity = projection.nodes.find(node => node.entity.id === assertion.object)?.entity; if (entity && (TECHNICAL_TYPES.has(entity.typeId) || entity.props?.factKind === 'implementation_mechanism')) mechanismIds.add(entity.id); }
      if (ids.has(assertion.object)) { const entity = projection.nodes.find(node => node.entity.id === assertion.subject)?.entity; if (entity && (TECHNICAL_TYPES.has(entity.typeId) || entity.props?.factKind === 'implementation_mechanism')) mechanismIds.add(entity.id); }
    });
    addTechnicalRelations(scopedIds); addTechnicalRelations(mechanismIds);
    const mechanisms = unique([root, ...projection.nodes.map(node => node.entity)].filter(entity => entity.id === root.id && TECHNICAL_TYPES.has(entity.typeId) || mechanismIds.has(entity.id) || entity.factKind === 'implementation_mechanism' && mechanismIds.has(entity.id)));
    const actorIds = new Set([...(root.props?.primaryActorIds || []), ...(root.participants || []), ...(root.actorIds || []), ...(root.actorId ? [root.actorId] : [])]);
    scopedActionIds.forEach(actionId => { const action = Access.readEntity(project, ctx, actionId).data; if (action?.actorId) actorIds.add(action.actorId); });
    const actors = [...actorIds].map(id => Access.readEntity(project, ctx, id).data).filter(Boolean);
    const visibleKnowledge = new Set(allAuthorized.map(entity => entity.id));
    const relatedIds = new Set([root.id, ...targetRuleIds, ...observations.map(item => item.id), ...mechanisms.map(item => item.id)]);
    const unknowns = (project.unknowns || []).filter(item => item.status !== 'resolved' && (item.relatedIds || []).some(id => relatedIds.has(id) && visibleKnowledge.has(id))).map(clone);
    const authorizedAssertionIds = new Set(projection.assertions.map(assertion => assertion.assertionId));
    const conflicts = (project.conflictRecords || []).filter(item => item.status !== 'resolved' && (item.assertionIds || []).some(id => authorizedAssertionIds.has(id))).map(clone);
    const conformance = conformanceFor(project, ctx, root, targetRules, observations, mechanisms);
    const flows = projection.flows.map(flow => flowModel(project, ctx, projection, flow));
    const sources = unique([...targetRules.flatMap(item => item.sources.map(source => ({ id: source.resourceId, name: source.name, ...source }))), ...observations.flatMap(item => (item.sourceIds || []).map(id => ({ id, name: nameOf(project, ctx, id) })))].filter(item => item.id && item.name));
    return {
      ok: true, root, projection, targetRules, proposalRules: targetRules.filter(item => !item.approved), approvedRules: targetRules.filter(item => item.approved), observations, mechanisms, cases, actors, flows, unknowns, conflicts, sources, conformance,
      authorization: { baselineId: ctx.baselineId, versionMode: ctx.versionMode, excludedCount: (projection.excluded || []).length + (projection.missing || []).length, flowReferencesComplete: !(projection.flowReferences || []).some(reference => reference.status !== 'visible'), complete: !(projection.excluded || []).length && !(projection.missing || []).length },
      note: '目标规范、当前观察和技术机制共享知识与版本，但任何一层都不会自动冒充另一层。'
    };
  }

  function flowModel(project, ctx, projection, flow) {
    const stageIds = [...new Set(flow.nodes.map(node => node.stageId).filter(Boolean))];
    const stages = stageIds.map((stageId, index) => {
      const stageEntity = Access.readEntity(project, ctx, stageId).data;
      const nodes = flow.nodes.filter(node => node.stageId === stageId).map(node => flowNode(project, ctx, node));
      const nodeIds = new Set(flow.nodes.filter(node => node.stageId === stageId).map(node => node.id));
      const edges = flow.edges.filter(edge => nodeIds.has(edge.from) || nodeIds.has(edge.to)).map(edge => flowEdge(project, ctx, flow, edge));
      return { id: stageId, index: index + 1, name: stageEntity?.name || (nodes.length === 1 ? nodes[0].name : `阶段 ${index + 1}`), goal: stageEntity?.goal || stageEntity?.description || null, nodes, edges };
    });
    return { id: flow.id, revision: flow.revision || null, scenarioId: flow.scenarioId, stages, nodes: flow.nodes.map(node => flowNode(project, ctx, node)), edges: flow.edges.map(edge => flowEdge(project, ctx, flow, edge)), omittedReferenceCount: flow.omittedReferenceCount || 0 };
  }
  function flowNode(project, ctx, node) {
    const knowledgeId = node.actionId || node.ruleId || node.eventId || null, entity = knowledgeId ? Access.readEntity(project, ctx, knowledgeId).data : null;
    return { ...clone(node), knowledgeId, name: entity?.name || node.name || ({ start: '开始', end: '结束', decision: '业务判断', exception: '异常处理' }[node.type] || '业务环节'), businessName: entity?.name || null };
  }
  function flowEdge(project, ctx, flow, edge) {
    const from = flow.nodes.find(node => node.id === edge.from), to = flow.nodes.find(node => node.id === edge.to);
    const rule = edge.when?.ruleId ? Access.readEntity(project, ctx, edge.when.ruleId).data : null, version = C.ruleVersion(rule), outcome = version?.outcomes?.find(item => item.id === edge.when?.outcomeId);
    return { ...clone(edge), fromName: flowNode(project, ctx, from).name, toName: flowNode(project, ctx, to).name, ruleName: rule?.name || null, outcomeLabel: outcome?.label || edge.when?.outcomeId || null, semanticLabel: edge.label || outcome?.label || ({ next: '下一步', return: '回流', when: '条件分支', error: '异常' }[edge.type] || edge.type) };
  }

  function detailedFlowGraph(projection, flowId, stageId = null) {
    const flow = projection.flows.find(item => item.id === flowId) || projection.flows[0];
    if (!flow) return null;
    let selected = new Set(flow.nodes.filter(node => !stageId || node.stageId === stageId).map(node => node.id));
    if (!selected.size) selected = new Set(flow.nodes.map(node => node.id));
    const neighbors = new Set(selected);
    flow.edges.forEach(edge => { if (selected.has(edge.from) || selected.has(edge.to)) { neighbors.add(edge.from); neighbors.add(edge.to); } });
    const nodes = flow.nodes.filter(node => neighbors.has(node.id)).map(node => {
      const knowledgeId = node.actionId || node.ruleId || node.eventId, entity = knowledgeId ? projection.nodes.find(item => item.entity.id === knowledgeId)?.entity : null;
      const type = node.type === 'decision' ? 'Rule' : node.type === 'event' ? 'Event' : node.type === 'exception' ? 'Exception' : 'Action';
      return { id: node.id, knowledgeId: knowledgeId || projection.root.id, name: entity?.name || node.name || node.id, type, typeId: type, preserve: true, stageId: node.stageId, semanticRole: node.type };
    });
    const edges = flow.edges.filter(edge => neighbors.has(edge.from) && neighbors.has(edge.to)).map(edge => ({ id: edge.id, from: edge.from, to: edge.to, type: edge.type, label: edge.label || edge.when?.outcomeId || ({ next: '下一步', return: '回流', when: '条件分支' }[edge.type] || edge.type), when: clone(edge.when || null), outcomeId: edge.when?.outcomeId || null, verificationStatus: edge.verificationStatus }));
    const model = V92.layoutSemantic(nodes, edges, 'detailed-flow');
    model.flowId = flow.id; model.flowRevision = flow.revision; model.stageId = stageId; model.semantics = { originalNodeIds: flow.nodes.map(node => node.id), originalEdgeIds: flow.edges.map(edge => edge.id), shownNodeIds: nodes.map(node => node.id), shownEdgeIds: edges.map(edge => edge.id), stageFiltered: !!stageId, allConditionsPreserved: edges.every(edge => flow.edges.some(original => original.id === edge.id && JSON.stringify(original.when || null) === JSON.stringify(edge.when || null))) };
    return model;
  }

  function semanticConservation(projection, flowId) {
    const flow = projection.flows.find(item => item.id === flowId) || projection.flows[0];
    if (!flow) return { ok: false, reason: 'FLOW_MISSING' };
    const stage = V92.stageGraph({ ...projection, flows: [flow] });
    const stageIds = new Set(stage.nodes.map(node => node.id)), expectedStages = new Set(flow.nodes.map(node => node.stageId || `UNSTAGED:${flow.nodes.find(item => item.id === node.id)?.id}`));
    const stageEdges = new Set(stage.edges.map(edge => edge.id)), crossStageEdges = flow.edges.filter(edge => {
      const from = flow.nodes.find(node => node.id === edge.from), to = flow.nodes.find(node => node.id === edge.to);
      return from && to && (from.stageId || `UNSTAGED:${from.id}`) !== (to.stageId || `UNSTAGED:${to.id}`);
    });
    const detailed = detailedFlowGraph(projection, flow.id);
    const detailedEdgeIds = new Set(detailed.edges.map(edge => edge.id));
    return { ok: [...expectedStages].every(id => stageIds.has(id)) && crossStageEdges.every(edge => stageEdges.has(edge.id)) && flow.edges.every(edge => detailedEdgeIds.has(edge.id)) && !stage.nodes.some(node => node.id === 'GROUP-undefined'), expectedStageIds: [...expectedStages], actualStageIds: [...stageIds], originalEdgeIds: flow.edges.map(edge => edge.id), detailedEdgeIds: [...detailedEdgeIds], conditionsPreserved: detailed.semantics.allConditionsPreserved, returnEdgesPreserved: flow.edges.filter(edge => edge.type === 'return').every(edge => detailedEdgeIds.has(edge.id)), exceptionEdgesPreserved: flow.edges.filter(edge => edge.type === 'error').every(edge => detailedEdgeIds.has(edge.id)) };
  }

  function exportDecisionProjection(project, ctx, rootId) {
    const view = decisionProjection(project, ctx, rootId);
    if (!view.ok) return { ok: false, code: view.code };
    const exported = { ...view, projection: undefined, exportedAt: C.now(), exportReadContext: clone(ctx), authorizationNotice: view.authorization.complete ? '导出时已重新授权。' : '当前授权或版本闭包不完整，不得作为正式执行依据。' };
    return { ok: true, data: exported };
  }

  return { optionsFor, ruleView, conformanceFor, decisionProjection, flowModel, detailedFlowGraph, semanticConservation, exportDecisionProjection };
});
