/* Business Atlas V5 — representative deep scenarios built on the unchanged V4 project corpus. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const v4 = commonjs ? require('../v4-model.js') : root.AtlasV4Model;
  const core = commonjs ? require('../v4-core.js') : root.AtlasCore;
  const v5 = commonjs ? require('./v5-core.js') : root.AtlasV5;
  const api = factory(v4, core, v5);
  if (commonjs) module.exports = api;
  root.AtlasV5Model = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (VM, K, G) {
  'use strict';
  const source = (resourceId, locator) => [{ resourceId, locator }];
  const q = (extra = {}) => ({ environment: 'production', organization: '华东一厂', businessScope: '质量异常登记与处置', configVersion: 'CFG-M-2026.11', version: 'v1.0', ...extra });
  function add(p, type, data) { if (!K.getEntity(p, data.id)) return VM.addKnowledge(p, type, { status: 'published', revision: 'r1', ...data }); return K.getEntity(p, data.id); }
  function assert(p, data) {
    if ((p.assertions || []).some(a => a.assertionId === data.assertionId)) return;
    return G.createAssertion(p, { factKind: 'approved_specification', verificationStatus: 'confirmed', owner: '项目业务与技术共同确认', validTime: { from: '2026-11-14', to: null }, ...data });
  }
  function ensureEventSchema(p) {
    if (!K.schemaFor(p, 'Event')) K.registerType(p, { id: 'Event', name: '业务事件', dimension: '业务认知', fields: [K.field('eventType', '事件类型'), K.field('payload', '业务载荷', 'json')], relations: ['triggers', 'produces', 'references'] });
  }
  function presentationProfiles(p) {
    p.presentationProfiles = {
      Configuration: ['summary', 'valueConstraints', 'effectiveScope', 'environmentComparison', 'impacts', 'sources', 'risks', 'versions'],
      BusinessObject: ['summary', 'properties', 'lifecycle', 'events', 'features', 'dataMappings', 'sources'],
      ManufacturingBatch: ['summary', 'properties', 'lifecycle', 'features', 'sources'],
      DataEntity: ['summary', 'ownership', 'fields', 'dataRelations', 'readersWriters', 'constraints', 'sources'],
      Rule: ['summary', 'ruleContext', 'decision', 'exceptions', 'impacts', 'versions', 'sources'],
      Term: ['summary', 'names', 'confusions', 'domainContext', 'relations', 'sources'],
      API: ['summary', 'contract', 'businessTrace', 'dataMappings', 'failure', 'sources'],
      Action: ['summary', 'behavior', 'businessTrace', 'objectChanges', 'sources'],
      Scenario: ['summary', 'causalFlow', 'caseActivities', 'features', 'sources'],
      Surface: ['summary', 'operations', 'businessTrace', 'sources'],
      System: ['summary', 'composition', 'businessTrace', 'sources'],
      Module: ['summary', 'composition', 'businessTrace', 'sources'],
      Resource: ['summary', 'resource', 'supportedFacts'],
      '*': ['summary', 'properties', 'relations', 'sources']
    };
  }
  function enhanceManufacturing(p) {
    ensureEventSchema(p);
    add(p, 'Feature', { id: 'FEAT-M02', name: '质量异常登记与批次隔离', description: '质检员保存异常时，在一次受控处理中创建缺陷、隔离批次并发布业务事件。', props: { scenarioId: 'SCN-M001', capabilityId: 'CAP-M01' }, sourceIds: ['SRC-M02'] });
    add(p, 'API', { id: 'API-M00', name: '质量异常登记接口', description: '保存质量异常并协调缺陷创建与批次隔离；支持两个业务动作，而非一对一动作包装。', props: { method: 'POST', path: '/quality/defects', providerId: 'MOD-M01', input: { batchNo: '批次号', severity: '缺陷等级', location: '缺陷位置', expectedState: '预期批次状态', evidence: '原始检验依据' }, output: { defectId: '异常记录 ID', batchState: '隔离后的批次状态', eventId: '待发布事件 ID' }, failure: '权限、批次状态或证据校验失败返回 422/409；任一批次写入失败则缺陷与状态同时回滚；事件通过同事务 outbox 投递。', contractVersion: 'QD-2026-021/v1.0', transaction: 'quality_defect + batch_quality + outbox_event 原子提交' }, sourceIds: ['SRC-M03'] });
    add(p, 'DataEntity', { id: 'DATA-M02', name: '质量异常记录', description: '保存缺陷事实、检验定位和处置上下文；异常登记与后续调查共同使用。', props: { tableName: 'quality_defect', owner: 'QMS 质量数据域', implementationVersion: 'v1.0', lifecycle: '关闭后保留原始检验与处置历史，不覆盖初检记录。', transaction: '与批次隔离在同一保存事务创建', fields: [{ name: 'defect_id', type: 'uuid', description: '质量异常稳定标识' }, { name: 'batch_no', type: 'varchar(40)', description: '受影响生产批次' }, { name: 'severity', type: 'enum', description: '严重或一般；决定后续放行约束' }, { name: 'inspection_ref', type: 'varchar(80)', description: '原始检验单和精确定位' }, { name: 'state', type: 'enum', description: '已发现、调查中、待处置或关闭' }] }, sourceIds: ['SRC-M03'] });
    add(p, 'DataEntity', { id: 'DATA-M03', name: '批次质量状态数据', description: '承载生产批次的质量状态、放行标记与乐观锁版本。', props: { tableName: 'batch_quality', owner: 'MES 批次数据域', implementationVersion: 'v1.0', lifecycle: '状态变化追加质量履历，已放行和已报废均为终止状态。', transaction: 'expected_version 防止并发覆盖；与异常记录、outbox 原子提交', fields: [{ name: 'batch_no', type: 'varchar(40)', description: '生产批次号，关联质量异常' }, { name: 'quality_state', type: 'enum', description: '生产中、质量隔离、待处置、返工中、待复检、已放行、已报废' }, { name: 'released', type: 'boolean', description: '只有满足放行规则后才为 true' }, { name: 'expected_version', type: 'integer', description: '并发写入的乐观锁版本' }, { name: 'rule_version', type: 'varchar(20)', description: '本次判断使用的规则修订' }] }, sourceIds: ['SRC-M03'] });
    add(p, 'Event', { id: 'EVT-M01', name: '质量异常已登记', description: '异常和批次隔离提交后发布的可靠业务事件，触发后续调查而非直接放行。', props: { eventType: 'QualityDefectRegistered', topic: 'manufacturing.quality.defect-registered', payload: { defectId: '异常 ID', batchNo: '批次号', severity: '缺陷等级', occurredAt: '登记时间' } }, sourceIds: ['SRC-M03'] });
    add(p, 'Resource', { id: 'SRC-M02', name: '质量异常登记与隔离规范 QD-2026-021', description: '规定登记必填信息、批次隔离和原始检验依据。', props: { resourceType: 'controlled-document', uri: 'atlas://manufacturing/quality/QD-2026-021', locator: { path: 'qms/QD-2026-021.md', section: '3.2 保存与隔离', lines: '42-71' }, sourceVersion: 'QD-2026-021/v1.0', summary: '保存前必须确认批次和缺陷信息，保存后批次进入质量隔离。', parseStatus: 'structured', owner: '赵衡', trust: 'confirmed' } });
    add(p, 'Resource', { id: 'SRC-M03', name: '质量登记服务实现核验 MQ-118', description: '代码、数据库约束和失败测试的模拟精确定位。', props: { resourceType: 'implementation-evidence', uri: 'atlas://manufacturing/verification/MQ-118', locator: { path: 'quality-service/src/defects/register.ts', lines: '88-146', tests: 'RegisterDefectTransactionTest#rollbackOnBatchConflict' }, sourceVersion: 'commit-mq118', summary: '观察实现：异常、批次状态和 outbox 在一个事务写入；冲突时不留单边记录。', parseStatus: 'structured', owner: '孙岚', trust: 'confirmed' } });
    add(p, 'Resource', { id: 'SRC-M00', name: '2025 版质量作业历史说明', description: '历史设计曾允许登记后再补充检验依据，仅用于理解迁移差异。', props: { resourceType: 'historical-document', uri: 'atlas://manufacturing/history/QD-2025-009', locator: { section: '旧版登记流程', paragraph: '4' }, sourceVersion: 'QD-2025-009/v0.9', summary: '历史意图，不代表现行批准要求。', parseStatus: 'structured', owner: '质量文控', trust: 'historical' } });
    if (!p.rules.some(r => r.id === 'RULE-M002')) p.rules.push({ id: 'RULE-M002', name: '异常登记与隔离前置校验', owner: '赵衡', currentVersion: 'v1.0', versions: { 'v1.0': { version: 'v1.0', status: 'published', effective: '2026-11-14 起生效', source: 'QD-2026-021 §3.2', supportsEvaluation: true, scope: '华东一厂生产环境；从质量异常登记页保存新异常。', inputs: [{ id: 'batchState', label: '批次状态', kind: 'enum', default: '生产中', options: [{ value: '生产中', label: '生产中' }, { value: '已放行', label: '已放行' }] }, { id: 'evidence', label: '检验依据', kind: 'enum', default: 'complete', options: [{ value: 'complete', label: '完整' }, { value: 'missing', label: '缺失' }] }], outcomes: [{ id: 'REGISTER', label: '允许登记并隔离', description: '批次可受控且检验依据完整' }, { id: 'REJECT', label: '拒绝保存', description: '已终止批次或缺少依据时不得写入' }], rows: [{ id: 'MR2-01', priority: 10, when: { batchState: '已放行' }, outcomeId: 'REJECT' }, { id: 'MR2-02', priority: 20, when: { evidence: 'missing' }, outcomeId: 'REJECT' }, { id: 'MR2-03', priority: 30, when: { batchState: '生产中', evidence: 'complete' }, outcomeId: 'REGISTER' }], exceptions: [], summary: '仅允许对可受控批次登记；检验依据缺失或批次已放行时拒绝保存。' } } });
    add(p, 'Requirement', { id: 'REQ-M001', name: '异常登记必须原子隔离受影响批次', description: '保存质量异常时创建缺陷、更新批次状态并发布可靠事件；任何写入失败均不得留下部分结果。', acceptance: ['检验依据完整且批次处于生产中时，保存后缺陷已创建、批次为质量隔离', '批次版本冲突时接口返回 409，缺陷、批次和事件均无部分写入', '严重缺陷登记后，未经复检与放行规则判断不得解除隔离', '保存记录可追踪到规则、接口、数据字段、事件和原始检验依据'], sourceIds: ['SRC-M02', 'SRC-M03'] });
    const batch = p.objects.find(o => o.id === 'OBJ-M01');
    batch.transitions = [
      { id: 'TR-M01', fromState: '生产中', toState: '质量隔离', triggerEvent: 'QualityDefectRegistered', guard: '异常记录和原始检验依据完整', actionRef: 'ACT-M002', effect: '停止批次向下游流转', sourceRefs: source('SRC-M02', '§3.2 / lines 55-61'), verificationStatus: 'confirmed' },
      { id: 'TR-M02', fromState: '质量隔离', toState: '待处置', triggerEvent: 'InvestigationCompleted', guard: '原因调查和返工可行性已记录', actionRef: 'ACT-M004', effect: '形成待决定的质量上下文', sourceRefs: source('SRC-M01', '§4 调查'), verificationStatus: 'confirmed' },
      { id: 'TR-M03', fromState: '待处置', toState: '返工中', triggerEvent: 'DispositionDecided', guard: 'RULE-M001 = REWORK 或一般缺陷允许先返工', actionRef: 'ACT-M006', effect: '保留处置决定并开始返工', sourceRefs: source('SRC-M01', 'disposition-matrix / MR-03'), verificationStatus: 'confirmed' },
      { id: 'TR-M04', fromState: '待处置', toState: '已报废', triggerEvent: 'DispositionDecided', guard: 'RULE-M001 = SCRAP，处置决定明确为报废', actionRef: 'ACT-M007', effect: '终止批次并隔离物料', sourceRefs: source('SRC-M01', 'disposition-matrix / MR-01, MR-02'), verificationStatus: 'confirmed' },
      { id: 'TR-M05', fromState: '返工中', toState: '待复检', triggerEvent: 'ReworkCompleted', guard: '返工工艺记录完整', actionRef: 'ACT-M006', effect: '等待独立复检', sourceRefs: source('SRC-M01', '§5 返工'), verificationStatus: 'confirmed' },
      { id: 'TR-M06', fromState: '待复检', toState: '已放行', triggerEvent: 'RecheckPassed', guard: '复检通过且 RULE-M001 = RELEASE', actionRef: 'ACT-M009', effect: '解除质量隔离并记录放行人', sourceRefs: source('SRC-M01', 'disposition-matrix / MR-04'), verificationStatus: 'confirmed' },
      { id: 'TR-M07', fromState: '待复检', toState: '返工中', triggerEvent: 'RecheckFailed', guard: '复检失败且仍允许再次返工', actionRef: 'ACT-M006', effect: '重新进入受控返工', sourceRefs: source('SRC-M01', 'disposition-matrix / MR-03'), verificationStatus: 'confirmed' },
      { id: 'TR-M08', fromState: '质量隔离', toState: '返工中', triggerEvent: ' inferred-from-old-note ', guard: '旧笔记暗示可跳过待处置，尚未确认', actionRef: 'ACT-M006', effect: '不进入已确认路径', sourceRefs: [], verificationStatus: 'unverified' }
    ];
    const caseObject = p.objects.find(o => o.id === 'OBJ-M02'); if (caseObject) caseObject.transitions = [];
    assert(p, { assertionId: 'AST-M-CFG-RULE', subject: 'CFG-M01', predicate: 'affects', object: 'RULE-M001', qualifiers: q(), sourceRefs: source('SRC-M01', '配置键 quality.disposition.ruleVersion'), explanation: '生产配置选择已批准的处置矩阵；不能跨工厂或环境外推。' });
    assert(p, { assertionId: 'AST-M-CFG-REGISTER', subject: 'CFG-M01', predicate: 'affects', object: 'RULE-M002', qualifiers: q({ businessScope: '质量异常登记' }), sourceRefs: source('SRC-M02', '配置键 quality.registration.requireRecheck'), explanation: '强制复检配置同时约束登记后的后续处理。' });
    assert(p, { assertionId: 'AST-M-BLOCK-RELEASE', subject: 'RULE-M001', predicate: 'blocks', object: 'ACT-M009', qualifiers: { condition: '缺陷严重、不可返工或复检未通过', organization: '华东一厂', version: 'v1.0' }, sourceRefs: source('SRC-M01', 'MR-01 至 MR-03'), explanation: '只有 RELEASE 结果允许执行放行。' });
    assert(p, { assertionId: 'AST-M-REQ-FEATURE', subject: 'REQ-M001', predicate: 'requires', object: 'FEAT-M02', qualifiers: { baseline: 'BL-M-2026-11-14' }, sourceRefs: source('SRC-M02', '§3.2 保存与隔离') });
    assert(p, { assertionId: 'AST-M-CONSTRAIN-SAVE', subject: 'RULE-M002', predicate: 'constrains', object: 'ACT-M001', qualifiers: { condition: '质量异常登记页保存', organization: '华东一厂', version: 'v1.0' }, sourceRefs: source('SRC-M02', '§3.2 lines 42-52') });
    assert(p, { assertionId: 'AST-M-SAVE-FEATURE', subject: 'UI-M001', predicate: 'triggers', object: 'FEAT-M02', qualifiers: { operation: '保存质量异常' }, sourceRefs: source('SRC-M03', 'RegisterDefectPage.tsx lines 31-48') });
    assert(p, { assertionId: 'AST-M-FEATURE-REGISTER', subject: 'FEAT-M02', predicate: 'implements', object: 'ACT-M001', qualifiers: { version: 'v1.0' }, sourceRefs: source('SRC-M02', '§3.2') });
    assert(p, { assertionId: 'AST-M-FEATURE-ISOLATE', subject: 'FEAT-M02', predicate: 'implements', object: 'ACT-M002', qualifiers: { version: 'v1.0' }, sourceRefs: source('SRC-M02', '§3.2') });
    assert(p, { assertionId: 'AST-M-API-REGISTER', subject: 'API-M00', predicate: 'implements', object: 'ACT-M001', qualifiers: { transaction: 'registration' }, sourceRefs: source('SRC-M03', 'register.ts:88-119') });
    assert(p, { assertionId: 'AST-M-API-ISOLATE', subject: 'API-M00', predicate: 'implements', object: 'ACT-M002', qualifiers: { transaction: 'registration' }, sourceRefs: source('SRC-M03', 'register.ts:120-136') });
    assert(p, { assertionId: 'AST-M-WRITE-DEFECT', subject: 'ACT-M001', predicate: 'writes', object: 'DATA-M02', qualifiers: { fields: ['defect_id', 'batch_no', 'severity', 'inspection_ref', 'state'] }, sourceRefs: source('SRC-M03', 'register.ts:96') });
    assert(p, { assertionId: 'AST-M-WRITE-BATCH', subject: 'ACT-M002', predicate: 'writes', object: 'DATA-M03', qualifiers: { fields: ['quality_state', 'released', 'expected_version', 'rule_version'], fromState: '生产中', toState: '质量隔离' }, sourceRefs: source('SRC-M03', 'register.ts:121-130') });
    assert(p, { assertionId: 'AST-M-API-READ-DEFECT', subject: 'API-M00', predicate: 'reads', object: 'DATA-M02', qualifiers: { purpose: '幂等与既有异常检查' }, sourceRefs: source('SRC-M03', 'register.ts:90') });
    assert(p, { assertionId: 'AST-M-API-WRITE-DEFECT', subject: 'API-M00', predicate: 'writes', object: 'DATA-M02', qualifiers: { transaction: 'registration' }, sourceRefs: source('SRC-M03', 'register.ts:96') });
    assert(p, { assertionId: 'AST-M-API-WRITE-BATCH', subject: 'API-M00', predicate: 'writes', object: 'DATA-M03', qualifiers: { transaction: 'registration' }, sourceRefs: source('SRC-M03', 'register.ts:121-130') });
    assert(p, { assertionId: 'AST-M-PRODUCE-EVENT', subject: 'ACT-M001', predicate: 'produces', object: 'EVT-M01', qualifiers: { after: '缺陷与批次隔离事务提交', delivery: 'transactional outbox' }, sourceRefs: source('SRC-M03', 'register.ts:132-136') });
    assert(p, { assertionId: 'AST-M-EVENT-ISOLATE', subject: 'EVT-M01', predicate: 'triggers', object: 'ACT-M003', qualifiers: { mode: '异步调查上下文采集', not: '不触发直接放行' }, sourceRefs: source('SRC-M03', 'QualityDefectRegistered consumer contract') });
    assert(p, { assertionId: 'AST-M-TRANSITION-RELEASE', subject: 'ACT-M009', predicate: 'transitions', object: 'OBJ-M01', value: undefined, qualifiers: { fromState: '待复检', toState: '已放行', guard: '复检通过且所有放行约束满足' }, sourceRefs: source('SRC-M01', 'MR-04') });
    assert(p, { assertionId: 'AST-M-HISTORICAL-CONFLICT', subject: 'SRC-M00', predicate: 'conflictsWith', object: 'RULE-M002', qualifiers: { aspect: '登记时是否必须具备原始检验依据' }, sourceRefs: source('SRC-M00', '旧版 §4'), factKind: 'historical_intent', verificationStatus: 'conflicted', explanation: '历史说明允许后补依据；当前批准规范不允许。两者并列保留，不互相覆盖。' });
    p.panoramas = [
      { id: 'PAN-M-DISPOSITION', rootId: 'FEAT-M01', title: '批次质量处置与放行', purpose: '依据缺陷等级、返工可行性和复检结果，决定返工、报废或放行。', why: '防止未满足质量约束的批次继续流转。', actorIds: ['ACTOR-M02', 'ACTOR-M03', 'ACTOR-M01'], scenarioId: 'SCN-M001', entityIds: ['SCN-M001', 'ACT-M005', 'ACT-M009', 'RULE-M001', 'API-M01', 'DATA-M01', 'UI-M002'], verificationStatus: 'confirmed', ruleIds: ['RULE-M001'], objectChanges: batch.transitions.filter(t => t.verificationStatus === 'confirmed'), evidenceIds: ['SRC-M01', 'FACT-M001', 'FACT-M002'], acceptance: ['严重或不可返工缺陷只能报废', '复检失败仅在允许返工时回到返工中', '只有复检合格且满足 RELEASE 才能放行', '已放行与已报废均无后续转移'], implementation: { apiIds: ['API-M01'], moduleIds: ['MOD-M01'], dataReads: ['DATA-M01'], dataWrites: ['DATA-M01', 'DATA-M03'], configIds: ['CFG-M01'], transaction: '处置决定、批次状态与证据必须在受控事务中一致保存', failures: ['输入缺失拒绝处置', '证据写入失败不得改变放行状态'] }, steps: [
        { id: 'PMD-UI', kind: 'ui', entityId: 'UI-M002', label: '提交质量上下文', input: '批次、缺陷与复检上下文', output: '处置请求' },
        { id: 'PMD-API', kind: 'api', entityId: 'API-M01', label: '校验请求与规则版本', input: '处置请求', output: '受控处置上下文' },
        { id: 'PMD-DECIDE', kind: 'decision', entityId: 'ACT-M005', label: '执行质量处置判断', input: '缺陷等级、返工可行性、复检结论', output: 'REWORK / SCRAP / RELEASE', assertionIds: ['AST-M-BLOCK-RELEASE'] },
        { id: 'PMD-RULE', kind: 'rule', entityId: 'RULE-M001', label: '匹配决策行', input: '条件组合', output: '唯一优先结果' },
        { id: 'PMD-READ', kind: 'data', entityId: 'DATA-M01', label: '形成不可覆盖上下文', input: '质量输入', output: '处置快照' },
        { id: 'PMD-TRANSITION', kind: 'state', entityId: 'ACT-M009', label: '满足 RELEASE 后放行', input: '复检通过与规则结果', output: '待复检 → 已放行', assertionIds: ['AST-M-TRANSITION-RELEASE'] },
        { id: 'PMD-WRITE', kind: 'data', entityId: 'DATA-M03', label: '保存批次状态与规则版本', input: '受控状态变化', output: '可审计质量履历' }
      ] },
      { id: 'PAN-M-REGISTER', rootId: 'FEAT-M02', default: true, title: '质量异常登记页的保存操作', purpose: '把一次页面保存解释为可追踪的业务判断、原子数据变化和后续事件。', why: '异常出现时先保留检验事实并阻止受影响批次继续流转。', actorIds: ['ACTOR-M01', 'ACTOR-M03'], scenarioId: 'SCN-M001', entityIds: ['UI-M001', 'ACT-M001', 'ACT-M002', 'API-M00', 'DATA-M02', 'DATA-M03', 'EVT-M01', 'RULE-M002', 'REQ-M001'], verificationStatus: 'confirmed', ruleIds: ['RULE-M002'], objectChanges: [batch.transitions[0]], evidenceIds: ['SRC-M02', 'SRC-M03', 'SRC-M00'], acceptance: ['依据完整且批次可受控时才允许保存', '缺陷、批次状态和 outbox 事件原子提交', '版本冲突返回 409 且无部分写入', '事件启动调查上下文采集，不直接放行'], implementation: { apiIds: ['API-M00'], moduleIds: ['MOD-M01'], dataReads: ['DATA-M02', 'DATA-M03'], dataWrites: ['DATA-M02', 'DATA-M03'], configIds: ['CFG-M01'], eventIds: ['EVT-M01'], transaction: 'quality_defect + batch_quality + outbox_event 原子提交；expected_version 乐观锁', failures: ['权限或前置条件失败：422，不写入', '批次版本冲突：409，全部回滚', '通知消费者失败：outbox 重试，不回滚已提交异常'] }, steps: [
        { id: 'PMR-UI', kind: 'ui', entityId: 'UI-M001', label: '输入异常并点击保存', input: '批次、缺陷等级、位置、检验依据', output: '保存请求' },
        { id: 'PMR-API', kind: 'api', entityId: 'API-M00', label: '接收请求与预期版本', input: '保存请求 + expected_version', output: '已校验接口上下文' },
        { id: 'PMR-RULE', kind: 'rule', entityId: 'RULE-M002', label: '检查权限、批次状态和依据', input: '批次状态 + 检验依据', output: 'REGISTER 或 REJECT', assertionIds: ['AST-M-CONSTRAIN-SAVE'] },
        { id: 'PMR-DEFECT', kind: 'action', entityId: 'ACT-M001', label: '创建质量异常记录', input: 'REGISTER + 异常信息', output: '已发现的缺陷', assertionIds: ['AST-M-WRITE-DEFECT'] },
        { id: 'PMR-DEFECT-DATA', kind: 'data', entityId: 'DATA-M02', label: '写入 quality_defect', input: '缺陷事实', output: 'defect_id / 检验定位', assertionIds: ['AST-M-WRITE-DEFECT'] },
        { id: 'PMR-ISOLATE', kind: 'state', entityId: 'ACT-M002', label: '隔离受影响批次', input: '已创建缺陷 + 生产中批次', output: '生产中 → 质量隔离', assertionIds: ['AST-M-WRITE-BATCH'] },
        { id: 'PMR-BATCH-DATA', kind: 'data', entityId: 'DATA-M03', label: '写入 batch_quality', input: '质量隔离 + 新版本号', output: '状态履历与乐观锁', assertionIds: ['AST-M-API-WRITE-BATCH'] },
        { id: 'PMR-EVENT', kind: 'event', entityId: 'EVT-M01', label: '提交后发布质量异常事件', input: '已提交事务', output: '启动调查，不直接放行', assertionIds: ['AST-M-PRODUCE-EVENT'] }
      ] }
    ];
    p.unknowns = [{ id: 'UNK-M01', title: '其他工厂是否采用相同处置时限', impact: '不影响华东一厂当前实施；跨工厂推广前必须确认。', relatedIds: ['RULE-M001', 'SCN-M001'], blocksFormal: false, status: 'open', owner: '质量委员会' }, { id: 'UNK-M02', title: '旧系统夜间批处理是否绕过强制复检', impact: '影响旧接口迁移安全，尚未取得代码与运行证据。', relatedIds: ['REQ-M-LEGACY'], blocksFormal: true, status: 'open', owner: 'MES 维护组' }];
    p.conflictRecords = [{ id: 'CON-M01', title: '历史登记说明与当前检验依据要求冲突', assertionIds: ['AST-M-HISTORICAL-CONFLICT'], status: 'open', resolution: '当前实施遵循 QD-2026-021；历史意图保留供迁移分析。' }];
    const wf = p.workflowInstances.find(i => i.id === 'WFI-M-BATCH-001');
    if (wf) { wf.currentStageId = 'WFS-M03'; wf.status = 'active'; wf.completed = wf.completed.filter(c => ['WFS-M01', 'WFS-M02'].includes(c.stageId)); wf.artifacts = {}; wf.records = wf.records.filter(r => r.type !== 'complete' || ['WFS-M01', 'WFS-M02'].includes(r.stageId)); }
    const definition = p.workflowDefinitions.find(d => d.id === 'WFD-M-QUALITY');
    const capabilityMap = { 'WFS-M01': ['fill', 'submitEvidence', 'complete'], 'WFS-M02': ['recordBusinessEvent', 'complete'], 'WFS-M03': ['recordInvestigation', 'submitEvidence', 'assignTask', 'proposeDisposition', 'complete'], 'WFS-M04': ['review', 'proposeDisposition', 'complete'], 'WFS-M05': ['recordBusinessEvent', 'submitEvidence', 'complete'], 'WFS-M06': ['submitEvidence', 'requestVerification', 'complete'], 'WFS-M07': ['approve', 'submitEvidence', 'complete'] };
    definition.stages.forEach(stage => { stage.capabilities = capabilityMap[stage.id]; stage.inputRequirements = stage.id === 'WFS-M03' ? ['异常记录', '设备与工艺上下文'] : ['上一活动输出']; stage.allowedTransitions = stage.returnTo ? [stage.returnTo, 'next'] : ['next']; stage.permissions = [stage.role]; stage.optionalBranches = stage.id === 'WFS-M05' ? ['返工', '报废'] : []; });
    if (wf) { wf.definitionSnapshot = G.clone(definition); const stage = definition.stages.find(s => s.id === 'WFS-M03'); stage.artifacts = ['调查结论', '检测证据']; wf.definitionSnapshot.stages.find(s => s.id === 'WFS-M03').artifacts = ['调查结论', '检测证据']; }
    return p;
  }
  function enhanceBooking(p) {
    ensureEventSchema(p);
    const object = p.objects.find(o => o.id === 'OBJ-B03');
    object.transitions = [
      { id: 'TR-B01', fromState: '待确认', toState: '已确认', triggerEvent: 'CapacityReserved', guard: '服务端复核容量充足且无时段冲突', actionRef: 'ACT-B0005', effect: '预约与占用原子写入', sourceRefs: source('SRC-B01', 'BOOK-105-08'), verificationStatus: 'confirmed' },
      { id: 'TR-B02', fromState: '待确认', toState: '预约失败', triggerEvent: 'CapacityConflict', guard: '提交时容量不足或时段冲突', actionRef: 'ACT-B0005', effect: '返回 409，不留下预约或占用', sourceRefs: source('SRC-B01', 'ConcurrencyTest#capacityConflict'), verificationStatus: 'confirmed' },
      { id: 'TR-B03', fromState: '已确认', toState: '已取消', triggerEvent: 'CancellationAccepted', guard: '预约已确认且服务未完成', actionRef: 'ACT-B0008', effect: '取消预约并释放原时段容量', sourceRefs: source('SRC-B01', 'cancellation-contract'), verificationStatus: 'confirmed' },
      { id: 'TR-B04', fromState: '改期中', toState: '已确认', triggerEvent: 'RescheduleAccepted', guard: '新时段可用且原子换占成功', actionRef: 'ACT-B0008', effect: '占用新时段并释放原时段', sourceRefs: source('SRC-B01', 'reschedule-contract'), verificationStatus: 'confirmed' },
      { id: 'TR-B05', fromState: '已确认', toState: '改期中', triggerEvent: 'RescheduleRequested', guard: '变更方式为改期', actionRef: 'ACT-B0007', effect: '保留原预约直到新时段确认', sourceRefs: source('SRC-B01', 'change-contract'), verificationStatus: 'confirmed' }
    ];
    add(p, 'API', { id: 'API-B02', name: '预约变更与取消接口', description: '按变更分支原子换占或释放资源；失败保留原预约。', props: { method: 'POST', path: '/bookings/{id}/changes', providerId: 'MOD-B01', input: { bookingId: '预约 ID', changeType: '改期或取消', targetSlotId: '目标时段（改期时）', expectedVersion: '预约版本' }, output: { status: '已确认、已取消或保持原预约', releasedSlotId: '已释放时段' }, failure: '新时段不可用返回 409 并保留原预约；取消与容量释放在同一事务。', contractVersion: 'v1.0' }, sourceIds: ['SRC-B01'] });
    add(p, 'DataEntity', { id: 'DATA-B02', name: '预约变更与资源释放数据', description: '保存预约状态、资源时段占用和取消事件。', props: { tableName: 'booking_change', owner: '预约数据域', implementationVersion: 'v1.0', lifecycle: '保留变更前后预约和资源占用历史。', transaction: '预约变更、时段释放与 outbox 原子提交', fields: [{ name: 'booking_id', type: 'uuid', description: '预约单 ID' }, { name: 'change_type', type: 'enum', description: '改期或取消' }, { name: 'released_slot_id', type: 'uuid', description: '被释放的原时段' }, { name: 'version', type: 'integer', description: '防止并发取消与改期互相覆盖' }] }, sourceIds: ['SRC-B01'] });
    add(p, 'Event', { id: 'EVT-B01', name: '预约资源已释放', description: '取消或改期事务提交后发布，驱动可用容量更新和通知。', props: { eventType: 'BookingCapacityReleased', topic: 'booking.capacity-released', payload: { bookingId: '预约 ID', slotId: '释放时段', reason: '取消或改期' } }, sourceIds: ['SRC-B01'] });
    add(p, 'Requirement', { id: 'REQ-B001', name: '取消预约必须一致释放资源', description: '取消成功后预约状态与容量释放必须一致，通知失败不回滚业务事实。', acceptance: ['已确认预约可取消并转为已取消', '取消与原时段释放原子提交', '并发改期冲突返回 409', '取消事件异步通知失败可重试且不回滚'], sourceIds: ['SRC-B01'] });
    assert(p, { assertionId: 'AST-B-CFG-CAPACITY', subject: 'CFG-B01', predicate: 'affects', object: 'RULE-B001', qualifiers: { environment: 'production', businessScope: '预约确认', region: '默认服务区域', configVersion: 'CFG-B-2026.11', version: 'v1.0' }, sourceRefs: source('SRC-B01', 'recheckOnSubmit') });
    assert(p, { assertionId: 'AST-B-REQ-CANCEL', subject: 'REQ-B001', predicate: 'requires', object: 'ACT-B0008', qualifiers: { operation: '取消预约' }, sourceRefs: source('SRC-B01', 'cancellation-contract') });
    assert(p, { assertionId: 'AST-B-API-CANCEL', subject: 'API-B02', predicate: 'implements', object: 'ACT-B0008', qualifiers: { operation: '取消或改期' }, sourceRefs: source('SRC-B01', 'BookingChangeService') });
    assert(p, { assertionId: 'AST-B-WRITE-CANCEL', subject: 'ACT-B0008', predicate: 'writes', object: 'DATA-B02', qualifiers: { transaction: 'booking-change' }, sourceRefs: source('SRC-B01', 'CancellationTransactionTest') });
    assert(p, { assertionId: 'AST-B-CANCEL-EVENT', subject: 'ACT-B0008', predicate: 'produces', object: 'EVT-B01', qualifiers: { after: '取消或改期提交' }, sourceRefs: source('SRC-B01', 'outbox contract') });
    assert(p, { assertionId: 'AST-B-CANCEL-RULE', subject: 'RULE-B002', predicate: 'constrains', object: 'ACT-B0007', qualifiers: { condition: '已确认预约申请改期或取消' }, sourceRefs: source('SRC-B01', '预约变更规范') });
    p.panoramas = [{ id: 'PAN-B-CANCEL', rootId: 'FEAT-B01', default: true, title: '预约容量、改期与取消', purpose: '在高并发下保持预约状态与资源容量一致，并允许失败后安全恢复。', why: '页面可用性可能过期，最终确认和变更必须由服务端重新判断。', actorIds: ['ACTOR-B01', 'ACTOR-B02'], scenarioId: 'SCN-B001', entityIds: ['SCN-B001', 'UI-B002', 'UI-B003', 'ACT-B0005', 'ACT-B0007', 'ACT-B0008', 'API-B01', 'API-B02', 'DATA-B01', 'DATA-B02', 'RULE-B001', 'RULE-B002', 'REQ-B001'], verificationStatus: 'confirmed', ruleIds: ['RULE-B001', 'RULE-B002'], objectChanges: object.transitions, evidenceIds: ['SRC-B01', 'FACT-B001', 'FACT-B002'], acceptance: ['并发容量不足返回 409 且不留下单边占用', '改期失败保留原预约', '取消与资源释放原子提交', '通知失败不回滚预约事实'], implementation: { apiIds: ['API-B01', 'API-B02'], moduleIds: ['MOD-B01'], dataReads: ['DATA-B01', 'DATA-B02'], dataWrites: ['DATA-B01', 'DATA-B02'], configIds: ['CFG-B01'], eventIds: ['EVT-B01'], transaction: '预约、资源占用或释放与 outbox 原子提交；预约版本防止并发覆盖', failures: ['容量或时间冲突：409，无部分写入', '改期失败：保留原预约', '通知失败：异步重试，不回滚'] }, steps: [
      { id: 'PBC-UI', kind: 'ui', entityId: 'UI-B003', label: '选择改期或取消', input: '预约 ID + 变更方式', output: '变更请求' },
      { id: 'PBC-RULE', kind: 'rule', entityId: 'RULE-B002', label: '判断变更分支', input: '预约状态 + 变更方式', output: 'RESCHEDULE / CANCEL_BOOKING / KEEP_BOOKING' },
      { id: 'PBC-API', kind: 'api', entityId: 'API-B02', label: '复核预约版本和目标容量', input: '变更请求 + expectedVersion', output: '可提交变更或 409' },
      { id: 'PBC-ACTION', kind: 'state', entityId: 'ACT-B0008', label: '换占或释放资源', input: '有效变更结论', output: '已确认新时段或已取消' },
      { id: 'PBC-DATA', kind: 'data', entityId: 'DATA-B02', label: '原子保存预约与容量', input: '变更结果', output: '预约和资源一致的新版本' },
      { id: 'PBC-EVENT', kind: 'event', entityId: 'EVT-B01', label: '发布资源释放事件', input: '已提交事务', output: '容量更新与异步通知' }
    ] }];
    const definition = p.workflowDefinitions[0]; definition.stages.forEach((stage, index) => { stage.capabilities = index === 0 ? ['fill', 'review', 'complete'] : index === 1 ? ['linkKnowledge', 'review', 'complete'] : index === 2 ? ['linkImplementation', 'generateDelivery', 'complete'] : index === 3 ? ['requestTest', 'submitAcceptance', 'complete'] : ['recordBusinessEvent', 'complete']; });
    return p;
  }
  function enhanceGovernment(p) {
    const object = p.objects.find(o => o.id === 'OBJ-G01');
    object.transitions = [
      { id: 'TR-G01', fromState: '已提交', toState: '受理审查中', triggerEvent: 'ApplicationReceived', guard: '申请主体和事项编码可识别', actionRef: 'ACT-G002', effect: '开始法定受理判断', sourceRefs: source('SRC-G01', '第三十二条'), verificationStatus: 'confirmed' },
      { id: 'TR-G02', fromState: '受理审查中', toState: '待补正', triggerEvent: 'CorrectionRequired', guard: '材料不齐全或不符合法定形式，一次性告知全部内容', actionRef: 'ACT-G008', effect: '记录补正材料与期限', sourceRefs: source('SRC-G01', '第三十二条第（四）项'), verificationStatus: 'confirmed' },
      { id: 'TR-G03', fromState: '待补正', toState: '受理审查中', triggerEvent: 'CorrectionSubmitted', guard: '补正材料已提交且在告知期限内', actionRef: 'ACT-G008', effect: '重新核验，不覆盖原补正记录', sourceRefs: source('SRC-G01', '第三十二条'), verificationStatus: 'confirmed' },
      { id: 'TR-G04', fromState: '受理审查中', toState: '协同核查中', triggerEvent: 'ApplicationAccepted', guard: '主体适格、职权属于本机关且材料齐全有效', actionRef: 'ACT-G002', effect: '按案件条件创建核查任务', sourceRefs: source('SRC-G01', '第三十二条'), verificationStatus: 'confirmed' },
      { id: 'TR-G05', fromState: '协同核查中', toState: '决定已作出', triggerEvent: 'DepartmentDecisionsCompleted', guard: '必要法规、会签与安全意见已形成', actionRef: 'ACT-G006', effect: '形成有证据的办理决定', sourceRefs: source('SRC-G01', '依法审查'), verificationStatus: 'confirmed' },
      { id: 'TR-G06', fromState: '决定已作出', toState: '实施中', triggerEvent: 'ImplementationStarted', guard: '办理决定允许实施', actionRef: 'ACT-G006', effect: '记录实施活动', sourceRefs: source('SRC-G01', '办理规范'), verificationStatus: 'confirmed' },
      { id: 'TR-G07', fromState: '实施中', toState: '已验收', triggerEvent: 'ImplementationVerified', guard: '实施结果满足批准条件', actionRef: 'ACT-G007', effect: '验收证据归档', sourceRefs: source('SRC-G01', '办理规范'), verificationStatus: 'confirmed' },
      { id: 'TR-G08', fromState: '已验收', toState: '已办结', triggerEvent: 'CaseArchived', guard: '全部完成条件满足且卷宗完整', actionRef: 'ACT-G007', effect: '案件办结并只读归档', sourceRefs: source('SRC-G01', '办理规范'), verificationStatus: 'confirmed' }
    ];
    add(p, 'Requirement', { id: 'REQ-G001', name: '材料补正后重新受理核验', description: '一次性告知补正内容与期限，收到补正后回到受理判断，而非沿固定步骤继续。', acceptance: ['补正告知列明全部材料与期限', '补正提交保留历史材料版本', '补正后重新执行受理条件判断', '跨部门核查按案件条件创建，不预设先后'], sourceIds: ['SRC-G01'] });
    assert(p, { assertionId: 'AST-G-REQ-CORRECTION', subject: 'REQ-G001', predicate: 'requires', object: 'ACT-G008', qualifiers: { matterScope: '公共文化设施临时使用许可' }, sourceRefs: source('SRC-G01', '第三十二条') });
    assert(p, { assertionId: 'AST-G-CORRECTION', subject: 'RULE-G001', predicate: 'constrains', object: 'ACT-G008', qualifiers: { condition: '材料不齐全或不符合法定形式', matterScope: '公共文化设施临时使用许可' }, sourceRefs: source('SRC-G01', '第三十二条第（四）项') });
    assert(p, { assertionId: 'AST-G-CORRECTION-EVENT', subject: 'ACT-G008', predicate: 'changes', object: 'OBJ-G02', qualifiers: { result: '补正告知与新物料版本' }, sourceRefs: source('SRC-G01', '第三十二条') });
    p.panoramas = [{ id: 'PAN-G-CORRECTION', rootId: 'FEAT-G01', default: true, title: '行政许可补正与协同核查', purpose: '以法规受理条件为边界，用案件活动承载补正和多部门独立意见。', why: '法定办理结果必须明确，但每个案件所需核查不必有固定先后。', actorIds: ['ACTOR-G02', 'ACTOR-G03', 'ACTOR-G04', 'ACTOR-G05'], scenarioId: 'SCN-G001', entityIds: ['SCN-G001', 'UI-G001', 'UI-G002', 'ACT-G002', 'ACT-G003', 'ACT-G004', 'ACT-G005', 'ACT-G008', 'RULE-G001', 'MATTER-G-001', 'MATERIAL-G-001', 'REQ-G001'], verificationStatus: 'confirmed', ruleIds: ['RULE-G001'], objectChanges: object.transitions, evidenceIds: ['SRC-G01', 'FACT-G001', 'FACT-G002'], acceptance: ['依法一次性告知全部补正内容和期限', '补正后回到受理核验而非直接会签', '各部门意见独立且引用证据', '未满足的动态任务不得被伪装为已完成'], implementation: { apiIds: ['API-G01'], moduleIds: ['MOD-G01'], dataReads: ['DATA-G01'], dataWrites: ['DATA-G01'], configIds: ['CFG-G01'], transaction: '受理结论、材料版本与案件任务分别留痕；必要任务汇聚后方可决定', failures: ['职责或证据缺失拒绝提交', '任务服务不可用不生成虚假通过结论'] }, caseDriven: true, steps: [
      { id: 'PGC-UI', kind: 'ui', entityId: 'UI-G001', label: '接收事项申请与材料', input: '主体、事项、材料版本', output: '受理审查请求' },
      { id: 'PGC-RULE', kind: 'rule', entityId: 'RULE-G001', label: '依法判断主体、职权和材料', input: '法定条件', output: '受理或一次性补正告知' },
      { id: 'PGC-CORRECT', kind: 'exception', entityId: 'ACT-G008', label: '需要时创建补正活动', input: '缺失或无效材料', output: '待补正；提交后回到受理判断' },
      { id: 'PGC-LEGAL', kind: 'action', entityId: 'ACT-G003', label: '开展法规审查', input: '事项与法规', output: '独立法规意见' },
      { id: 'PGC-COUNTERSIGN', kind: 'parallel', entityId: 'ACT-G004', label: '按案件发起多部门会签', input: '职责触发条件', output: '必要的部门意见；原型不模拟并行调度' },
      { id: 'PGC-SAFETY', kind: 'action', entityId: 'ACT-G005', label: '按需开展安全评估', input: '实施风险', output: '安全结论与整改证据' }
    ] }];
    const definition = p.workflowDefinitions[0];
    const caps = { 'WFS-G01': ['viewRegulations', 'review', 'requestCorrection', 'complete'], 'WFS-G02': ['viewRegulations', 'review', 'submitEvidence', 'complete'], 'WFS-G03': ['viewRegulations', 'countersign', 'decideDepartment', 'complete'], 'WFS-G04': ['viewRegulations', 'submitEvidence', 'review', 'complete'], 'WFS-G05': ['recordBusinessEvent', 'linkImplementation', 'complete'], 'WFS-G06': ['submitEvidence', 'submitAcceptance', 'complete'] };
    definition.stages.forEach(stage => { stage.capabilities = caps[stage.id]; stage.allowedTransitions = ['next']; stage.inputRequirements = ['案件材料与适用法规']; stage.completionConditions = stage.parallelGroup ? ['必要独立意见已形成（原型仅表达，不调度并行）'] : ['活动记录与必要证据完整']; });
    p.workflowInstances.forEach(instance => { if (instance.definitionId === definition.id) instance.definitionSnapshot = G.clone(definition); });
    p.unknowns = [{ id: 'UNK-G01', title: '特殊行业附加核查清单', impact: '仅特殊行业事项需要，当前公共文化示范事项不阻塞。', relatedIds: ['MATTER-G-SPECIAL'], blocksFormal: true, status: 'open', owner: '法规处' }];
    return p;
  }
  function configureGenericWorkflow(p) {
    if (p.meta.id === 'PRJ-00001') {
      add(p, 'Requirement', { id: 'REQ-A001', name: '按最小必要范围发起重新审批', description: '根据金额、成本中心和收款方变化创建必要审批任务，不覆盖历史审批事实。', acceptance: ['成本中心变化命中预算负责人和原审批人', '收款方变化进入完整重审', '版本冲突优先阻止任务创建', '审批任务批量写入失败时整体回滚'], sourceIds: ['SRC-A01'] });
      assert(p, { assertionId: 'AST-A-REQ-REVIEW', subject: 'REQ-A001', predicate: 'requires', object: 'ACT-00424', qualifiers: { version: 'v2.4' }, sourceRefs: source('SRC-A01', 'review-task-creation') });
      assert(p, { assertionId: 'AST-A-RULE-REVIEW', subject: 'RULE-0017', predicate: 'constrains', object: 'ACT-00424', qualifiers: { version: 'v2.4', condition: '变化清单已生成且无版本冲突' }, sourceRefs: source('SRC-A01', 'RULE-0017@v2.4') });
      p.panoramas = [{ id: 'PAN-A-REVIEW', rootId: 'FEAT-A01', default: true, title: '最小必要重审与任务创建', purpose: '比较关键字段并只创建必要审批任务。', why: '避免无差别完整重审，同时保留历史审批事实。', actorIds: ['ACTOR-07', 'ACTOR-02', 'ACTOR-03'], scenarioId: 'SCN-00126', entityIds: ['SCN-00126', 'UI-00079', 'ACT-00424', 'RULE-0017', 'API-A01', 'DATA-A01', 'REQ-A001'], verificationStatus: 'confirmed', ruleIds: ['RULE-0017', 'RULE-0021'], objectChanges: G.getEntity(p, 'ACT-00424').objectChanges || [], evidenceIds: ['SRC-A01', 'FACT-SPEC-001', 'FACT-IMPL-003'], acceptance: G.getEntity(p, 'REQ-A001').acceptance, implementation: { apiIds: ['API-A01'], moduleIds: ['MOD-A01'], dataReads: ['DATA-A01'], dataWrites: ['DATA-A01'], configIds: ['CFG-A01'], transaction: '审批任务批量创建同一事务；预算外部调用使用补偿', failures: ['版本冲突返回 409', '任一任务失败撤销本批', '预算超时进入待重试，不标记通过'] }, steps: [
        { id: 'PAR-UI', kind: 'ui', entityId: 'UI-00079', label: '确认并发起重审', input: '变化清单与基线', output: '重审请求' },
        { id: 'PAR-API', kind: 'api', entityId: 'API-A01', label: '校验预期版本', input: '修订与变化清单', output: '受控任务创建请求' },
        { id: 'PAR-ACTION', kind: 'action', entityId: 'ACT-00424', label: '服务端重新执行规则', input: '变化清单 + 固定规则版本', output: '必要审批任务集合' },
        { id: 'PAR-RULE', kind: 'rule', entityId: 'RULE-0017', label: '计算最小重审范围', input: '金额、成本中心、收款方变化', output: '原审批人 / 预算 / 完整重审' },
        { id: 'PAR-DATA', kind: 'data', entityId: 'DATA-A01', label: '原子保存审批任务', input: '任务与幂等键', output: '不可覆盖的新审批事实' }
      ] }];
      (p.unknowns ||= []).push({ id: 'UNK-A01', title: '成本中心变化的下一版人工审批范围尚未形成结论', impact: '影响正式修改重审规则的安全性；当前实现与历史规范必须分别核验。', relatedIds: ['RULE-0017'], blocksFormal: true, status: 'open', owner: '陈屿' });
    }
    (p.workflowDefinitions || []).forEach(def => def.stages.forEach((stage, index) => {
      if (stage.capabilities) return;
      if (def.id === 'WFD-AI-DELIVERY') stage.capabilities = index === 0 ? ['fill', 'askQuestion', 'complete'] : index === 1 ? ['linkKnowledge', 'generateDelivery', 'complete'] : index === 2 ? ['delegateAgent', 'linkImplementation', 'generateDelivery', 'complete'] : index === 3 ? ['requestTest', 'review', 'complete'] : ['submitAcceptance', 'generateDelivery', 'complete'];
      else stage.capabilities = ['fill', 'review', 'complete'];
      stage.inputRequirements ||= ['按活动定义提供信息']; stage.allowedTransitions ||= stage.returnTo ? [stage.returnTo, 'next'] : ['next'];
    }));
    p.workflowInstances.forEach(instance => { const def = p.workflowDefinitions.find(d => d.id === instance.definitionId && d.version === instance.definitionVersion); if (def) instance.definitionSnapshot = G.clone(def); });
    p.unknowns ||= []; p.conflictRecords ||= [];
  }
  function enhance(project) {
    presentationProfiles(project);
    if (project.meta.id === 'PRJ-00003') enhanceManufacturing(project);
    if (project.meta.id === 'PRJ-00002') enhanceBooking(project);
    if (project.meta.id === 'PRJ-00004') enhanceGovernment(project);
    configureGenericWorkflow(project);
    G.initializeProject(project);
    return project;
  }
  function createProjectSet() { const projects = VM.createProjectSet(); Object.values(projects).forEach(enhance); return projects; }
  function createBlankProject(id, name, goal, template = 'blank') { return enhance(VM.createBlankProject(id, name, goal, template)); }
  return { createProjectSet, createBlankProject, enhance };
});
