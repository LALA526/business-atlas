/* Business Atlas V9.2 — human-first reading page and local SVG explanation components. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const C = commonjs ? require('./v6-core.js') : root.AtlasV6;
  const V = commonjs ? require('./v6-views.js') : root.AtlasV6Views;
  const V9 = commonjs ? require('./v9-ui.js') : root.AtlasV9UI;
  const V91 = commonjs ? require('./v9-1-ui.js') : root.AtlasV91UI;
  const Reading = commonjs ? require('./v9-2-reading.js') : root.AtlasV92Reading;
  const api = factory(C, V, V9, V91, Reading);
  if (commonjs) module.exports = api;
  root.AtlasV92UI = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C, V, V9, V91, Reading) {
  'use strict';
  const esc = V.esc, clone = C.clone;
  const text = value => value == null || value === '' ? '尚未记录' : value;
  function link(entity) { return entity ? `<button class="v92-knowledge-link" data-open-studio="${esc(entity.id)}"><b>${esc(entity.name)}</b><small>${esc(entity.typeId)}</small></button>` : ''; }
  function valueBlock(value) { return value == null || value === '' || (Array.isArray(value) && !value.length) ? '' : `<dl class="v92-value-list">${Object.entries(typeof value === 'object' && !Array.isArray(value) ? value : { 说明: value }).map(([key, item]) => `<div><dt>${esc(key)}</dt><dd>${esc(typeof item === 'object' ? JSON.stringify(item) : item)}</dd></div>`).join('')}</dl>`; }
  function localDiagram(model) {
    if (!model?.nodes?.length) return '';
    const positions = Object.fromEntries(model.nodes.map(node => [node.id, node]));
    const labels = { next: '下一步', when: '条件分支', return: '回流', error: '异常', parallel: '并行', join: '汇合', constrains: '业务约束', blocks: '阻止', implements: '技术实现', triggers: '触发', reads: '读取', writes: '写入', produces: '产生事件', dependsOn: '技术依赖', uses: '使用', transitions: '状态转移', affects: '影响', contains: '组成', hosts: '承载', exposes: '暴露接口', confirmed: '已确认转移', unverified: '未确认转移' };
    const execution = new Set(['next', 'when', 'return', 'error', 'parallel', 'join', 'confirmed', 'unverified']);
    const edgePaths = model.edges.map(edge => {
      const from = positions[edge.from], to = positions[edge.to]; if (!from || !to) return '';
      const x1 = from.x + from.width / 2, y1 = from.y + from.height / 2, x2 = to.x + to.width / 2, y2 = to.y + to.height / 2;
      const right = x2 >= x1, startX = right ? from.x + from.width : from.x, endX = right ? to.x : to.x + to.width, midX = (startX + endX) / 2;
      const marker = execution.has(edge.type) ? ' marker-end="url(#v92-arrow)"' : '';
      return `<path class="v92-diagram-edge ${esc(edge.type)}" data-relation="${esc(edge.type)}" d="M${startX},${y1} H${midX} V${y2} H${endX}"${marker}/><text x="${midX}" y="${(y1 + y2) / 2 - 5}" text-anchor="middle">${esc(edge.label || labels[edge.type] || edge.type)}</text>`;
    }).join('');
    return `<svg class="v92-local-diagram" viewBox="0 0 ${model.width} ${model.height}" role="img" aria-label="${esc(model.viewType === 'business-flow' ? '真实流程阶段与条件分支' : model.viewType === 'state' ? '已定义状态转移' : model.viewType === 'data-flow' ? '数据读取与写入' : '带关系标签的局部知识图')}" preserveAspectRatio="xMidYMid meet"><defs><marker id="v92-arrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L0,6 L7,3 z"/></marker></defs>${edgePaths}${model.nodes.map(node => `<g class="v92-diagram-node ${esc(node.type)}" data-open-studio="${esc(node.knowledgeId)}" tabindex="0" role="button" aria-label="打开 ${esc(node.name)}"><rect x="${node.x}" y="${node.y}" width="${node.width}" height="${node.height}" rx="9"/><text x="${node.x + 12}" y="${node.y + 24}" class="v92-node-type">${esc(node.type)}</text><text x="${node.x + 12}" y="${node.y + 47}" class="v92-node-name">${esc(node.name.length > 18 ? `${node.name.slice(0, 17)}…` : node.name)}</text></g>`).join('')}</svg>`;
  }
  function visualFor(project, root) {
    const views = project.visualViews || [];
    const preferred = root.typeId === 'Scenario' ? 'business-flow' : root.typeId === 'BusinessObject' ? 'state' : root.typeId === 'Surface' ? 'surface' : ['System', 'Component', 'Module'].includes(root.typeId) ? 'architecture' : ['API', 'DataEntity'].includes(root.typeId) ? 'data-flow' : 'sequence';
    return preferred;
  }
  function renderSection(api, section, projection) {
    const content = section.content || {}, root = projection.root;
    const missing = text => `<p class="v92-missing">${esc(text)}</p>`;
    if (['purpose', 'problem'].includes(section.kind)) return `<div class="v92-purpose"><p>${esc(content.meaning || content.goal || '尚未记录业务目的')}</p>${content.result ? `<p class="v92-result"><b>业务结果：</b>${esc(content.result)}</p>` : ''}</div>`;
    if (section.kind === 'trigger') return `${content.trigger ? `<p>${esc(content.trigger)}</p>` : missing('尚未记录触发条件')}${content.participants?.length ? `<p class="v92-secondary">参与者：${esc(content.participants.join('、'))}</p>` : ''}`;
    if (section.kind === 'behavior') {
      const model = Reading.localVisualModel(projection, api.Ctx().focusId || root.id, visualFor(api.M(), root));
      return `${content.actions?.length ? `<div class="v92-action-list">${content.actions.map(link).join('')}</div>` : ''}${model ? localDiagram(model) : ''}${!content.actions?.length && !model ? missing('尚未建立主要行为或流程') : ''}`;
    }
    if (section.kind === 'rules' || section.kind === 'decision') {
      const rules = content.rules || [];
      return `${rules.length ? rules.map(rule => `${link(rule)}${rule.id === root.id && content.ruleVersion ? V.RuleTable(api.M(), rule, content.ruleVersion, `reading-${rule.id}`) : `<p class="v92-secondary">${esc(rule.selectedVersion?.scope || rule.versions?.[rule.currentVersion]?.scope || rule.description || '')}</p>`}`).join('') : missing('尚未关联关键业务规则')}`;
    }
    if (['implementation', 'composition', 'dependencies', 'data', 'data-access', 'consumers', 'affected'].includes(section.kind)) return content.items?.length ? `<div class="v92-link-grid">${content.items.map(link).join('')}</div>` : missing(content.emptyText || '尚未建立技术实现关联');
    if (['boundaries', 'exceptions', 'failures', 'risks'].includes(section.kind)) return `${content.exceptions?.length ? `<p>${esc(content.exceptions.join('、'))}</p>` : ''}${content.items?.length ? `<ul class="v92-unknown-list">${content.items.map(item => `<li><b>${esc(item.title)}</b><p>${esc(item.impact || item.description || '')}</p></li>`).join('')}</ul>` : missing(content.emptyText || '尚未记录异常或未知；这不等于没有异常')}`;
    if (section.kind === 'applicability') return content.applicableContext ? valueBlock(content.applicableContext) : missing('尚未声明适用条件');
    if (section.kind === 'outcomes') return Array.isArray(content.outcomes) && content.outcomes.length ? `<div class="v92-outcome-list">${content.outcomes.map(outcome => `<div><b>${esc(outcome.label || outcome.id || outcome)}</b>${outcome.description ? `<p>${esc(outcome.description)}</p>` : ''}</div>`).join('')}</div>` : valueBlock(content.outcomes || '尚未定义结果');
    if (section.kind === 'contract') return `${content.method || content.path ? `<code class="v92-endpoint">${esc(content.method || '')} ${esc(content.path || '')}</code>` : ''}${valueBlock({ 输入: content.input, 输出: content.output })}`;
    if (section.kind === 'fields') return valueBlock(content.fields || '尚未记录关键字段');
    if (section.kind === 'lifecycle') return valueBlock(content.lifecycle || '尚未记录生命周期');
    if (section.kind === 'value') return valueBlock({ 默认值: content.defaultValue, 配置版本: content.configVersion });
    if (section.kind === 'rationale') return `<p>${esc(content.rationale || '尚未记录选择理由')}</p>`;
    if (section.kind === 'alternatives') return `<p>${esc(content.alternatives)}</p>`;
    if (section.kind === 'locator') return valueBlock({ 定位: content.locator, URI: content.uri, 原始版本: content.sourceVersion });
    if (section.kind === 'supported') return content.assertions?.length ? `<div class="v92-link-grid">${content.assertions.slice(0, 12).map(assertion => `<button class="v92-knowledge-link" data-open-studio="${esc(assertion.object || assertion.subject)}"><b>${esc(assertion.predicate)}</b><small>${esc(assertion.subject)} → ${esc(assertion.object || assertion.value)}</small></button>`).join('')}</div>` : missing('尚未关联支持的知识');
    if (section.kind === 'evidence') return `<details class="v92-evidence"><summary>版本、来源、核验与适用状态</summary>${content.sources?.length ? content.sources.map(ref => `<button class="v92-source-link" data-open-studio="${esc(ref.entity.id)}"><b>${esc(ref.entity.name)}</b><small>${esc(typeof ref.locator === 'object' ? JSON.stringify(ref.locator) : ref.locator)}</small></button>`).join('') : missing('尚未关联可用来源')}${valueBlock({ 修订: content.revision, 基线: content.baselineId, 事实状态: content.verificationStatus })}</details>`;
    return valueBlock(content);
  }
  function readingWorkbench(api, projection, focusId) {
    const plan = Reading.readingPlan(api.M(), projection, api.Ctx().readingTask || 'understand');
    if (!plan.ok) return V.empty('当前知识不可读', plan.code || '当前版本或权限无法读取此内容');
    const sections = plan.sections.map(section => `<section class="v92-reading-section" data-section="${section.id}"><h2>${esc(section.title)}</h2>${renderSection(api, section, projection)}</section>`).join('');
    return `<div class="v92-reading-layout"><main class="v92-reading-main">${sections}</main>${api.Ctx().inspectorOpen ? `<aside class="v92-context-inspector"><button class="v92-inspector-close" data-action="toggle-inspector" aria-label="关闭检查器">×</button>${V9.renderVisualInspector(api, Reading.localVisualModel(projection, focusId, 'architecture') ? { ok: true, root: projection.root, view: { viewId: api.Ctx().visualViewId || 'context' } } : { ok: true, root: projection.root, view: { viewId: 'context' } }, focusId)}</aside>` : ''}</div>`;
  }
  function businessSystemHome(api) {
    const entities = api.currentEntities(), project = api.authorizedRecords ? { ...api.M(), importProposals: api.authorizedRecords('import-proposal') } : api.M(), composition = V91.homeComposition(project, entities);
    if (!composition.hasMeaningfulContent) return `<section class="v92-empty-project"><h2>知识尚未建立</h2><p>这是一个空白项目。可以从知识目录创建第一项知识，或在项目菜单接入已有资料。</p><button class="v5-button primary" data-action="global-create">新建第一项知识</button></section>`;
    return `<section class="v92-business-home"><header><span class="v5-eyebrow">BUSINESS & SYSTEM</span><h2>选择要了解的业务或系统内容</h2><p>这里显示项目真实拥有的功能、流程、组件、数据与最近阅读，不需要提前知道知识 ID。</p></header>${composition.sections.map(section => `<section class="v92-entry-group"><h3>${esc(section.title)}</h3><p>${esc(section.subtitle)}</p><div>${section.items.filter(item => item.typeId !== 'ImportProposal').slice(0, 10).map(link).join('')}</div></section>`).join('')}</section>`;
  }
  return { localDiagram, readingWorkbench, businessSystemHome, visualFor };
});
