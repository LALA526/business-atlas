/* Business Atlas V6 — dynamic presentation composition for reading and building. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const G = commonjs ? require('./v5-core.js') : root.AtlasV5;
  const V = commonjs ? require('./v5-views.js') : root.AtlasV5Views;
  const C = commonjs ? require('./v6-core.js') : root.AtlasV6;
  const P = commonjs ? require('./v6-projection.js') : root.AtlasV6Projection;
  const E = commonjs ? require('../engine.js') : root.AtlasEngine;
  const api = factory(G, V, C, P, E);
  if (commonjs) module.exports = api;
  root.AtlasV6Views = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (G, V, C, P, E) {
  'use strict';
  const esc = V.esc, badge = V.badge, status = V.status, tone = V.tone;
  const typeName = (p, type) => p.schemaRegistry?.[type]?.name || ({ Event: '业务事件', Exception: '异常处理', Assertion: '语义断言' })[type] || V.typeName(p, type);
  function link(id, entity, extra = '') { return entity ? `<button class="v6-link" data-focus="${esc(id)}" ${extra}><b>${esc(entity.name)}</b><small>${esc(typeName({}, entity.typeId))} · ${esc(id)}</small></button>` : `<span class="v6-missing">${esc(id)} · 尚未建立</span>`; }
  function section(title, body, subtitle = '', aside = '') { return body ? `<section class="v6-section"><header><div><h2>${esc(title)}</h2>${subtitle ? `<p>${esc(subtitle)}</p>` : ''}</div>${aside}</header>${body}</section>` : ''; }
  function empty(title, copy, action = '') { return `<div class="v6-empty"><span>○</span><div><b>${esc(title)}</b><p>${esc(copy)}</p>${action}</div></div>`; }
  function FieldValues({ label, value }) {
    if (value === undefined || value === null || value === '' || (Array.isArray(value) && !value.length)) return '';
    if (typeof value === 'object') return `<div class="v6-kv"><dt>${esc(label)}</dt><dd><dl>${Object.entries(value).map(([k, v]) => `<div><span>${esc(k)}</span><b>${esc(typeof v === 'object' ? JSON.stringify(v) : v)}</b></div>`).join('')}</dl></dd></div>`;
    return `<div class="v6-kv"><dt>${esc(label)}</dt><dd>${esc(Array.isArray(value) ? value.join('；') : value)}</dd></div>`;
  }
  function RuleTable(p, entity, version, idPrefix = 'rule') {
    if (!version) return empty('规则定义尚未建立', '请在构建模式中补充适用范围和约束。');
    if (!version.supportsEvaluation) return `<div class="v6-constraint"><span>人工约束 · 不伪装可执行</span><p>${esc(version.constraint || version.summary || '约束内容待补充')}</p><dl>${FieldValues({ label: '适用范围', value: version.scope })}${FieldValues({ label: '违反后的处理', value: version.violationHandling })}${FieldValues({ label: '例外', value: version.exception })}</dl></div>`;
    const rows = [...(version.exceptions || []).map(r => ({ ...r, exception: true })), ...(version.rows || [])].sort((a, b) => a.priority - b.priority);
    return `<div class="v6-rule-table"><table><thead><tr><th>优先级</th>${(version.inputs || []).map(i => `<th>${esc(i.label)}</th>`).join('')}<th>结果</th></tr></thead><tbody>${rows.map(row => `<tr class="${row.exception ? 'exception' : ''}"><td>${row.exception ? '例外 · ' : ''}${esc(row.priority)}</td>${version.inputs.map(input => `<td>${esc(input.options?.find(o => o.value === row.when?.[input.id])?.label || row.when?.[input.id] || '任意')}</td>`).join('')}<td>${badge(version.outcomes.find(o => o.id === row.outcomeId)?.label || row.outcomeId, 'purple')}</td></tr>`).join('')}</tbody></table></div><div class="v6-simulator"><b>当前修订试算</b><div>${(version.inputs || []).map(input => `<label>${esc(input.label)}<select data-v6-rule-input="${esc(input.id)}" data-rule-id="${esc(entity.id)}">${(input.options || []).map(o => `<option value="${esc(o.value)}">${esc(o.label)}</option>`).join('')}</select></label>`).join('')}</div><output id="v6-rule-result">${RuleSimulation(entity, version, E.defaultValues(version))}</output></div>`;
  }
  function RuleSimulation(entity, version, values) { const result = E.evaluateRule(version, values); return `<div class="v6-sim-result ${result.outcome ? 'ok' : 'warn'}"><b>${esc(result.outcome?.label || result.code)}</b><p>${esc(result.explanation)}</p><code>${esc(entity.id)}@${esc(version.version || 'draft')}</code></div>`; }
  function StateView(entity) {
    const states = entity.states || entity.props?.states || [], transitions = entity.transitions || [];
    const directory = `<div class="v6-state-list">${states.map(s => `<span>${esc(s)}</span>`).join('')}</div>`;
    if (!transitions.length) return `${directory}${empty('只有合法状态目录', '尚未定义状态转移，不按排列顺序绘制箭头。')}`;
    return `${directory}<div class="v6-transitions">${transitions.map(t => `<article class="${t.verificationStatus !== 'confirmed' ? 'draft' : ''}"><div><b>${esc(t.fromState)}</b><span>→</span><b>${esc(t.toState)}</b></div><p><strong>触发</strong> ${esc(t.triggerEvent)} · <strong>条件</strong> ${esc(t.guard)}</p><small>${esc(t.effect || '')} · ${badge(status(t.verificationStatus), tone(t.verificationStatus))}</small></article>`).join('')}</div>`;
  }
  function FlowStructure(p, projection, focusId, buildMode) {
    if (!projection.flows.length) return '';
    return projection.flows.map(flow => {
      const nodeEntity = node => node.actionId || node.ruleId || node.eventId;
      return `<div class="v6-flow" data-flow="${esc(flow.id)}"><div class="v6-flow-title"><b>显式业务结构</b><span>${esc(flow.id)}@${esc(flow.revision || 'draft')} · 布局顺序不产生因果</span></div><div class="v6-flow-nodes">${flow.nodes.slice().sort((a, b) => (a.layout?.x || 0) - (b.layout?.x || 0)).map(node => {
        const id = nodeEntity(node), entity = C.getEntity(p, id, projection.options), selected = id === focusId || node.id === focusId;
        return `<button class="v6-node ${esc(node.type)} ${selected ? 'selected' : ''}" draggable="true" data-drag-node="${esc(node.id)}" data-scenario-id="${esc(flow.scenarioId)}" ${id ? `data-focus="${esc(id)}"` : `data-flow-node="${esc(node.id)}"`}><span>${esc({ action: '动作', decision: '判断', event: '事件', exception: '异常', parallel: '并行', join: '汇合', subprocess: '子流程', case: '案件活动' }[node.type] || node.type)}</span><b>${esc(entity?.name || node.name || node.id)}</b><small>${esc(id || node.id)}</small></button>`;
      }).join('') || empty('尚无业务环节', '切换构建模式，添加动作、判断或事件。')}</div><div class="v6-edge-list">${flow.edges.map(edge => {
        const from = flow.nodes.find(n => n.id === edge.from), to = flow.nodes.find(n => n.id === edge.to), fromEntity = C.getEntity(p, nodeEntity(from), projection.options), toEntity = C.getEntity(p, nodeEntity(to), projection.options);
        return `<article class="v6-edge ${esc(edge.type)}"><div>${fromEntity ? link(fromEntity.id, fromEntity) : `<b>${esc(from?.name || edge.from)}</b>`}</div><span><b>${esc({ next: '正常', when: '条件', parallel: '并行', join: '汇合', error: '异常', return: '回流', terminate: '终止', event: '事件' }[edge.type] || edge.type)} →</b><small>${esc(edge.label || edge.when?.outcomeId || '')}</small></span><div>${toEntity ? link(toEntity.id, toEntity) : `<b>${esc(to?.name || edge.to)}</b>`}</div></article>`;
      }).join('') || '<p class="v6-muted">尚未建立业务因果连接；节点位置不会被转换成流程边。</p>'}</div></div>`;
    }).join('');
  }
  function SemanticStructure(p, projection, focusId) {
    const groups = new Map();
    projection.nodes.forEach(node => { const type = node.entity.typeId; if (!groups.has(type)) groups.set(type, []); groups.get(type).push(node); });
    return `<div class="v6-semantic-groups">${[...groups.entries()].map(([type, nodes]) => `<div><h3>${esc(typeName(p, type))}<span>${nodes.length}</span></h3>${nodes.sort((a, b) => a.distance - b.distance).map(node => link(node.entity.id, node.entity, node.entity.id === focusId ? 'class="selected"' : '')).join('')}</div>`).join('')}</div>`;
  }
  function FocusCenter(p, projection, focus) {
    if (!focus || focus.missing) return empty('当前焦点尚未建立', focus?.errors?.[0] || '请选择已有知识或直接补充。');
    const e = focus.entity, version = focus.ruleVersion;
    const behavior = `<dl class="v6-facts">${FieldValues({ label: '业务目的', value: focus.meaning })}${FieldValues({ label: '输入', value: focus.inputs })}${FieldValues({ label: '前提 / 适用范围', value: focus.preconditions })}${FieldValues({ label: '输出与结果', value: focus.outputs })}</dl>`;
    const rule = e.typeId === 'Rule' ? section('判断与约束', RuleTable(p, e, version), version?.supportsEvaluation ? '条件表来自当前知识修订，试算与阅读使用同一版本。' : '尚未形式化的规则保持人工约束。') : '';
    const state = e.typeId === 'BusinessObject' ? section('状态与真实转移', StateView(e), '只有明确定义的转移才显示箭头。') : '';
    const api = e.typeId === 'API' ? section('接口契约', `<div class="v5-endpoint"><b>${esc(e.props?.method || '')}</b><code>${esc(e.props?.path || '路径未记录')}</code></div><dl class="v6-facts">${FieldValues({ label: '输入', value: e.props?.input })}${FieldValues({ label: '输出', value: e.props?.output })}${FieldValues({ label: '失败与恢复', value: e.props?.failure })}</dl>`, '技术接口可反向追踪业务动作。') : '';
    const data = e.typeId === 'DataEntity' ? section('核心数据字段', (e.props?.fields || []).length ? `<table><thead><tr><th>字段</th><th>类型</th><th>业务含义</th></tr></thead><tbody>${e.props.fields.map(f => `<tr><td><code>${esc(f.name)}</code></td><td>${esc(f.type)}</td><td>${esc(f.description || '')}</td></tr>`).join('')}</tbody></table>` : empty('字段尚未建立', '当前数据实体只有身份和业务含义。')) : '';
    const event = e.typeId === 'Event' ? section('事件契约', `<dl class="v6-facts">${FieldValues({ label: '事件类型', value: e.props?.eventType })}${FieldValues({ label: '主题', value: e.props?.topic })}${FieldValues({ label: '业务载荷', value: e.props?.payload })}</dl>`, '事件只在明确行为结果发生后产生。') : '';
    const engineering = ['Component', 'Module', 'Framework', 'Dependency', 'Runtime', 'DeploymentUnit', 'ArchitectureDecision', 'BuildPipeline', 'Technology'].includes(e.typeId) ? section('工程实现与技术约束', `<dl class="v6-facts">${FieldValues({ label: '组件 / 模块职责', value: e.props?.responsibility })}${FieldValues({ label: '技术或依赖版本', value: e.props?.version || e.props?.release })}${FieldValues({ label: '运行环境', value: e.props?.runtime })}${FieldValues({ label: '兼容与依赖约束', value: e.props?.compatibility })}${FieldValues({ label: '架构决策', value: e.props?.decision })}${FieldValues({ label: '选型依据', value: e.props?.rationale })}${FieldValues({ label: '影响与代价', value: e.props?.consequences })}${FieldValues({ label: '构建入口与产物', value: e.props?.entry ? `${e.props.entry} → ${e.props.output || '未声明'}` : null })}${FieldValues({ label: '实际代码位置', value: e.props?.codePaths })}</dl>`, '技术依赖、运行调用、业务约束和设计决定分别通过关系语义表达。') : '';
    const resource = ['Resource', 'Evidence'].includes(e.typeId) ? section('原始资料与精确定位', `<dl class="v6-facts">${FieldValues({ label: '资料类型', value: e.props?.resourceType })}${FieldValues({ label: '原始版本', value: e.props?.sourceVersion })}${FieldValues({ label: 'URI / 路径', value: e.props?.uri })}${FieldValues({ label: '精确定位', value: e.props?.locator })}${FieldValues({ label: '内容哈希', value: e.props?.contentHash })}</dl><p>${esc(e.props?.summary || '没有摘录；请按来源定位核对原文。')}</p>`, '原始资料与结构化结论分别保存；摘要不会替代来源。') : '';
    const flow = focus.flowFacts.length ? section('在业务结构中的位置', focus.flowFacts.map(f => `<div class="v6-node-position"><b>${esc(f.node.name || e.name)}</b><p>上游 ${f.incoming.length} 条 · 下游 ${f.outgoing.length} 条</p>${[...f.incoming, ...f.outgoing].map(edge => `<code>${esc(edge.from)} → ${esc(edge.to)}${edge.when ? ` · ${edge.when.outcomeId}` : ''}</code>`).join('')}</div>`).join(''), '来自规范流程定义，而非实例记录。') : '';
    return `<div class="v6-focus-head"><div><span class="v6-type">${esc(typeName(p, e.typeId))}</span><h2>${esc(e.name)}</h2><code>${esc(e.id)}@${esc(e.revision || 'draft')}</code></div>${badge(status(e.status), tone(e.status))}</div>${behavior}${rule}${state}${api}${data}${event}${engineering}${resource}${flow}`;
  }
  function EvidenceList(focus) {
    if (!focus.evidence.length) return `<p class="v6-missing">尚无可用来源；当前内容不能自动视为已确认事实。</p>`;
    return focus.evidence.map(ref => `<button class="v6-evidence" data-focus="${esc(ref.entity.id)}"><b>${esc(ref.entity.name)}</b><small>${esc(typeof ref.locator === 'object' ? JSON.stringify(ref.locator) : ref.locator)}</small><span>${esc(ref.entity.props?.sourceVersion || '')} · ${esc(ref.entity.props?.trust || ref.entity.status || '')}</span></button>`).join('');
  }
  function Inspector(p, projection, focus, buildMode) {
    if (!focus || focus.missing) return '';
    const e = focus.entity;
    const rules = focus.rules.length ? section('关联规则', focus.rules.map(rule => link(rule.id, rule)).join('')) : '';
    const transitions = focus.transitions.length ? section('对象变化', focus.transitions.map(t => `<article class="v6-inspector-item"><b>${esc(t.fromState)} → ${esc(t.toState)}</b><p>${esc(t.guard)}</p><small>${esc(t.triggerEvent)} · ${esc(t.actionRef)}</small></article>`).join('')) : '';
    const technical = focus.technical.length ? section('技术映射', focus.technical.map(r => `<article class="v6-inspector-item">${link(r.entity.id, r.entity)}<p>${esc(r.assertion.explanation || '')}</p><code>${esc(JSON.stringify(r.assertion.qualifiers || {}))}</code></article>`).join(''), '每个资源独立建模，可复用于多个入口。') : '';
    const relations = section('上下游与关联', `<div class="v6-related">${focus.related.map(r => `<article><span>${r.outgoing ? '当前 →' : '← 关联'} ${esc(G.PREDICATES[r.assertion.predicate]?.label || r.assertion.predicate)}</span>${r.entity ? link(r.entity.id, r.entity) : `<b>${esc(r.otherId)}</b>`}<small>${badge(status(r.assertion.verificationStatus), tone(r.assertion.verificationStatus))} · ${esc(r.assertion.assertionId)}@${esc(r.assertion.revision)}</small>${buildMode ? `<button class="v5-button small" data-retire-assertion="${esc(r.assertion.assertionId)}">停用关联</button>` : ''}</article>`).join('') || '<p class="v6-muted">尚无直接关系。</p>'}</div>`);
    const collaboration = focus.issues.length || focus.tasks.length ? section('相关协作', `${focus.tasks.map(t => `<button class="v6-inspector-item" data-task="${esc(t.id)}"><b>${esc(t.title)}</b><small>${esc(t.status)}</small></button>`).join('')}${focus.issues.map(i => `<button class="v6-inspector-item" data-issue="${esc(i.id)}"><b>${esc(i.title)}</b><small>${esc(i.status)} · ${esc(i.assignee)}</small></button>`).join('')}`) : '';
    return `${rules}${transitions}${technical}${relations}${section('来源与可信状态', EvidenceList(focus))}${collaboration}${buildMode ? `<div class="v6-inspector-actions" data-context-type="${esc(e.typeId)}" data-context-id="${esc(e.id)}"></div>` : ''}`;
  }
  function Workbench(p, projection, focusId, options = {}) {
    if (!projection.ok) return empty(projection.code === 'FORBIDDEN' ? '当前权限不可见' : '没有找到对应业务视图', projection.errors.join('；') || '不会回退到项目默认剖面。', `<button class="v5-button primary" data-action="create-from-missing">直接建立知识</button>`);
    const focus = P.focusFacts(p, projection, focusId || projection.root.id), buildMode = options.mode === 'build';
    return `<div class="v6-workbench ${buildMode ? 'building' : 'reading'}"><aside class="v6-structure"><div class="v6-pane-label">局部知识结构 <span>${projection.nodes.length} 个对象</span></div>${FlowStructure(p, projection, focus.entity?.id, buildMode)}${SemanticStructure(p, projection, focus.entity?.id)}</aside><main class="v6-focus"><div class="v6-pane-label">当前业务事实 <span>随焦点实时投影</span></div>${FocusCenter(p, projection, focus)}</main><aside class="v6-inspector"><div class="v6-pane-label">上下文检查器 <span>规则 · 技术 · 证据</span></div>${Inspector(p, projection, focus, buildMode)}</aside></div>`;
  }
  function ContractPackage(pack) {
    const group = (title, items, render) => `<section class="v6-contract-group"><header><h3>${esc(title)}</h3>${badge(`${items?.length || 0} 项`)}</header>${items?.length ? items.map(render).join('') : '<p>无纳入内容</p>'}</section>`;
    return `<article class="v6-contract"><header><div><span>正式交付 · 必要依赖完整闭包</span><h2>${esc(pack.packageId)}</h2><p>${esc(pack.taskIntent)}</p></div>${badge(pack.valid ? '当前有效' : '需要复核', pack.valid ? 'green' : 'amber')}</header><div class="v6-contract-meta"><span>基线 <b>${esc(pack.versionBinding.baselineId)}</b></span><span>对象 ${pack.includedFacts.length}</span><span>断言 ${pack.includedAssertions.length}</span><span>规则 ${pack.constraints.length}</span><span>证据 ${pack.evidence.length}</span></div><div class="v6-contract-columns">${group('业务上下文', pack.businessContext, e => `<button data-focus="${esc(e.id)}"><b>${esc(e.name)}</b><small>${esc(e.id)}@${esc(e.revision)}</small></button>`)}${group('必须遵守的规则', pack.constraints, e => `<button data-focus="${esc(e.id)}"><b>${esc(e.name)}</b><p>${esc(C.ruleVersion(e)?.summary || C.ruleVersion(e)?.constraint || e.description)}</p></button>`)}${group('技术上下文', pack.implementationContext, e => `<button data-focus="${esc(e.id)}"><b>${esc(e.name)}</b><small>${esc(e.typeId)} · ${esc(e.id)}</small></button>`)}${group('纳入原因', pack.inclusionReasons, r => `<div><code>${esc(r.assertionId)}@${esc(r.revision)}</code><p>${esc(r.reason)} · ${esc(r.predicate)}</p></div>`)}</div>${group('验收条件', pack.acceptance, a => `<p class="v6-acceptance">✓ ${esc(typeof a === 'string' ? a : JSON.stringify(a))}</p>`)}<details><summary>查看版本绑定和结构化契约</summary><pre>${esc(JSON.stringify(pack, null, 2))}</pre></details></article>`;
  }
  return { esc, badge, status, tone, typeName, link, section, empty, FieldValues, RuleTable, RuleSimulation, StateView, FlowStructure, SemanticStructure, FocusCenter, Inspector, Workbench, ContractPackage };
});
