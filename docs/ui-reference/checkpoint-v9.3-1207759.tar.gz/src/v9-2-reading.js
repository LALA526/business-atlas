/* Business Atlas V9.2 — Cognitive Reading Plan, bounded projection selection and local visual semantics. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const C = commonjs ? require('./v6-core.js') : root.AtlasV6;
  const P = commonjs ? require('./v6-projection.js') : root.AtlasV6Projection;
  const api = factory(C, P);
  if (commonjs) module.exports = api;
  root.AtlasV92Reading = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C, P) {
  'use strict';
  const clone = C.clone;
  const TASKS = Object.freeze({ UNDERSTAND: 'understand', IMPLEMENT: 'implement', CHANGE: 'change', VERIFY: 'verify' });
  const TYPE_PURPOSE = {
    Feature: '这个功能做什么', Scenario: '业务怎样发生', Rule: '条件怎样决定结果', System: '系统承担什么职责', Component: '组件承担什么职责', Module: '模块承担什么职责',
    API: '接口解决什么业务问题', DataEntity: '数据代表什么', Configuration: '配置影响什么', ArchitectureDecision: '为什么选择这个方案', Resource: '资料支持哪些结论', Evidence: '证据证明什么'
  };
  const TYPE_ORDER = {
    Feature: ['purpose', 'behavior', 'rules', 'implementation', 'boundaries', 'evidence'],
    Scenario: ['purpose', 'trigger', 'behavior', 'rules', 'outcome', 'boundaries', 'implementation', 'evidence'],
    Rule: ['applicability', 'decision', 'outcomes', 'exceptions', 'behavior', 'evidence'],
    System: ['purpose', 'capabilities', 'composition', 'implementation', 'dependencies', 'boundaries', 'evidence'],
    Component: ['purpose', 'capabilities', 'composition', 'implementation', 'dependencies', 'boundaries', 'evidence'],
    Module: ['purpose', 'capabilities', 'composition', 'implementation', 'dependencies', 'boundaries', 'evidence'],
    API: ['purpose', 'contract', 'behavior', 'data', 'failures', 'consumers', 'evidence'],
    DataEntity: ['purpose', 'fields', 'lifecycle', 'data-access', 'constraints', 'evidence'],
    Configuration: ['purpose', 'applicability', 'value', 'behavior', 'differences', 'risks', 'evidence'],
    ArchitectureDecision: ['problem', 'decision', 'rationale', 'constraints', 'alternatives', 'affected', 'evidence'],
    Resource: ['purpose', 'locator', 'supported', 'applicability', 'evidence'], Evidence: ['purpose', 'locator', 'supported', 'applicability', 'evidence']
  };
  const TYPE_TITLES = {
    purpose: '它做什么', behavior: '它怎样运行', rules: '关键条件与业务规则', implementation: '系统怎样实现', boundaries: '异常、边界与未确认事项', evidence: '来源与知识状态',
    trigger: '谁触发，为什么发生', outcome: '产生什么结果', applicability: '适用条件', decision: '判断逻辑', outcomes: '不同条件的结果', exceptions: '例外与边界',
    capabilities: '支持哪些能力', composition: '内部组成', dependencies: '依赖与运行约束', contract: '调用前提与输入输出', data: '涉及哪些数据', failures: '失败与异常处理', consumers: '调用方与来源',
    fields: '关键字段', lifecycle: '生命周期与数据约束', 'data-access': '谁读取和修改', constraints: '数据约束', value: '默认值与配置值', differences: '环境差异', risks: '风险与来源',
    problem: '要解决的问题', rationale: '选择理由', alternatives: '替代方案与取舍', affected: '受影响模块', locator: '来源定位', supported: '支持哪些知识'
  };
  function depthFor(entity, task = TASKS.UNDERSTAND) {
    if (task === TASKS.CHANGE) return 3;
    if (task === TASKS.IMPLEMENT) return 2;
    return entity?.typeId === 'Feature' ? 2 : 1;
  }
  function projectionRequest(entity, task = TASKS.UNDERSTAND) { return { unlimited: false, depth: depthFor(entity, task), readingTask: task, scope: 'focus-context' }; }
  function neighbors(projection, id) { return P.neighbors(projection, id); }
  function relatedEntities(projection, id, predicates = []) { return neighbors(projection, id).filter(item => !predicates.length || predicates.includes(item.assertion.predicate)).map(item => item.entity).filter(Boolean); }
  function collectRuleReferences(project, projection, root) {
    const candidates = new Map(), add = (entity, via) => { if (entity?.typeId === 'Rule') candidates.set(entity.id, { entity, via }); };
    relatedEntities(projection, root.id, ['constrains', 'blocks', 'uses', 'affects', 'appliesTo']).forEach(entity => add(entity, 'direct'));
    relatedEntities(projection, root.id, ['implements', 'triggers', 'contains', 'uses']).filter(entity => entity.typeId === 'Action').forEach(action => relatedEntities(projection, action.id, ['constrains', 'blocks', 'uses', 'affects', 'appliesTo']).forEach(entity => add(entity, `action:${action.id}`)));
    const rootActionIds = new Set(relatedEntities(projection, root.id, ['implements', 'triggers', 'contains', 'uses']).filter(entity => entity.typeId === 'Action').map(entity => entity.id));
    (projection.flows || []).forEach(flow => {
      const includeWholeFlow = root.typeId === 'Scenario' || (candidates.size === 0 && root.props?.scenarioId === flow.scenarioId);
      const relevantNodeIds = new Set(flow.nodes.filter(node => includeWholeFlow || rootActionIds.has(node.actionId)).map(node => node.id));
      flow.nodes.filter(node => node.ruleId && relevantNodeIds.has(node.id)).forEach(node => add(C.getEntity(project, node.ruleId, projection.options), `flow-node:${node.id}`));
      flow.edges.filter(edge => edge.when?.ruleId && (relevantNodeIds.has(edge.from) || relevantNodeIds.has(edge.to))).forEach(edge => add(C.getEntity(project, edge.when.ruleId, projection.options), `flow-edge:${edge.id}`));
    });
    projection.nodes.filter(node => node.entity.typeId === 'BusinessObject').forEach(node => (node.entity.transitions || []).forEach(transition => {
      const ruleId = transition.guardRuleId || transition.decisionRef?.ruleId;
      if (ruleId) add(C.getEntity(project, ruleId, projection.options), `state-guard:${transition.id}`);
    }));
    return [...candidates.values()];
  }
  function readingPlan(project, projection, task = TASKS.UNDERSTAND) {
    if (!projection?.ok) return { ok: false, code: projection?.code || 'NOT_FOUND', sections: [] };
    const root = projection.root, type = root.typeId, facts = P.focusFacts(project, projection, root.id), order = TYPE_ORDER[type] || ['purpose', 'behavior', 'implementation', 'boundaries', 'evidence'];
    const relations = neighbors(projection, root.id), referencedRules = collectRuleReferences(project, projection, root), rules = [...new Map([...referencedRules.map(item => item.entity), ...(facts.rules || [])].map(entity => [entity.id, entity])).values()];
    const technical = [...new Map([...relatedEntities(projection, root.id, ['implements', 'triggers', 'reads', 'writes', 'dependsOn', 'uses', 'hosts', 'exposes', 'contains']).filter(entity => ['Surface', 'API', 'Component', 'Module', 'System', 'DataEntity', 'Configuration', 'Framework', 'Dependency', 'DeploymentUnit', 'BuildPipeline'].includes(entity.typeId)), ...(facts.technical || []).map(item => item.entity)].map(entity => [entity.id, entity])).values()];
    const boundaries = [
      ...(project.unknowns || []).filter(item => item.status !== 'resolved' && (item.relatedIds || []).some(id => projection.nodes.some(node => node.entity.id === id))),
      ...technical.filter(entity => entity.props?.failure).map(entity => ({ title: `${entity.name}：失败处理`, impact: entity.props.failure })),
      ...relatedEntities(projection, root.id, ['implements', 'triggers']).filter(entity => entity.typeId === 'Action').flatMap(action => (action.exceptions || []).map(exceptionId => {
        const exception = C.getEntity(project, exceptionId, projection.options);
        return exception ? { title: exception.name, impact: `${exception.trigger || ''} ${exception.recovery || ''}` } : { title: '异常处理待核验', impact: `动作 ${action.name} 关联异常 ${exceptionId}` };
      })),
      ...(facts.transitions || []).filter(item => item.verificationStatus !== 'confirmed').map(item => ({ title: '尚未核验的状态转移', impact: `${item.fromState} → ${item.toState} · ${item.guard}` }))
    ];
    const sections = order.map(kind => ({ id: kind, title: TYPE_TITLES[kind] || TYPE_PURPOSE[kind] || kind, kind, status: 'known', content: null }));
    sections.forEach(section => {
      if (['purpose', 'problem'].includes(section.kind)) section.content = { meaning: facts.meaning, goal: root.goal || root.purpose || root.description, actorId: root.actorId || null, result: root.result || root.output || null };
      if (section.kind === 'trigger') section.content = { trigger: root.trigger || root.pre || root.props?.trigger || null, participants: root.participants || root.actorIds || [] };
      if (section.kind === 'behavior') section.content = { actions: relatedEntities(projection, root.id, ['implements', 'triggers', 'contains', 'uses']).filter(entity => ['Action', 'Rule', 'Event'].includes(entity.typeId)), flows: projection.flows || [], transitions: facts.transitions || [] };
      if (section.kind === 'rules' || section.kind === 'decision') section.content = { rules: type === 'Rule' ? [root] : rules, ruleVersion: facts.ruleVersion, ruleReferences: referencedRules };
      if (section.kind === 'capabilities') section.content = { items: relatedEntities(projection, root.id, ['implements', 'triggers']), emptyText: '尚未建立能力关联' };
      if (section.kind === 'composition') section.content = { items: relatedEntities(projection, root.id, ['contains', 'hosts', 'exposes']), emptyText: '尚未建立内部组成或接口关系' };
      if (section.kind === 'dependencies') section.content = { items: relatedEntities(projection, root.id, ['dependsOn', 'uses', 'constrains']), emptyText: '尚未建立依赖或运行约束' };
      if (['implementation', 'data', 'data-access', 'consumers'].includes(section.kind)) section.content = { items: technical, emptyText: type === 'DataEntity' ? '尚未记录数据读写方' : '尚未建立技术实现关联' };
      if (section.kind === 'applicability') section.content = { applicableContext: root.applicableContext || root.props?.effectiveWhen || facts.ruleVersion?.scope || null, evaluation: root.applicability || null };
      if (section.kind === 'outcomes' || section.kind === 'outcome') section.content = { outcomes: facts.ruleVersion?.outcomes || root.outcome || root.result || null };
      if (section.kind === 'exceptions' || section.kind === 'boundaries' || section.kind === 'failures' || section.kind === 'risks') section.content = { items: boundaries, exceptions: root.exceptions || [], verificationStatus: root.verificationStatus || root.factKind || null, emptyText: '尚未记录异常、边界或待确认事项' };
      if (section.kind === 'contract') section.content = { input: root.props?.input || root.input || null, output: root.props?.output || root.output || null, method: root.props?.method || null, path: root.props?.path || null };
      if (section.kind === 'fields') section.content = { fields: root.props?.fields || root.props || null };
      if (section.kind === 'lifecycle') section.content = { lifecycle: root.props?.lifecycle || root.states || null };
      if (section.kind === 'value') section.content = { defaultValue: root.props?.defaultValue ?? root.props?.allowedValues ?? null, configVersion: root.props?.configVersion || null };
      if (section.kind === 'rationale') section.content = { rationale: root.props?.rationale || root.description || null };
      if (section.kind === 'alternatives') section.content = { alternatives: root.props?.alternatives || root.props?.consequences || '尚未记录替代方案' };
      if (section.kind === 'affected') section.content = { items: technical };
      if (section.kind === 'locator') section.content = { locator: root.props?.locator || null, uri: root.props?.uri || null, sourceVersion: root.props?.sourceVersion || null };
      if (section.kind === 'supported') section.content = { assertions: relations, sourceIds: root.sourceIds || [] };
      if (section.kind === 'evidence') section.content = { sources: facts.evidence || [], revision: root.revision, verificationStatus: root.verificationStatus || root.factKind || null, baselineId: projection.options?.baselineId || null };
      if (section.content == null || (Array.isArray(section.content.items) && !section.content.items.length && section.kind !== 'boundaries') || (Array.isArray(section.content.rules) && !section.content.rules.length) || (Array.isArray(section.content.sources) && !section.content.sources.length)) section.status = section.kind === 'boundaries' ? 'unknown' : 'missing';
    });
    return { ok: true, task, root, sections, facts, purpose: TYPE_PURPOSE[type] || '知识解释' };
  }
  const BUSINESS_PREDICATES = new Set(['triggers', 'implements', 'constrains', 'blocks', 'uses', 'reads', 'writes', 'produces', 'transitions', 'changes', 'affects']);
  const TECH_PREDICATES = new Set(['contains', 'dependsOn', 'hosts', 'exposes', 'uses']);
  function operationGraph(projection, focusId, viewType) {
    const focus = focusId && projection.nodes.some(node => node.entity.id === focusId) ? focusId : projection.root.id;
    const allowed = viewType === 'architecture' ? new Set([...BUSINESS_PREDICATES, ...TECH_PREDICATES]) : viewType === 'data-flow' ? new Set(['reads', 'writes', 'produces']) : BUSINESS_PREDICATES;
    const edges = projection.assertions.filter(assertion => allowed.has(assertion.predicate) && assertion.applicability?.status !== 'not_applicable');
    const nodeIds = new Set([focus]);
    edges.forEach(edge => { if (edge.subject === focus || edge.object === focus) { nodeIds.add(edge.subject); if (edge.object) nodeIds.add(edge.object); } });
    // An operation may need its direct Action's implementation and data context, not the whole dependency graph.
    const directActions = [...nodeIds].filter(id => projection.nodes.find(node => node.entity.id === id)?.entity.typeId === 'Action');
    if (directActions.length) edges.forEach(edge => { if (directActions.includes(edge.subject) || directActions.includes(edge.object)) { nodeIds.add(edge.subject); if (edge.object) nodeIds.add(edge.object); } });
    if (viewType === 'architecture') {
      const directTechnical = [...nodeIds].filter(id => ['System', 'Component', 'Module', 'API', 'DataEntity', 'Configuration'].includes(projection.nodes.find(node => node.entity.id === id)?.entity.typeId));
      edges.filter(edge => ['dependsOn', 'contains', 'hosts', 'exposes', 'reads', 'writes'].includes(edge.predicate)).forEach(edge => { if (directTechnical.includes(edge.subject) || directTechnical.includes(edge.object)) { nodeIds.add(edge.subject); if (edge.object) nodeIds.add(edge.object); } });
    }
    const nodes = [...nodeIds].map(id => projection.nodes.find(node => node.entity.id === id)?.entity).filter(Boolean);
    const selectedEdges = edges.filter(edge => nodeIds.has(edge.subject) && nodeIds.has(edge.object));
    return layoutSemantic(nodes, selectedEdges, viewType);
  }
  function stageGraph(projection) {
    const flow = projection.flows?.[0]; if (!flow) return null;
    const groups = new Map();
    flow.nodes.forEach(node => {
      const stageId = node.stageId || `UNSTAGED:${node.id}`;
      if (!groups.has(stageId)) groups.set(stageId, { id: stageId, knowledgeId: projection.root.id, name: stageId, type: 'stage', typeId: 'stage', stageId, members: [], preserve: true });
      groups.get(stageId).members.push(node);
    });
    const stageNames = new Map((projection.root.stageIds || []).map(id => [id, projection.nodes.find(node => node.entity.id === id)?.entity?.name || id]));
    groups.forEach(group => {
      const stageEntity = projection.nodes.find(node => node.entity.id === group.id)?.entity;
      group.name = stageEntity?.name || stageNames.get(group.id) || (group.members.length === 1 ? group.members[0]?.name : null) || '未分阶段环节';
      group.memberNames = group.members.map(member => member.name || member.actionId || member.id);
    });
    // Keep every original edge id and every condition. Different outcomes between the same
    // stages are not duplicates; unstageable intra-stage outcomes remain in flowSemanticModel.
    const edges = flow.edges.map(edge => {
      const from = flow.nodes.find(node => node.id === edge.from), to = flow.nodes.find(node => node.id === edge.to); if (!from || !to) return null;
      const fromId = from.stageId || `UNSTAGED:${from.id}`, toId = to.stageId || `UNSTAGED:${to.id}`;
      return { id: edge.id, from: fromId, to: toId, type: edge.type, label: edge.label || edge.when?.outcomeId || '', outcomeId: edge.when?.outcomeId || null, originalFrom: edge.from, originalTo: edge.to, intraStage: fromId === toId };
    }).filter(edge => edge && !edge.intraStage);
    const model = layoutSemantic([...groups.values()], edges, 'business-flow');
    model.flowId = flow.id; model.flowRevision = flow.revision || null;
    model.semantics = { stageIds: [...groups.keys()], originalNodeIds: flow.nodes.map(node => node.id), originalEdgeIds: flow.edges.map(edge => edge.id), preservedEdgeIds: edges.map(edge => edge.id), deferredIntraStageEdgeIds: flow.edges.filter(edge => {
      const from = flow.nodes.find(node => node.id === edge.from), to = flow.nodes.find(node => node.id === edge.to);
      return from && to && (from.stageId || `UNSTAGED:${from.id}`) === (to.stageId || `UNSTAGED:${to.id}`);
    }).map(edge => edge.id) };
    return model;
  }
  function stateGraph(projection, focusId) {
    const root = projection.root, states = root.states || root.props?.states || [], includeUnverified = projection.options?.applicabilityMode === 'explore' || projection.options?.includeUnverified === true, transitions = (root.transitions || []).filter(item => includeUnverified || item.verificationStatus === 'confirmed');
    if (!states.length || !transitions.length) return null;
    const relevant = focusId && transitions.some(item => item.actionRef === focusId) ? transitions.filter(item => item.actionRef === focusId) : transitions;
    const nodes = states.map((state, index) => ({ id: `STATE-${index}`, knowledgeId: root.id, name: state, type: 'state', members: [] }));
    const index = Object.fromEntries(states.map((state, i) => [state, `STATE-${i}`]));
    const edges = relevant.map((transition, i) => ({ id: transition.id || `TR-${i}`, from: index[transition.fromState], to: index[transition.toState], type: transition.verificationStatus === 'confirmed' ? 'confirmed' : 'unverified', label: transition.triggerEvent })).filter(edge => edge.from && edge.to);
    return layoutSemantic(nodes, edges, 'state');
  }
  function layoutSemantic(entities, edges, viewType) {
    const order = viewType === 'data-flow' ? ['Surface', 'Feature', 'Action', 'API', 'Component', 'Module', 'Configuration', 'DataEntity', 'Event'] : ['Surface', 'Feature', 'Rule', 'Action', 'API', 'Component', 'Module', 'Configuration', 'DataEntity', 'Event', 'System', 'DeploymentUnit', 'Framework', 'Dependency'];
    const grouped = new Map();
    entities.forEach(entity => { const key = entity.preserve ? entity.id : entity.typeId || `untyped:${entity.id}`; if (!grouped.has(key)) grouped.set(key, []); grouped.get(key).push(entity); });
    const nodes = [];
    grouped.forEach((members, typeId) => {
      const actualType = members[0].type || members[0].typeId || 'unknown';
      if (members[0].preserve || members.length <= 2) members.forEach(member => nodes.push({ id: member.id, knowledgeId: member.knowledgeId || member.id, name: member.name, type: actualType, stageId: member.stageId, memberNames: member.memberNames, members: member.members?.map(item => item.id || item) || [member.id] }));
      else nodes.push({ id: `GROUP-${typeId}`, knowledgeId: members[0].id, name: `${members[0].name} 等 ${members.length} 项`, type: actualType, members: members.map(member => member.id) });
    });
    if (viewType === 'business-flow' && nodes.every(node => node.type === 'stage')) {
      const stageOrder = new Map((projectionStageOrder(entities)).map((id, index) => [id, index]));
      nodes.sort((a, b) => (stageOrder.get(a.id) ?? 999) - (stageOrder.get(b.id) ?? 999) || a.name.localeCompare(b.name, 'zh-CN'));
      nodes.forEach((node, index) => { node.lane = index % 4; node.row = Math.floor(index / 4); node.x = 18 + node.lane * 185; node.y = 24 + node.row * 105; node.width = 158; node.height = 68; });
    } else {
      const lanes = new Map();
      nodes.forEach(node => { const type = node.type === 'stage' ? 'Action' : node.type, lane = Math.max(0, order.indexOf(type)); node.lane = lane; const row = lanes.get(lane) || 0; lanes.set(lane, row + 1); node.row = row; });
      const columns = Math.min(4, Math.max(...nodes.map(node => node.lane), 0) + 1);
      nodes.forEach(node => { const lane = node.lane % columns, row = Math.floor(node.lane / columns) + node.row; node.x = 18 + lane * 185; node.y = 24 + row * 105; node.width = 158; node.height = 68; });
    }
    const aliases = new Map();
    entities.forEach(entity => { const node = nodes.find(candidate => candidate.id === entity.id) || nodes.find(candidate => candidate.members?.includes(entity.id)); if (node) aliases.set(entity.id, node.id); });
    const visualEdges = edges.map(edge => ({ ...edge, id: edge.id || edge.assertionId, type: edge.type || edge.predicate, from: aliases.get(edge.subject ?? edge.from), to: aliases.get(edge.object ?? edge.to) })).filter(edge => edge.from && edge.to && edge.from !== edge.to);
    const width = Math.max(620, ...nodes.map(node => node.x + node.width + 22)), height = Math.max(240, ...nodes.map(node => node.y + node.height + 28));
    return { nodes, edges: visualEdges, width, height, viewType, aggregated: nodes.some(node => node.id.startsWith('GROUP-')) };
  }
  function projectionStageOrder(entities) {
    const explicit = entities.map(entity => entity.stageId).filter(Boolean);
    return explicit.length ? explicit : entities.map(entity => entity.id);
  }
  function localVisualModel(projection, focusId, viewType) {
    if (!projection?.ok) return null;
    if (viewType === 'state') return stateGraph(projection, focusId);
    if (viewType === 'business-flow' && projection.root.typeId === 'Scenario') return stageGraph(projection);
    return operationGraph(projection, focusId, viewType);
  }
  function shouldUseDiagram(plan) {
    if (!plan?.ok) return false;
    return !['Rule', 'Resource', 'Evidence', 'ArchitectureDecision', 'DataEntity', 'Configuration'].includes(plan.root.typeId);
  }
  return { TASKS, TYPE_PURPOSE, TYPE_ORDER, depthFor, projectionRequest, readingPlan, localVisualModel, shouldUseDiagram, relatedEntities, collectRuleReferences, stageGraph, stateGraph, layoutSemantic };
});
