/* Business Atlas V7 — layered, causal flow reading separate from construction. */
(function (root, factory) {
  const commonjs = typeof module === 'object' && module.exports;
  const C = commonjs ? require('./v6-core.js') : root.AtlasV6;
  const P = commonjs ? require('./v6-projection.js') : root.AtlasV6Projection;
  const V6 = commonjs ? require('./v6-views.js') : root.AtlasV6Views;
  const api = factory(C, P, V6);
  if (commonjs) module.exports = api;
  root.AtlasV7Flow = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C, P, V6) {
  'use strict';
  const esc = V6.esc;
  function stageFor(p, id) { return p.stages?.find(s => s.id === id); }
  function stageSummary(p, projection, flow, stageId, nodes) {
    const ids = new Set(nodes.map(n => n.id)), incoming = flow.edges.filter(e => ids.has(e.to) && !ids.has(e.from)), outgoing = flow.edges.filter(e => ids.has(e.from) && !ids.has(e.to));
    const actions = nodes.filter(n => n.actionId).map(n => C.getEntity(p, n.actionId, projection.options)).filter(Boolean), decisions = nodes.filter(n => n.ruleId).map(n => C.getEntity(p, n.ruleId, projection.options)).filter(Boolean);
    const transitions = (p.objects || []).flatMap(object => (object.transitions || []).filter(t => actions.some(a => a.id === t.actionRef)).map(t => ({ ...t, objectName: object.name })));
    const actors = [...new Set(actions.map(a => a.actorId).filter(Boolean))].map(id => C.getEntity(p, id, projection.options)?.name || id);
    const stageName = id => stageFor(p, id)?.name || id;
    const row = (label, values) => values?.length ? `<div><dt>${label}</dt><dd>${esc(values.join('；'))}</dd></div>` : '';
    const summary = `<dl class="v7-stage-summary">${row('进入', [...new Set(incoming.map(e => e.label || `${stageName(flow.nodes.find(n => n.id === e.from)?.stageId)} → ${stageName(flow.nodes.find(n => n.id === e.to)?.stageId)}`))])}${row('关键行为 / 判断', [...actions.slice(0, 3).map(a => a.name), ...decisions.map(r => r.name)])}${row('对象变化', transitions.map(t => `${t.objectName}：${t.fromState} → ${t.toState}`))}${row('退出结果', [...new Set(outgoing.map(e => e.label || e.when?.outcomeId || stageName(flow.nodes.find(n => n.id === e.to)?.stageId)))])}${row('责任角色', actors)}</dl>`;
    return summary.includes('<dt>') ? summary : '<p class="v7-stage-missing">阶段细节尚未建立，可继续补充动作、条件与结果。</p>';
  }
  function overview(p, projection, options) {
    return projection.flows.map(flow => {
      const groups = new Map();
      flow.nodes.forEach(node => { const key = node.stageId || 'main'; if (!groups.has(key)) groups.set(key, []); groups.get(key).push(node); });
      return `<div class="v7-flow-overview"><div class="v7-overview-head"><div><span>业务全貌</span><h2>主要阶段、判断与结果</h2></div><small>只展示当前层级，不展开整张巨图</small></div><div class="v7-stage-path">${[...groups.entries()].map(([stageId, nodes], index) => {
        const stage = stageFor(p, stageId), selected = options.stageId === stageId || (!options.stageId && index === 0), decisions = nodes.filter(n => n.type === 'decision').length;
        return `<button class="v7-stage-card ${selected ? 'selected' : ''}" data-flow-stage="${esc(stageId)}" data-flow-id="${esc(flow.id)}"><span>${String(index + 1).padStart(2, '0')}</span><b>${esc(stage?.name || (stageId === 'main' ? '业务主线' : stageId))}</b>${stageSummary(p, projection, flow, stageId, nodes)}<small>${nodes.length} 个环节${decisions ? ` · ${decisions} 个判断` : ''}</small></button>`;
      }).join('')}</div></div>`;
    }).join('');
  }
  function layoutLocal(flow, stageId, showExceptions) {
    const stageNodes = (stageId ? flow.nodes.filter(n => (n.stageId || 'main') === stageId) : flow.nodes).map(n => ({ ...n }));
    const selectedIds = new Set(stageNodes.map(n => n.id));
    let nodes = stageNodes;
    if (stageId) {
      flow.edges.forEach(edge => { if (selectedIds.has(edge.from) || selectedIds.has(edge.to)) { const other = flow.nodes.find(n => n.id === (selectedIds.has(edge.from) ? edge.to : edge.from)); if (other && !selectedIds.has(other.id)) { nodes.push({ ...other }); selectedIds.add(other.id); } } });
    }
    if (!showExceptions) {
      const visible = new Set(nodes.filter(n => n.type !== 'exception').map(n => n.id));
      nodes = nodes.filter(n => visible.has(n.id));
    }
    const ids = new Set(nodes.map(n => n.id)), edges = flow.edges.filter(e => ids.has(e.from) && ids.has(e.to) && (showExceptions || !['error'].includes(e.type)));
    const incomingNormal = new Map(), ranks = new Map();
    nodes.forEach(n => incomingNormal.set(n.id, []));
    edges.filter(e => !['return', 'error'].includes(e.type)).forEach(e => incomingNormal.get(e.to).push(e.from));
    const starts = nodes.filter(n => n.type === 'start' || !incomingNormal.get(n.id).length);
    const queue = (starts.length ? starts : [nodes[0]]).filter(Boolean).map(n => n.id);
    queue.forEach(id => ranks.set(id, 0));
    for (let i = 0; i < nodes.length + 2 && queue.length; i++) {
      const id = queue.shift(), rank = ranks.get(id) || 0;
      edges.filter(e => e.from === id && !['return', 'error'].includes(e.type)).forEach(e => { if (!ranks.has(e.to) || ranks.get(e.to) < rank + 1) { ranks.set(e.to, rank + 1); queue.push(e.to); } });
    }
    nodes.forEach(n => { if (!ranks.has(n.id)) ranks.set(n.id, 0); });
    const columns = new Map();
    nodes.forEach(n => { const rank = ranks.get(n.id), index = columns.get(rank) || 0; n.__x = 30 + rank * 195; n.__y = 34 + index * 98; columns.set(rank, index + 1); });
    const width = Math.max(720, Math.max(...nodes.map(n => n.__x), 0) + 190), height = Math.max(260, Math.max(...nodes.map(n => n.__y), 0) + 120);
    return { nodes, edges, width, height };
  }
  function LocalFlow(p, projection, flow, options) {
    if (!options.stageId) return `<div class="v7-local-empty"><b>选择一个业务阶段</b><p>在上方业务全貌中聚焦局部流程，再逐层进入动作、规则与实现。</p></div>`;
    const { nodes, edges, width, height } = layoutLocal(flow, options.stageId, options.showExceptions);
    const nodeEntity = node => C.getEntity(p, node.actionId || node.ruleId || node.eventId, projection.options);
    const paths = `<svg class="v7-flow-svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" aria-hidden="true"><defs><marker id="v7-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#8c82ae"/></marker><marker id="v7-arrow-return" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#b36c62"/></marker></defs>${edges.map(edge => {
      const from = nodes.find(n => n.id === edge.from), to = nodes.find(n => n.id === edge.to), returning = ['return', 'error'].includes(edge.type);
      const x1 = from.__x + 150, y1 = from.__y + 28, x2 = to.__x, y2 = to.__y + 28;
      const path = returning ? `M ${from.__x + 75} ${from.__y + 56} C ${from.__x + 75} ${height - 10}, ${to.__x + 75} ${height - 10}, ${to.__x + 75} ${to.__y + 56}` : `M ${x1} ${y1} C ${x1 + 45} ${y1}, ${x2 - 45} ${y2}, ${x2} ${y2}`;
      return `<path class="v7-edge-line ${returning ? 'returning' : ''} ${options.focusId && ![edge.from, edge.to].some(id => { const n = flow.nodes.find(x => x.id === id); return (n.actionId || n.ruleId || n.eventId) === options.focusId; }) ? 'dim' : ''}" d="${path}" marker-end="url(#v7-arrow${returning ? '-return' : ''})"/><text class="v7-edge-label" x="${returning ? (from.__x + to.__x) / 2 + 75 : (x1 + x2) / 2}" y="${returning ? height - 20 : (y1 + y2) / 2 - 7}" text-anchor="middle">${esc(edge.label || edge.when?.outcomeId || edge.type)}</text>`;
    }).join('')}</svg>`;
    return `<div class="v7-local-head"><div><span>局部子流程</span><b>${esc(stageFor(p, options.stageId)?.name || options.stageId)}</b></div><div><button data-flow-exceptions>${options.showExceptions ? '收起异常路径' : '展开异常路径'}</button><button data-flow-zoom="out">−</button><button data-flow-zoom="in">＋</button><button data-flow-stage="">返回业务全貌</button></div></div><div class="v7-flow-canvas" style="--flow-zoom:${options.zoom || 1}"><div class="v7-flow-inner" style="width:${width}px;height:${height}px">${paths}${nodes.map(node => {
      const entity = nodeEntity(node), entityId = entity?.id, selected = options.focusId === entityId;
      return `<button class="v7-canvas-node ${esc(node.type)} ${selected ? 'selected' : ''}" style="left:${node.__x}px;top:${node.__y}px" ${entityId ? `data-focus="${entityId}"` : `data-flow-node="${node.id}"`}><span>${esc({ action: '动作', decision: '判断', event: '事件', exception: '异常', parallel: '并行', join: '汇合', start: '开始', end: '结果' }[node.type] || node.type)}</span><b>${esc(entity?.name || node.name || node.id)}</b><small>${esc(entityId || node.id)}</small></button>`;
    }).join('')}</div></div><div class="v7-flow-legend"><span>实线：正常/条件</span><span>虚线：异常/恢复</span><span>点击节点查看规则、状态、实现与证据</span></div>`;
  }
  function ReadingWorkbench(p, projection, focusId, options = {}) {
    if (!projection.ok) return V6.Workbench(p, projection, focusId, options);
    const focus = P.focusFacts(p, projection, focusId || projection.root.id);
    return `<div class="v7-reading-workspace"><section class="v7-reading-top">${overview(p, projection, options)}${projection.flows.map(flow => LocalFlow(p, projection, flow, options)).join('')}</section><div class="v6-workbench reading"><aside class="v6-structure"><div class="v6-pane-label">相关对象 <span>同一知识身份</span></div>${V6.SemanticStructure(p, projection, focus.entity?.id)}</aside><main class="v6-focus"><div class="v6-pane-label">节点解释 <span>分析视图</span></div>${V6.FocusCenter(p, projection, focus)}</main><aside class="v6-inspector"><div class="v6-pane-label">上下文检查器 <span>规则 · 状态 · 实现</span></div>${V6.Inspector(p, projection, focus, false)}</aside></div></div>`;
  }
  return { overview, layoutLocal, LocalFlow, ReadingWorkbench };
});
