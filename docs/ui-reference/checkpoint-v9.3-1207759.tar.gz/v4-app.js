/* Business Atlas V4 — project workspace and interaction controllers. No industry-specific render pages. */
'use strict';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const K = AtlasCore, V = AtlasViews, E = AtlasEngine;
const esc = V.esc, clone = K.clone;
const STORE = 'business-atlas-v4';
const initialHash = location.hash.slice(1);
const state = { route: initialHash.startsWith('entity/') ? 'entity' : initialHash || 'projects', entityId: initialHash.startsWith('entity/') ? initialHash.split('/')[1] : null, entityView: 'summary', entityVersion: null, returnStack: [], modal: null, drawer: null, catalogPage: 1, workflowDraft: null, searchTimer: null };
let store;
try { store = JSON.parse(localStorage.getItem(STORE) || 'null'); } catch (_) { /* use clean demonstration data */ }
if (!store?.projects?.['PRJ-00004']) store = { currentProjectId: 'PRJ-00001', contexts: {}, recent: {}, projects: AtlasV4Model.createProjectSet() };
store.contexts ||= {}; store.recent ||= {};
const M = () => store.projects[store.currentProjectId];
const C = () => {
  const id = store.currentProjectId;
  store.contexts[id] ||= {
    catalogType: 'all', catalogQuery: '', catalogDimension: '', selectedScenarioId: M().scenarios?.[0]?.id || null,
    exploreFlow: false, flowValues: {}, ruleValues: {}, selectedInstanceId: M().workflowInstances?.[0]?.id || null,
    workTab: 'workflow', adminTab: 'health', selectedChangeId: M().changes?.[0]?.id || null, selectedPathId: M().workspace?.readingPaths?.[0]?.id || null,
    homeSections: clone(M().workspace?.homeSections || []), pins: [], role: 'newbie'
  };
  return store.contexts[id];
};
const save = () => { try { localStorage.setItem(STORE, JSON.stringify(store)); } catch (_) { toast('浏览器存储不足，修改尚未持久化', 'error'); } };
const badge = V.badge;
const button = (label, action, style = '', extra = '') => `<button class="v4-button ${style}" data-action="${action}" ${extra}>${label}</button>`;
const typeName = item => V.typeName(M(), item?.typeId);
const publishedRule = rule => rule?.versions?.[rule.currentVersion] || rule?.versions?.draft;
const statusName = status => ({ published: '已发布', draft: '草稿', pending: '待审批', approved: '已批准', historical: '历史', active: '进行中', completed: '已完成', resolved: '已解决', internal: '内部', sensitive: '敏感', restricted: '受限', confirmed: '已确认' }[status] || status || '未建立');
const statusTone = status => ['published', 'approved', 'active', 'completed', 'resolved', 'confirmed', '已批准', '已核验'].includes(status) ? 'green' : ['draft', 'pending', 'historical', 'stale'].includes(status) ? 'amber' : '';
function toast(message, type = 'success') { const el = document.createElement('div'); el.className = `v4-toast ${type === 'error' ? 'error' : ''}`; el.textContent = message; $('#toast-root').appendChild(el); setTimeout(() => el.remove(), 3800); }
function go(route) { state.route = route; state.modal = null; state.drawer = null; location.hash = route; renderOverlay(); render(); scrollTo(0, 0); }
function openEntity(id, view) {
  if (!K.getEntity(M(), id)) { toast('当前项目中不存在此知识对象', 'error'); return; }
  if (state.route === 'entity' && state.entityId) state.returnStack.push({ route: state.route, entityId: state.entityId, entityView: state.entityView, entityVersion: state.entityVersion });
  else if (state.route !== 'entity') state.returnStack.push({ route: state.route, entityId: state.entityId, entityView: state.entityView, entityVersion: state.entityVersion });
  state.entityId = id;
  const item = K.getEntity(M(), id), preferred = K.schemaFor(M(), item.typeId)?.defaultView || 'summary', available = V.availableViews(M(), item);
  state.entityView = view || (available.some(option => option.id === preferred) ? preferred : 'summary'); state.entityVersion = null; state.route = 'entity'; location.hash = `entity/${id}`;
  store.recent[store.currentProjectId] ||= []; store.recent[store.currentProjectId] = [id, ...store.recent[store.currentProjectId].filter(item => item !== id)].slice(0, 8);
  state.modal = null; state.drawer = null; save(); render(); renderOverlay(); scrollTo(0, 0);
}
function returnContext() {
  const previous = state.returnStack.pop();
  if (!previous) { go('home'); return; }
  state.route = previous.route; state.entityId = previous.entityId; state.entityView = previous.entityView || 'summary'; state.entityVersion = previous.entityVersion || null;
  location.hash = previous.route === 'entity' ? `entity/${previous.entityId}` : previous.route; save(); render();
}
function pageHead(title, eyebrow, description, actions = '') { return `<div class="v4-page-head"><div><div class="v4-eyebrow">${esc(eyebrow)}</div><h1>${esc(title)}</h1>${description ? `<p>${esc(description)}</p>` : ''}</div><div class="v4-actions">${actions}</div></div>`; }
function contextBar(items = []) { return `<div class="v4-contextbar">${items.map((item, index) => `${index ? '<span>›</span>' : ''}${item.action ? `<button data-action="${item.action}">${esc(item.label)}</button>` : `<b>${esc(item.label)}</b>`}`).join('')}<span class="spacer"></span>${state.returnStack.length ? '<button data-action="return-context">← 返回原阅读位置</button>' : ''}</div>`; }
function navItem(route, icon, label) { const active = state.route === route || (state.route === 'entity' && route === 'explore'); return `<button class="v4-nav-item ${active ? 'active' : ''}" data-route="${route}" title="${label}"><i>${icon}</i><span>${label}</span></button>`; }
function shell(content) {
  const m = M(), health = K.health(m), pending = m.issues.filter(item => !['resolved', 'cancelled'].includes(item.status)).length + m.changes.filter(item => item.status === 'pending').length;
  return `<div class="v4-app"><header class="v4-topbar"><button class="v4-brand" data-action="projects"><span class="v4-brand-mark">A</span>Business Atlas</button><button class="v4-project-switch" data-action="projects">${esc(m.meta.name)}<small>${esc(m.meta.id)} · ${esc(m.versionLayers?.baseline || m.meta.version)}</small></button><div class="v4-global-search"><input id="global-search" placeholder="搜索项目知识、别名或稳定 ID" autocomplete="off"><span>Ctrl K</span></div><select class="v4-role-select" id="role-select" title="演示信息可见范围"><option value="newbie" ${C().role === 'newbie' ? 'selected' : ''}>业务阅读视角</option><option value="developer" ${C().role === 'developer' ? 'selected' : ''}>开发阅读视角</option><option value="restricted" ${C().role === 'restricted' ? 'selected' : ''}>受限外部视角</option></select><button class="v4-avatar" data-action="profile">${pending || '林'}</button></header><div class="v4-body"><aside class="v4-sidebar"><div class="v4-nav-group"><div class="v4-nav-label">认识项目</div>${navItem('home', '⌂', '项目空间')}${navItem('scenarios', '⇢', '业务与场景')}</div><div class="v4-nav-group"><div class="v4-nav-label">追溯知识</div>${navItem('explore', '⌕', '知识探索')}${navItem('entity', '◇', '对象阅读')}</div><div class="v4-nav-group"><div class="v4-nav-label">共同维护</div>${navItem('work', '↻', '协作与工作')}${navItem('admin', '⚙', '知识与项目配置')}</div><div class="v4-sidebar-bottom">知识基线与运行版本分离<br><span class="v4-mono">${esc(m.versionLayers?.release || '未发布软件')}</span><button class="v4-context-button" data-action="agent-context">⌘ 查询结构化知识上下文<br><small>固定 ID / 版本 / 深度 / 权限</small></button><button class="v4-context-button" data-action="health">知识健康 ${health.missingSources.length + health.inferredRelations.length} 项待处理</button></div></aside><main class="v4-main">${content}</main></div></div>`;
}
function render() {
  const routes = { projects: renderProjects, home: renderHome, explore: renderExplore, scenarios: renderScenarios, entity: renderEntity, work: renderWork, admin: renderAdmin };
  const route = state.route.split('/')[0], fn = routes[route] || renderHome;
  $('#app').innerHTML = route === 'projects' ? fn() : shell(fn()); renderOverlay();
}

/* Project directory and creation */
function renderProjects() {
  const projects = Object.values(store.projects);
  return `<div class="v4-app"><header class="v4-topbar"><div class="v4-brand"><span class="v4-brand-mark">A</span>Business Atlas</div><div class="v4-global-search"><input id="project-search" placeholder="搜索项目"><span>V4</span></div><button class="v4-avatar" data-action="profile">林</button></header><main class="v4-entry"><div class="v4-entry-head"><div><div class="v4-eyebrow">PROJECT COGNITION WORKSPACE</div><h1>从项目本身开始，而不是从工具模块开始</h1><p>业务、系统、配置、原始资料与协作过程共享同一套知识语法。</p></div><div class="v4-actions">${button('接入已有项目', 'connect')}${button('＋ 创建项目', 'create-project', 'primary')}</div></div><div class="v4-project-grid">${projects.map(project => {
    const knowledge = K.allEntities(project), custom = project.knowledge?.length || 0, issues = project.issues.filter(item => !['resolved', 'cancelled'].includes(item.status)).length;
    return `<button class="v4-project-card" data-project="${project.meta.id}" data-project-name="${esc(project.meta.name.toLowerCase())}"><div class="v4-project-card-top"><span class="v4-project-symbol">${esc(project.meta.name[0])}</span>${badge(project.meta.status === 'published' ? '已建立基线' : '构建中', project.meta.status === 'published' ? 'green' : 'amber')}</div><h2>${esc(project.meta.name)}</h2><p>${esc(project.profile?.positioning || project.meta.goal || '项目定位待补充')}</p><div class="v4-project-stats"><div><b>${project.domains.length}</b><small>业务领域</small></div><div><b>${project.scenarios.length}</b><small>业务场景</small></div><div><b>${knowledge.length}</b><small>知识对象</small></div><div><b>${issues}</b><small>待关注</small></div></div><div class="v4-project-foot"><small>${custom} 个扩展对象 · ${project.workflowDefinitions?.length || 0} 份工作流定义</small><span class="v4-inline-link">进入项目 →</span></div></button>`;
  }).join('')}</div><section class="v4-card v4-template-strip"><b>模板只是初始配置，不是行业枷锁</b><span>空白项目 · 软件产品 · 业务审批 · 制造业务 · 政务事项</span><span>创建后仍可修改知识类型、首页、阅读路径和工作流。</span></section></main></div>`;
}

/* Project Profile driven home */
function homeSection(id, content) { return C().homeSections.includes(id) && content ? content : ''; }
function renderHome() {
  const m = M(), p = m.profile || {}, scenarios = m.scenarios || [], systems = (m.knowledge || []).filter(item => ['System', 'Subsystem', 'Module'].includes(item.typeId)), terms = (m.knowledge || []).filter(item => item.typeId === 'Term'), configs = (m.knowledge || []).filter(item => item.typeId === 'Configuration'), resources = (m.knowledge || []).filter(item => item.typeId === 'Resource');
  const paths = m.workspace?.readingPaths || [], selected = paths.find(item => item.id === C().selectedPathId) || paths[0], health = K.health(m);
  const actions = `${button('编辑项目档案', 'edit-profile')}${!m.domains.length ? button('＋ 添加领域', 'add-domain', 'primary') : ''}`;
  const hero = `<section class="v4-hero"><div class="v4-actions" style="position:absolute;right:24px;top:24px;z-index:2">${actions}</div><div class="v4-eyebrow">${esc(m.meta.id)} · ${esc(p.stage || '项目认知空间')}</div><h1>${esc(m.meta.name)}</h1><p class="v4-hero-positioning">${esc(p.positioning || m.meta.goal || '尚未描述项目定位。')}</p><div class="v4-boundaries"><div><b>负责什么</b><p>${esc((p.inScope || []).join('；') || '业务边界待明确')}</p></div><div><b>不负责什么 / 如何分工</b><p>${esc((p.outScope || []).join('；') || '外部边界待明确')}</p></div></div></section>`;
  const intro = homeSection('intro', `<section class="v4-section"><div class="v4-section-title"><div><h2>了解这个项目</h2><p>先建立整体认知，再沿对象逐层深入</p></div>${badge(p.audience || '服务对象待明确', 'blue')}</div><div class="v4-intro-narrative"><p>${esc(p.background || '项目背景尚未整理。')}</p><p>${esc(p.value || m.meta.goal || '')}</p></div><div class="v4-home-metrics"><div><b>${m.domains.length}</b><small>业务领域</small></div><div><b>${systems.length}</b><small>系统组成</small></div><div><b>${terms.length}</b><small>独立术语</small></div><div><b>${resources.length}</b><small>原始资料</small></div></div></section>`);
  const business = homeSection('business', m.domains.length || scenarios.length ? `<section class="v4-section"><div class="v4-section-title"><div><h2>探索业务</h2><p>能力、功能与业务活动分别建模、相互关联</p></div><button class="v4-inline-link" data-route="scenarios">全部场景 →</button></div><div class="v4-home-links">${m.domains.slice(0, 3).map(domain => `<button data-entity="${domain.id}"><b>${esc(domain.name)}</b><p>${esc(domain.desc || domain.goal)}</p></button>`).join('')}${scenarios.slice(0, Math.max(0, 3 - m.domains.length)).map(scenario => `<button data-entity="${scenario.id}"><b>${esc(scenario.name)}</b><p>${esc(scenario.goal)}</p></button>`).join('')}</div></section>` : '');
  const system = homeSection('systems', systems.length || configs.length ? `<section class="v4-section"><div class="v4-section-title"><div><h2>理解系统</h2><p>从结构进入，也可以从配置或数据反向回到业务</p></div></div><div class="v4-home-links">${systems.slice(0, 2).map(item => `<button data-entity="${item.id}"><b>${esc(item.name)}</b><p>${esc(item.description)}</p></button>`).join('')}${configs.slice(0, Math.max(0, 3 - systems.length)).map(item => `<button data-entity="${item.id}"><b>${esc(item.name)}</b><p>${esc(item.description)}</p></button>`).join('')}</div></section>` : '');
  const assets = homeSection('assets', terms.length || resources.length ? `<section class="v4-section"><div class="v4-section-title"><h2>项目知识</h2><button class="v4-inline-link" data-action="catalog-terms">术语与原始资料 →</button></div><div class="v4-home-links">${terms.slice(0, 2).map(item => `<button data-term="${item.id}"><b>${esc(item.name)}</b><p>${esc(item.props?.shortDefinition || item.description)}</p></button>`).join('')}${resources.slice(0, 1).map(item => `<button data-entity="${item.id}"><b>${esc(item.name)}</b><p>${esc(item.props?.resourceType || '原始资料')} · ${esc(item.props?.sourceVersion || '')}</p></button>`).join('')}</div></section>` : '');
  const concerns = m.issues.filter(item => !['resolved', 'cancelled'].includes(item.status));
  const concernSection = homeSection('concerns', concerns.length || health.inferredRelations.length ? `<section class="v4-section"><div class="v4-section-title"><h2>当前关注</h2><span>不阻塞正常知识阅读</span></div>${concerns.slice(0, 4).map(issue => `<button class="v4-concern" data-issue="${issue.id}"><b>${esc(issue.title)}</b><small>${esc(issue.objectId)} · ${esc(statusName(issue.status))}</small></button>`).join('')}${health.inferredRelations.length ? `<button class="v4-concern" data-action="health"><b>${health.inferredRelations.length} 条关系仍需核验</b><small>AI 推断不能冒充人工确认事实</small></button>` : ''}</section>` : '');
  const questions = [
    ['这个项目是什么？', '项目定位与业务边界', null, 'scroll-intro'],
    scenarios[0] ? [`系统如何处理${scenarios[0].name.replace(/^用户|^修订/, '')}？`, scenarios[0].name, scenarios[0].id] : null,
    configs[0] ? ['这个配置影响哪些功能？', configs[0].name, configs[0].id] : null,
    terms[0] ? [`“${terms[0].name}”是什么意思？`, '独立术语与名称来源', terms[0].id, 'term'] : null,
    (m.knowledge || []).find(item => item.typeId === 'DataEntity') ? ['保存操作最终写了什么数据？', '从数据反向探索业务', (m.knowledge || []).find(item => item.typeId === 'DataEntity').id] : null,
    ['这条需求已经确认了吗？', '进入实际工作流实例', null, 'work']
  ].filter(Boolean);
  const left = `${intro}<section class="v4-section" id="project-questions"><div class="v4-section-title"><div><h2>从一个自然问题开始</h2><p>无需先理解 Scenario、Action 或数据分类</p></div></div><div class="v4-question-grid">${questions.map(([label, sub, id, special]) => `<button ${id ? special === 'term' ? `data-term="${id}"` : `data-entity="${id}"` : `data-action="${special}"`}>${esc(label)}<span>${esc(sub)}</span></button>`).join('')}</div></section>${business}${system}${assets}`;
  const right = `<aside><section class="v4-section"><div class="v4-section-title"><h2>推荐理解路径</h2><span>阅读导航，不改变知识事实</span></div>${paths.length ? `<div class="v4-field"><select id="reading-path">${paths.map(path => `<option value="${path.id}" ${path.id === selected?.id ? 'selected' : ''}>${esc(path.name)}</option>`).join('')}</select></div><div class="v4-reading-path">${(selected?.steps || []).map((step, index) => `<button class="v4-reading-step" data-entity="${step.entityId}"><span>${index + 1}</span><div><b>${esc(step.label)}</b><small>${esc(K.getEntity(m, step.entityId)?.name || step.entityId)}</small></div></button>`).join('')}</div>` : '<p class="muted">尚未配置阅读路径。</p>'}</section>${concernSection}<section class="v4-section"><div class="v4-section-title"><h2>知识现状</h2><button class="v4-inline-link" data-action="health">详情 →</button></div><div class="v4-notice blue">${esc(health.note)}</div><div class="v4-kv-list"><p>已结构化对象 <b>${health.modeled}</b></p><p>待补来源 <b>${health.missingSources.length}</b></p><p>待核验关系 <b>${health.inferredRelations.length}</b></p></div></section></aside>`;
  return `${hero}${contextBar([{ label: m.meta.name }, { label: '项目认知入口' }])}<div class="v4-home-layout"><div>${left}</div>${right}</div>`;
}

/* Unified knowledge catalog: filtering, grouping, pagination, no fixed number assumptions */
function catalogEntities() {
  const seen = new Set(); return K.allEntities(M(), { permission: permissionContext() }).filter(item => { if (seen.has(item.id)) return false; seen.add(item.id); return true; });
}
function permissionContext() { return C().role === 'restricted' ? { role: 'external', clearance: 'internal' } : C().role === 'developer' ? { role: 'developer', clearance: 'sensitive' } : { role: 'reader', clearance: 'restricted' }; }
function renderExplore() {
  const m = M(), c = C(), all = catalogEntities(), schemas = Object.values(m.schemaRegistry || {});
  const usedTypes = new Set(all.map(item => item.typeId));
  const filtered = all.filter(item => {
    const text = `${item.id}${item.name}${item.description || ''}${item.aliases || ''}${item.props?.synonyms || ''}${item.props?.historicalNames || ''}`.toLowerCase();
    return (!c.catalogType || c.catalogType === 'all' || item.typeId === c.catalogType) && (!c.catalogDimension || K.schemaFor(m, item.typeId)?.dimension === c.catalogDimension) && text.includes(c.catalogQuery.toLowerCase());
  }).sort((a, b) => String(typeName(a) || '知识').localeCompare(String(typeName(b) || '知识'), 'zh-CN') || String(a.name || a.id).localeCompare(String(b.name || b.id), 'zh-CN'));
  const page = K.paginate(filtered, state.catalogPage, 14); state.catalogPage = page.page;
  const dimensions = [...new Set(schemas.filter(schema => usedTypes.has(schema.id)).map(schema => schema.dimension))];
  return `${pageHead('知识探索', `${filtered.length} 个匹配对象 · 按需分页与局部聚焦`, '知识维度用于筛选，不是把项目拆成互不相通的五个页面。', button('＋ 新建知识对象', 'new-entity', 'primary'))}<div class="v4-catalog-layout"><aside class="v4-card v4-type-index"><button class="${c.catalogType === 'all' ? 'active' : ''}" data-catalog-type="all"><span>全部知识</span><small>${all.length}</small></button>${dimensions.map(dimension => `<div class="v4-type-group">${esc(dimension)}</div>${schemas.filter(schema => schema.dimension === dimension && usedTypes.has(schema.id)).map(schema => `<button class="${c.catalogType === schema.id ? 'active' : ''}" data-catalog-type="${schema.id}"><span>${esc(schema.name)}</span><small>${all.filter(item => item.typeId === schema.id).length}</small></button>`).join('')}`).join('')}</aside><div><div class="v4-filterbar"><input id="catalog-query" value="${esc(c.catalogQuery)}" placeholder="搜索名称、定义、别名或稳定 ID"><select id="catalog-dimension"><option value="">全部知识维度</option>${dimensions.map(item => `<option value="${esc(item)}" ${c.catalogDimension === item ? 'selected' : ''}>${esc(item)}</option>`).join('')}</select>${button('清除', 'clear-catalog', 'small')}</div><section class="v4-card v4-knowledge-list">${page.items.map(item => `<button class="v4-knowledge-row" data-entity="${item.id}"><div><b>${esc(item.name)}</b><p>${esc(item.description || item.selectedVersion?.summary || item.goal || '')}</p></div><small>${esc(typeName(item))}</small><span class="v4-mono">${esc(item.id)}</span>${badge(item.sensitivity || statusName(item.status || item.revision), item.sensitivity === 'restricted' ? 'amber' : '')}</button>`).join('') || V.empty('没有匹配知识', '调整搜索或筛选；平台不会为空白类型生成虚构内容。')}</section><div class="v4-pagination"><span>第 ${page.page} / ${page.pages} 页 · 共 ${page.total} 条</span><div><button data-page="${Math.max(1, page.page - 1)}">上一页</button><button data-page="${Math.min(page.pages, page.page + 1)}">下一页</button></div></div></div></div>`;
}
function renderScenarios() {
  const m = M(), scenarios = m.scenarios || [];
  return `${pageHead('业务与场景', 'FLOW · CASE · STATE · DECISION · KNOWLEDGE', '表达模式由知识结构决定；没有流程的内容不会被强制包装成流程。', button('＋ 创建业务场景', 'add-scenario', 'primary'))}${m.domains.length ? `<section class="v4-section"><div class="v4-section-title"><h2>业务职责</h2><button class="v4-inline-link" data-action="add-domain">＋ 添加领域</button></div>${V.DomainMap(m)}</section>` : `<section class="v4-section">${V.empty('先建立业务职责或项目知识', '新项目可以只有术语、系统和原始资料，不强制先创建场景。')}${button('＋ 添加领域', 'add-domain', 'primary')}</section>`}<div class="v4-three-col">${scenarios.map(scenario => {
    const mode = scenario.caseModel ? '案件型' : scenario.expressionMode === 'state' ? '状态驱动' : scenario.expressionMode === 'decision' ? '决策驱动' : '流程型';
    return `<button class="v4-project-card" data-entity="${scenario.id}"><div class="v4-project-card-top"><span class="v4-project-symbol">${esc(scenario.name[0])}</span>${badge(mode, 'blue')}</div><h2>${esc(scenario.name)}</h2><p>${esc(scenario.goal || '场景目标待明确')}</p><div class="v4-project-foot"><small>${scenario.id}@${scenario.version || 'draft'}</small><span class="v4-inline-link">打开适用视图 →</span></div></button>`;
  }).join('')}</div>`;
}

/* Generic object reader and view selection */
function currentEntity() { return K.getEntity(M(), state.entityId, state.entityVersion); }
function renderEntity() {
  const m = M(), item = currentEntity();
  if (!item) return `${pageHead('对象不可用', state.entityId || '未选择对象', '指定版本或对象不存在，不自动替换为其他内容。', button('返回知识索引', 'back-catalog', 'primary'))}`;
  const allowed = K.allEntities(m, { permission: permissionContext() }).some(entry => entry.id === item.id);
  if (!allowed) return `${pageHead('当前视角不可见', item.id, '此知识对象的敏感度或阅读权限超出当前演示角色范围。', button('返回知识索引', 'back-catalog', 'primary'))}`;
  const views = V.availableViews(m, item); if (!views.some(view => view.id === state.entityView)) state.entityView = views[0]?.id || 'summary';
  const actions = `${button('固定关注', 'pin-entity')}${item.typeId === 'Rule' ? button('提出修改', 'new-rule-change', 'primary', `data-id="${item.id}"`) : ''}${item.typeId === 'Scenario' ? button('＋ 添加动作', 'add-action', 'primary', `data-id="${item.id}"`) : ''}${m.knowledge?.some(entry => entry.id === item.id) && K.schemaFor(m, item.typeId)?.editable ? button('编辑对象', 'edit-entity', 'primary', `data-id="${item.id}"`) : ''}`;
  const main = renderEntityView(m, item, state.entityView);
  return `<div class="v4-object-head"><div class="v4-object-title"><div class="v4-object-icon">${esc(item.name?.[0] || '◇')}</div><div><div class="v4-eyebrow">${esc(typeName(item))} · ${esc(K.schemaFor(m, item.typeId)?.dimension || '项目知识')}</div><h1>${esc(item.name)}</h1><div class="v4-object-meta"><span class="v4-mono">${item.id}@${esc(item.revision || item.currentVersion || 'r1')}</span>${badge(statusName(item.status), statusTone(item.status))}${item.sensitivity ? badge(`敏感度：${statusName(item.sensitivity)}`, item.sensitivity === 'internal' ? '' : 'amber') : ''}</div></div></div><div class="v4-actions">${actions}</div></div>${contextBar([{ label: m.meta.name, action: 'home' }, { label: typeName(item), action: 'back-catalog-type' }, { label: item.name }])}<div class="v4-tabs">${views.map(view => `<button class="v4-tab ${state.entityView === view.id ? 'active' : ''}" data-object-view="${view.id}">${esc(view.name)}</button>`).join('')}</div><div class="v4-object-layout"><div>${main}</div><aside class="v4-object-aside"><section class="v4-section"><div class="v4-section-title"><h2>继续探索</h2><span>局部一度关系</span></div>${V.RelationExplorer(m, item, { compact: true })}</section><section class="v4-section"><div class="v4-section-title"><h2>上下文操作</h2></div><div class="v4-actions">${button('提问或澄清', 'new-issue', 'small', `data-id="${item.id}"`)}${button('建立关联', 'add-relation', 'small', `data-id="${item.id}"`)}${button('查询知识契约', 'agent-context', 'small', `data-id="${item.id}"`)}</div><div class="v4-notice blue">修改、审阅、批准和任务都指向当前稳定 ID。</div></section></aside></div>`;
}
function renderEntityView(m, item, view) {
  if (view === 'decision') return V.KnowledgeSummary(m, item) + TermLinks(m, item) + V.DecisionTable(m, item);
  if (view === 'flow') return V.KnowledgeSummary(m, item) + V.DirectedFlow(m, item, { explore: C().exploreFlow, exploreValues: C().flowValues });
  if (view === 'case') return V.KnowledgeSummary(m, item) + V.CaseActivityView(m, item);
  if (view === 'state') return V.KnowledgeSummary(m, item) + V.StateLifecycle(m, item);
  if (view === 'system') return V.KnowledgeSummary(m, item) + V.PropertyTable(m, item) + V.SystemMap(m, item);
  if (view === 'data') return V.KnowledgeSummary(m, item) + V.DataMapping(m, item);
  if (view === 'config') return V.KnowledgeSummary(m, item) + V.ConfigurationInspector(m, item);
  if (view === 'resource') return V.KnowledgeSummary(m, item) + V.ResourceViewer(m, item);
  if (view === 'relations') return `<section class="v4-section"><div class="v4-section-title"><div><h2>局部关系探索</h2><p>关系包含范围、来源、可信状态、条件与方向</p></div></div>${V.RelationExplorer(m, item)}</section>`;
  if (view === 'evidence') return V.EvidenceInspector(m, item);
  if (view === 'versions') return V.VersionComparison(m, item) + VersionLayers(m);
  let extra = V.PropertyTable(m, item);
  if (item.typeId === 'Action') extra += ActionBehavior(m, item);
  if (item.typeId === 'Scenario' && item.explore) extra += `<section class="v4-section"><h2>场景上下文</h2><dl class="v4-properties"><div class="v4-property"><dt>触发</dt><dd>${esc(item.trigger)}</dd></div><div class="v4-property"><dt>最终结果</dt><dd>${esc(item.result)}</dd></div></dl></section>`;
  if (item.typeId === 'Term') extra += TermDetail(m, item);
  return V.KnowledgeSummary(m, item) + TermLinks(m, item) + extra;
}
function ActionBehavior(m, action) {
  const rules = E.actionRules(m, action.id), changes = action.objectChanges || [];
  return `<section class="v4-section"><div class="v4-section-title"><h2>行为、判断与结果</h2><span>动作自身修订 ${esc(action.version || 'draft')}</span></div><div class="v4-two-col"><div><h3>前置与输入</h3><p class="v4-longcopy">${esc((action.pre || []).join('；') || '待完善')}</p><p class="v4-longcopy">${esc((action.input || []).join(' · ') || '输入待完善')}</p><h3>使用规则</h3>${rules.map(({ rule }) => V.entityLink(m, rule.id)).join('') || '<p class="muted">无直接规则</p>'}</div><div><h3>输出与对象变化</h3><p class="v4-longcopy">${esc((action.output || []).join(' · ') || '输出待完善')}</p>${changes.map(change => `<div class="v4-notice green"><b>${esc(E.byId(m.objects, change.objectId)?.name || change.objectId)}</b><br>${esc(change.before)} → ${esc(change.after)}<br><small>${esc(change.constraint)}</small></div>`).join('')}</div></div>${action.referenceReviews && Object.keys(action.referenceReviews).length ? `<div class="v4-notice amber">引用规则已有新修订，本动作内容版本保持不变，但需要重新核验：${esc(JSON.stringify(action.referenceReviews))}</div>` : ''}</section>`;
}
function TermLinks(m, item) {
  const relations = [...K.outgoing(m, item.id, 'explains'), ...K.incoming(m, item.id, 'explains')];
  const terms = [...new Set(relations.map(relation => relation.from === item.id ? relation.to : relation.from))].map(id => K.getEntity(m, id)).filter(entry => entry?.typeId === 'Term');
  if (!terms.length) return '';
  return `<section class="v4-section"><div class="v4-section-title"><h2>文中项目概念</h2><span>无需离开当前上下文</span></div><div class="v4-actions">${terms.map(term => `<button class="v4-button small" data-term="${term.id}">${esc(term.name)} · 查看解释</button>`).join('')}</div></section>`;
}
function TermDetail(m, term) {
  const p = term.props || {};
  const sourceNames = p.nameSources || [];
  return `<section class="v4-section"><div class="v4-section-title"><h2>名称如何被使用</h2><span>同名不强制合并，异名可定位同一概念</span></div><div class="v4-two-col"><div><h3>同义 / 历史 / 缩写</h3><p class="v4-longcopy">${esc([...(p.synonyms || []), ...(p.historicalNames || []), ...(p.abbreviations || [])].join(' · ') || '无其他名称')}</p></div><div><h3>名称来源</h3>${sourceNames.map(source => `<div class="v4-notice blue"><b>${esc(source.name || source.alias)}</b><br>${esc(source.source || source.uri || '')}</div>`).join('') || '<p class="muted">尚未记录名称来源</p>'}</div></div>${(p.confusedWith || []).length ? `<h3>易混淆概念</h3>${p.confusedWith.map(id => V.entityLink(m, id)).join('')}` : ''}</section>`;
}
function VersionLayers(m) {
  const layers = m.versionLayers || {};
  return `<section class="v4-section"><div class="v4-section-title"><h2>项目版本层次</h2><span>不统一增长</span></div><dl class="v4-properties"><div class="v4-property"><dt>批准知识基线</dt><dd>${esc(layers.baseline || m.meta.version)}</dd></div><div class="v4-property"><dt>软件实现版本</dt><dd>${esc(layers.release || '未发布')}</dd></div><div class="v4-property"><dt>配置版本</dt><dd>${esc(layers.config || '未发布')}</dd></div><div class="v4-property"><dt>部署环境</dt><dd>${esc((layers.deployments || []).map(item => `${item.environment}: ${item.release} / ${item.config}`).join('；') || '未记录')}</dd></div></dl></section>`;
}
function showTerm(id) {
  const m = M(), term = K.getEntity(m, id); if (!term || term.typeId !== 'Term') return;
  const graph = K.relationsFor(m, id, { depth: 1 }), scenarios = graph.nodes.filter(item => item.typeId === 'Scenario'), resources = graph.nodes.filter(item => item.typeId === 'Resource');
  state.drawer = { title: '项目概念 · 保持原阅读位置', body: `<div class="v4-term-pop"><span class="v4-mono">${term.id}@${term.revision}</span><h2>${esc(term.name)}</h2><p>${esc(term.props?.shortDefinition || term.description)}</p></div><p class="v4-longcopy">${esc(term.description)}</p>${V.PropertyTable(m, term)}<section class="v4-section"><h3>法规与原始依据</h3>${resources.map(item => V.entityLink(m, item.id)).join('') || '<p class="muted">无直接资源关联</p>'}<h3>相关业务场景</h3>${scenarios.map(item => V.entityLink(m, item.id)).join('') || '<p class="muted">无直接场景关联</p>'}</section>`, foot: button('返回原内容', 'close') + button('打开完整术语', 'open-drawer-entity', 'primary', `data-id="${id}"`) };
  renderOverlay();
}

/* Workflow definitions and instances share one renderer */
function renderWork() {
  const m = M(), c = C();
  const tabs = [['workflow', '工作流实例'], ['changes', `知识变更 ${m.changes.length}`], ['issues', `问题确认 ${m.issues.filter(item => !['resolved', 'cancelled'].includes(item.status)).length}`], ['deliveries', `交接产物 ${m.deliveries.length}`]];
  return `${pageHead('协作与工作', '业务运行 / 知识治理 / 开发交付分别建模', '当前页面只呈现项目实际绑定的流程；Agent 是可选执行者，不是固定阶段。', button('＋ 新建工作流', 'new-workflow', 'primary') + button('创建工作流实例', 'new-workflow-instance'))}<div class="v4-workspace-tabs">${tabs.map(([id, label]) => `<button class="${c.workTab === id ? 'active' : ''}" data-work-tab="${id}">${esc(label)}</button>`).join('')}</div>${c.workTab === 'workflow' ? renderWorkflows() : c.workTab === 'changes' ? renderChanges() : c.workTab === 'issues' ? renderIssues() : renderDeliveries()}`;
}
function renderWorkflows() {
  const m = M(), c = C(), instances = m.workflowInstances || [];
  if (!instances.length) return `<section class="v4-section">${V.empty('尚未创建工作流实例', '先选择或定义适合当前项目的流程，再绑定真实业务对象。')}</section>`;
  let instance = instances.find(item => item.id === c.selectedInstanceId) || instances[0]; c.selectedInstanceId = instance.id;
  const def = instance.definitionSnapshot, stage = K.currentStage(instance), blockers = stage ? K.workflowBlockers(instance) : [];
  return `<div class="v4-workflow-layout"><aside class="v4-card v4-instance-list">${instances.map(item => `<button class="${item.id === instance.id ? 'active' : ''}" data-instance="${item.id}"><span class="v4-mono">${item.id}</span><b>${esc(item.definitionSnapshot.name)}</b><small>${esc(item.subjectId || '未绑定对象')}</small>${badge(statusName(item.status), statusTone(item.status))}</button>`).join('')}</aside><div><section class="v4-section"><div class="v4-section-title"><div><h2>${esc(def.name)}</h2><p>${esc(instance.id)} · 定义 ${esc(def.id)}@${esc(def.version)} · 对象 ${esc(instance.subjectId || '未绑定')}</p></div><div class="v4-actions">${button('编辑为新定义版本', 'edit-workflow', 'small', `data-id="${def.id}"`)}${instance.subjectId && K.getEntity(m, instance.subjectId) ? button('查看处理对象', 'open-instance-subject', 'small') : ''}</div></div>${V.WorkflowProgress(def, instance)}${stage ? `<div class="v4-current-activity"><div class="v4-eyebrow">当前可执行活动</div><h2>${esc(stage.name)}</h2><p>${esc(stage.description || '按定义完成本活动，并记录必要产物与确认。')}</p><dl><dt>责任角色</dt><dd>${esc(stage.role)}</dd><dt>活动要求</dt><dd>${stage.required === false ? '可选，可跳过' : '必需'}</dd><dt>进入条件</dt><dd>${esc(stage.entryWhen ? JSON.stringify(stage.entryWhen) : '无附加条件')}</dd><dt>完成条件</dt><dd>${esc(stage.completionWhen ? JSON.stringify(stage.completionWhen) : '活动完成')}</dd><dt>确认 / 产物</dt><dd>${esc([stage.confirmation ? stage.name : '', ...(stage.artifacts || [])].filter(Boolean).join(' · ') || '无强制要求')}</dd></dl>${renderWorkflowContext(def, stage, instance)}${blockers.length ? `<div class="v4-notice amber"><b>完成前仍需：</b>${blockers.map(esc).join('；')}</div><div class="v4-actions">${stage.confirmation && !instance.confirmations[stage.id] ? button('记录当前活动确认', 'confirm-workflow-stage', 'small') : ''}${(stage.artifacts || []).filter(id => !instance.artifacts[id]).map(id => button(`登记产物：${esc(id)}`, 'add-workflow-artifact', 'small', `data-artifact="${esc(id)}"`)).join('')}</div>` : '<div class="v4-notice green">当前活动的进入与完成条件已满足。</div>'}<div class="v4-actions">${button('完成并推进', 'advance-workflow', 'primary')}${stage.required === false ? button('跳过可选活动', 'skip-workflow') : ''}${button('按定义退回', 'return-workflow')}${button('生成业务交接包', 'generate-handoff')}</div></div>` : `<div class="v4-current-activity"><h2>工作流已完成</h2><p>实例仍固定引用 ${esc(def.id)}@${esc(def.version)}，定义后续变化不会污染执行历史。</p>${button('重新打开最后活动', 'reopen-workflow', 'primary')}</div>`}</section>${V.ReviewPanel(m, instance)}</div></div>`;
}
function renderWorkflowContext(def, stage, instance) {
  const conditions = [stage.returnWhen, ...def.stages.filter(item => item.id !== stage.id).map(item => item.entryWhen)].filter(Boolean);
  const fields = new Map(); conditions.forEach(condition => { if (condition.equals) fields.set(condition.equals.key, condition.equals.value); });
  if (!fields.size) return '';
  return `<div class="v4-sim-grid">${[...fields.entries()].map(([key, expected]) => `<label>条件上下文：${esc(key)}<input data-wf-context="${esc(key)}" value="${esc(instance.context?.[key] || '')}" placeholder="例如 ${esc(expected)}"></label>`).join('')}</div><p class="muted">这些值仅作为当前实例的条件输入，执行记录保留实际转移。</p>`;
}
function openWorkflowEditor(def) {
  state.workflowDraft = def ? clone(def) : { id: null, name: '', purpose: 'delivery', version: 'v1', stages: [{ id: 'stage-1', name: '', role: '', required: true, returnTo: null, artifacts: [], confirmation: false }] };
  state.modal = { type: 'workflow-editor', wide: true, title: def ? `编辑工作流并生成新定义版本 · ${def.id}` : '创建项目工作流', body: renderWorkflowEditor(), foot: button('取消', 'close') + button('保存定义', 'save-workflow', 'primary') + button('保存并创建实例', 'save-run-workflow', 'primary') };
  renderOverlay();
}
function renderWorkflowEditor() {
  const draft = state.workflowDraft, m = M();
  return `<div class="v4-two-col"><div class="v4-field"><label>工作流名称 *</label><input data-wf-meta="name" value="${esc(draft.name)}"></div><div class="v4-field"><label>用途</label><select data-wf-meta="purpose">${[['delivery', '开发交付'], ['governance', '知识治理'], ['business', '业务运行'], ['case', '案件处理']].map(([id, name]) => `<option value="${id}" ${draft.purpose === id ? 'selected' : ''}>${name}</option>`).join('')}</select></div></div><div class="v4-notice blue">活动、角色、顺序、可选性、进入 / 完成条件、确认、产物和退回都来自定义。已有实例继续引用自己的定义快照。</div><div id="workflow-stage-list">${draft.stages.map((stage, index) => `<div class="v4-stage-editor" data-wf-stage="${stage.id}"><div class="v4-stage-editor-head"><b>活动 ${index + 1}</b><div class="v4-actions"><button class="v4-inline-link" data-wf-move="up" data-index="${index}">上移</button><button class="v4-inline-link" data-wf-move="down" data-index="${index}">下移</button><button class="v4-inline-link" data-wf-remove="${index}">删除</button></div></div><div class="v4-stage-editor-grid"><div class="v4-field"><label>活动名称 *</label><input data-wf-field="name" value="${esc(stage.name)}"></div><div class="v4-field"><label>责任角色 *</label><input data-wf-field="role" value="${esc(stage.role)}" placeholder="由项目定义，不限定 Agent"></div><div class="v4-field"><label>必需性</label><select data-wf-field="required"><option value="true" ${stage.required !== false ? 'selected' : ''}>必需</option><option value="false" ${stage.required === false ? 'selected' : ''}>可选</option></select></div><div class="v4-field"><label>退回目标</label><select data-wf-field="returnTo"><option value="">默认上一活动</option>${draft.stages.filter(candidate => candidate.id !== stage.id).map(candidate => `<option value="${candidate.id}" ${stage.returnTo === candidate.id ? 'selected' : ''}>${esc(candidate.name || candidate.id)}</option>`).join('')}</select></div></div><div class="v4-three-col"><div class="v4-field"><label>必需产物（顿号分隔）</label><input data-wf-field="artifacts" value="${esc((stage.artifacts || []).join('、'))}"></div><div class="v4-field"><label>进入条件（如 risk=high）</label><input data-wf-field="entry" value="${esc(stage.entryWhen?.equals ? `${stage.entryWhen.equals.key}=${stage.entryWhen.equals.value}` : '')}"></div><div class="v4-field"><label>退回条件（如 result=fail）</label><input data-wf-field="return" value="${esc(stage.returnWhen?.equals ? `${stage.returnWhen.equals.key}=${stage.returnWhen.equals.value}` : '')}"></div></div><label class="v4-checkbox"><input type="checkbox" data-wf-field="confirmation" ${stage.confirmation ? 'checked' : ''}> 完成前需要责任角色确认</label></div>`).join('')}</div>${button('＋ 添加活动', 'workflow-add-stage', 'small')}<div class="v4-field" style="margin-top:16px"><label>实例绑定对象 ID（保存并运行时填写）</label><input id="workflow-subject" value="${esc(m.scenarios[0]?.id || m.meta.id)}" placeholder="需求、案件、质量异常或其他知识对象"></div>`;
}
function readWorkflowEditor() {
  const draft = state.workflowDraft;
  $$('[data-wf-meta]').forEach(input => { draft[input.dataset.wfMeta] = input.value; });
  $$('[data-wf-stage]').forEach(row => {
    const stage = draft.stages.find(item => item.id === row.dataset.wfStage); if (!stage) return;
    $$('[data-wf-field]', row).forEach(input => {
      const key = input.dataset.wfField;
      if (key === 'required') stage.required = input.value === 'true';
      else if (key === 'confirmation') stage.confirmation = input.checked;
      else if (key === 'returnTo') stage.returnTo = input.value || null;
      else if (key === 'artifacts') stage.artifacts = input.value.split(/[、,，]/).map(item => item.trim()).filter(Boolean);
      else if (key === 'entry' || key === 'return') { const [keyName, value] = input.value.split('='); stage[key === 'entry' ? 'entryWhen' : 'returnWhen'] = keyName && value ? { equals: { key: keyName.trim(), value: value.trim() } } : null; }
      else stage[key] = input.value;
    });
  });
}
function saveWorkflow(run) {
  readWorkflowEditor(); const draft = state.workflowDraft, m = M();
  if (!draft.name.trim() || !draft.stages.length || draft.stages.some(stage => !stage.name.trim() || !stage.role.trim())) { toast('请填写工作流名称及每个活动的名称、责任角色', 'error'); return; }
  try {
    let def;
    if (draft.id) {
      const old = m.workflowDefinitions.find(item => item.id === draft.id);
      def = K.workflowDefinition({ ...draft, version: `v${Number(String(old.version).replace(/\D/g, '')) + 1 || 2}` });
      m.workflowDefinitions.push(def);
    } else def = K.createWorkflow(m, { ...draft, id: `WFD-${m.meta.id}-${String(m.workflowDefinitions.length + 1).padStart(3, '0')}`, projectId: m.meta.id });
    if (run) { const instance = K.instantiateWorkflow(m, def.id, { subjectId: $('#workflow-subject')?.value.trim() || null }); C().selectedInstanceId = instance.id; }
    C().workTab = 'workflow'; save(); closeOverlays(); render(); toast(run ? '工作流定义已保存，实例已按固定版本创建' : '工作流定义已保存');
  } catch (error) { toast(error.message, 'error'); }
}

/* Knowledge governance: isolated drafts and immutable published versions */
function renderChanges() {
  const m = M(), c = C(), changes = m.changes || [];
  if (!changes.length) return `<section class="v4-section">${V.empty('没有知识变更', '从任意规则提出修改，草稿与已发布定义保持隔离。')}</section>`;
  const change = changes.find(item => item.id === c.selectedChangeId) || changes[0]; c.selectedChangeId = change.id;
  if (!change.ruleId) return `<section class="v4-section"><h2>${esc(change.title)}</h2><p class="v4-longcopy">${esc(change.reason || '非规则对象沿用 V3 独立快照，可从原对象继续维护。')}</p><div class="v4-notice blue">${esc(change.objectType)}:${esc(change.objectId)}@${esc(change.baseVersion)} → ${esc(change.targetVersion)} · ${esc(statusName(change.status))}</div></section>`;
  const rule = E.byId(m.rules, change.ruleId), base = rule?.versions?.[change.baseVersion], draft = change.draftRule, diffs = base && draft ? E.compareRuleVersions(base, draft) : [];
  return `<div class="v4-change-layout"><aside class="v4-card v4-change-list">${changes.map(item => `<button class="${item.id === change.id ? 'active' : ''}" data-change="${item.id}"><span class="v4-mono">${item.id}</span><b>${esc(item.title)}</b><small>${esc(item.ruleId || item.objectId)}@${esc(item.baseVersion || 'draft')}</small>${badge(statusName(item.status), statusTone(item.status))}</button>`).join('')}</aside><div><section class="v4-section"><div class="v4-section-title"><div><h2>${esc(change.title)}</h2><p>${esc(change.id)} · ${esc(change.ruleId)}@${esc(change.baseVersion || 'draft')} → ${esc(change.targetVersion)}</p></div>${badge(statusName(change.status), statusTone(change.status))}</div><div class="v4-diff"><div class="v4-diff-before"><b>已发布定义（只读）</b><br>${esc(base?.summary || '首次发布前无正式定义')}</div><div class="v4-diff-after"><b>独立草稿</b><br>${esc(draft?.summary || '尚未建立草稿')}</div></div><div class="v4-actions" style="margin-top:15px">${change.status === 'draft' ? button(draft ? '继续编辑草稿' : '创建修改草稿', 'edit-rule-change', 'primary') : ''}${change.status === 'draft' ? button('提交审批', 'submit-change') : ''}${change.status === 'pending' ? button('批准并发布新修订', 'approve-change') : ''}${change.ruleId ? button('查看规则', 'open-change-rule', 'small') : ''}</div></section><section class="v4-section"><div class="v4-section-title"><h2>影响确认</h2><span>定位影响，不无条件升级关联对象版本</span></div><div class="v4-check-grid">${Object.entries(change.checks || {}).map(([key, checked]) => `<label><input type="checkbox" data-change-check="${key}" ${checked ? 'checked' : ''} ${change.status !== 'draft' ? 'disabled' : ''}> ${esc({ actions: '相关动作已检查', scenarios: '业务场景已检查', acceptance: '验收影响已检查', technical: '技术映射已检查' }[key] || key)}</label>`).join('')}</div>${diffs.length ? `<h3>行为差异 ${diffs.filter(item => item.changed).length} / ${diffs.length}</h3><p class="v4-longcopy">${esc(diffs.filter(item => item.changed).slice(0, 5).map(item => `${JSON.stringify(item.values)}：${item.before} → ${item.after}`).join('\n') || '相同输入下没有行为变化')}</p>` : ''}${changeIssues(m, change)}</section></div></div>`;
}
function changeIssues(m, change) {
  const issues = m.issues.filter(item => item.changeId === change.id && !['resolved', 'cancelled'].includes(item.status));
  return issues.length ? `<div class="v4-notice amber"><b>关联确认问题</b>${issues.map(issue => `<button class="v4-concern" data-issue="${issue.id}">${esc(issue.title)} · ${issue.decision ? '已有结论' : '待形成结论'}</button>`).join('')}</div>` : '';
}
function newRuleChange(ruleId) {
  const m = M(), rule = E.byId(m.rules, ruleId); if (!rule) return;
  let change = m.changes.find(item => item.ruleId === ruleId && item.status === 'draft' && !m.issues.some(issue => issue.changeId === item.id && !issue.decision));
  if (!change) {
    const baseVersion = rule.currentVersion;
    change = { id: AtlasModel.nextId(m, 'CHG'), title: `修改${rule.name}`, ruleId, baseVersion, targetVersion: E.nextVersion(baseVersion), status: 'draft', reason: '', draftRule: null, checks: { actions: false, scenarios: false, acceptance: false, technical: false }, history: [{ at: new Date().toISOString(), by: '当前用户', text: '从规则阅读上下文创建变更' }] };
    m.changes.push(change);
  }
  C().selectedChangeId = change.id; C().workTab = 'changes'; save(); go('work');
}
function openRuleChangeEditor() {
  const m = M(), change = m.changes.find(item => item.id === C().selectedChangeId), rule = E.byId(m.rules, change.ruleId);
  if (change.status !== 'draft') { toast('待审批或已发布变更已锁定', 'error'); return; }
  if (!change.draftRule) { change.draftRule = clone(rule.versions[change.baseVersion] || rule.versions.draft); change.draftRule.version = change.targetVersion; change.draftRule.status = 'draft'; change.draftRule.effective = '批准后生效'; }
  const draft = change.draftRule;
  state.drawer = { type: 'rule-change', wide: true, title: `独立规则草稿 · ${change.ruleId}@${change.targetVersion}`, body: `<div class="v4-notice blue">当前已发布 ${esc(change.baseVersion)} 保持只读；保存只写入 ${esc(change.id)}。</div><div class="v4-field"><label>变更原因 *</label><textarea id="change-reason">${esc(change.reason)}</textarea></div><div class="v4-field"><label>适用范围</label><textarea id="change-scope">${esc(draft.scope || '')}</textarea></div>${draft.supportsEvaluation === false ? `<div class="v4-field"><label>人工核验约束</label><textarea id="change-constraint">${esc(draft.constraint || '')}</textarea></div>` : `<h3>结构化决策行</h3><div class="v4-table-wrap"><table class="v4-table"><thead><tr><th>决策行</th><th>条件</th><th>新结果</th></tr></thead><tbody>${draft.rows.map(row => `<tr data-draft-row="${row.id}"><td>${esc(row.id)} · ${row.priority}</td><td>${esc(E.describeWhen(draft, row.when))}</td><td><select data-draft-outcome>${draft.outcomes.map(outcome => `<option value="${outcome.id}" ${row.outcomeId === outcome.id ? 'selected' : ''}>${esc(outcome.label)}</option>`).join('')}</select></td></tr>`).join('')}</tbody></table></div>`}<div id="change-validation" class="v4-notice blue">保存时重新生成摘要并检查冲突、无效引用和覆盖情况。</div>`, foot: button('取消', 'close') + button('保存独立草稿', 'save-rule-change', 'primary') };
  renderOverlay();
}
function saveRuleChange() {
  const m = M(), change = m.changes.find(item => item.id === C().selectedChangeId), draft = change.draftRule;
  const reason = $('#change-reason').value.trim(); if (!reason) { toast('变更原因不能为空', 'error'); return; }
  change.reason = reason; draft.scope = $('#change-scope').value.trim();
  if ($('#change-constraint')) draft.constraint = $('#change-constraint').value.trim();
  $$('[data-draft-row]').forEach(row => { draft.rows.find(item => item.id === row.dataset.draftRow).outcomeId = $('[data-draft-outcome]', row).value; });
  draft.summary = E.summarizeRule(draft); change.history.push({ at: new Date().toISOString(), by: '当前用户', text: '保存独立结构化草稿' });
  save(); closeOverlays(); render(); toast('草稿已保存，已发布定义未改变');
}
function renderIssues() {
  const m = M();
  return `<section class="v4-section"><div class="v4-section-title"><h2>围绕知识对象的问题与确认</h2><span>回复不等于批准</span></div>${m.issues.map(issue => `<button class="v4-concern" data-issue="${issue.id}"><b>${esc(issue.title)}</b><small>${esc(issue.objectId)} · ${esc(statusName(issue.status))} · ${issue.replies?.length || 0} 条回复</small></button>`).join('') || V.empty('没有待处理问题', '从任意知识对象发起提问或澄清。')}</section>`;
}
function showIssue(id) {
  const m = M(), issue = E.byId(m.issues, id); if (!issue) return;
  state.drawer = { type: 'issue', id, title: `${issue.id} · ${statusName(issue.status)}`, body: `<h2>${esc(issue.title)}</h2><p class="v4-longcopy">${esc(issue.why || '')}</p><div class="v4-notice blue">知识对象：${V.entityLink(m, issue.objectId)}<br>关联变更：${esc(issue.changeId || '无')}</div><h3>回复与决定</h3>${(issue.replies || []).map(reply => `<div class="v4-notice blue"><b>${esc(reply.by)}</b><p>${esc(reply.text)}</p></div>`).join('')}${issue.decision ? `<div class="v4-notice green"><b>业务结论</b><p>${esc(issue.decision)}</p></div>` : ''}<div class="v4-field"><label>补充回复或明确结论</label><textarea id="issue-text"></textarea></div>`, foot: button('定位知识对象', 'open-issue-object') + button('仅回复', 'reply-issue') + button('形成业务结论', 'decide-issue', 'primary') };
  renderOverlay();
}
function renderDeliveries() {
  const m = M();
  return `<section class="v4-section"><div class="v4-section-title"><div><h2>结构化交接产物</h2><p>由工作流按需产生；即使不用 Agent 也保留相同业务约束</p></div></div>${m.deliveries.map(delivery => `<article class="v4-card v4-card-pad" style="margin-bottom:12px"><div class="v4-section-title"><div><h3>${esc(delivery.id)} · ${esc(delivery.requirementId || delivery.subjectId || '')}</h3><p>${esc(delivery.packageVersion || '尚未形成正式包')}</p></div>${badge(delivery.packageVersion ? '不可变快照' : '草稿', delivery.packageVersion ? 'green' : 'amber')}</div><div class="v4-two-col"><div><b>固定知识版本</b><p>${esc(delivery.ruleId || '')}@${esc(delivery.ruleVersion || '')}</p><p>场景 ${esc(delivery.scenarioId || delivery.subjectId || '')}</p></div><div><b>快照状态</b><p>${delivery.snapshot ? '已保存独立内容，不受后续发布污染' : '尚未生成；不会伪称已交接'}</p></div></div>${delivery.snapshot ? `<details><summary>查看快照中的规则定义</summary><pre class="v4-json">${esc(JSON.stringify(delivery.snapshot.rule || delivery.snapshot, null, 2))}</pre></details>` : ''}</article>`).join('') || V.empty('没有交接产物', '在工作流需要时生成，不预设固定六阶段。')}</section>`;
}

/* Administration: schema, resources, health, workspace and adapter contracts */
function renderAdmin() {
  const c = C(), tabs = [['health', '知识健康'], ['schemas', '知识类型'], ['resources', '原始资料'], ['settings', '项目配置'], ['versions', '版本层次']];
  return `${pageHead('知识与项目配置', 'SCHEMA · WORKSPACE · SOURCE · REVISION', '治理集中处理缺失与冲突；正常阅读仍从对象内嵌来源进入。', button('＋ 注册知识类型', 'new-schema', 'primary') + button('＋ 新建知识对象', 'new-entity'))}<div class="v4-workspace-tabs">${tabs.map(([id, name]) => `<button class="${c.adminTab === id ? 'active' : ''}" data-admin-tab="${id}">${name}</button>`).join('')}</div>${c.adminTab === 'health' ? renderHealth() : c.adminTab === 'schemas' ? renderSchemas() : c.adminTab === 'resources' ? renderResources() : c.adminTab === 'settings' ? renderSettings() : VersionLayers(M())}`;
}
function renderHealth() {
  const m = M(), h = K.health(m), validation = E.validateProject(m), sourcePercent = h.modeled ? Math.round((h.modeled - h.missingSources.length) / h.modeled * 100) : 0, relationPercent = h.totalRelations ? Math.round(h.confirmedRelations / h.totalRelations * 100) : 0;
  return `<div class="v4-health-grid"><div><small>已建模知识</small><b>${h.modeled}</b><small>不代表事实已全部确认</small><div class="v4-meter"><i style="width:${Math.min(100, h.modeled * 2)}%"></i></div></div><div><small>具备来源</small><b>${sourcePercent}%</b><small>${h.missingSources.length} 个对象待补来源</small><div class="v4-meter"><i style="width:${sourcePercent}%"></i></div></div><div><small>关系已核验</small><b>${relationPercent}%</b><small>${h.inferredRelations.length} 条推断或待核验</small><div class="v4-meter"><i style="width:${relationPercent}%"></i></div></div><div><small>原始资料</small><b>${h.resources}</b><small>${h.unparsedResources} 份尚未完全结构化</small></div></div><section class="v4-section" style="margin-top:18px"><div class="v4-section-title"><h2>可重复一致性检查</h2>${button('重新运行', 'run-validation', 'primary')}</div><div class="v4-notice ${validation.ok ? 'green' : 'red'}">${validation.ok ? '✓ ID、流程引用、规则版本、关系端点与交接快照检查通过。' : validation.errors.map(esc).join('；')}${validation.warnings.length ? `<br>${validation.warnings.map(esc).join('；')}` : ''}</div><h3>待补来源对象</h3><p class="v4-longcopy">${esc(h.missingSources.slice(0, 30).join(' · ') || '没有缺失')}</p><h3>待核验关系</h3><p class="v4-longcopy">${esc(h.inferredRelations.slice(0, 30).join(' · ') || '没有待核验关系')}</p></section>`;
}
function renderSchemas() {
  const m = M(), schemas = Object.values(m.schemaRegistry || {}), used = new Set(K.allEntities(m).map(item => item.typeId));
  return `<section class="v4-section"><div class="v4-section-title"><div><h2>项目 Schema Registry</h2><p>字段具有数据类型、必填校验、引用与权限；行业扩展无需新页面</p></div></div><div class="v4-schema-grid">${schemas.filter(schema => used.has(schema.id) || schema.custom).map(schema => `<article class="v4-schema-card"><span class="v4-mono">${esc(schema.id)}@schema-v${schema.version}</span><h3>${esc(schema.name)}</h3><p>${esc(schema.dimension)} · ${schema.fields.length} 个字段<br>${schema.fields.slice(0, 5).map(field => `${field.label}:${field.dataType}${field.required ? '*' : ''}`).join(' · ')}</p><footer>${badge(schema.custom ? '项目扩展' : '核心语义', schema.custom ? 'purple' : 'blue')}<button class="v4-inline-link" data-new-entity-type="${schema.id}">＋ 创建实例</button></footer></article>`).join('')}</div></section>`;
}
function renderResources() {
  const m = M(), resources = (m.knowledge || []).filter(item => item.typeId === 'Resource');
  return `<section class="v4-section"><div class="v4-section-title"><div><h2>原始知识资产</h2><p>原始资料与从资料提炼的结构化结论分开保存</p></div>${button('登记原始资料', 'new-resource', 'primary')}</div>${resources.map(item => `<button class="v4-concern" data-entity="${item.id}"><b>${esc(item.name)} · ${esc(item.props?.resourceType || '')}</b><small>${esc(item.props?.uri || '')}<br>${esc(item.props?.sourceVersion || '')} · ${esc(item.props?.parseStatus || '')}</small></button>`).join('') || V.empty('尚未登记原始资料', '可登记文件、外部链接、配置键、API 路径或测试记录。')}</section>`;
}
function renderSettings() {
  const m = M(), sections = [['intro', '项目概述'], ['business', '业务入口'], ['systems', '系统入口'], ['assets', '术语与资料'], ['concerns', '当前关注']];
  return `<div class="v4-two-col"><section class="v4-section"><div class="v4-section-title"><h2>首页内容组合</h2><span>保存布局配置，不修改 JS</span></div>${sections.map(([id, name]) => `<label class="v4-checkbox"><input type="checkbox" data-home-section="${id}" ${C().homeSections.includes(id) ? 'checked' : ''}> ${name}</label>`).join('')}<div class="v4-notice blue">没有数据的内容即使启用也会自然收缩，不展示空白拓扑或虚构指标。</div></section><section class="v4-section"><div class="v4-section-title"><h2>角色阅读路径</h2><span>可配置导航，不是工作流</span></div>${(m.workspace.readingPaths || []).map(path => `<div class="v4-notice blue"><b>${esc(path.name)}</b><p>${esc(path.steps.map(step => step.label).join(' → '))}</p></div>`).join('') || '<p class="muted">尚未配置阅读路径。</p>'}<h3>治理策略</h3><p class="v4-longcopy">${esc(JSON.stringify(m.governancePolicy || {}, null, 2))}</p></section></div>`;
}
function newSchemaModal() {
  state.modal = { title: '注册项目知识类型', body: `<div class="v4-field"><label>类型名称 *</label><input id="schema-name" placeholder="例如：生产批次"></div><div class="v4-field"><label>稳定类型 ID *</label><input id="schema-id" placeholder="例如：ProductionBatch（英文，不改核心代码）"></div><div class="v4-field"><label>知识维度</label><input id="schema-dimension" value="项目扩展"></div><div class="v4-field"><label>扩展字段（每行：字段ID|显示名|类型|是否必填）</label><textarea id="schema-fields" placeholder="batchNo|批次号|text|required&#10;quantity|数量|number&#10;released|已放行|boolean"></textarea><small>支持 ${K.PROPERTY_TYPES.join('、')}。名称与定义字段由核心语法提供；枚举可在第五段用逗号填写候选值。</small></div>`, foot: button('取消', 'close') + button('注册类型', 'save-schema', 'primary') };
  renderOverlay();
}
function saveSchema() {
  const name = $('#schema-name').value.trim(), id = $('#schema-id').value.trim();
  try {
    const fields = $('#schema-fields').value.split('\n').map(line => line.trim()).filter(Boolean).map(line => {
      const [fieldId, label, dataType = 'text', required, enumValues] = line.split('|').map(value => value.trim());
      return { id: fieldId, label, dataType, required: required === 'required', ...(dataType === 'enum' ? { options: enumValues ? enumValues.split(/[、,，]/).map(item => item.trim()).filter(Boolean) : ['待定'] } : {}) };
    });
    const schema = K.registerType(M(), { id, name, dimension: $('#schema-dimension').value.trim(), fields }); save(); closeOverlays(); C().adminTab = 'schemas'; render(); toast(`${schema.name} 已注册，可直接创建并用通用视图阅读`);
  } catch (error) { toast(error.message, 'error'); }
}
function fieldControl(definition, value = '') {
  const id = `prop-${definition.id}`, label = esc(definition.label), val = value ?? (definition.dataType === 'boolean' ? false : definition.dataType === 'json' || definition.dataType === 'refs' ? [] : '');
  if (definition.dataType === 'boolean') return `<label class="v4-checkbox"><input type="checkbox" id="${id}" data-entity-prop="${definition.id}" ${val ? 'checked' : ''}> ${label}${definition.required ? ' *' : ''}</label>`;
  if (definition.dataType === 'enum') return `<div class="v4-field"><label>${label}${definition.required ? ' *' : ''}</label><select id="${id}" data-entity-prop="${definition.id}"><option value="">请选择</option>${(definition.options || []).map(option => { const optionValue = typeof option === 'object' ? option.value : option, optionLabel = typeof option === 'object' ? option.label : option; return `<option value="${esc(optionValue)}" ${val === optionValue ? 'selected' : ''}>${esc(optionLabel)}</option>`; }).join('')}</select></div>`;
  if (['longtext', 'json', 'refs'].includes(definition.dataType)) return `<div class="v4-field"><label>${label}${definition.required ? ' *' : ''}</label><textarea id="${id}" data-entity-prop="${definition.id}" placeholder="${definition.dataType === 'refs' ? '对象 ID，用顿号分隔' : definition.dataType === 'json' ? 'JSON 或每行一项' : ''}">${esc(typeof val === 'object' ? JSON.stringify(val, null, 2) : val)}</textarea></div>`;
  return `<div class="v4-field"><label>${label}${definition.required ? ' *' : ''}</label><input id="${id}" data-entity-prop="${definition.id}" type="${definition.dataType === 'number' || definition.dataType === 'money' ? 'number' : definition.dataType === 'date' ? 'date' : 'text'}" value="${esc(val)}" placeholder="${esc(definition.dataType)}"></div>`;
}
function newEntityModal(typeId, existing) {
  const m = M(), schema = K.schemaFor(m, typeId), item = existing ? K.getEntity(m, existing) : null;
  if (!schema) { toast('请先注册知识类型', 'error'); return; }
  const customFields = schema.fields.filter(field => !['name', 'description'].includes(field.id));
  state.modal = { type: 'entity-editor', entityId: existing || null, title: `${item ? '编辑' : '创建'}${schema.name}`, body: `<div class="v4-two-col"><div class="v4-field"><label>稳定 ID *</label><input id="entity-id" value="${esc(item?.id || `${typeId.toUpperCase()}-${String((m.knowledge?.length || 0) + 1).padStart(3, '0')}`)}" ${item ? 'disabled' : ''}></div><div class="v4-field"><label>名称 *</label><input id="entity-name" value="${esc(item?.name || '')}"></div></div><div class="v4-field"><label>定义</label><textarea id="entity-description">${esc(item?.description || '')}</textarea></div><div class="v4-two-col">${customFields.map(field => fieldControl(field, item?.props?.[field.id])).join('')}</div><div class="v4-two-col"><div class="v4-field"><label>敏感级别</label><select id="entity-sensitivity">${['public', 'internal', 'sensitive', 'restricted'].map(level => `<option value="${level}" ${item?.sensitivity === level ? 'selected' : ''}>${level}</option>`).join('')}</select></div><div class="v4-field"><label>状态</label><select id="entity-status"><option value="draft" ${item?.status === 'draft' ? 'selected' : ''}>草稿</option><option value="published" ${item?.status === 'published' ? 'selected' : ''}>已确认发布</option></select></div></div><div class="v4-notice blue">保存后由同一个 Entity Detail、Relation Explorer 和 Evidence Inspector 展示，不创建专用页面。</div>`, foot: button('取消', 'close') + button(item ? '保存新修订' : '创建对象', 'save-entity', 'primary', `data-type="${typeId}"`) };
  renderOverlay();
}
function readEntityProps(schema) {
  const props = {};
  schema.fields.filter(field => !['name', 'description'].includes(field.id)).forEach(field => {
    const input = $(`[data-entity-prop="${field.id}"]`); if (!input) return;
    if (field.dataType === 'boolean') props[field.id] = input.checked;
    else if (['number', 'money', 'duration', 'unit'].includes(field.dataType)) props[field.id] = input.value === '' ? null : Number(input.value);
    else if (field.dataType === 'refs') props[field.id] = input.value.split(/[、,，\n]/).map(item => item.trim()).filter(Boolean);
    else if (field.dataType === 'json') { const text = input.value.trim(); if (!text) props[field.id] = []; else { try { props[field.id] = JSON.parse(text); } catch (_) { props[field.id] = text.split('\n').map(item => item.trim()).filter(Boolean); } } }
    else props[field.id] = input.value.trim();
  });
  return props;
}
function saveEntity(typeId) {
  const m = M(), id = $('#entity-id').value.trim(), data = { id, name: $('#entity-name').value.trim(), description: $('#entity-description').value.trim(), props: readEntityProps(K.schemaFor(m, typeId)), sensitivity: $('#entity-sensitivity').value, status: $('#entity-status').value, governance: { state: $('#entity-status').value === 'published' ? 'confirmed' : 'draft', owner: '当前用户' } };
  try {
    const item = state.modal.entityId ? K.updateEntity(m, state.modal.entityId, data, K.getEntity(m, state.modal.entityId).revision) : K.createEntity(m, typeId, data);
    save(); closeOverlays(); openEntity(item.id); toast(`${item.id}@${item.revision} 已保存`);
  } catch (error) { toast(error.message, 'error'); }
}

/* Overlay, search, source-aware navigation and generic query contract */
function modal(title, body, foot = '', wide = false, type = null) { state.modal = { title, body, foot, wide, type }; renderOverlay(); }
function closeOverlays() { state.modal = null; state.drawer = null; state.workflowDraft = null; renderOverlay(); }
function renderOverlay() {
  let html = '';
  if (state.modal) html += `<div class="v4-overlay" data-action="overlay-bg"><section class="v4-modal ${state.modal.wide ? 'wide' : ''}"><header class="v4-modal-head"><h2>${esc(state.modal.title)}</h2><button class="v4-close" data-action="close">×</button></header><div class="v4-modal-body">${state.modal.body}</div>${state.modal.foot ? `<footer class="v4-modal-foot">${state.modal.foot}</footer>` : ''}</section></div>`;
  if (state.drawer) html += `<div class="v4-drawer-overlay" data-action="close"></div><aside class="v4-drawer ${state.drawer.wide ? 'wide' : ''}"><header class="v4-modal-head"><h2>${esc(state.drawer.title)}</h2><button class="v4-close" data-action="close">×</button></header><div class="v4-modal-body">${state.drawer.body}</div>${state.drawer.foot ? `<footer class="v4-modal-foot">${state.drawer.foot}</footer>` : ''}</aside>`;
  $('#overlay-root').innerHTML = html;
}
function globalSearch(query) {
  const q = query.toLowerCase(), items = catalogEntities().filter(item => `${item.id}${item.name}${item.description || ''}${item.aliases || ''}${item.props?.synonyms || ''}${item.props?.historicalNames || ''}`.toLowerCase().includes(q)).slice(0, 15);
  modal('搜索当前项目知识', `<div class="v4-field"><input id="search-modal-input" value="${esc(query)}" placeholder="名称、别名、历史名称或稳定 ID"></div><div>${items.map(item => `<button class="v4-search-result" data-entity="${item.id}"><span>${esc(item.name[0])}</span><div><b>${esc(item.name)}</b><small>${esc(typeName(item))} · ${esc(item.id)} · ${esc(item.description || '')}</small></div></button>`).join('') || V.empty('没有匹配结果', '尝试术语别名、历史名称或完整稳定 ID。')}</div>`, '', true);
}
function agentContext(id) {
  const item = K.getEntity(M(), id || state.entityId) || M().rules[0] || M().knowledge[0];
  state.drawer = { title: '通用知识查询契约（MCP 接口预留）', body: `<div class="v4-notice blue">不实现真实 MCP。内部查询已支持项目、对象、版本、深度、视角与权限上下文，不局限于审批字段。</div><div class="v4-field"><label>对象 ID</label><input id="query-id" value="${esc(item?.id || '')}"></div><div class="v4-two-col"><div class="v4-field"><label>指定版本（留空为当前）</label><input id="query-version" placeholder="v2.4 或 r1"></div><div class="v4-field"><label>关系深度</label><select id="query-depth"><option>1</option><option>2</option><option>3</option></select></div></div><div class="v4-two-col"><div class="v4-field"><label>查询视角</label><select id="query-view"><option value="all">全部可见关系</option><option value="approved">仅已确认</option></select></div><div class="v4-field"><label>权限上下文</label><select id="query-role"><option value="reader">reader / internal</option><option value="external">external / public</option></select></div></div><div id="query-result"></div>`, foot: button('执行结构化查询', 'run-agent-query', 'primary') };
  renderOverlay();
}
function runAgentQuery() {
  const role = $('#query-role').value, result = K.queryKnowledge(M(), { id: $('#query-id').value.trim(), version: $('#query-version').value.trim() || undefined, depth: Number($('#query-depth').value), view: $('#query-view').value, permission: role === 'external' ? { role: 'external', clearance: 'public' } : { role: 'reader', clearance: 'internal' } });
  $('#query-result').innerHTML = result.ok ? `<div class="v4-notice green">返回 ${result.nodes.length} 个对象与 ${result.relations.length} 条关系</div><pre class="v4-json">${esc(JSON.stringify(result, null, 2))}</pre>` : `<div class="v4-notice red">${esc(result.code)} · ${esc(result.error)}</div>`;
}

/* Creation helpers for the fifth-project path */
function addDomainModal() { modal('添加业务领域', `<div class="v4-field"><label>领域名称 *</label><input id="domain-name"></div><div class="v4-field"><label>职责与业务贡献</label><textarea id="domain-description"></textarea></div>`, button('取消', 'close') + button('添加领域', 'save-domain', 'primary')); }
function addScenarioModal() { modal('创建业务场景', `<div class="v4-field"><label>场景名称 *</label><input id="scenario-name"></div><div class="v4-field"><label>业务目标</label><textarea id="scenario-goal"></textarea></div><div class="v4-two-col"><div class="v4-field"><label>主要表达模式</label><select id="scenario-mode"><option value="flow">流程型</option><option value="case">案件型</option><option value="state">状态驱动</option><option value="decision">决策驱动</option><option value="knowledge">知识与结构</option></select></div><div class="v4-field"><label>所属领域</label><select id="scenario-domain">${M().domains.map(domain => `<option value="${domain.id}">${esc(domain.name)}</option>`).join('')}</select></div></div><div class="v4-field"><label>触发或适用上下文（可不填）</label><input id="scenario-trigger"></div><div class="v4-field"><label>期望结果（可不填）</label><textarea id="scenario-result"></textarea></div><div class="v4-notice blue">参与者、固定步骤和审批结果都不是创建场景的必填项。</div>`, button('取消', 'close') + button('创建场景', 'save-scenario', 'primary')); }
function addActionModal(scenarioId) { modal('添加业务动作', `<div class="v4-field"><label>动作名称 *</label><input id="action-name"></div><div class="v4-field"><label>业务目的</label><textarea id="action-purpose"></textarea></div><div class="v4-field"><label>责任角色（可后补）</label><input id="action-actor"></div>`, button('取消', 'close') + button('创建动作', 'save-action', 'primary', `data-id="${scenarioId}"`)); }
function newRuleModal() {
  const related = state.entityId || M().scenarios[0]?.id || '';
  modal('创建业务规则', `<div class="v4-field"><label>规则名称 *</label><input id="new-rule-name"></div><div class="v4-field"><label>适用范围</label><textarea id="new-rule-scope"></textarea></div><div class="v4-field"><label>人工核验约束</label><textarea id="new-rule-constraint" placeholder="第五项目可先建立人工约束，再在以后修订中结构化"></textarea></div><div class="v4-field"><label>关联知识对象 ID（可选）</label><input id="new-rule-related" value="${esc(related)}"></div><div class="v4-notice blue">规则以独立草稿创建；通过 uses 关系连接场景或动作，不写入页面源码。</div>`, button('取消', 'close') + button('创建规则', 'save-new-rule', 'primary'));
}
function newResourceModal() { modal('登记原始知识资料', `<div class="v4-field"><label>资料名称 *</label><input id="resource-name"></div><div class="v4-two-col"><div class="v4-field"><label>资料类型</label><input id="resource-type" value="技术文档"></div><div class="v4-field"><label>原始版本</label><input id="resource-version" value="v1"></div></div><div class="v4-field"><label>文件或外部定位 *</label><input id="resource-uri" placeholder="repo://path/file.md 或 https://..."></div><div class="v4-field"><label>精确定位（行号、段落、配置键等）</label><input id="resource-locator" placeholder='{"lines":"20-48"}'></div><div class="v4-field"><label>摘要（不替代原文）</label><textarea id="resource-summary"></textarea></div>`, button('取消', 'close') + button('登记资料', 'save-resource', 'primary')); }

/* Main delegated actions */
function handleAction(action, el) {
  const m = M(), c = C(), id = el.dataset.id;
  switch (action) {
    case 'projects': go('projects'); break;
    case 'home': go('home'); break;
    case 'return-context': returnContext(); break;
    case 'close': closeOverlays(); break;
    case 'overlay-bg': if (el.classList.contains('v4-overlay')) closeOverlays(); break;
    case 'back-catalog': go('explore'); break;
    case 'back-catalog-type': c.catalogType = m.knowledge?.find(item => item.id === state.entityId)?.typeId || K.legacyType(m, state.entityId) || 'all'; save(); go('explore'); break;
    case 'clear-catalog': c.catalogType = 'all'; c.catalogDimension = ''; c.catalogQuery = ''; state.catalogPage = 1; save(); render(); break;
    case 'catalog-terms': c.catalogType = 'Term'; save(); go('explore'); break;
    case 'scroll-intro': $('.v4-intro-narrative')?.scrollIntoView({ behavior: 'smooth' }); break;
    case 'work': c.workTab = 'workflow'; save(); go('work'); break;
    case 'health': c.adminTab = 'health'; save(); go('admin'); break;
    case 'create-project':
      modal('创建项目', `<div class="v4-field"><label>项目名称 *</label><input id="new-project-name"></div><div class="v4-field"><label>项目定位</label><textarea id="new-project-goal"></textarea></div><div class="v4-field"><label>初始模板</label><select id="new-project-template"><option value="blank">空白项目</option><option value="software">软件产品项目</option><option value="approval">业务审批项目</option><option value="manufacturing">制造业务模板</option><option value="government">政务事项模板</option></select><small>模板只预设 Schema、布局和常见工作流，之后均可修改。</small></div>`, button('取消', 'close') + button('创建项目', 'confirm-create-project', 'primary')); break;
    case 'connect': modal('接入已有项目', `<div class="v4-field"><label>项目名称</label><input id="connect-name"></div><div class="v4-notice amber">仅创建逆向恢复工作台，不读取真实仓库。原始资料与推断关系需要分别登记和核验。</div>`, button('取消', 'close') + button('创建恢复工作台', 'confirm-connect', 'primary')); break;
    case 'confirm-create-project': case 'confirm-connect': {
      const name = $(action === 'confirm-create-project' ? '#new-project-name' : '#connect-name').value.trim() || (action === 'confirm-connect' ? '已恢复项目' : '');
      if (!name) { toast('请输入项目名称', 'error'); return; }
      const pid = `PRJ-${String(Math.max(0, ...Object.keys(store.projects).map(key => Number(key.split('-')[1]) || 0)) + 1).padStart(5, '0')}`;
      const goal = action === 'confirm-create-project' ? $('#new-project-goal').value.trim() : '从原始资料逆向恢复并逐条核验项目知识';
      const template = action === 'confirm-create-project' ? $('#new-project-template').value : 'blank';
      store.projects[pid] = AtlasV4Model.createBlankProject(pid, name, goal, template); store.currentProjectId = pid; C(); save(); go('home'); toast('第五个项目已通过数据与配置创建，核心页面代码未改变'); break;
    }
    case 'edit-profile': {
      const p = m.profile;
      modal('维护 Project Profile', `<div class="v4-field"><label>项目定位</label><textarea id="profile-positioning">${esc(p.positioning || '')}</textarea></div><div class="v4-field"><label>服务对象</label><input id="profile-audience" value="${esc(p.audience || '')}"></div><div class="v4-field"><label>负责范围（顿号分隔）</label><textarea id="profile-in">${esc((p.inScope || []).join('、'))}</textarea></div><div class="v4-field"><label>不负责与外部边界</label><textarea id="profile-out">${esc((p.outScope || []).join('、'))}</textarea></div><div class="v4-field"><label>项目背景</label><textarea id="profile-background">${esc(p.background || '')}</textarea></div><div class="v4-field"><label>业务价值</label><textarea id="profile-value">${esc(p.value || '')}</textarea></div>`, button('取消', 'close') + button('保存项目档案', 'save-profile', 'primary'), true); break;
    }
    case 'save-profile': Object.assign(m.profile, { positioning: $('#profile-positioning').value.trim(), audience: $('#profile-audience').value.trim(), inScope: $('#profile-in').value.split(/[、,，]/).map(item => item.trim()).filter(Boolean), outScope: $('#profile-out').value.split(/[、,，]/).map(item => item.trim()).filter(Boolean), background: $('#profile-background').value.trim(), value: $('#profile-value').value.trim() }); m.meta.goal = m.profile.value || m.profile.positioning; save(); closeOverlays(); render(); break;
    case 'add-domain': addDomainModal(); break;
    case 'save-domain': {
      const name = $('#domain-name').value.trim(); if (!name) { toast('领域名称不能为空', 'error'); return; }
      const domain = { id: AtlasModel.nextId(m, 'DOM'), name, icon: name[0], desc: $('#domain-description').value.trim(), goal: $('#domain-description').value.trim(), caps: [], objects: [], actorIds: [], depends: [], version: 'draft', status: 'draft' };
      m.domains.push(domain); save(); closeOverlays(); render(); break;
    }
    case 'add-scenario': if (!m.domains.length) { toast('请先添加至少一个领域；其他知识对象不受此限制', 'error'); return; } addScenarioModal(); break;
    case 'save-scenario': {
      const name = $('#scenario-name').value.trim(); if (!name) { toast('场景名称不能为空', 'error'); return; }
      const scenario = { id: AtlasModel.nextId(m, 'SCN'), name, goal: $('#scenario-goal').value.trim(), trigger: $('#scenario-trigger').value.trim(), result: $('#scenario-result').value.trim(), participants: [], stageIds: [], exceptionIds: [], version: 'draft', status: 'draft', expressionMode: $('#scenario-mode').value, domainId: $('#scenario-domain').value, full: true };
      if (scenario.expressionMode === 'case') scenario.caseModel = { completionConditions: [], dynamicTasks: [], evidenceIds: [], availableActivityIds: [] };
      m.scenarios.push(scenario); c.selectedScenarioId = scenario.id; save(); closeOverlays(); openEntity(scenario.id); break;
    }
    case 'add-action': addActionModal(id || state.entityId); break;
    case 'save-action': {
      const scenario = E.byId(m.scenarios, id), name = $('#action-name').value.trim(); if (!scenario || !name) { toast('动作名称不能为空', 'error'); return; }
      let stage = scenario.stageIds.map(stageId => E.byId(m.stages, stageId)).filter(Boolean)[0];
      if (!stage) { stage = { id: AtlasModel.nextId(m, 'STG'), name: scenario.name, goal: scenario.goal, domainId: scenario.domainId || m.domains[0]?.id, actorIds: [], stepIds: [], status: 'draft' }; m.stages.push(stage); scenario.stageIds.push(stage.id); m.relations.push({ id: AtlasModel.nextId(m, 'REL'), from: scenario.id, type: 'contains', to: stage.id, kind: 'structure', verified: true, trust: 'confirmed' }); }
      let actor = m.actors.find(item => item.name === $('#action-actor').value.trim());
      if (!actor && $('#action-actor').value.trim()) { actor = { id: AtlasModel.nextId(m, 'ACTOR'), name: $('#action-actor').value.trim(), concern: '待明确' }; m.actors.push(actor); }
      const actionId = AtlasModel.nextId(m, 'ACT'), stepId = AtlasModel.nextId(m, 'STEP');
      m.steps.push({ id: stepId, actionId, stageId: stage.id, name, number: stage.stepIds.length + 1 }); stage.stepIds.push(stepId);
      m.actions.push({ id: actionId, name, version: 'draft', status: 'draft', scenarioId: scenario.id, stageId: stage.id, stepId, domainId: stage.domainId, actorId: actor?.id, purpose: $('#action-purpose').value.trim(), pre: [], input: [], output: [], objectChanges: [], exceptions: [], evidence: [], depth: 'detailed' });
      m.relations.push({ id: AtlasModel.nextId(m, 'REL'), from: stage.id, type: 'contains', to: stepId, kind: 'structure', verified: true, trust: 'confirmed' }, { id: AtlasModel.nextId(m, 'REL'), from: actionId, type: 'belongsTo', to: scenario.id, kind: 'structure', verified: true, trust: 'confirmed' });
      const flow = { id: `FLOW-${scenario.id}`, scenarioId: scenario.id, nodes: [], edges: [] }, actions = m.actions.filter(item => item.scenarioId === scenario.id);
      flow.nodes = actions.map((item, index) => ({ id: `N-${item.id}`, actionId: item.id, stageId: item.stageId, type: 'action' }));
      flow.edges = actions.slice(1).map((item, index) => ({ id: `E-${scenario.id}-${index}`, from: `N-${actions[index].id}`, to: `N-${item.id}`, type: 'next' }));
      const flowIndex = m.flows.findIndex(item => item.scenarioId === scenario.id); if (flowIndex >= 0) m.flows[flowIndex] = flow; else m.flows.push(flow);
      save(); closeOverlays(); openEntity(actionId); break;
    }
    case 'new-schema': newSchemaModal(); break;
    case 'save-schema': saveSchema(); break;
    case 'new-entity': {
      const schemas = Object.values(m.schemaRegistry).filter(schema => !['Domain', 'Scenario', 'Action', 'Actor', 'Evidence', 'Change', 'Delivery', 'Project'].includes(schema.id));
      modal('选择知识类型', `<div class="v4-schema-grid">${schemas.map(schema => `<button class="v4-schema-card" data-new-entity-type="${schema.id}"><span class="v4-mono">${schema.id}</span><h3>${esc(schema.name)}</h3><p>${esc(schema.dimension)} · ${schema.custom ? '项目扩展' : '核心类型'}</p></button>`).join('')}</div>`, button('取消', 'close') + button('注册新类型', 'new-schema'), true); break;
    }
    case 'save-entity': saveEntity(el.dataset.type); break;
    case 'edit-entity': newEntityModal(K.getEntity(m, id).typeId, id); break;
    case 'save-new-rule': {
      const name = $('#new-rule-name').value.trim(); if (!name) { toast('规则名称不能为空', 'error'); return; }
      const id = AtlasModel.nextId(m, 'RULE'), version = { version: 'draft', status: 'draft', name, scope: $('#new-rule-scope').value.trim() || '当前项目', supportsEvaluation: false, constraint: $('#new-rule-constraint').value.trim() || '人工核验约束待完善', inputs: [], outcomes: [], rows: [], exceptions: [], effective: '草稿', source: '用户创建' };
      version.summary = E.summarizeRule(version); m.rules.push({ id, name, owner: '当前用户', currentVersion: null, versions: { draft: version } });
      const related = $('#new-rule-related').value.trim(); if (related && K.getEntity(m, related)) K.addRelation(m, { from: related, type: 'uses', to: id, trust: 'confirmed', verified: true });
      save(); closeOverlays(); openEntity(id, 'decision'); break;
    }
    case 'new-resource': newResourceModal(); break;
    case 'save-resource': {
      const name = $('#resource-name').value.trim(), uri = $('#resource-uri').value.trim(); if (!name || !uri) { toast('资料名称和资源定位不能为空', 'error'); return; }
      try { const item = K.createEntity(m, 'Resource', { id: `SRC-${m.meta.id}-${String((m.knowledge || []).filter(entry => entry.typeId === 'Resource').length + 1).padStart(3, '0')}`, name, description: $('#resource-summary').value.trim(), props: { resourceType: $('#resource-type').value.trim(), uri, sourceVersion: $('#resource-version').value.trim(), locator: $('#resource-locator').value.trim(), summary: $('#resource-summary').value.trim(), parseStatus: 'unparsed', trust: 'unverified', owner: '当前用户' } }); save(); closeOverlays(); openEntity(item.id); } catch (error) { toast(error.message, 'error'); } break;
    }
    case 'add-relation': {
      const source = K.getEntity(m, id || state.entityId), targets = catalogEntities().filter(item => item.id !== source.id);
      modal(`建立关联 · ${source.id}`, `<div class="v4-two-col"><div class="v4-field"><label>关系类型</label><select id="relation-type">${['references', 'uses', 'contains', 'implements', 'affects', 'reads', 'writes', 'explains', 'cites', 'supports', 'dependsOn', 'derivedFrom'].map(type => `<option>${type}</option>`).join('')}</select></div><div class="v4-field"><label>目标知识对象</label><select id="relation-target">${targets.map(item => `<option value="${item.id}">${esc(item.name)} · ${item.id}</option>`).join('')}</select></div></div><div class="v4-field"><label>关系解释或适用条件</label><textarea id="relation-explanation"></textarea></div><div class="v4-two-col"><div class="v4-field"><label>可信状态</label><select id="relation-trust"><option value="confirmed">人工确认</option><option value="inferred">推断，待核验</option></select></div><div class="v4-field"><label>来源对象 ID（可选）</label><input id="relation-source"></div></div>`, button('取消', 'close') + button('建立关系', 'save-relation', 'primary', `data-id="${source.id}"`)); break;
    }
    case 'save-relation': try { K.addRelation(m, { from: id, to: $('#relation-target').value, type: $('#relation-type').value, trust: $('#relation-trust').value, verified: $('#relation-trust').value === 'confirmed', sourceId: $('#relation-source').value.trim() || null, explanation: $('#relation-explanation').value.trim() }); save(); closeOverlays(); render(); toast('关系已建立，可从两端反向查询'); } catch (error) { toast(error.message, 'error'); } break;
    case 'pin-entity': c.pins = [...new Set([state.entityId, ...c.pins])].slice(0, 12); save(); toast('已固定到当前项目关注项'); break;
    case 'new-issue': {
      const objectId = id || state.entityId || '';
      modal('围绕知识对象提问', `<div class="v4-field"><label>问题 *</label><textarea id="new-issue-title"></textarea></div><div class="v4-field"><label>知识对象 ID</label><input id="new-issue-object" value="${esc(objectId)}"></div>`, button('取消', 'close') + button('创建问题', 'save-issue', 'primary')); break;
    }
    case 'save-issue': { const title = $('#new-issue-title').value.trim(); if (!title) { toast('问题不能为空', 'error'); return; } m.issues.unshift({ id: AtlasModel.nextId(m, 'Q'), title, why: '围绕明确知识对象补充事实与决定。', status: 'waiting', owner: '当前用户', objectId: $('#new-issue-object').value.trim(), replies: [], evidenceIds: [], requiresChange: false, decision: null }); save(); closeOverlays(); c.workTab = 'issues'; go('work'); break; }
    case 'reply-issue': case 'decide-issue': { const issue = E.byId(m.issues, state.drawer.id), text = $('#issue-text').value.trim(); if (!text) { toast('请输入回复或结论', 'error'); return; } issue.replies.push({ by: '当前用户', text, time: new Date().toISOString() }); if (action === 'decide-issue') { issue.decision = text; issue.status = 'resolved'; } else issue.status = 'replied'; save(); closeOverlays(); render(); break; }
    case 'open-issue-object': { const issue = E.byId(m.issues, state.drawer.id); closeOverlays(); openEntity(issue.objectId); break; }
    case 'new-workflow': openWorkflowEditor(); break;
    case 'edit-workflow': openWorkflowEditor(m.workflowDefinitions.find(item => item.id === id)); break;
    case 'workflow-add-stage': readWorkflowEditor(); state.workflowDraft.stages.push({ id: `stage-${Date.now()}-${state.workflowDraft.stages.length + 1}`, name: '', role: '', required: true, returnTo: null, artifacts: [], confirmation: false }); state.modal.body = renderWorkflowEditor(); renderOverlay(); break;
    case 'save-workflow': saveWorkflow(false); break;
    case 'save-run-workflow': saveWorkflow(true); break;
    case 'new-workflow-instance': {
      if (!m.workflowDefinitions.length) { openWorkflowEditor(); return; }
      modal('创建工作流实例', `<div class="v4-field"><label>工作流定义与固定版本</label><select id="instance-definition">${m.workflowDefinitions.map(def => `<option value="${def.id}">${esc(def.name)} · ${def.id}@${def.version}</option>`).join('')}</select></div><div class="v4-field"><label>处理对象 ID</label><input id="instance-subject" value="${esc(m.scenarios[0]?.id || m.meta.id)}"></div>`, button('取消', 'close') + button('创建实例', 'save-workflow-instance', 'primary')); break;
    }
    case 'save-workflow-instance': try { const instance = K.instantiateWorkflow(m, $('#instance-definition').value, { subjectId: $('#instance-subject').value.trim() }); c.selectedInstanceId = instance.id; c.workTab = 'workflow'; save(); closeOverlays(); render(); } catch (error) { toast(error.message, 'error'); } break;
    case 'open-instance-subject': openEntity(m.workflowInstances.find(item => item.id === c.selectedInstanceId).subjectId); break;
    case 'confirm-workflow-stage': { const instance = m.workflowInstances.find(item => item.id === c.selectedInstanceId), stage = K.currentStage(instance); instance.confirmations[stage.id] = { by: '当前用户', at: new Date().toISOString() }; instance.records.push({ at: new Date().toISOString(), by: '当前用户', type: 'confirm', stageId: stage.id }); save(); render(); break; }
    case 'add-workflow-artifact': { const instance = m.workflowInstances.find(item => item.id === c.selectedInstanceId), stage = K.currentStage(instance), artifact = el.dataset.artifact; instance.artifacts[artifact] = { id: `ART-${Date.now()}`, stageId: stage.id, at: new Date().toISOString(), status: 'recorded' }; save(); render(); break; }
    case 'advance-workflow': case 'skip-workflow': case 'return-workflow': case 'reopen-workflow': {
      const fn = { 'advance-workflow': K.advanceWorkflow, 'skip-workflow': K.skipWorkflowStage, 'return-workflow': K.returnWorkflow, 'reopen-workflow': K.reopenWorkflow }[action], result = fn(m, c.selectedInstanceId, { by: '当前用户', context: m.workflowInstances.find(item => item.id === c.selectedInstanceId)?.context || {} });
      if (!result.ok) { toast(result.errors[0], 'error'); return; } save(); render(); toast(action === 'return-workflow' ? '已按定义退回并保留执行记录' : action === 'reopen-workflow' ? '已重新打开，定义版本保持不变' : '工作流状态已真实更新'); break;
    }
    case 'generate-handoff': {
      const instance = m.workflowInstances.find(item => item.id === c.selectedInstanceId), subject = K.getEntity(m, instance.subjectId), related = subject ? K.queryKnowledge(m, { id: subject.id, depth: 2, permission: { role: 'admin', clearance: 'restricted' } }) : null;
      const delivery = { id: AtlasModel.nextId(m, 'DLV'), requirementId: `WF-${instance.id}`, subjectId: instance.subjectId, ruleId: subject?.typeId === 'Rule' ? subject.id : null, ruleVersion: subject?.typeId === 'Rule' ? subject.currentVersion : null, packageVersion: `HANDOFF-${instance.id}@${instance.records.length + 1}`, snapshot: clone({ subject, knowledge: related, workflow: { definitionId: instance.definitionId, version: instance.definitionVersion, records: instance.records }, generatedAt: new Date().toISOString() }) };
      m.deliveries.push(delivery); instance.artifacts.handoff = { id: delivery.id, at: new Date().toISOString() }; save(); c.workTab = 'deliveries'; render(); toast('已生成固定知识版本与执行记录的快照'); break;
    }
    case 'new-rule-change': closeOverlays(); newRuleChange(id || state.entityId); break;
    case 'edit-rule-change': openRuleChangeEditor(); break;
    case 'save-rule-change': saveRuleChange(); break;
    case 'submit-change': {
      const change = m.changes.find(item => item.id === c.selectedChangeId), errors = [];
      if (!change.draftRule) errors.push('尚未建立草稿'); if (Object.values(change.checks || {}).some(value => !value)) errors.push('影响检查未完成');
      const issues = m.issues.filter(item => item.changeId === change.id && !['resolved', 'cancelled'].includes(item.status)); if (issues.some(item => !item.decision)) errors.push('关联问题尚未形成结论');
      if (change.draftRule) { const validation = E.validateRuleVersion(change.draftRule); errors.push(...validation.errors); if (validation.uncovered.length) errors.push('仍有输入组合未覆盖'); }
      if (errors.length) { toast(errors[0], 'error'); return; } change.status = 'pending'; change.draftRule.status = 'pending'; save(); render(); break;
    }
    case 'approve-change': {
      const change = m.changes.find(item => item.id === c.selectedChangeId), result = E.publishRuleChange(m, change.id, '项目批准人');
      if (!result.ok) { toast(result.errors[0], 'error'); return; } m.versionLayers.baseline = `${m.meta.id}-BASELINE@${result.version.version}`; save(); render(); toast(`${change.ruleId}@${result.version.version} 已发布，关联对象版本未被强制提升`); break;
    }
    case 'open-change-rule': openEntity(m.changes.find(item => item.id === c.selectedChangeId).ruleId, 'decision'); break;
    case 'toggle-flow-explore': c.exploreFlow = !c.exploreFlow; save(); render(); break;
    case 'run-validation': c.adminTab = 'health'; save(); render(); toast('已重新执行项目一致性检查'); break;
    case 'agent-context': closeOverlays(); agentContext(id); break;
    case 'run-agent-query': runAgentQuery(); break;
    case 'open-drawer-entity': closeOverlays(); openEntity(id); break;
    case 'profile': modal('原型数据与恢复', `<div class="v4-notice blue">V4 数据独立保存在 localStorage 的 ${STORE}，不会覆盖 V3 数据。</div><p>当前项目：${esc(m.meta.name)}</p><p>固定关注：${c.pins.map(esc).join('、') || '无'}</p><p>最近访问：${(store.recent[m.meta.id] || []).map(esc).join('、') || '无'}</p>`, button('关闭', 'close') + button('重置 V4 演示数据', 'reset', 'danger')); break;
    case 'reset': localStorage.removeItem(STORE); store = { currentProjectId: 'PRJ-00001', contexts: {}, recent: {}, projects: AtlasV4Model.createProjectSet() }; state.returnStack = []; save(); closeOverlays(); go('home'); toast('已恢复四个 V4 演示项目'); break;
    default: break;
  }
}

document.addEventListener('click', event => {
  const el = event.target.closest('[data-route],[data-action],[data-project],[data-entity],[data-term],[data-catalog-type],[data-page],[data-object-view],[data-instance],[data-work-tab],[data-admin-tab],[data-change],[data-issue],[data-new-entity-type],[data-rule-version],[data-wf-move],[data-wf-remove]');
  if (!el) return; const d = el.dataset, m = M(), c = C();
  if (d.route) { if (d.route === 'entity' && !state.entityId) { go('explore'); return; } go(d.route); return; }
  if (d.project) { store.currentProjectId = d.project; state.returnStack = []; state.entityId = null; C(); save(); go('home'); return; }
  if (d.entity) { closeOverlays(); openEntity(d.entity); return; }
  if (d.term) { showTerm(d.term); return; }
  if (d.catalogType) { c.catalogType = d.catalogType; state.catalogPage = 1; save(); render(); return; }
  if (d.page) { state.catalogPage = Number(d.page); render(); return; }
  if (d.objectView) { state.entityView = d.objectView; state.entityVersion = null; render(); return; }
  if (d.instance) { c.selectedInstanceId = d.instance; save(); render(); return; }
  if (d.workTab) { c.workTab = d.workTab; save(); render(); return; }
  if (d.adminTab) { c.adminTab = d.adminTab; save(); render(); return; }
  if (d.change) { c.selectedChangeId = d.change; save(); render(); return; }
  if (d.issue) { closeOverlays(); showIssue(d.issue); return; }
  if (d.newEntityType) { closeOverlays(); if (d.newEntityType === 'Rule') newRuleModal(); else newEntityModal(d.newEntityType); return; }
  if (d.ruleVersion) { state.entityVersion = d.ruleVersion; state.entityView = 'decision'; render(); return; }
  if (d.wfMove) { readWorkflowEditor(); const index = Number(d.index), target = d.wfMove === 'up' ? index - 1 : index + 1; if (target >= 0 && target < state.workflowDraft.stages.length) { const [stage] = state.workflowDraft.stages.splice(index, 1); state.workflowDraft.stages.splice(target, 0, stage); } state.modal.body = renderWorkflowEditor(); renderOverlay(); return; }
  if (d.wfRemove !== undefined) { readWorkflowEditor(); state.workflowDraft.stages.splice(Number(d.wfRemove), 1); state.modal.body = renderWorkflowEditor(); renderOverlay(); return; }
  if (d.action) handleAction(d.action, el);
});
document.addEventListener('change', event => {
  const el = event.target, d = el.dataset, m = M(), c = C();
  if (el.id === 'role-select') { c.role = el.value; c.homeSections = el.value === 'developer' ? ['intro', 'systems', 'assets', 'business', 'concerns'] : clone(m.workspace.homeSections); const path = m.workspace.readingPaths.find(item => el.value === 'developer' ? item.role === 'developer' : item.role !== 'developer'); if (path) c.selectedPathId = path.id; save(); render(); }
  if (el.id === 'catalog-dimension') { c.catalogDimension = el.value; state.catalogPage = 1; save(); render(); }
  if (el.id === 'reading-path') { c.selectedPathId = el.value; save(); render(); }
  if (d.homeSection) { c.homeSections = el.checked ? [...new Set([...c.homeSections, d.homeSection])] : c.homeSections.filter(item => item !== d.homeSection); m.workspace.homeSections = clone(c.homeSections); save(); render(); }
  if (d.ruleSim) { const rule = K.getEntity(m, d.ruleId, state.entityVersion), version = rule.selectedVersion; c.ruleValues[d.ruleId] ||= E.defaultValues(version); c.ruleValues[d.ruleId][d.ruleSim] = el.value; $('#rule-sim-result').innerHTML = V.RuleSimulation(m, rule, c.ruleValues[d.ruleId]); }
  if (d.flowInput) { c.flowValues[d.flowInput] = el.value; save(); render(); }
  if (d.changeCheck) { const change = m.changes.find(item => item.id === c.selectedChangeId); change.checks[d.changeCheck] = el.checked; save(); render(); }
  if (d.wfContext) { const instance = m.workflowInstances.find(item => item.id === c.selectedInstanceId); instance.context ||= {}; instance.context[d.wfContext] = el.value.trim(); save(); }
});
document.addEventListener('input', event => {
  const el = event.target, c = C();
  if (el.id === 'global-search' || el.id === 'search-modal-input') { clearTimeout(state.searchTimer); state.searchTimer = setTimeout(() => globalSearch(el.value), 250); }
  if (el.id === 'catalog-query') { c.catalogQuery = el.value; state.catalogPage = 1; clearTimeout(state.searchTimer); state.searchTimer = setTimeout(() => { save(); render(); const input = $('#catalog-query'); input?.focus(); input?.setSelectionRange(input.value.length, input.value.length); }, 180); }
  if (el.id === 'project-search') $$('[data-project]').forEach(card => { card.hidden = !card.dataset.projectName.includes(el.value.toLowerCase()); });
});
document.addEventListener('keydown', event => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); globalSearch(''); } if (event.key === 'Escape') closeOverlays(); });
addEventListener('hashchange', () => { const hash = location.hash.slice(1); if (hash.startsWith('entity/')) { state.entityId = hash.split('/')[1]; state.route = 'entity'; } else if (hash && hash !== state.route) state.route = hash; render(); });
render();
