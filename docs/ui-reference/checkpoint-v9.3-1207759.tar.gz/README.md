# Business Atlas V9.3

V9.3 在完整保留 V9.2 知识、导入、权限、版本和协作能力的基础上，纠正核心业务认知：不仅能管理知识对象，还能解释业务判断、区分目标与实现、验证案例、分析需求影响，并把代码、测试、知识和交付闭环连接起来。

纯 HTML / CSS / JavaScript 原型，无后端、无外部运行资源、无 npm 运行依赖。

## 直接运行

双击 `dist/business-atlas-v9.3.html`。全部脚本、样式、Self Knowledge 和演示数据已内联，可直接通过 `file://` 打开。

模块开发版为根目录 `index.html`，与单文件版使用相同源码。沿用 `localStorage` 的 `business-atlas-v9`，已有项目、草稿、问答、反馈、Agent Run、任务、契约和 Visual View 不会被清空；旧任务缺少的新语义明确显示未分析，不自动补全。

## 六项主导航保持不变

- 理解项目：项目概览、知识目录、业务与系统。
- 维护知识：变更与审核。
- 项目协作：任务与问题、交付与验收。

“业务应该怎样 / 当前实际怎样 / 实现如何完成”是业务与系统中的三个阅读视角，不是三个一级导航。项目助手仍在左侧底部，使用确定性查询，不声称接入真实 LLM/Agent。

## 核心业务决策阅读

`src/v9-3-decision.js` 提供受权限、批准状态和适用上下文约束的确定性评估器：

- Context、Inputs、Preconditions、Evaluation、Priority、Branch、Outcome、Default、Exception、Evidence。
- equals、notEquals、contains、startsWith、exists、notExists、greaterThan、lessThan、in、all、any。
- 三值条件结果、缺失输入、未支持条件、规则冲突、未确认优先级和默认分支。
- 正例、反例、边界例、未知例与回归例只验证规则，不反推或修改规范。
- 评估轨迹包含规则行、命中分支、结果类型、缺失事实、来源、规则版本和基线。

`src/v9-3-reading.js` 形成统一 Business Decision Projection、Target / Observed / Mechanism 对照、Cognitive Completeness 和 Flow 语义守恒模型。Feature、Scenario、Rule 默认先显示业务目的、条件—判断—结果、案例和实际符合性；技术字段、JSON、版本和来源按需展开。

## Task Semantic Contract 与影响调查

`src/v9-3-task.js` 在现有 Task 上实现 `TSC/1.0`：Business Intent、Existing Behavior、Target Behavior、Business Difference、Impact Scope、Acceptance Cases、Knowledge Delivery。

- 新需求只要求业务目标、具体问题、关联功能和目标描述。
- 候选规则保存基线引用与差异操作，不复制独立规范，不自动批准。
- 影响调查覆盖调用链、界面、API、后端、数据、参数、事件、配置、测试、旧路径、兼容、部署和知识。
- 每项区分需要修改、潜在影响、已检查无需修改、转其他 Task、尚未确认，并保存路径、语义、证据和理由。
- 重复实现、无效兼容和旧路径进入主动收敛调查，不自动改变业务语义。
- 文案、样式和内部重构使用简化合同，但仍说明保留行为和验证方式。

## 开发知识同步交付

沿用 V1.2：PR 候选知识、合并后 Knowledge Delivery Manifest、知识治理与 Baseline、部署版本与知识版本对账。

Task 分别关联需求、业务决策、实现、测试、KnowledgeChange、Manifest、批准基线和部署版本。状态区分：

- `not-ready`：业务、影响、实现或验收仍有阻断。
- `implementation-complete-knowledge-pending`：实现和测试完成，知识待审批。
- `fully-delivered`：业务、实现、测试、影响、知识、版本和批准全部闭合。

原型 PR、测试和 Manifest 均明确标为模拟，不代表真实 GitHub、测试执行器或部署事件。

## 图形与权限修复

- 修复 `GROUP-undefined`，七阶段身份独立，条件分支与回流保留。
- 修复恒真的状态过滤；未确认转移只在探索中标记显示。
- 统一收集直接 Rule、Action Rule、Flow 节点/分支 Rule 和显式状态 Guard Rule。
- Flow 引用逐节点执行权限、基线和适用性检查，正式契约不再误报完整闭包。
- 执行、约束、依赖、实现、读写分别使用有标签关系，不混成无标签执行箭头。
- 流程语义指纹排除布局；纯布局变化不使任务契约失效。
- 任务、问题、首页、交付选择器、图形、评估、搜索、助手和导出统一使用 Read Context。
- 普通备份变为当前项目授权导出；决策和 Task 导出重新授权。

## 认知黄金样本与制造项目

独立“遗留参数与搜索认知治理”项目包含：

1. `parameterName`：只批准存在性与默认分支，具体业务比较字段仍待确认。
2. 123 / 1234：当前词元观察和技术机制可解释，目标匹配规则未批准；提供选项、兼容影响与推荐，但推荐不等于批准。

制造质量项目继续验证异常登记、批次隔离、质量处置、放行判断、状态变化、七阶段 Flow、技术映射和模拟知识交付。所有页面由统一知识和投影生成，没有行业或示例专用判断逻辑。

## 构建与测试

只需要 Node.js（验收环境 24.21.0）：

```bash
node scripts/extract-self-knowledge.js
node scripts/prepare-self-project.js
node build.js
node acceptance.test.js
node v4-acceptance.test.js
node tests/v5-acceptance.test.js
node tests/v6-acceptance.test.js
node tests/v7-acceptance.test.js
node tests/v8-acceptance.test.js
node tests/v9-acceptance.test.js
node tests/v9-1-acceptance.test.js
node tests/v9-2-acceptance.test.js
node tests/v9-3-acceptance.test.js
```

V5–V9.2 的单文件兼容测试指定当前产物：

```powershell
$env:ATLAS_SINGLE_HTML='dist/business-atlas-v9.3.html'
```

当前结果：**V3 17/17、V4 32/32、V5 43/43、V6 41/41、V7 35/35、V8 30/30、V9 51/51、V9.1 30/30、V9.2 45/45、V9.3 65/65，共 389/389 通过**。V9-06 的跨日有效期问题已通过明确 AKP 未声明时间边界的语义修复，未冻结时钟或删除检查。

干净目录重建、全量测试与 SHA-256 验证：

```bash
node scripts/validate-rebuild.js
node scripts/package-source.js
node scripts/validate-source-zip.js
```

## 浏览器验收

```bash
node scripts/browser-cdp-v9-3.js
```

真实 Chrome `file://` 六条业务旅程：**19/19 断言通过**，控制台错误 0、外部请求 0。1440、1280、1024、800 四种视口均无整页横向溢出。11 张实际截图和布局数据位于 `artifacts/v9-3-browser/`。

## 文档

- `docs/v9-3-business-decision-model.md`：决策模型、条件语义、案例与符合性。
- `docs/v9-3-task-semantic-contract.md`：Task 语义合同、版本引用与 Agent 权限。
- `docs/v9-3-impact-and-delivery.md`：影响调查、闭环阻断与 V1.2 映射。
- `docs/v9-3-migration-compatibility.md`：旧数据、AKP、版本与权限兼容。
- `docs/v9-3-design-decisions.md`：重要决定与未解决问题。
- `docs/v9-3-browser-acceptance.md`：六条旅程、截图和响应式结果。
- `dist/business-atlas-v9.3-review.md`：最终产品评审。

Self Knowledge 继续由实际源码锚点和 SHA-256 提取，包含 V9.3 决策、阅读、Task、UI、测试与构建知识；观察、推断和知识提案不自动成为批准事实。

## 产品边界

结论：**READY FOR CONTROLLED PILOT**。V9.3 的交互和领域语义可作为正式产品开发纵切依据，但不等于生产上线就绪。权限仍为前端模拟；不包含真实后端、数据库、企业认证、MCP/LLM、真实编程 Agent、多人协作、仓库同步或生产部署。真实项目的认知效率、影响召回率和复杂图可读性仍需受控试点验证。
