/* Business Atlas V3 — composable, project-agnostic front-end prototype. */
'use strict';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const clone = AtlasModel.deepClone;
const E = AtlasEngine;
const STORE = 'business-atlas-v3';
const icons = { overview: '⌂', explore: '◈', scenario: '⇢', knowledge: '▤', surface: '▦', changes: '↻', delivery: '◇', governance: '✓' };
const nav = [
  ['overview', '项目全景'], ['explore', '业务地图'], ['scenario', '业务故事板'], ['knowledge', '规则与对象'],
  ['surface', '界面映射'], ['changes', '变更工作台'], ['delivery', '开发交接'], ['governance', '证据治理']
];
let store;
try { store = JSON.parse(localStorage.getItem(STORE) || 'null'); } catch (error) { /* recover with clean demo data */ }
if (!store?.projects?.['PRJ-00001'] || !store?.projects?.['PRJ-00002']) {
  store = {
    currentProjectId: 'PRJ-00001', contexts: {},
    projects: { 'PRJ-00001': AtlasModel.createMatureProject(), 'PRJ-00002': AtlasModel.createBookingProject() }
  };
}
store.contexts ||= {};
const state = { route: location.hash.slice(1) || 'projects', returnContext: null, modal: null, drawer: null, actionLens: 'business', surfaceMode: 'directory', actionPage: 1, surfacePage: 1 };
const M = () => store.projects[store.currentProjectId];
const save = () => { try { localStorage.setItem(STORE, JSON.stringify(store)); } catch (error) { toast('浏览器存储空间不足，当前修改尚未持久化', 'error'); } };
const actor = (m, id) => E.byId(m.actors, id);
const actorName = (m, id) => actor(m, id)?.name || id || '未指定';
const objectName = (m, id) => E.byId(m.objects, id)?.name || id;
const domainName = (m, id) => E.byId(m.domains, id)?.name || id || '未分组';
const statusText = status => ({ published: '已发布', draft: '草稿', pending: '待审批', approved: '已批准', historical: '历史版本', active: '有效', stale: '待重新核验', index: '仅索引', unassigned: '待澄清', waiting: '等待回复', replied: '已回复待核验', confirming: '待业务确认', investigating: '待澄清', resolved: '已解决', cancelled: '不再适用' }[status] || status || '未建立');
const statusType = status => ['published', 'approved', 'resolved', 'active'].includes(status) ? 'green' : ['pending', 'confirming', 'replied', 'draft', 'investigating', 'stale'].includes(status) ? 'amber' : '';
const badge = (text, type = '') => `<span class="badge ${type}">${esc(text)}</span>`;
const btn = (text, action, type = '', extra = '') => `<button class="btn ${type}" data-action="${action}" ${extra}>${text}</button>`;
const selectOptions = (options, selected) => options.map(([value, label]) => `<option value="${esc(value)}" ${value === selected ? 'selected' : ''}>${esc(label)}</option>`).join('');

function defaultContext(m) {
  const scenario = m.scenarios.find(item => item.full) || m.scenarios[0];
  const scenarioStages = m.stages.filter(stage => scenario?.stageIds.includes(stage.id));
  const scenarioFlow = scenario ? E.flowFor(m, scenario.id) : { nodes: [] };
  const preferredStage = scenarioStages.find(stage => scenarioFlow.nodes.some(node => node.stageId === stage.id && node.ruleId && scenario.explore?.ruleIds?.includes(node.ruleId))) || scenarioStages.find(stage => stage.stepIds.some(stepId => {
    const step = E.byId(m.steps, stepId), action = E.byId(m.actions, step?.actionId);
    return action?.depth === 'detailed' && E.actionRules(m, action.id).length;
  })) || scenarioStages[0];
  const preferredAction = m.actions.find(action => action.stageId === preferredStage?.id && action.depth === 'detailed') || m.actions.find(action => action.scenarioId === scenario?.id) || m.actions[0];
  return {
    selectedDomainId: m.domains[0]?.id || null, selectedCapabilityId: null, selectedScenarioId: scenario?.id || null,
    selectedStageId: preferredStage?.id || null, selectedActionId: preferredAction?.id || null,
    selectedRuleId: m.rules[0]?.id || null, selectedSurfaceId: m.surfaces[0]?.id || null,
    selectedObjectId: m.objects[0]?.id || null, selectedIssueId: null, selectedChangeId: m.changes[0]?.id || null,
    selectedDeliveryId: m.deliveries[0]?.id || null, storyNodeId: preferredAction?.id || null, selectedFlowNodeId: null,
    overviewLens: 'responsibilities', overviewSelection: null, overviewQuery: '', knowledgeTab: 'rules',
    ruleVersion: null, rulePreviewChange: null, explore: false, exploreValues: {}, showExceptions: false, focus: false,
    actionQuery: '', actionDomain: '', actionActor: '', actionDepth: '', surfaceQuery: '', surfaceActor: '', surfaceType: '', ruleSim: {}
  };
}
function C() {
  const id = store.currentProjectId;
  if (!store.contexts[id]) store.contexts[id] = defaultContext(M());
  return store.contexts[id];
}
function resetContext() { store.contexts[store.currentProjectId] = defaultContext(M()); }
function currentScenario() { return E.byId(M().scenarios, C().selectedScenarioId) || M().scenarios.find(item => item.full) || M().scenarios[0]; }
function currentAction() { return E.byId(M().actions, C().selectedActionId); }
function currentRule() { return E.byId(M().rules, C().selectedRuleId) || M().rules[0]; }
function activeChange() { return E.byId(M().changes, C().selectedChangeId) || M().changes[0]; }
function publishedRule(rule) { return rule?.versions?.[rule.currentVersion] || rule?.versions?.draft; }
function pageHead(title, id, desc, actions = '') {
  return `<div class="page-head"><div class="page-title-wrap"><h1>${esc(title)}</h1><div class="eyebrow mono">${esc(id)}</div>${desc ? `<p>${esc(desc)}</p>` : ''}</div><div class="actions">${actions}</div></div>`;
}
function empty(icon, title, desc, action = '') {
  return `<div class="empty"><div class="empty-icon">${icon}</div><h2>${esc(title)}</h2><p class="empty-copy">${esc(desc)}</p>${action}</div>`;
}
function toast(message, type = 'success') {
  const element = document.createElement('div'); element.className = `toast ${type === 'success' ? 'success-toast' : ''}`;
  element.innerHTML = `<span>${type === 'success' ? '✓' : '!'}</span><span>${esc(message)}</span>`;
  $('#toast-root').appendChild(element); setTimeout(() => element.remove(), 3600);
}
function go(route) { state.route = route; location.hash = route; state.modal = null; state.drawer = null; renderOverlay(); render(); scrollTo(0, 0); }
function rememberReturn(route = state.route) {
  state.returnContext = { route, context: clone(C()) };
}
function openAction(id, from = state.route) {
  const action = E.byId(M().actions, id);
  if (!action) { toast('此条目只有规模索引，尚未建立动作剖面', 'error'); return; }
  rememberReturn(from); C().selectedActionId = id; C().storyNodeId = id; C().selectedStageId = action.stageId;
  C().selectedScenarioId = action.scenarioId || C().selectedScenarioId; save(); go('action');
}
function openRule(id, from = state.route) {
  if (!E.byId(M().rules, id)) return;
  rememberReturn(from); C().selectedRuleId = id; C().ruleVersion = null; C().rulePreviewChange = null; C().knowledgeTab = 'rules'; save(); go('knowledge');
}
function returnContext() {
  const previous = state.returnContext;
  if (!previous) { go('overview'); return; }
  store.contexts[store.currentProjectId] = previous.context; state.returnContext = null; save(); go(previous.route);
}
function shell(content) {
  const m = M(), c = C();
  const pending = m.issues.filter(issue => !['resolved', 'cancelled'].includes(issue.status)).length;
  return `<div class="app"><header class="topbar"><div class="brand" data-action="projects"><span class="brand-mark">A</span>Business Atlas</div><div class="project-switch" data-action="projects">${esc(m.meta.name)} <span>⌄</span></div><div class="global-search"><span class="search-icon">⌕</span><input id="global-search" placeholder="搜索当前项目或稳定 ID" autocomplete="off"><span class="key">⌘ K</span></div><span class="top-action" data-action="recent">返回上下文</span><span class="top-action" data-action="notifications">待确认 ${pending}</span><span class="top-action" data-action="help">?</span><div class="avatar" data-action="profile">林</div></header><div class="body"><aside class="sidebar">${nav.map(([route, name]) => `<button class="nav-item ${state.route === route || (state.route === 'action' && route === 'scenario') || (state.route === 'issues' && route === 'changes') ? 'active' : ''}" data-route="${route}"><span class="nav-icon">${icons[route]}</span><span>${name}</span></button>`).join('')}<div class="side-version">当前项目基线<br><span class="mono">${esc(m.meta.version)} · ${m.meta.status === 'published' ? '已发布' : '构建中'}</span></div><button class="ai-launcher" data-action="agent-context">✦ <span>获取业务上下文</span><br><small>按稳定 ID 与指定版本</small></button></aside><main class="main ${c.focus ? 'focus-main' : ''}">${content}</main></div></div>`;
}
function render() {
  const routes = { projects: renderProjects, overview: renderOverview, explore: renderDomain, scenario: renderScenario, action: renderAction, knowledge: renderKnowledge, surface: renderSurface, changes: renderChanges, issues: renderIssues, delivery: renderDelivery, governance: renderGovernance };
  const fn = routes[state.route] || renderOverview;
  $('#app').innerHTML = state.route === 'projects' ? fn() : shell(fn()); renderOverlay();
}

/* Project entry and project-local context */
function renderProjects() {
  const projects = Object.values(store.projects);
  return `<div class="app"><header class="topbar"><div class="brand"><span class="brand-mark">A</span>Business Atlas</div><div class="global-search"><span class="search-icon">⌕</span><input id="project-search" placeholder="搜索项目"><span class="key">V3</span></div><div class="avatar" data-action="profile">林</div></header><div class="entry-wrap"><div class="entry-head"><div><h1>项目业务工作空间</h1><p class="muted entry-subtitle">同一套认知语法，视图只呈现当前项目真实拥有的信息。</p></div><div class="actions">${btn('接入已有项目', 'connect')}${btn('＋ 创建新项目', 'create-project', 'primary')}</div></div><div class="project-grid">${projects.map(project => `<div class="card project-card" data-project="${project.meta.id}" data-project-name="${esc(project.meta.name.toLowerCase())}"><div class="project-symbol">${esc(project.meta.name[0] || '项')}</div>${badge(project.meta.version, project.meta.status === 'published' ? 'blue' : 'amber')}<h2>${esc(project.meta.name)}</h2><p>${esc(project.meta.desc || project.meta.goal)}</p><div class="project-meta">${project.domains.length} 领域 / ${project.scenarios.length} 场景 / ${project.actions.length} 个已建模动作<br><span class="warning">${project.issues.filter(issue => !['resolved', 'cancelled'].includes(issue.status)).length} 项待确认 · ${project.changes.filter(change => change.status === 'pending').length} 项待审批</span></div><div class="project-foot"><small>${project.meta.status === 'published' ? `正式基线 ${project.meta.version}` : '本地草稿 · 等待首次发布'}</small><button class="btn small ${project.meta.id === store.currentProjectId ? 'primary' : ''}">${project.meta.status === 'published' ? '进入业务全景' : '继续构建'}</button></div></div>`).join('')}</div><div class="principle-strip"><div class="principle"><b>01</b><span>统一事实：参与者、场景、动作、规则、对象、事件与证据</span></div><div class="principle"><b>02</b><span>三类关系：结构组织、业务因果、知识关联分别表达</span></div><div class="principle"><b>03</b><span>稳定治理：草稿隔离、版本固定、影响可定位、验收需复核</span></div></div></div></div>`;
}

/* Reusable business information components */
function actorBadges(m, ids = []) { return ids.map(id => badge(actorName(m, id), 'blue')).join(' ') || '<span class="muted">尚未指定参与者</span>'; }
function objectChange(m, item, compact = false) {
  return `<div class="object-change-detail ${compact ? 'compact' : ''}"><div class="spread"><b>${esc(objectName(m, item.objectId))}</b><span class="mono">${esc(item.objectId)}</span></div><div class="state-transition"><span>${esc(item.before)}</span><i>→</i><b>${esc(item.after)}</b></div>${item.constraint ? `<small>${esc(item.constraint)}</small>` : ''}</div>`;
}
function ruleReference(m, ruleId) {
  const rule = E.byId(m.rules, ruleId); if (!rule) return '';
  const version = publishedRule(rule);
  return `<button class="rule-reference" data-rule="${rule.id}"><b>${rule.id}@${version?.version || '未发布'}</b><span>${esc(rule.name)}</span><i>查看规则与判断依据 →</i></button>`;
}
function scenarioItem(m, scenario) {
  return `<button class="scenario-item" data-scenario="${scenario.id}"><div class="spread"><h3>${esc(scenario.name)}</h3>${badge(scenario.full ? '可探索' : '概要', scenario.full ? 'green' : 'amber')}</div><p>${esc(scenario.goal)}</p><small class="mono">${scenario.id}</small><small> · ${scenario.stageIds.length} 阶段 · ${scenario.exceptionIds.length} 个异常</small></button>`;
}
function relationLegend() {
  return `<div class="relation-legend"><span><i class="line solid"></i>结构 / 正常流转</span><span><i class="line branch"></i>条件与并行</span><span><i class="line error"></i>异常与返回</span><span>所有业务关联通过统一关系表查询</span></div>`;
}

/* Project overview: one model, four observation lenses */
function domainScenarios(m, domainId) {
  const ids = new Set(m.actions.filter(action => action.domainId === domainId).map(action => action.scenarioId));
  m.stages.filter(stage => stage.domainId === domainId).forEach(stage => m.scenarios.forEach(scenario => { if (scenario.stageIds.includes(stage.id)) ids.add(scenario.id); }));
  return m.scenarios.filter(scenario => ids.has(scenario.id));
}
function renderOverview() {
  const m = M(), c = C(), scenario = currentScenario();
  const lenses = [['responsibilities', '业务职责'], ['activities', '主要业务活动'], ['actors', '用户角色'], ['objects', '核心业务对象']];
  return `${pageHead(m.meta.name, `${m.meta.id} · ${m.meta.status === 'published' ? `已发布 ${m.meta.version}` : '未发布草稿'}`, m.meta.goal || '尚未描述项目业务目标。', btn(m.meta.status === 'draft' ? '首次确认并发布' : '编辑业务目标', m.meta.status === 'draft' ? 'first-publish' : 'edit-goal', 'primary'))}
    <section class="business-world card"><div class="world-goal"><small>业务定位</small><h2>${esc(m.meta.goal || '先明确这个项目创造什么业务价值')}</h2><div class="world-actors">${m.actors.slice(0, 6).map(item => `<span>${badge(item.name, 'blue')}<small>${esc(item.concern)}</small></span>`).join('') || '<span class="muted">创建场景时添加参与者</span>'}</div></div><div class="world-objects"><small>核心结果与业务对象</small><div class="world-outcome">${esc(scenario?.result || '创建场景后定义成功结果')}</div>${m.objects.slice(0, 3).map(object => `<button data-object="${object.id}"><b>${esc(object.name)}</b><span class="mono">${object.id}</span><small>${object.states.slice(0, 3).join(' → ')}</small></button>`).join('')}</div></section>
    <div class="overview-workspace"><section class="card card-pad overview-territory"><div class="section-head"><div><small>业务认知地图</small><h2>选择观察角度，再选择一项深入</h2></div><div class="segmented">${lenses.map(([key, name]) => `<button class="${c.overviewLens === key ? 'active' : ''}" data-overview-lens="${key}">${name}</button>`).join('')}</div></div><div class="filterbar overview-filter"><div class="searchbox"><input class="input" id="overview-query" value="${esc(c.overviewQuery)}" placeholder="搜索当前视角"></div><span class="muted">选中状态在返回后保留</span></div>${overviewLens(m, c)}</section><aside class="card inspector overview-inspector">${overviewInspector(m, c)}</aside></div>
    ${scenario ? overviewChain(m, scenario) : ''}`;
}
function overviewLens(m, c) {
  const query = c.overviewQuery.toLowerCase();
  if (c.overviewLens === 'actors') {
    const actors = m.actors.filter(item => `${item.name}${item.id}`.toLowerCase().includes(query));
    return `<div class="cognition-grid">${actors.map(item => {
      const domains = m.domains.filter(domain => domain.actorIds.includes(item.id));
      return `<button class="cognition-cell ${c.overviewSelection === item.id ? 'selected' : ''}" data-overview-select="${item.id}" data-overview-type="actor"><span class="mono">${item.id}</span><h3>${esc(item.name)}</h3><p>${esc(item.concern)}</p><small>${domains.map(domain => domain.name).join('、') || '尚未关联领域'}</small></button>`;
    }).join('') || empty('⌕', '没有匹配角色', '调整搜索词。')}</div>`;
  }
  if (c.overviewLens === 'objects') {
    const objects = m.objects.filter(item => `${item.name}${item.id}`.toLowerCase().includes(query));
    return `<div class="cognition-grid">${objects.map(object => `<button class="cognition-cell ${c.overviewSelection === object.id ? 'selected' : ''}" data-overview-select="${object.id}" data-overview-type="object"><span class="mono">${object.id}</span><h3>${esc(object.name)}</h3><p>${esc(object.desc)}</p><small>${object.states.join(' → ')}</small></button>`).join('') || empty('▤', '没有业务对象', '对象只会在被真实建模后出现。')}</div>`;
  }
  if (c.overviewLens === 'activities') {
    return `<div class="domain-map dynamic">${m.domains.filter(domain => `${domain.name}${domain.id}`.toLowerCase().includes(query) || m.actions.some(action => action.domainId === domain.id && action.name.toLowerCase().includes(query))).map(domain => {
      const actions = m.actions.filter(action => action.domainId === domain.id && action.depth === 'detailed');
      return `<div class="map-domain"><button class="map-domain-title" data-overview-select="${domain.id}" data-overview-type="domain"><b>${esc(domain.name)}</b><span class="mono">${domain.id}</span></button><div class="activity-links">${actions.slice(0, 8).map(action => `<button data-open-action="${action.id}">${esc(action.name)}<span class="mono">${action.id}</span></button>`).join('') || '<small>尚无完整动作剖面</small>'}</div></div>`;
    }).join('')}</div>`;
  }
  return `<div class="domain-map dynamic">${m.domains.filter(domain => `${domain.name}${domain.id}`.toLowerCase().includes(query)).map(domain => `<div class="map-domain ${c.overviewSelection === domain.id ? 'selected' : ''}"><button class="map-domain-title" data-overview-select="${domain.id}" data-overview-type="domain"><i>${esc(domain.icon || '域')}</i><span><b>${esc(domain.name)}</b><small>${esc(domain.goal)}</small></span><span class="mono">${domain.id}</span></button><div class="capability-row">${domain.caps.map(id => { const capability = E.byId(m.capabilities, id); return capability ? `<button class="capability ${c.overviewSelection === id ? 'selected' : ''}" data-overview-select="${id}" data-overview-type="capability">${esc(capability.name)}</button>` : ''; }).join('') || '<small>尚未建立能力</small>'}</div></div>`).join('') || empty('◈', '建立第一个业务领域', '按业务职责组织项目，不按技术模块填空。', btn('＋ 添加领域', 'add-domain', 'primary'))}</div>`;
}
function overviewInspector(m, c) {
  const id = c.overviewSelection;
  const domain = E.byId(m.domains, id) || (!id ? m.domains[0] : null);
  const capability = E.byId(m.capabilities, id), object = E.byId(m.objects, id), selectedActor = E.byId(m.actors, id);
  if (capability) {
    const actions = m.actions.filter(action => action.capabilityIds?.includes(capability.id));
    const scenarioIds = [...new Set(actions.map(action => action.scenarioId))];
    return `<small>业务能力</small><h2>${esc(capability.name)}</h2><span class="mono">${capability.id}</span><p>${esc(capability.desc)}</p><div class="kv"><span>所属领域</span><span>${esc(domainName(m, capability.domainId))}</span><span>服务场景</span><span>${scenarioIds.length}</span></div>${scenarioIds.map(scenarioId => scenarioItem(m, E.byId(m.scenarios, scenarioId))).join('') || '<p class="muted">此能力尚未关联具体场景。</p>'}`;
  }
  if (object) return `<small>业务对象</small><h2>${esc(object.name)}</h2><span class="mono">${object.id}</span><p>${esc(object.desc)}</p><h3>生命周期</h3><div class="mini-lifecycle">${object.states.map((state, index) => `<span>${esc(state)}${index < object.states.length - 1 ? '<i>→</i>' : ''}</span>`).join('')}</div><button class="btn primary full-button" data-object="${object.id}">打开对象与变化动作</button>`;
  if (selectedActor) return `<small>参与者</small><h2>${esc(selectedActor.name)}</h2><span class="mono">${selectedActor.id}</span><p>${esc(selectedActor.concern)}</p><h3>参与动作</h3>${m.actions.filter(action => action.actorId === selectedActor.id && action.depth === 'detailed').slice(0, 6).map(action => `<button class="object-row" data-open-action="${action.id}"><b>${esc(action.name)}</b><span>→</span></button>`).join('') || '<p class="muted">尚无完整动作。</p>'}`;
  if (domain) return `<small>业务领域</small><h2>${esc(domain.name)}</h2><span class="mono">${domain.id}</span><p>${esc(domain.desc)}</p><div class="kv"><span>业务贡献</span><span>${esc(domain.goal)}</span><span>业务能力</span><span>${domain.caps.length}</span><span>相关场景</span><span>${domainScenarios(m, domain.id).length}</span></div>${domainScenarios(m, domain.id).slice(0, 3).map(scenario => scenarioItem(m, scenario)).join('')}<button class="btn full-button" data-domain="${domain.id}">进入领域工作区</button>`;
  return `<h2>选择一项业务信息</h2><p>检查器会保持当前视角，显示职责、场景、对象或参与者的实际关联。</p>`;
}
function overviewChain(m, scenario) {
  const stages = scenario.stageIds.map(id => E.byId(m.stages, id)).filter(Boolean), flow = E.flowFor(m, scenario.id);
  if (!stages.length) return '';
  return `<section class="card card-pad operating-model"><div class="section-head"><div><small>端到端业务链路 · ${esc(scenario.name)}</small><h2>节点间存在真实流转关系</h2></div><button class="btn small" data-scenario="${scenario.id}">进入故事板 →</button></div><div class="operating-chain">${stages.map((stage, index) => {
    const next = stages[index + 1], linked = next && flow.edges.some(edge => {
      const from = flow.nodes.find(node => node.id === edge.from), to = flow.nodes.find(node => node.id === edge.to);
      return from?.stageId === stage.id && to?.stageId === next.id && !edge.defaultCollapsed;
    });
    return `<button class="operating-stage" data-operating-stage="${stage.id}"><span class="stage-index">${String(index + 1).padStart(2, '0')}</span><b>${esc(stage.name)}</b><small>输入：${esc(stage.input)}</small><p>结果：${esc(stage.result)}</p>${next ? `<i>${linked ? '→' : '⋯'}</i>` : ''}</button>`;
  }).join('')}</div><div class="operation-caption"><span>只展示场景中已定义的阶段与连接；分支、异常和对象变化在故事板展开。</span><span>${scenario.id}@${scenario.version}</span></div></section>`;
}

function renderDomain() {
  const m = M(), c = C(), domain = E.byId(m.domains, c.selectedDomainId) || m.domains[0];
  if (!domain) return pageHead('业务地图', '尚未建立领域', '先建立业务职责边界。', btn('＋ 添加领域', 'add-domain', 'primary')) + `<section class="card">${empty('◈', '没有业务领域', '从项目全景添加第一个领域。')}</section>`;
  c.selectedDomainId = domain.id;
  const scenarios = domainScenarios(m, domain.id), actions = m.actions.filter(action => action.domainId === domain.id);
  return `${pageHead(domain.name, `${domain.id} · ${m.meta.name}`, domain.desc, btn('返回业务全景', 'back-overview') + btn('＋ 创建场景', 'add-scenario', 'primary'))}<div class="context-bar"><button data-action="back-overview">业务全景</button>›<b>${esc(domain.name)}</b></div><div class="domain-work"><div class="stack"><section class="card card-pad"><div class="section-head"><h2>能力与场景</h2><small>能力服务于哪些业务结果</small></div><div class="cap-groups">${domain.caps.map(id => E.byId(m.capabilities, id)).filter(Boolean).map(capability => `<button class="cap-card" data-overview-select="${capability.id}" data-overview-type="capability" data-capability-open="true"><span class="tag blue">${capability.id}</span><h3>${esc(capability.name)}</h3><p class="muted">${esc(capability.desc)}</p><small>${m.actions.filter(action => action.capabilityIds?.includes(capability.id)).length} 个关联动作</small></button>`).join('') || '<p class="muted">尚未建立能力。</p>'}</div><div class="scenario-list">${scenarios.map(scenario => scenarioItem(m, scenario)).join('') || '<p class="muted">尚无关联场景。</p>'}</div></section><section class="card card-pad"><div class="section-head"><h2>动作索引</h2><button class="btn small" data-action="actions-index">筛选与搜索</button></div>${actions.slice(0, 12).map(action => `<button class="object-row" data-open-action="${action.id}"><span><b>${esc(action.name)}</b><small class="mono">${action.id}</small></span>${badge(action.depth === 'detailed' ? '完整' : '概要', action.depth === 'detailed' ? 'green' : 'amber')}</button>`).join('') || '<p class="muted">尚无动作。</p>'}</section></div><aside class="stack"><section class="card card-pad"><h2>业务对象</h2>${domain.objects.map(id => E.byId(m.objects, id)).filter(Boolean).map(object => `<button class="object-row" data-object="${object.id}"><span><b>${esc(object.name)}</b><small>${esc(object.desc)}</small></span><span>→</span></button>`).join('') || '<p class="muted">此领域尚未声明对象。</p>'}</section><section class="card card-pad"><h2>参与者</h2>${actorBadges(m, domain.actorIds)}<div class="divider"></div><p class="muted">参与者的实际动作和决策从统一动作模型计算。</p></section></aside></div>`;
}

/* Scenario storyboard: semantic zoom, causal graph and condition exploration */
function scenarioVersionsForExplore(m, scenario) {
  return (scenario.explore?.ruleIds || []).map(id => E.byId(m.rules, id)).filter(Boolean).map(rule => publishedRule(rule)).filter(Boolean);
}
function ensureExploreValues(m, scenario) {
  const c = C(), versions = scenarioVersionsForExplore(m, scenario);
  versions.forEach(version => { const defaults = E.defaultValues(version); Object.entries(defaults).forEach(([key, value]) => { if (c.exploreValues[key] === undefined) c.exploreValues[key] = value; }); });
  return c.exploreValues;
}
function renderScenario() {
  const m = M(), c = C(), scenario = currentScenario();
  if (!scenario) return pageHead('业务故事板', '尚未创建场景', '通过参与者、触发条件和结果开始。', btn('＋ 创建场景', 'add-scenario', 'primary')) + `<section class="card">${empty('⇢', '没有业务场景', '创建后沿用统一动作、规则、对象和关系模型。')}</section>`;
  c.selectedScenarioId = scenario.id;
  const stages = scenario.stageIds.map(id => E.byId(m.stages, id)).filter(Boolean);
  if (!stages.length) return renderScenarioBuilder(scenario);
  let selectedStage = E.byId(m.stages, c.selectedStageId);
  if (!selectedStage || !scenario.stageIds.includes(selectedStage.id)) { selectedStage = stages[0]; c.selectedStageId = selectedStage.id; }
  const flow = E.flowFor(m, scenario.id), values = ensureExploreValues(m, scenario), evaluation = E.evaluateFlow(m, scenario.id, values);
  const selectedAction = E.byId(m.actions, c.storyNodeId) || m.actions.find(action => action.stageId === selectedStage.id);
  const scenarioSteps = m.steps.filter(step => scenario.stageIds.includes(step.stageId));
  return `${pageHead(scenario.name, `${scenario.id}@${scenario.version} · ${scenarioSteps.length} 个步骤 · ${stages.length} 个阶段`, scenario.goal, `<select class="version-select" id="scenario-switch">${m.scenarios.map(item => `<option value="${item.id}" ${item.id === scenario.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select>${btn('编辑场景', 'edit-scenario')}${btn(c.focus ? '退出焦点' : '局部焦点', 'focus', 'primary')}`)}<div class="context-bar"><button data-action="back-overview">业务全景</button>›<button data-action="scenario-list">场景</button>›<b>${esc(selectedStage.name)}</b>${selectedAction ? `<span class="context-note">选中 ${selectedAction.id}</span>` : ''}</div><section class="story-trigger card"><div><small>触发</small><p>${esc(scenario.trigger)}</p></div><div><small>参与角色</small><p>${actorBadges(m, scenario.participants)}</p></div><div><small>最终业务结果</small><p>${esc(scenario.result)}</p></div></section><section class="card story-scale"><div class="section-head"><div><small>故事全貌</small><h2>${stages.length} 个实际阶段，选择一层深入</h2></div><button class="btn small" data-action="exceptions">异常 ${scenario.exceptionIds.length}</button></div><div class="phase-track dynamic">${stages.map((stage, index) => {
    const hasDecision = flow.nodes.some(node => node.stageId === stage.id && ['decision', 'parallel'].includes(node.type));
    const hasRisk = m.exceptions.some(exception => exception.stepIds?.some(stepId => E.byId(m.steps, stepId)?.stageId === stage.id) || E.byId(m.steps, exception.stepId)?.stageId === stage.id);
    return `<button class="phase-card ${stage.id === selectedStage.id ? 'active' : ''}" data-stage="${stage.id}"><span class="phase-no">${String(index + 1).padStart(2, '0')}</span><h3>${esc(stage.name)}</h3><p>${esc(stage.goal)}</p><div><small>${stage.actorIds.map(id => actorName(m, id)).join(' / ')}</small>${badge(`${stage.stepIds.length} 步`)}</div><footer><span>输入：${esc(stage.input)}</span><b>结果：${esc(stage.result)}</b><span>${hasDecision ? '含关键分支' : ''}${hasRisk ? ' · 含异常恢复' : ''}</span></footer></button>`;
  }).join('')}</div></section>${scenario.explore ? renderExplorer(m, scenario, versionsUnique(scenarioVersionsForExplore(m, scenario)), evaluation, values) : ''}<div class="story-detail-layout ${c.focus ? 'focused' : ''}"><section class="card story-canvas causal-canvas"><div class="section-head"><div><small>子流程画布 · ${esc(selectedStage.name)}</small><h2>动作、条件与对象变化形成因果路径</h2></div><div class="actions">${btn(c.showExceptions ? '折叠异常' : '展开异常', 'toggle-exceptions', 'small')}${c.explore ? btn('退出探索', 'toggle-explore', 'small') : ''}</div></div>${relationLegend()}${renderFlowCanvas(m, flow, selectedStage.id, evaluation, c)}</section><aside class="card inspector story-inspector">${selectedAction ? actionInspector(m, selectedAction) : flowNodeInspector(m, c.selectedFlowNodeId, flow)}</aside></div>`;
}
function versionsUnique(versions) {
  const inputs = new Map();
  versions.forEach(version => version.inputs.forEach(input => { if (!inputs.has(input.id)) inputs.set(input.id, input); }));
  return [...inputs.values()];
}
function renderExplorer(m, scenario, inputs, evaluation, values) {
  const c = C();
  const outcomes = evaluation.explanations.filter(result => result.ruleId && scenario.explore.ruleIds.includes(result.ruleId));
  return `<section class="card explorer ${c.explore ? 'active' : ''}"><div class="section-head"><div><small>探索业务结果 · 规范试算，不修改业务数据</small><h2>${c.explore ? '当前条件决定高亮路径与参与角色' : '修改关键条件，理解为什么会走这条路径'}</h2></div>${btn(c.explore ? '收起探索' : '探索业务结果', 'toggle-explore', c.explore ? '' : 'primary')}</div>${c.explore ? `<div class="explorer-body"><div class="explorer-inputs">${inputs.map(input => `<div class="field"><label>${esc(input.label)}</label><select data-explore-input="${input.id}">${selectOptions(input.options.map(option => [option.value, option.label]), values[input.id])}</select></div>`).join('') || '<p class="muted">当前场景没有可试算条件。</p>'}</div><div class="explorer-result"><div class="result-box"><b>${outcomes.map(result => esc(result.outcome?.label || result.code)).join('；') || '没有可用判断结果'}</b><p>本次参与：${evaluation.actorIds.length ? evaluation.actorIds.map(id => actorName(m, id)).join('、') : '按路径动作确定'}</p><small>${outcomes.map(result => `${result.ruleId}@${result.ruleVersion} · ${result.explanation}`).join(' ') || '未命中独立规则'}</small></div><div class="path-summary"><div><small>将经过的动作</small><b>${evaluation.actions.length}</b></div><div><small>可观察对象变化</small><b>${evaluation.objectChanges.length}</b></div></div><div class="explorer-changes">${evaluation.objectChanges.slice(0, 4).map(item => objectChange(m, item, true)).join('') || '<p class="muted">当前路径没有已声明对象变化。</p>'}</div></div></div><p class="explorer-note">高亮为本次经过路径；淡化节点为当前不会执行的分支。点击命中规则可继续查看版本化决策表。</p>` : ''}</section>`;
}
function renderFlowCanvas(m, flow, stageId, evaluation, c) {
  if (!flow.nodes.length) return empty('⇢', '尚未建立流转关系', '为此场景添加动作后生成可探索流程。');
  const layout = E.layoutFlow(flow, stageId, c.showExceptions), position = layout.positions;
  const paths = layout.edges.map(edge => {
    const from = position[edge.from], to = position[edge.to]; if (!from || !to) return '';
    const x1 = from.x + from.width, y1 = from.y + from.height / 2, x2 = to.x, y2 = to.y + from.height / 2;
    const backward = to.rank <= from.rank, mid = backward ? Math.max(30, Math.abs(y2 - y1) / 2 + 50) : Math.max(30, (x2 - x1) / 2);
    const path = backward ? `M ${from.x + from.width / 2} ${from.y + from.height} C ${from.x + from.width / 2} ${from.y + from.height + mid}, ${to.x + to.width / 2} ${to.y + to.height + mid}, ${to.x + to.width / 2} ${to.y + to.height}` : `M ${x1} ${y1} C ${x1 + mid} ${y1}, ${x2 - mid} ${y2}, ${x2} ${y2}`;
    const active = c.explore && evaluation.edgeIds.has(edge.id), dim = c.explore && !active;
    const labelX = backward ? (from.x + to.x + to.width) / 2 : (x1 + x2) / 2, labelY = backward ? Math.max(from.y, to.y) + 145 : (y1 + y2) / 2 - 8;
    return `<path class="flow-edge ${edge.type} ${active ? 'active' : ''} ${dim ? 'dim' : ''}" d="${path}" marker-end="url(#arrow-${edge.type})"/>${edge.label ? `<text class="flow-edge-label ${dim ? 'dim' : ''}" x="${labelX}" y="${labelY}" text-anchor="middle">${esc(edge.label)}</text>` : ''}`;
  }).join('');
  const nodes = layout.nodes.map(node => {
    const action = E.byId(m.actions, node.actionId), name = action?.name || node.name || node.id;
    const active = c.explore && evaluation.nodeIds.has(node.id), dim = c.explore && !active;
    const selected = action?.id === c.storyNodeId || node.id === c.selectedFlowNodeId;
    return `<button class="causal-node ${node.type} ${active ? 'path-active' : ''} ${dim ? 'path-dim' : ''} ${selected ? 'selected' : ''}" style="left:${node.x}px;top:${node.y}px;width:${node.width}px;min-height:${node.height}px" data-flow-node="${node.id}" data-flow-action="${node.actionId || ''}"><span class="node-type">${nodeTypeName(node.type)}</span><b>${esc(name)}</b><span class="mono">${node.actionId || node.id}</span><small>${esc(actorName(m, action?.actorId || node.actorId))}</small>${action?.depth === 'summary' ? badge('概要', 'amber') : ''}${node.ruleId ? `<span class="node-rule">◇ ${node.ruleId}</span>` : ''}</button>`;
  }).join('');
  return `<div class="flow-scroll"><div class="flow-graph" style="width:${layout.width}px;height:${layout.height + 100}px"><svg width="${layout.width}" height="${layout.height + 100}" viewBox="0 0 ${layout.width} ${layout.height + 100}" aria-hidden="true"><defs>${['next', 'when', 'parallel', 'join', 'error', 'return', 'terminate'].map(type => `<marker id="arrow-${type}" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L0,6 L7,3 z" class="arrow-${type}"/></marker>`).join('')}</defs>${paths}</svg>${nodes}</div></div>`;
}
function nodeTypeName(type) { return { start: '开始', action: '业务动作', decision: '业务判断', event: '业务事件', parallel: '并行分支', join: '并行汇合', exception: '异常处理', end: '业务终点' }[type] || type; }
function actionInspector(m, action) {
  const rules = E.actionRules(m, action.id), step = E.byId(m.steps, action.stepId);
  return `<small>动作检查器</small><div class="inspector-badges">${badge(action.id, 'blue')}${badge(action.depth === 'detailed' ? '完整剖面' : '概要 / 待完善', action.depth === 'detailed' ? 'green' : 'amber')}</div><h2>${esc(action.name)}</h2><p>${esc(action.purpose || '此步骤保留业务名称与结构位置，独立业务语义仍待分析。')}</p><div class="kv"><span>执行者</span><span>${esc(actorName(m, action.actorId))}</span><span>步骤</span><span>${esc(step?.id || '未建立')}</span><span>输入</span><span>${action.input.map(esc).join('、') || '待完善'}</span><span>输出</span><span>${action.output.map(esc).join('、') || '待完善'}</span></div><h3>命中规则</h3>${rules.map(({ rule }) => ruleReference(m, rule.id)).join('') || '<p class="muted">无直接规则引用。</p>'}<h3>对象变化</h3>${action.objectChanges.map(item => objectChange(m, item, true)).join('') || '<p class="muted">未声明对象变化。</p>'}<button class="btn primary full-button" data-open-action="${action.id}">打开完整动作剖面</button>`;
}
function flowNodeInspector(m, nodeId, flow) {
  const node = E.byId(flow.nodes, nodeId);
  if (!node) return `<h2>选择流程节点</h2><p>判断节点可打开规则；动作节点可继续深入输入、异常、实现和证据。</p>`;
  return `<small>${nodeTypeName(node.type)}</small><h2>${esc(node.name || node.id)}</h2><p>${esc(actorName(m, node.actorId))}</p>${node.ruleId ? ruleReference(m, node.ruleId) : '<p class="muted">此节点用于表达流程结构，没有独立动作剖面。</p>'}`;
}
function renderScenarioBuilder(scenario) {
  const m = M(), actions = m.actions.filter(action => action.scenarioId === scenario.id);
  return `${pageHead(scenario.name, `${scenario.id} · ${statusText(scenario.status)}`, scenario.goal, btn('＋ 添加业务动作', 'add-action', 'primary'))}<div class="context-bar"><button data-action="back-overview">业务全景</button>›<b>${esc(scenario.name)}</b></div><section class="story-trigger card"><div><small>参与者</small><p>${actorBadges(m, scenario.participants)}</p></div><div><small>触发条件</small><p>${esc(scenario.trigger)}</p></div><div><small>期望结果</small><p>${esc(scenario.result)}</p></div></section><section class="card card-pad"><div class="section-head"><h2>业务动作</h2><small>新项目从真实动作开始，不生成虚构分支</small></div>${actions.map(action => `<div class="business-step" data-open-action="${action.id}"><div class="step-sequence"><span>${E.byId(m.steps, action.stepId)?.number || '—'}</span></div><div class="step-actor">${badge(actorName(m, action.actorId), 'blue')}</div><div class="step-main"><b>${esc(action.name)}</b><span class="mono">${action.id}</span><p>${esc(action.purpose || '业务目的待完善')}</p></div></div>`).join('') || empty('□', '添加第一个业务动作', '动作创建后拥有稳定 ID，可继续关联规则和对象。', btn('＋ 添加动作', 'add-action', 'primary'))}</section>`;
}

/* Action profile: premise -> action / decision -> observable result */
function renderAction() {
  const m = M(), action = currentAction();
  if (!action) return pageHead('业务动作', '未建立动作', '从场景或索引选择业务动作。') + `<section class="card">${empty('□', '没有动作详情', '当前项目尚未创建该业务动作。')}</section>`;
  const scenario = E.byId(m.scenarios, action.scenarioId), stage = E.byId(m.stages, action.stageId), step = E.byId(m.steps, action.stepId);
  return `${pageHead(action.name, `${action.id}@${action.version} · ${statusText(action.status)}`, action.purpose || '概要步骤：独立业务目的、输入输出与证据仍待完善。', btn('返回原上下文', 'return-context') + btn('提出修改', 'edit-action', 'primary'))}<div class="context-bar"><button data-action="back-overview">${esc(m.meta.name)}</button>›<button data-action="back-scenario">${esc(scenario?.name || '动作索引')}</button>›<span>${esc(stage?.name || '未分组')} / ${esc(step?.id || '未分步')}</span>›<b>${action.id}</b>${badge(action.depth === 'detailed' ? '完整' : '概要 / 待完善', action.depth === 'detailed' ? 'green' : 'amber')}</div><div class="tabs action-lenses">${[['business', '业务行为'], ['implementation', '技术信息流'], ['evidence', '来源与证据'], ['history', '版本与历史']].map(([key, name]) => `<button class="tab ${state.actionLens === key ? 'active' : ''}" data-action-lens="${key}">${name}</button>`).join('')}</div>${state.actionLens === 'business' ? actionBusiness(m, action) : state.actionLens === 'implementation' ? actionImplementation(m, action) : state.actionLens === 'evidence' ? actionEvidence(m, action) : actionHistory(m, action)}`;
}
function actionBusiness(m, action) {
  const rules = E.actionRules(m, action.id);
  return `<section class="action-causality"><div class="causal-column premise"><small>01 · 前置事实</small><h2>谁触发，允许在什么状态发生</h2><div class="causal-actor">${badge(actorName(m, action.actorId), 'blue')}</div>${action.pre.length ? `<ul>${action.pre.map(item => `<li>${esc(item)}</li>`).join('')}</ul>` : '<p class="muted">前置约束待完善。</p>'}<h3>输入</h3>${action.input.map(item => `<span class="fact-chip">${esc(item)}</span>`).join('') || '<p class="muted">输入待完善。</p>'}</div><div class="causal-connector">→</div><div class="causal-column operation"><small>02 · 动作与判断</small><h2>${esc(action.name)}</h2><p>${esc(action.purpose || '独立业务描述待完善。')}</p>${rules.length ? `<div class="action-rules">${rules.map(({ rule, version }) => `<div><button class="link inline-link" data-rule="${rule.id}">${rule.id}@${version?.version || '未发布'} · ${esc(rule.name)}</button><p>${esc(version?.summary || '规则版本不可用')}</p></div>`).join('')}</div>` : '<p class="muted">此动作不直接引用业务规则。</p>'}<h3>输出</h3>${action.output.map(item => `<span class="fact-chip output">${esc(item)}</span>`).join('') || '<p class="muted">输出待完善。</p>'}</div><div class="causal-connector">→</div><div class="causal-column result"><small>03 · 业务变化</small><h2>对象状态与新增事实</h2>${action.objectChanges.map(item => objectChange(m, item)).join('') || '<p class="muted">没有已声明的对象变化。</p>'}</div></section><div class="grid-2 action-secondary"><section class="card card-pad"><div class="section-head"><h2>异常与恢复</h2><small>${action.exceptions.length} 个直接关联</small></div>${action.exceptions.map(id => E.byId(m.exceptions, id)).filter(Boolean).map(exception => `<button class="exception-row" data-exception="${exception.id}"><b>${exception.id} · ${esc(exception.name)}</b><span>${esc(exception.trigger)}</span><i>${esc(exception.recovery)}</i></button>`).join('') || '<p class="muted">未定义独立异常分支。</p>'}</section><section class="card card-pad"><h2>精确定位</h2><div class="kv"><span>场景</span><span>${esc(action.scenarioId || '未关联')}</span><span>步骤</span><span>${esc(action.stepId || '未关联')}</span><span>界面</span><span>${E.relationIndex(m).sources(action.id, 'triggers').join('、') || '无独立 UI 入口'}</span><span>实现</span><span>${esc(action.implementation?.status || '尚未建立映射')}</span></div></section></div>`;
}
function actionImplementation(m, action) {
  const implementation = action.implementation;
  if (!implementation) return `<section class="card">${empty('◇', '尚未建立技术映射', `${action.id} 没有独立实现资料，不使用其他动作的接口或证据补全。`)}</section>`;
  const chain = [
    ['UI 操作或自动触发', implementation.trigger], ['接口或入口', implementation.api], ['读取数据', implementation.reads.join('、')],
    ['业务条件', implementation.decision], ['新增 / 更新数据', implementation.writes.join('、')], ['业务事件', implementation.event], ['外部系统', implementation.external]
  ].filter(([, value]) => value && value !== '无');
  return `<section class="card implementation-flow"><div class="section-head"><div><h2>围绕同一个动作的信息流</h2><small>技术映射具有独立核验状态</small></div>${badge(implementation.status, implementation.status === '已核验' ? 'green' : 'amber')}</div><div class="implementation-chain dynamic">${chain.map(([name, value], index) => `<div><small>${String(index + 1).padStart(2, '0')} · ${esc(name)}</small><b>${esc(value)}</b></div>`).join('')}</div></section><div class="grid-2 action-secondary"><section class="card card-pad"><h2>一致性与失败处理</h2><div class="relation-box"><b>事务与幂等</b><p>${esc(implementation.transaction)}</p></div><div class="relation-box"><b>失败、重试与补偿</b><p>${esc(implementation.failure)}</p></div></section><section class="card card-pad"><h2>测试与核验</h2><p>${esc(implementation.test)}</p><div class="notice ${implementation.status === '已核验' ? 'green' : 'amber'}">${implementation.status === '已核验' ? '技术映射已核验；业务正确性仍由业务负责人确认。' : '映射仍包含待核验内容，不能视为已完成技术审查。'}</div></section></div>`;
}
function actionEvidence(m, action) {
  const ids = new Set(action.evidence || []); E.relationIndex(m).sources(action.id, 'supports').forEach(id => ids.add(id));
  const facts = [...ids].map(id => E.byId(m.facts, id)).filter(Boolean);
  return `<section class="card card-pad"><div class="section-head"><div><h2>来源、结论与核验状态</h2><small>历史资料、当前规范和实现观察互不冒充</small></div>${badge(`${facts.length} 条来源`)}</div>${facts.length ? factTable(facts) : empty('▤', '尚无事实证据', '该动作没有可展示的规范、实现或历史证据。')}</section>`;
}
function factTable(facts) {
  return `<div class="fact-table"><div class="fact-header"><span>事实类型 / 来源</span><span>结论</span><span>状态</span></div>${facts.map(fact => `<div class="fact-row ${fact.kind}"><div><b>${factKind(fact.kind)}</b><span>${esc(fact.source)}</span><small>${esc(fact.date)} · ${esc(fact.owner)}</small></div><p>${esc(fact.conclusion)}</p><div>${badge(fact.status, ['已批准', '已核验'].includes(fact.status) ? 'green' : fact.status === '待核验' ? 'amber' : '')}</div></div>`).join('')}</div>`;
}
function factKind(kind) { return { history: '历史业务资料', specification: '已批准业务规范', implementation: '当前实现 / 观察' }[kind] || kind; }
function actionHistory(m, action) {
  const ruleRefs = E.actionRules(m, action.id);
  return `<div class="grid-2"><section class="card card-pad"><h2>版本与草稿隔离</h2><div class="evidence-source"><b>${action.id}@${action.version} · ${statusText(action.status)}</b><p>${esc(action.purpose || '概要待完善')}</p></div>${action.draft ? `<div class="diff-after"><b>未提交草稿</b><p>${esc(action.draft.purpose)}</p><small>普通阅读仍读取已发布定义。</small></div>` : '<p class="muted">当前没有未提交草稿。</p>'}</section><section class="card card-pad"><h2>固定版本引用</h2><div class="kv"><span>场景</span><span>${esc(action.scenarioId)}@${esc(E.byId(m.scenarios, action.scenarioId)?.version || '—')}</span><span>规则</span><span>${ruleRefs.map(({ rule }) => `${rule.id}@${rule.currentVersion || '未发布'}`).join('、') || '无'}</span><span>交接</span><span>${m.deliveries.filter(delivery => delivery.actionIds.includes(action.id)).map(delivery => delivery.id).join('、') || '尚未引用'}</span></div></section></div>`;
}

/* Knowledge index and authoritative rule workbench */
function renderKnowledge() {
  const m = M(), c = C();
  return `${pageHead('业务知识', 'RULE · OBJECT · ACTION · 稳定身份', '所有列表、数量和反向影响均从当前项目数据及统一关系计算。', btn('＋ 新建知识', 'new-knowledge', 'primary'))}<div class="tabs">${[['rules', `业务规则 ${m.rules.length}`], ['objects', `业务对象 ${m.objects.length}`], ['actions', `业务动作 ${m.scale.actions || m.actions.length}`]].map(([key, name]) => `<button class="tab ${c.knowledgeTab === key ? 'active' : ''}" data-knowledge-tab="${key}">${name}</button>`).join('')}</div>${c.knowledgeTab === 'rules' ? renderRules() : c.knowledgeTab === 'objects' ? renderObjects() : renderActionsIndex()}`;
}
function ruleDisplayVersion(m, rule) {
  const c = C(), change = E.byId(m.changes, c.rulePreviewChange);
  if (change?.ruleId === rule.id && change.draftRule) return { version: change.draftRule, draft: true, change };
  const version = rule.versions[c.ruleVersion] || publishedRule(rule);
  return { version, draft: version?.status === 'draft', change: null };
}
function renderRules() {
  const m = M(), c = C(), rule = currentRule();
  if (!rule) return `<section class="card">${empty('◇', '还没有业务规则', '创建第一条规则并关联场景动作。', btn('＋ 添加规则', 'add-rule', 'primary'))}</section>`;
  c.selectedRuleId = rule.id;
  const display = ruleDisplayVersion(m, rule), version = display.version;
  if (!version) return `<section class="card">${empty('◇', '规则版本不可用', '指定版本不存在，不会自动替换为其他版本。')}</section>`;
  const usage = E.ruleUsage(m, rule.id), active = m.changes.filter(change => change.ruleId === rule.id && !['approved', 'cancelled'].includes(change.status));
  return `${state.returnContext ? `<div class="context-bar"><button data-action="return-context">← 返回原业务上下文</button><span>动作、场景与阶段选择已保留</span></div>` : ''}<div class="knowledge-layout"><aside class="card rule-index"><div class="section-head"><h3>规则目录</h3><button class="btn small" data-action="add-rule">＋</button></div>${m.rules.map(item => `<button class="${item.id === rule.id ? 'active' : ''}" data-select-rule="${item.id}"><b>${esc(item.name)}</b><span class="mono">${item.id}@${item.currentVersion || '草稿'}</span><small>${publishedRule(item)?.supportsEvaluation === false ? '人工约束' : '结构化决策'}</small></button>`).join('')}</aside><div class="stack"><section class="card card-pad"><div class="section-head"><div><h2>${esc(rule.name)}</h2><span class="mono muted">${rule.id}@${version.version} · ${statusText(version.status)}${display.change ? ` · 读取 ${display.change.id} 草稿预览` : ''}</span></div><div class="actions"><select class="version-select" id="rule-version">${Object.keys(rule.versions).reverse().map(key => `<option value="${key}" ${!display.change && version.version === key ? 'selected' : ''}>${key} · ${statusText(rule.versions[key].status)}</option>`).join('')}</select>${btn('影响范围', 'rule-impact')}${btn(version.status === 'historical' ? '基于当前版本修改' : '提出修改', 'edit-rule', 'primary')}</div></div>${display.change ? `<div class="notice purple"><b>草稿预览：</b>普通业务阅读和正式交接仍使用 ${rule.id}@${rule.currentVersion || '未发布'}。<button class="link inline-link" data-action="clear-rule-preview">退出草稿预览</button></div>` : ''}<div class="rule-semantics"><div><small>适用范围</small><p>${esc(version.scope || '尚未描述')}</p></div><div><small>由结构化定义生成的业务摘要</small><p>${esc(version.summary || E.summarizeRule(version))}</p></div><div><small>版本与来源</small><p>${esc(version.effective || '未发布')} · ${esc(version.source || '未建立')}</p></div></div>${renderDecisionTable(m, version)}${active.length ? `<div class="notice blue">${active.map(change => `<button class="link inline-link" data-change="${change.id}">${change.id} · ${change.targetVersion} · ${statusText(change.status)}</button>`).join('；')} 草稿与已发布版本分开保存。</div>` : ''}</section><section class="card card-pad rule-simulator"><div class="section-head"><div><h2>条件试算</h2><small>实际执行 ${rule.id}@${version.version} 的结构化条件、优先级和例外</small></div>${badge(version.supportsEvaluation === false ? '不支持自动试算' : display.draft ? '草稿结果' : '指定版本结果', display.draft ? 'purple' : 'green')}</div>${renderRuleSimulator(m, version, rule)}</section><section class="card card-pad"><div class="section-head"><h2>直接引用与间接影响</h2><button class="btn small" data-action="rule-impact">完整清单</button></div><div class="impact-summary"><div class="impact-stat"><b>${usage.actions.length}</b><small>直接引用动作</small></div><div class="impact-stat"><b>${usage.scenarios.length}</b><small>间接关联场景</small></div><div class="impact-stat"><b>${usage.surfaces.length}</b><small>需审查界面映射</small></div><div class="impact-stat"><b>${usage.acceptance.length}</b><small>关联验收条件</small></div></div></section></div></div>`;
}
function renderDecisionTable(m, version) {
  if (version.supportsEvaluation === false) return `<div class="notice blue"><b>结构化约束：</b>${esc(version.constraint || version.summary)}<br>此规则需人工核验，不生成空白决策表。</div>`;
  const rows = [...(version.exceptions || []).map(row => ({ ...row, exception: true })), ...(version.rows || [])];
  if (!rows.length) return '<p class="muted">尚未建立决策行。</p>';
  return `<div class="table-scroll"><table class="condition-table decision-table dynamic"><thead><tr><th>类型 / 优先级</th>${version.inputs.map(input => `<th>${esc(input.label)}</th>`).join('')}<th>决策结果</th><th>参与角色</th></tr></thead><tbody>${rows.sort((a, b) => a.priority - b.priority).map(row => {
    const outcome = version.outcomes.find(item => item.id === row.outcomeId);
    return `<tr class="${row.exception ? 'exception-row-bg' : ''}"><td>${row.exception ? '例外' : '决策'} · ${row.priority}</td>${version.inputs.map(input => `<td>${row.when[input.id] !== undefined && row.when[input.id] !== 'any' ? esc(input.options.find(option => option.value === row.when[input.id])?.label || row.when[input.id]) : '<span class="muted">任意</span>'}</td>`).join('')}<td>${badge(outcome?.label || row.outcomeId, 'purple')}</td><td>${(outcome?.actorIds || []).map(id => actorName(m, id)).join('、') || '—'}</td></tr>`;
  }).join('')}</tbody></table></div>`;
}
function renderRuleSimulator(m, version, rule) {
  if (version.supportsEvaluation === false) return '<p class="muted">此约束提供人工核验说明，不能伪造自动试算结果。</p>';
  const c = C(), key = `${rule.id}@${version.version}`;
  c.ruleSim[key] ||= E.defaultValues(version);
  const values = c.ruleSim[key], result = E.evaluateRule(version, values);
  return `<div class="simulator-grid"><div class="simulator-inputs">${version.inputs.map(input => `<div class="field"><label>${esc(input.label)}</label><select data-rule-sim="${input.id}" data-sim-key="${esc(key)}">${selectOptions(input.options.map(option => [option.value, option.label]), values[input.id])}</select></div>`).join('')}</div><div class="result-box ${['NO_MATCH', 'CONFLICT', 'OUTCOME_MISSING'].includes(result.code) ? 'error' : ''}"><b>试算结果：${esc(result.outcome?.label || result.code)}</b><p>参与角色：${(result.outcome?.actorIds || []).map(id => actorName(m, id)).join('、') || '无指定角色'}</p><small>${esc(result.explanation)}</small></div></div>`;
}
function renderObjects() {
  const m = M(), c = C(), object = E.byId(m.objects, c.selectedObjectId) || m.objects[0];
  if (!object) return `<section class="card">${empty('▤', '尚未建立业务对象', '对象只在被真实建模后出现，不生成空生命周期。')}</section>`;
  c.selectedObjectId = object.id;
  const actions = m.actions.filter(action => action.objectChanges.some(item => item.objectId === object.id));
  return `<div class="object-layout"><aside class="card object-index"><h3>业务对象</h3>${m.objects.map(item => `<button class="${item.id === object.id ? 'active' : ''}" data-select-object="${item.id}"><b>${esc(item.name)}</b><span class="mono">${item.id}</span></button>`).join('')}</aside><div class="stack"><section class="card card-pad"><div class="section-head"><div><h2>${esc(object.name)}</h2><span class="mono muted">${object.id} · ${statusText(object.status || 'published')}</span></div>${btn('提出修改', 'edit-object', 'primary')}</div><p>${esc(object.desc)}</p><div class="relation-box"><small>核心属性</small><h3>${object.props.map(esc).join(' · ')}</h3></div></section><section class="card lifecycle"><div class="section-head"><h2>业务生命周期</h2><small>状态来自对象定义，实际变化由动作造成</small></div><div class="life-track dynamic">${object.states.map((state, index) => `<div class="life-state"><span class="life-dot"></span><b>${esc(state)}</b><small>${index === 0 ? '起点' : index === object.states.length - 1 ? '终点' : '可观察状态'}</small></div>`).join('')}</div></section><section class="card card-pad"><h2>造成变化的动作</h2>${actions.map(action => `<button class="object-row" data-open-action="${action.id}"><span><b>${esc(action.name)}</b><small class="mono">${action.id}@${action.version}</small></span><span>${action.objectChanges.filter(item => item.objectId === object.id).length} 项变化 →</span></button>`).join('') || '<p class="muted">尚无动作声明此对象的变化。</p>'}</section></div></div>`;
}
function renderActionsIndex() {
  const m = M(), c = C(), all = [...m.actions, ...AtlasModel.scaleIndex(m, 'actions')];
  const filtered = all.filter(action => (!c.actionDomain || action.domainId === c.actionDomain) && (!c.actionActor || action.actorId === c.actionActor) && (!c.actionDepth || (c.actionDepth === 'index' ? action.indexOnly : action.depth === c.actionDepth)) && `${action.id}${action.name}`.toLowerCase().includes(c.actionQuery.toLowerCase()));
  const pages = Math.max(1, Math.ceil(filtered.length / 14)); state.actionPage = Math.min(state.actionPage, pages);
  const rows = filtered.slice((state.actionPage - 1) * 14, state.actionPage * 14);
  return `<div class="notice blue">${esc(m.scale.note)}</div><div class="filterbar action-filters"><div class="searchbox"><input class="input" id="action-query" value="${esc(c.actionQuery)}" placeholder="搜索名称或稳定 ID"></div><select data-action-filter="actionDomain"><option value="">全部领域</option>${m.domains.map(domain => `<option value="${domain.id}" ${c.actionDomain === domain.id ? 'selected' : ''}>${esc(domain.name)}</option>`).join('')}</select><select data-action-filter="actionActor"><option value="">全部角色</option>${m.actors.map(item => `<option value="${item.id}" ${c.actionActor === item.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select><select data-action-filter="actionDepth">${selectOptions([['', '全部深度'], ['detailed', '完整剖面'], ['summary', '概要 / 待完善'], ['index', '仅索引']], c.actionDepth)}</select></div><section class="card table-card"><table class="data-table"><thead><tr><th>稳定 ID</th><th>业务动作</th><th>领域 / 场景</th><th>参与者</th><th>资料深度</th></tr></thead><tbody>${rows.map(action => `<tr data-action-row="${action.id}"><td class="mono link">${action.id}</td><td><b>${esc(action.name)}</b></td><td>${esc(domainName(m, action.domainId))}<div class="mono muted">${esc(action.scenarioId || '规模索引')}</div></td><td>${esc(actorName(m, action.actorId))}</td><td>${badge(action.indexOnly ? '仅索引' : action.depth === 'detailed' ? '完整' : '概要 / 待完善', action.indexOnly || action.depth !== 'detailed' ? 'amber' : 'green')}</td></tr>`).join('')}</tbody></table><div class="table-footer"><span>筛选结果 ${filtered.length} 条 · 每页 14 条</span><div class="pagination">${Array.from({ length: pages }, (_, i) => i + 1).slice(Math.max(0, state.actionPage - 3), state.actionPage + 2).map(page => `<button class="${page === state.actionPage ? 'active' : ''}" data-action-page="${page}">${page}</button>`).join('')}</div></div></section>`;
}

/* Relationship-aware impact analysis */
function ruleImpact() {
  const m = M(), rule = currentRule(); if (!rule) return;
  const usage = E.ruleUsage(m, rule.id);
  modal(`${rule.id}@${rule.currentVersion || '草稿'} · 影响定位`, `<p class="muted">直接影响来自 uses 关系；场景影响由动作归属间接推导；界面、实现和验收只标记为需要重新审查，不断言一定发生技术变化。</p><h3>直接影响 · 动作</h3><div class="impact-action-list">${usage.actions.map(action => `<button data-open-action="${action.id}"><span class="mono">${action.id}</span><b>${esc(action.name)}</b><small>${esc(action.scenarioId)}</small></button>`).join('') || '<p class="muted">没有直接动作引用。</p>'}</div><h3>间接影响 · 场景</h3>${usage.scenarios.map(scenario => scenarioItem(m, scenario)).join('') || '<p class="muted">没有场景受到影响。</p>'}<h3>需要重新审查 · 界面与验收</h3>${usage.surfaces.map(surface => `<div class="relation-box"><b>${surface.id} · ${esc(surface.name)}</b><p>核验 UI 操作、服务端判断和失败处理是否仍符合新规则。</p></div>`).join('')}${usage.acceptance.map(item => `<div class="relation-box"><b>${item.id} · ${item.deliveryId}</b><p>${esc(item.ruleVersion)} · ${statusText(item.status)}</p></div>`).join('') || '<p class="muted">没有关联验收条件。</p>'}`, btn('关闭', 'close'), true);
}

/* Surface directory: filters, local relations and honest index-only entries */
function renderSurface() {
  const m = M(), c = C(), all = [...m.surfaces, ...AtlasModel.scaleIndex(m, 'surfaces')];
  const filtered = all.filter(surface => (!c.surfaceActor || surface.actorId === c.surfaceActor) && (!c.surfaceType || surface.type === c.surfaceType) && `${surface.id}${surface.name}`.includes(c.surfaceQuery));
  const selected = E.byId(m.surfaces, c.selectedSurfaceId) || m.surfaces[0];
  const visible = filtered.filter(item => !item.indexOnly).slice(0, 60), indexMatches = filtered.filter(item => item.indexOnly).slice(0, c.surfaceQuery ? 20 : 5);
  return `${pageHead('界面映射', `${m.scale.surfaces || m.surfaces.length} 个界面 · 局部关系`, '界面操作按参与者、对象状态和动作 ID 建立映射；规模索引不参与关系绘制。', `<div class="segmented"><button class="${state.surfaceMode === 'directory' ? 'active' : ''}" data-surface-mode="directory">页面目录</button><button class="${state.surfaceMode === 'map' ? 'active' : ''}" data-surface-mode="map">局部关系</button></div>`)}<div class="notice blue">${esc(m.scale.note)}</div><div class="filterbar"><div class="searchbox"><input class="input" id="surface-query" value="${esc(c.surfaceQuery)}" placeholder="搜索页面或稳定 ID"></div><select data-surface-filter="surfaceActor"><option value="">全部角色</option>${m.actors.map(item => `<option value="${item.id}" ${c.surfaceActor === item.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select><select data-surface-filter="surfaceType"><option value="">全部类型</option>${[...new Set(m.surfaces.map(item => item.type))].map(type => `<option ${c.surfaceType === type ? 'selected' : ''}>${esc(type)}</option>`).join('')}</select></div>${!selected ? `<section class="card">${empty('▦', '尚未建立界面', '后台自动动作可以没有独立 UI 入口。')}</section>` : state.surfaceMode === 'directory' ? `<div class="surface-layout"><section class="card table-card"><table class="data-table"><thead><tr><th>页面</th><th>领域</th><th>类型</th><th>角色</th><th>操作</th></tr></thead><tbody>${visible.map(surface => `<tr class="${selected.id === surface.id ? 'selected' : ''}" data-surface="${surface.id}"><td><b>${esc(surface.name)}</b><div class="mono muted">${surface.id}</div></td><td>${esc(domainName(m, surface.domainId))}</td><td>${esc(surface.type)}</td><td>${esc(actorName(m, surface.actorId))}</td><td>${surface.operations.length} 个</td></tr>`).join('')}${indexMatches.map(item => `<tr><td><b>${esc(item.name)}</b><div class="mono muted">${item.id}</div></td><td>仅索引</td><td>—</td><td>—</td><td>${badge('仅索引', 'amber')}</td></tr>`).join('')}</tbody></table></section>${surfaceInspector(m, selected)}</div>` : `<div class="surface-layout"><section class="card card-pad"><h2>局部关系 · ${esc(selected.name)}</h2><div class="local-relation-map"><div class="relation-center"><b>${selected.id}</b><span>${esc(selected.name)}</span></div>${selected.operations.map(operation => { const action = E.byId(m.actions, operation.actionId); return `<button class="relation-target" data-open-action="${operation.actionId}"><small>triggers</small><b>${esc(action?.name || operation.actionId)}</b><span class="mono">${operation.actionId}</span></button>`; }).join('')}</div><p class="muted">只加载当前界面的直接关系，不绘制全部 ${m.scale.surfaces || m.surfaces.length} 个界面的关系线。</p></section>${surfaceInspector(m, selected)}</div>`}`;
}
function surfaceInspector(m, surface) {
  const properties = [...new Set(surface.objectIds.flatMap(id => E.byId(m.objects, id)?.props || []))];
  return `<aside class="card inspector"><span class="tag blue">${surface.id}</span><h2>${esc(surface.name)}</h2><p>${esc(domainName(m, surface.domainId))} · ${esc(actorName(m, surface.actorId))}</p><div class="surface-preview"><div class="browser-chrome"><i></i><i></i><i></i></div><div class="mock-surface"><div class="mock-toolbar"><b>${esc(surface.name)}</b><small>···</small></div><div class="mock-fields">${properties.slice(0, 6).map(property => `<div class="mock-field">${esc(property)}</div>`).join('') || '<div class="mock-field">字段映射待建立</div>'}</div></div></div><h3>状态下的业务操作</h3>${surface.operations.map(operation => `<div class="surface-operation"><div><b>${esc(operation.name)}</b><small>${operation.states.join(' / ')}可用</small></div><button class="link" data-open-action="${operation.actionId}">${operation.actionId} →</button></div>`).join('')}<div class="kv"><span>对象</span><span>${surface.objectIds.join('、')}</span><span>接口</span><span class="mono">${esc(surface.api)}</span></div></aside>`;
}

/* In-place rule editing, independent drafts and multiple changes */
function ensureChange(rule) {
  const m = M(), c = C();
  let change = m.changes.find(item => item.id === c.selectedChangeId && item.ruleId === rule.id && !['approved', 'cancelled'].includes(item.status));
  change ||= m.changes.find(item => item.ruleId === rule.id && !['approved', 'cancelled'].includes(item.status));
  if (!change) {
    const baseVersion = rule.currentVersion || null;
    change = { id: AtlasModel.nextId(m, 'CHG'), title: `修改${rule.name}`, ruleId: rule.id, baseVersion, targetVersion: E.nextVersion(baseVersion), status: 'draft', reason: '', draftRule: null, checks: { actions: false, scenarios: false, acceptance: false, technical: false }, history: [{ at: new Date().toISOString(), by: '林岚', text: '从业务阅读上下文创建变更' }] };
    m.changes.push(change);
  }
  c.selectedChangeId = change.id;
  if (!change.draftRule) {
    const source = rule.versions[change.baseVersion] || rule.versions.draft;
    change.draftRule = clone(source); change.draftRule.version = change.targetVersion; change.draftRule.status = 'draft';
    change.draftRule.source = `${change.id} · 未批准`; change.draftRule.effective = '批准后生效';
  }
  return change;
}
function openRuleEditor() {
  const m = M(), rule = currentRule(); if (!rule) return;
  const change = ensureChange(rule);
  if (change.status === 'pending') { toast('待审批版本已锁定，请先处理审批或撤回报审', 'error'); return; }
  const draft = change.draftRule, base = rule.versions[change.baseVersion];
  state.drawer = { type: 'rule-editor', changeId: change.id, title: `提出修改 · ${rule.id}@${change.baseVersion || '未发布'}`, wide: true,
    body: `<div class="version-isolation"><div><small>当前已发布内容 · 只读</small><b>${rule.id}@${change.baseVersion || '无正式版本'}</b><p>${esc(base?.summary || '首次发布前没有已发布定义')}</p></div><span>→</span><div><small>本次独立草稿</small><b>${rule.id}@${change.targetVersion}</b><p>只有保存后写入变更单；批准前不污染正式版本。</p></div></div><div class="field"><label>变更原因 *</label><textarea id="change-reason" data-rule-editor>${esc(change.reason)}</textarea></div><div class="field"><label>适用范围</label><textarea id="draft-scope" data-rule-editor>${esc(draft.scope || '')}</textarea></div>${draft.supportsEvaluation === false ? `<div class="field"><label>人工核验约束</label><textarea id="draft-constraint" data-rule-editor>${esc(draft.constraint || '')}</textarea></div>` : renderRuleRowsEditor(m, change)}<div class="notice blue"><b>自动摘要：</b><span id="draft-summary">${esc(E.summarizeRule(draft))}</span><br>摘要是结构化结果的人类可读投影，不能单独修改成另一套含义。</div><div id="editor-validation">${renderDraftValidation(draft)}</div><div class="editor-preview"><h3>草稿即时试算</h3><div class="simulator-inputs">${draft.inputs.map(input => `<div class="field"><label>${esc(input.label)}</label><select data-editor-sample="${input.id}">${selectOptions(input.options.map(option => [option.value, option.label]), input.default)}</select></div>`).join('')}</div><div id="editor-preview-result">${editorPreviewResult(m, draft)}</div></div>`,
    foot: `${btn('取消', 'close')}${btn('保存独立草稿', 'save-rule-draft', 'primary')}` };
  renderOverlay();
}
function renderRuleRowsEditor(m, change) {
  const draft = change.draftRule, allRows = [...(draft.exceptions || []).map(row => ({ row, exception: true })), ...(draft.rows || []).map(row => ({ row, exception: false }))];
  return `<div class="editor-section"><div class="section-head"><h3>结构化条件与结果</h3><div class="actions">${btn('＋ 添加条件', 'editor-add-input', 'small')}${btn('＋ 决策行', 'editor-add-row', 'small')}${btn('＋ 例外', 'editor-add-exception', 'small')}</div></div><div class="input-definition-list">${draft.inputs.map(input => `<span class="fact-chip"><input class="condition-label-input" data-input-label="${input.id}" data-rule-editor value="${esc(input.label)}" aria-label="条件名称"><button data-editor-remove-input="${input.id}" title="删除条件">×</button></span>`).join('')}</div><div class="table-scroll"><table class="condition-table editor-table"><thead><tr><th>类型</th><th>优先级</th>${draft.inputs.map(input => `<th>${esc(input.label)}</th>`).join('')}<th>结果</th><th></th></tr></thead><tbody>${allRows.map(({ row, exception }) => `<tr data-editor-row="${row.id}" data-row-exception="${exception}"><td>${exception ? '例外' : '决策'}</td><td><input type="number" data-row-priority value="${row.priority}"></td>${draft.inputs.map(input => `<td><select data-row-condition="${input.id}"><option value="any">任意</option>${selectOptions(input.options.map(option => [option.value, option.label]), row.when[input.id])}</select></td>`).join('')}<td><select data-row-outcome>${draft.outcomes.map(outcome => `<option value="${outcome.id}" ${row.outcomeId === outcome.id ? 'selected' : ''}>${esc(outcome.label)}</option>`).join('')}</select></td><td><button class="link danger" data-editor-remove-row="${row.id}">删除</button></td></tr>`).join('')}</tbody></table></div><h3>决策结果定义</h3>${draft.outcomes.map(outcome => `<div class="outcome-editor" data-outcome-id="${outcome.id}"><span class="mono">${outcome.id}</span><input data-outcome-label value="${esc(outcome.label)}" data-rule-editor><small>${(outcome.actorIds || []).map(id => actorName(m, id)).join('、') || '未指定角色'}</small></div>`).join('')}${btn('＋ 添加结果', 'editor-add-outcome', 'small')}</div>`;
}
function readRuleEditor(change) {
  const draft = change.draftRule;
  change.reason = $('#change-reason')?.value.trim() || '';
  if ($('#draft-scope')) draft.scope = $('#draft-scope').value.trim();
  if ($('#draft-constraint')) { draft.constraint = $('#draft-constraint').value.trim(); draft.summary = E.summarizeRule(draft); return; }
  $$('[data-editor-row]').forEach(element => {
    const collection = element.dataset.rowException === 'true' ? draft.exceptions : draft.rows;
    const row = collection.find(item => item.id === element.dataset.editorRow); if (!row) return;
    row.priority = Number($('[data-row-priority]', element).value); row.when = {};
    $$('[data-row-condition]', element).forEach(select => { if (select.value !== 'any') row.when[select.dataset.rowCondition] = select.value; });
    row.outcomeId = $('[data-row-outcome]', element).value;
  });
  $$('[data-input-label]').forEach(element => {
    const input = draft.inputs.find(item => item.id === element.dataset.inputLabel);
    if (input) input.label = element.value.trim() || input.id;
  });
  $$('[data-outcome-id]').forEach(element => {
    const outcome = draft.outcomes.find(item => item.id === element.dataset.outcomeId);
    if (outcome) outcome.label = $('[data-outcome-label]', element).value.trim();
  });
  draft.summary = E.summarizeRule(draft);
}
function renderDraftValidation(draft) {
  const validation = E.validateRuleVersion(draft);
  return `<div class="notice ${validation.errors.length ? 'red' : validation.warnings.length ? 'amber' : 'green'}"><b>规则一致性检查</b>${validation.errors.length ? `<ul>${validation.errors.map(error => `<li>${esc(error)}</li>`).join('')}</ul>` : '<p>未发现冲突结果、无效引用或摘要分歧。</p>'}${validation.warnings.map(warning => `<p>${esc(warning)}</p>`).join('')}</div>`;
}
function editorPreviewResult(m, draft) {
  const values = {};
  $$('[data-editor-sample]').forEach(select => { values[select.dataset.editorSample] = select.value; });
  draft.inputs.forEach(input => { if (values[input.id] === undefined) values[input.id] = input.default; });
  const result = E.evaluateRule(draft, values);
  return `<div class="result-box ${['NO_MATCH', 'CONFLICT'].includes(result.code) ? 'error' : ''}"><b>${esc(result.outcome?.label || result.code)}</b><p>${(result.outcome?.actorIds || []).map(id => actorName(m, id)).join('、')}</p><small>${esc(result.explanation)}</small></div>`;
}
function refreshRuleEditor(change) {
  readRuleEditor(change); const draft = change.draftRule;
  if ($('#draft-summary')) $('#draft-summary').textContent = E.summarizeRule(draft);
  if ($('#editor-validation')) $('#editor-validation').innerHTML = renderDraftValidation(draft);
  if ($('#editor-preview-result')) $('#editor-preview-result').innerHTML = editorPreviewResult(M(), draft);
}
function changeTarget(m, change) {
  if (change.ruleId) return E.byId(m.rules, change.ruleId);
  const collection = { action: 'actions', scenario: 'scenarios', object: 'objects' }[change.objectType];
  return collection ? E.byId(m[collection], change.objectId) : null;
}
function definitionText(target, type) {
  if (!target) return '尚未建立内容';
  if (type === 'action') return `${target.name}\n${target.purpose || '业务目的待完善'}`;
  if (type === 'scenario') return `${target.name}\n${target.goal || ''}\n触发：${target.trigger || '未定义'}\n结果：${target.result || '未定义'}`;
  return `${target.name}\n${target.desc || ''}\n状态：${(target.states || []).join(' → ')}`;
}
function definitionImpacts(m, change) {
  const index = E.relationIndex(m); let actions = [], scenarios = [], surfaces = [];
  if (change.objectType === 'action') {
    actions = [E.byId(m.actions, change.objectId)].filter(Boolean);
    scenarios = [...new Set(actions.map(action => action.scenarioId))].map(id => E.byId(m.scenarios, id)).filter(Boolean);
    surfaces = index.sources(change.objectId, 'triggers').map(id => E.byId(m.surfaces, id)).filter(Boolean);
  } else if (change.objectType === 'scenario') {
    actions = m.actions.filter(action => action.scenarioId === change.objectId);
    scenarios = [E.byId(m.scenarios, change.objectId)].filter(Boolean);
    surfaces = m.surfaces.filter(surface => surface.sceneIds.includes(change.objectId));
  } else {
    actions = m.actions.filter(action => action.objectChanges.some(item => item.objectId === change.objectId));
    scenarios = [...new Set(actions.map(action => action.scenarioId))].map(id => E.byId(m.scenarios, id)).filter(Boolean);
    surfaces = m.surfaces.filter(surface => surface.objectIds.includes(change.objectId));
  }
  const acceptance = m.deliveries.flatMap(delivery => delivery.actionIds.filter(id => actions.some(action => action.id === id)).map(() => delivery.id));
  return { actions, scenarios, surfaces, acceptance: [...new Set(acceptance)] };
}
function ensureObjectChange(type, target) {
  const m = M(), c = C();
  let change = m.changes.find(item => item.id === c.selectedChangeId && item.objectType === type && item.objectId === target.id && !['approved', 'cancelled'].includes(item.status));
  change ||= m.changes.find(item => item.objectType === type && item.objectId === target.id && !['approved', 'cancelled'].includes(item.status));
  if (!change) {
    change = { id: AtlasModel.nextId(m, 'CHG'), title: `修改${target.name}`, objectType: type, objectId: target.id, baseVersion: target.version, targetVersion: E.nextVersion(target.version), status: 'draft', reason: '', draftDefinition: clone(target), checks: { actions: false, scenarios: false, acceptance: false, technical: false }, history: [{ at: new Date().toISOString(), by: '林岚', text: '从业务阅读上下文创建独立变更' }] };
    m.changes.push(change);
  }
  change.draftDefinition ||= clone(target); c.selectedChangeId = change.id; return change;
}
function openObjectEditor(type, target) {
  if (!target) return;
  const change = ensureObjectChange(type, target), draft = change.draftDefinition;
  if (change.status === 'pending') { toast('待审批版本已锁定', 'error'); return; }
  const fields = type === 'action' ? `<div class="field"><label>动作名称</label><input id="definition-name" value="${esc(draft.name)}"></div><div class="field"><label>业务目的</label><textarea id="definition-purpose">${esc(draft.purpose || '')}</textarea></div>` : type === 'scenario' ? `<div class="field"><label>场景名称</label><input id="definition-name" value="${esc(draft.name)}"></div><div class="field"><label>业务目标</label><textarea id="definition-goal">${esc(draft.goal || '')}</textarea></div><div class="field"><label>触发条件</label><input id="definition-trigger" value="${esc(draft.trigger || '')}"></div><div class="field"><label>成功结果</label><textarea id="definition-result">${esc(draft.result || '')}</textarea></div>` : `<div class="field"><label>对象名称</label><input id="definition-name" value="${esc(draft.name)}"></div><div class="field"><label>业务含义</label><textarea id="definition-desc">${esc(draft.desc || '')}</textarea></div><div class="field"><label>生命周期状态（用 → 分隔）</label><input id="definition-states" value="${esc((draft.states || []).join(' → '))}"></div><div class="field"><label>核心属性（用顿号分隔）</label><input id="definition-props" value="${esc((draft.props || []).join('、'))}"></div>`;
  state.drawer = { type: 'object-editor', changeId: change.id, title: `提出修改 · ${target.id}@${target.version}`, wide: true,
    body: `<div class="version-isolation"><div><small>当前已发布内容 · 只读</small><b>${target.id}@${target.version}</b><p>${esc(definitionText(target, type))}</p></div><span>→</span><div><small>独立修改草稿</small><b>${target.id}@${change.targetVersion}</b><p>保存到 ${change.id}，不会直接覆盖当前阅读版本。</p></div></div>${fields}<div class="field"><label>变更原因 *</label><textarea id="definition-reason">${esc(change.reason)}</textarea></div><div class="notice blue">影响检查、问题确认和批准在变更工作台完成。历史版本保存在独立快照中。</div>`,
    foot: btn('取消', 'close') + btn('保存独立草稿', 'save-object-draft', 'primary') };
  renderOverlay();
}
function renderGenericChange(m, change) {
  const target = changeTarget(m, change), draft = change.draftDefinition, impacts = definitionImpacts(m, change);
  return `${pageHead('业务变更工作台', `${m.changes.length} 张独立变更单 · 当前 ${change.id}`, '动作、场景、对象与规则共用隔离草稿和版本批准机制。', btn('问题与确认', 'issues'))}<div class="change-center"><aside class="card change-list"><div class="section-head"><h3>变更单</h3>${badge(m.changes.length)}</div>${m.changes.map(item => `<button class="${item.id === change.id ? 'active' : ''}" data-change="${item.id}"><span class="mono">${item.id}</span><b>${esc(item.title)}</b><small>${esc(item.ruleId || item.objectId)}@${item.baseVersion || '未发布'} → ${item.targetVersion}</small>${badge(statusText(item.status), statusType(item.status))}</button>`).join('')}</aside><div class="stack"><section class="card card-pad"><div class="section-head"><div><h2>${esc(change.title)}</h2><span class="mono">${change.objectId}@${change.baseVersion} → ${change.targetVersion}</span></div><div class="actions">${change.status === 'draft' ? btn('提交审批', 'submit-change', 'primary') : change.status === 'pending' ? btn('批准并发布', 'approve-change', 'primary') : btn('查看新版本', 'view-new-rule', 'primary')}</div></div><div class="change-status-line">${['draft', 'pending', 'approved'].map((status, index) => `<span class="${change.status === status ? 'current' : ''}">${index + 1} · ${statusText(status)}</span>`).join('')}<b>${statusText(change.status)}</b></div><div class="diff-grid"><div><div class="diff-label">${badge(`已发布 ${change.baseVersion}`)}</div><div class="diff-before definition-diff">${esc(definitionText(target, change.objectType))}</div></div><div><div class="diff-label">${badge(`草稿 ${change.targetVersion}`, 'purple')}</div><div class="diff-after definition-diff">${esc(definitionText(draft, change.objectType))}</div></div></div><div class="draft-isolation">已发布定义和 ${change.id} 草稿独立保存，批准时先归档历史快照。</div>${btn('继续原位编辑', 'edit-selected-rule', 'primary')}</section><section class="card card-pad"><div class="section-head"><h2>影响清单与确认</h2><small>定位到真实对象，不推断必然技术变化</small></div>${[['actions', '直接影响', `${impacts.actions.length} 个相关动作`], ['scenarios', '间接影响', `${impacts.scenarios.length} 个相关场景`], ['acceptance', '交付重审', `${impacts.acceptance.length} 个交接需求`], ['technical', '技术重审', `${impacts.surfaces.length} 个界面或映射需核验`]].map(([key, name, text]) => `<label class="check-row"><div><b>${name}</b><p>${text}</p></div><input type="checkbox" data-check="${key}" ${change.checks[key] ? 'checked' : ''} ${change.status !== 'draft' ? 'disabled' : ''}></label>`).join('')}<div id="change-validation">${changeValidation(m, change)}</div></section></div><aside class="stack"><section class="card card-pad"><h2>责任与审批</h2><div class="kv"><span>对象</span><span>${change.objectId}</span><span>当前状态</span><span>${statusText(change.status)}</span><span>目标版本</span><span>${change.targetVersion}</span></div>${change.history.map(item => `<div class="history-entry"><b>${esc(item.by)}</b><p>${esc(item.text)}</p><small>${esc(item.at)}</small></div>`).join('')}</section></aside></div>`;
}
function renderChanges() {
  const m = M(), c = C(), change = activeChange();
  if (!change) return pageHead('变更工作台', '没有变更草稿', '从规则上下文直接发起修改。') + `<section class="card">${empty('↻', '没有业务变更', '在规则页面选择“提出修改”，会自动携带对象与基线版本。')}</section>`;
  c.selectedChangeId = change.id;
  if (!change.ruleId) return renderGenericChange(m, change);
  const rule = E.byId(m.rules, change.ruleId), base = rule?.versions[change.baseVersion], draft = change.draftRule, usage = rule ? E.ruleUsage(m, rule.id) : null;
  const differences = base && draft ? E.compareRuleVersions(base, draft) : [];
  return `${pageHead('业务变更工作台', `${m.changes.length} 张独立变更单 · 当前 ${change.id}`, '每张变更单拥有自己的对象、基线、草稿、核验和审批记录。', btn('问题与确认', 'issues'))}<div class="change-center"><aside class="card change-list"><div class="section-head"><h3>变更单</h3>${badge(m.changes.length)}</div>${m.changes.map(item => `<button class="${item.id === change.id ? 'active' : ''}" data-change="${item.id}"><span class="mono">${item.id}</span><b>${esc(item.title)}</b><small>${item.ruleId || item.objectId}@${item.baseVersion || '未发布'} → ${item.targetVersion}</small>${badge(statusText(item.status), statusType(item.status))}</button>`).join('')}</aside><div class="stack"><section class="card card-pad"><div class="section-head"><div><h2>${esc(change.title)}</h2><span class="mono">${change.ruleId}@${change.baseVersion || '未发布'} → ${change.targetVersion}</span></div><div class="actions">${change.status === 'draft' ? btn('提交审批', 'submit-change', 'primary') : change.status === 'pending' ? btn('批准并发布', 'approve-change', 'primary') : btn('查看新版本', 'view-new-rule', 'primary')}</div></div><div class="change-status-line">${['draft', 'pending', 'approved'].map((status, index) => `<span class="${change.status === status ? 'current' : ''}">${index + 1} · ${statusText(status)}</span>`).join('')}<b>${statusText(change.status)}</b></div><div class="diff-grid"><div><div class="diff-label">${badge(`已发布 ${change.baseVersion || '无'}`)}</div><div class="diff-before">${esc(base?.summary || '首次发布前没有正式定义')}</div></div><div><div class="diff-label">${badge(`草稿 ${change.targetVersion}`, 'purple')}</div><div class="diff-after">${esc(draft?.summary || '尚未建立结构化草稿')}</div></div></div><div class="draft-isolation">已发布版本与 ${change.id} 草稿独立存储；并发变更会检查基线是否仍为最新。</div>${btn(draft ? '继续原位编辑' : '创建修改草稿', 'edit-selected-rule', 'primary')}</section><section class="card card-pad"><div class="section-head"><h2>行为差异</h2><small>使用同一组输入比较新旧版本</small></div>${differences.length ? `<div class="table-scroll"><table class="condition-table"><thead><tr><th>输入组合</th><th>旧结果</th><th>新结果</th><th>差异</th></tr></thead><tbody>${differences.slice(0, 24).map(diff => `<tr class="${diff.changed ? 'changed-result' : ''}"><td>${Object.entries(diff.values).map(([key, value]) => `${esc(key)}=${esc(value)}`).join('，')}</td><td>${esc(diff.before)}</td><td>${esc(diff.after)}</td><td>${diff.changed ? badge('行为改变', 'amber') : '一致'}</td></tr>`).join('')}</tbody></table></div>` : '<p class="muted">创建草稿后显示版本行为差异。</p>'}</section><section class="card card-pad"><div class="section-head"><h2>影响清单与确认</h2><button class="btn small" data-action="rule-impact">定位真实关系</button></div>${[['actions', '直接影响', `${usage?.actions.length || 0} 个动作直接引用`], ['scenarios', '间接影响', `${usage?.scenarios.length || 0} 个场景包含相关动作`], ['acceptance', '验收重审', `${usage?.acceptance.length || 0} 条验收条件`], ['technical', '技术重审', `${usage?.surfaces.length || 0} 个界面及相关映射需核验`]].map(([key, name, text]) => `<label class="check-row"><div><b>${name}</b><p>${text}</p></div><input type="checkbox" data-check="${key}" ${change.checks[key] ? 'checked' : ''} ${change.status !== 'draft' ? 'disabled' : ''}></label>`).join('')}<div id="change-validation">${changeValidation(m, change)}</div></section></div><aside class="stack"><section class="card card-pad"><h2>责任与审批</h2><div class="kv"><span>责任人</span><span>${esc(rule?.owner || '未分派')}</span><span>当前状态</span><span>${statusText(change.status)}</span><span>目标版本</span><span>${change.targetVersion}</span><span>关联问题</span><span>${m.issues.filter(issue => issue.changeId === change.id && !['resolved', 'cancelled'].includes(issue.status)).length} 项未闭环</span></div>${change.history.map(item => `<div class="history-entry"><b>${esc(item.by)}</b><p>${esc(item.text)}</p><small>${esc(item.at)}</small></div>`).join('')}</section><section class="card card-pad"><h2>发布前一致性</h2>${draft ? renderDraftValidation(draft) : '<p class="muted">尚无草稿。</p>'}</section></aside></div>`;
}
function changeValidation(m, change) {
  const errors = [];
  if (!change.ruleId) {
    if (!change.draftDefinition) errors.push('尚未建立修改草稿');
    if (Object.values(change.checks || {}).some(value => !value)) errors.push('影响检查尚未全部确认');
    const issues = m.issues.filter(issue => issue.changeId === change.id && !['resolved', 'cancelled'].includes(issue.status));
    if (issues.some(issue => !issue.decision)) errors.push('关联问题尚未形成业务确认结论');
    if (changeTarget(m, change)?.version !== change.baseVersion) errors.push('基线已被其他变更更新，需要重新基于最新版本');
    return errors.length ? `<div class="notice red"><b>当前阻塞</b><ul>${errors.map(error => `<li>${esc(error)}</li>`).join('')}</ul></div>` : '<div class="notice green">结构、关系、核验和基线检查均已满足，可进入下一状态。</div>';
  }
  if (!change.draftRule) errors.push('尚未建立修改草稿');
  if (Object.values(change.checks || {}).some(value => !value)) errors.push('影响检查尚未全部确认');
  const issues = m.issues.filter(issue => issue.changeId === change.id && !['resolved', 'cancelled'].includes(issue.status));
  if (issues.some(issue => !issue.decision)) errors.push('关联问题尚未形成业务确认结论');
  if (change.baseVersion !== (E.byId(m.rules, change.ruleId)?.currentVersion || null)) errors.push('基线已被其他变更更新，需要重新基于最新版本');
  if (change.draftRule) {
    const validation = E.validateRuleVersion(change.draftRule); errors.push(...validation.errors);
    if (validation.uncovered.length) errors.push(`存在 ${validation.uncovered.length} 个未覆盖输入组合`);
  }
  return errors.length ? `<div class="notice red"><b>当前阻塞</b><ul>${[...new Set(errors)].map(error => `<li>${esc(error)}</li>`).join('')}</ul></div>` : '<div class="notice green">结构、关系、核验和基线检查均已满足，可进入下一状态。</div>';
}

/* Clarification is separate from business confirmation and approval */
function renderIssues() {
  const m = M();
  const columns = [['待澄清', ['unassigned', 'waiting', 'investigating']], ['已回复待核验', ['replied']], ['待业务确认', ['confirming']], ['已解决', ['resolved', 'cancelled']]];
  return `${pageHead('问题与业务确认', '回复 ≠ 规则确认 ≠ 技术审查 ≠ 业务验收', '证据不足或业务冲突未解决时，不会自动生成已批准事实。', btn('返回变更', 'back-change') + btn('＋ 创建问题', 'new-issue', 'primary'))}<div class="kanban dynamic">${columns.map(([title, statuses]) => { const issues = m.issues.filter(issue => statuses.includes(issue.status)); return `<div class="kanban-col"><div class="kanban-title"><span>${title}</span>${badge(issues.length)}</div>${issues.map(issue => `<button class="issue-card" data-issue="${issue.id}"><div class="spread"><span class="mono muted">${issue.id}</span>${badge(statusText(issue.status), statusType(issue.status))}</div><h3>${esc(issue.title)}</h3><p>${issue.objectId} · ${issue.requiresChange ? '需关联规范变更' : '仅需业务确认'}</p><div class="issue-foot"><span>${esc(issue.owner)}</span><small>${issue.replies.length} 条回复</small></div></button>`).join('') || '<div class="empty"><small>暂无事项</small></div>'}</div>`; }).join('')}</div>`;
}
function showIssue(id) {
  const m = M(), issue = E.byId(m.issues, id); if (!issue) return;
  C().selectedIssueId = id; const change = E.byId(m.changes, issue.changeId), evidence = issue.evidenceIds.map(evidenceId => E.byId(m.facts, evidenceId)).filter(Boolean);
  state.drawer = { title: `${issue.id} · ${statusText(issue.status)}`, body: `<h2>${esc(issue.title)}</h2><p class="muted issue-why">${esc(issue.why)}</p><div class="kv"><span>涉及对象</span><span>${issue.objectId}</span><span>责任人</span><span>${esc(issue.owner)}</span><span>关联变更</span><span>${issue.changeId || '无需修改规范'}</span></div><h3>现有证据</h3>${evidence.map(fact => `<div class="evidence-source ${fact.kind === 'history' ? 'conflict' : ''}"><b>${factKind(fact.kind)} · ${esc(fact.source)}</b><p>${esc(fact.conclusion)}</p><small>${fact.status}</small></div>`).join('') || '<p class="muted">尚未关联证据，不能直接形成已确认事实。</p>'}<h3>回复与处理记录</h3>${issue.replies.map(reply => `<div class="ai-message"><div class="spread"><b>${esc(reply.by)}</b><small>${esc(reply.time)}</small></div><p>${esc(reply.text)}</p></div>`).join('')}${issue.decision ? `<div class="notice blue"><b>业务确认结论</b><br>${esc(issue.decision)}</div>` : ''}<div class="field"><label>补充回复或明确结论</label><textarea id="issue-reply"></textarea></div>`, foot: issueFooter(issue, change) };
  renderOverlay();
}
function issueFooter(issue, change) {
  if (['resolved', 'cancelled'].includes(issue.status)) return `<button class="btn" data-action="locate-issue">定位业务对象</button><button class="btn" data-action="reopen-issue">重新打开</button>`;
  return `<div class="issue-actions"><button class="btn" data-action="reply-issue">仅回复</button><button class="btn" data-action="investigate-issue">继续调查</button><button class="btn" data-action="return-supplement">退回补充</button><button class="btn primary" data-action="propose-decision">提交业务确认结论</button>${issue.status === 'confirming' ? `<button class="btn primary" data-action="finalize-issue" ${issue.requiresChange && change?.status !== 'approved' ? 'disabled' : ''}>${issue.requiresChange && change?.status !== 'approved' ? '等待变更批准' : '批准并解决'}</button>` : ''}</div>`;
}

/* Immutable handoff packages and acceptance revalidation */
function deliveryBlockers(m, delivery) {
  if (!delivery) return ['当前项目没有交接需求'];
  const rule = E.byId(m.rules, delivery.ruleId), blocks = [];
  if (!rule?.versions?.[delivery.ruleVersion] || rule.currentVersion !== delivery.ruleVersion || rule.versions[delivery.ruleVersion].status !== 'published') blocks.push(`${delivery.ruleId}@${delivery.ruleVersion} 尚未批准发布`);
  if (!delivery.technicalReview) blocks.push('技术审查尚未完成');
  (delivery.acceptance || []).filter(item => item.ruleId === delivery.ruleId).forEach(acceptance => {
    if (acceptance.status === 'stale' || acceptance.requiresReview) blocks.push(`${acceptance.id} 因规则行为变化而待重新核验`);
    if (acceptance.ruleVersion !== delivery.ruleVersion) blocks.push(`${acceptance.id} 尚未更新到交接版本 ${delivery.ruleVersion}`);
  });
  return blocks;
}
function renderDelivery() {
  const m = M(), c = C(), delivery = E.byId(m.deliveries, c.selectedDeliveryId) || m.deliveries[0];
  if (!delivery) return pageHead('开发交接', '未建立交接需求', '正式交付只能引用已批准业务基线。') + `<section class="card">${empty('◇', '没有开发交接', '此项目当前没有交付包，不生成虚构交接内容。')}</section>`;
  c.selectedDeliveryId = delivery.id;
  const blocks = deliveryBlockers(m, delivery), rule = E.byId(m.rules, delivery.ruleId), version = rule?.versions?.[delivery.ruleVersion], scenario = E.byId(m.scenarios, delivery.scenarioId);
  const stages = ['业务批准', '技术审查', '委托 Agent', '实现汇报', '测试', '业务验收'];
  return `${pageHead(`开发交接 · ${scenario?.name || delivery.scenarioId}`, `${delivery.id} · ${delivery.requirementId} · 目标 ${delivery.ruleId}@${delivery.ruleVersion}`, '交接包固定同一批准版本的规则、动作、场景、界面、验收和证据。', btn('获取指定版本上下文', 'agent-context') + btn(delivery.packageVersion ? '推进交付' : '生成正式交接包', delivery.packageVersion ? 'advance-delivery' : 'generate-package', 'primary'))}${blocks.length ? `<div class="notice red"><b>正式交接当前被阻止：</b><ul>${blocks.map(block => `<li>${esc(block)}</li>`).join('')}</ul></div>` : '<div class="notice green">业务版本与技术审查满足要求，可以生成不可变正式交接包。</div>'}<section class="card pipeline">${stages.map((name, index) => `<div class="pipeline-step ${index < delivery.stage ? 'done' : index === delivery.stage ? 'current' : ''}"><div class="pipeline-dot">${index < delivery.stage ? '✓' : index + 1}</div><b>${name}</b><small>${index < delivery.stage ? '已完成' : index === delivery.stage ? '当前阶段' : '待处理'}</small></div>`).join('')}</section><div class="grid-2"><div class="stack"><section class="card card-pad"><div class="section-head"><h2>固定业务定义</h2>${badge(version ? `${delivery.ruleId}@${delivery.ruleVersion}` : '指定版本不可用', version ? 'green' : 'amber')}</div>${delivery.actionIds.map(id => E.byId(m.actions, id)).filter(Boolean).map(action => `<button class="object-row" data-open-action="${action.id}"><span><b>${esc(action.name)}</b><small class="mono">${action.id}@${action.version}</small></span><span>→</span></button>`).join('')}<div class="relation-box"><b>${esc(rule?.name || delivery.ruleId)}</b><p>${esc(version?.summary || '请求的版本不存在或未发布，不自动使用其他版本替代。')}</p><button class="link inline-link" data-rule="${delivery.ruleId}">查看规则工作台</button></div><div class="kv"><span>场景</span><span>${delivery.scenarioId}@${scenario?.version || '不可用'}</span><span>UI</span><span>${delivery.surfaceIds.join('、')}</span><span>交接包</span><span>${delivery.packageVersion || '未生成'}</span></div></section><section class="card card-pad"><div class="section-head"><h2>验收条件与规则版本</h2><small>规则行为变化后必须重新核验</small></div>${delivery.acceptance.map(acceptance => acceptanceRow(m, delivery, acceptance)).join('')}</section></div><aside class="stack"><section class="card card-pad"><h2>技术审查</h2><label class="checkbox"><input type="checkbox" id="technical-review" ${delivery.technicalReview ? 'checked' : ''}> 已独立核验技术映射</label><p class="muted">技术审查与业务批准是不同事实。</p><h3>未解决问题</h3>${m.issues.filter(issue => issue.blocked.includes(delivery.id) && !['resolved', 'cancelled'].includes(issue.status)).map(issue => `<button class="issue-card" data-issue="${issue.id}"><b>${esc(issue.title)}</b><p>${statusText(issue.status)}</p></button>`).join('') || '<p class="muted">没有阻塞问题。</p>'}</section><section class="card card-pad"><h2>验收操作</h2><p class="muted">完成开发不等于完成业务验收。交接包生成后逐条确认验收结果。</p>${btn('完成业务验收', 'accept-delivery', 'primary')}</section></aside></div>`;
}
function acceptanceRow(m, delivery, acceptance) {
  const rule = E.byId(m.rules, acceptance.ruleId), before = rule?.versions?.[acceptance.ruleVersion], after = rule?.versions?.[rule.currentVersion];
  const oldResult = before ? E.evaluateRule(before, acceptance.sample).outcome?.label : '版本不可用';
  const newResult = after ? E.evaluateRule(after, acceptance.sample).outcome?.label : '版本不可用';
  return `<div class="acceptance-item"><input type="checkbox" data-acceptance="${acceptance.id}" ${acceptance.checked ? 'checked' : ''} ${acceptance.status === 'stale' ? 'disabled' : ''}><div class="acceptance-content"><div class="spread"><b>${acceptance.id} · ${statusText(acceptance.status)}</b><span class="mono">${acceptance.ruleId}@${acceptance.ruleVersion}</span></div><p>输入：${Object.entries(acceptance.sample).map(([key, value]) => `${esc(key)}=${esc(value)}`).join('，')}</p><div class="acceptance-compare"><span>原预期：${esc(oldResult)}</span><span>当前结果：${esc(newResult)}</span></div>${acceptance.status === 'stale' ? `<button class="btn small" data-revalidate-acceptance="${acceptance.id}">按当前结果重新核验</button>` : ''}</div></div>`;
}

/* Evidence governance and executable model checks */
function renderGovernance() {
  const m = M(), validation = E.validateProject(m), detailed = m.actions.filter(action => action.depth === 'detailed').length;
  return `${pageHead('证据与知识治理', '规范 / 实现 / 历史分开记录', '证据支持特定对象或规范版本；一致性问题可以重复执行检查。', btn('创建确认问题', 'new-issue') + btn('运行一致性检查', 'run-validation', 'primary'))}<div id="validation-result" class="notice ${validation.ok ? 'green' : 'red'}">${validation.ok ? `✓ 当前项目通过 ${m.relations.length} 条关系、流程引用、规则版本和交接快照检查。` : `发现 ${validation.errors.length} 个一致性错误。`}${validation.warnings.length ? ` 另有 ${validation.warnings.length} 个需关注事项。` : ''}</div><section class="card card-pad"><div class="section-head"><h2>事实来源与结论</h2>${badge(`${m.facts.length} 条事实记录`)}</div>${factTable(m.facts)}</section><div class="grid-2 action-secondary"><section class="card card-pad"><h2>待裁决事项</h2>${m.issues.filter(issue => !['resolved', 'cancelled'].includes(issue.status)).map(issue => `<button class="issue-card" data-issue="${issue.id}"><b>${esc(issue.title)}</b><p>${issue.objectId} · ${statusText(issue.status)}</p></button>`).join('') || '<p class="muted">没有待裁决事项。</p>'}</section><section class="card card-pad"><h2>资料深度</h2><p class="muted">核心动作 ${m.actions.length} 个，其中完整剖面 ${detailed} 个，概要 / 待完善 ${m.actions.length - detailed} 个。</p><p class="muted">技术映射已核验 ${m.actions.filter(action => action.implementation?.status === '已核验').length} 个，待核验 ${m.actions.filter(action => action.implementation?.status === '待核验').length} 个，未建立 ${m.actions.filter(action => !action.implementation).length} 个。</p><p class="muted">规模索引不计入语义完整度。</p></section></div>`;
}

/* Overlays, search, exact-version Agent context */
function modal(title, body, foot = '', wide = false) { state.modal = { title, body, foot, wide }; renderOverlay(); }
function closeOverlays() { state.modal = null; state.drawer = null; renderOverlay(); }
function renderOverlay() {
  let html = '';
  if (state.modal) html += `<div class="overlay" data-action="overlay-bg"><section class="modal ${state.modal.wide ? 'wide' : ''}"><div class="modal-head"><h2>${state.modal.title}</h2><button class="close" data-action="close">×</button></div><div class="modal-body">${state.modal.body}</div>${state.modal.foot ? `<div class="modal-foot">${state.modal.foot}</div>` : ''}</section></div>`;
  if (state.drawer) html += `<div class="drawer-overlay" data-action="close"></div><aside class="drawer ${state.drawer.wide ? 'wide' : ''}"><div class="drawer-head"><div class="spread"><h2>${state.drawer.title}</h2><button class="close" data-action="close">×</button></div></div><div class="drawer-body">${state.drawer.body}</div>${state.drawer.foot ? `<div class="drawer-foot">${state.drawer.foot}</div>` : ''}</aside>`;
  $('#overlay-root').innerHTML = html;
}
function showException(id) {
  const m = M(), exception = E.byId(m.exceptions, id); if (!exception) return;
  const step = E.byId(m.steps, exception.stepId), stage = E.byId(m.stages, step?.stageId);
  state.drawer = { title: `${exception.id} · ${exception.name}`, body: `<div class="notice amber"><b>触发位置</b><br>${esc(stage?.name || '未分组')} / ${esc(step?.id || '未指定')} · ${esc(step?.name || '')}</div><div class="kv"><span>触发条件</span><span>${esc(exception.trigger)}</span><span>处理角色</span><span>${esc(actorName(m, exception.actorId))}</span></div><h3>处理路径</h3><div class="recovery-path">${exception.handling.map((item, index) => `<div><span>${index + 1}</span><b>${esc(item)}</b></div>`).join('')}</div><div class="notice green"><b>恢复结果</b><br>${esc(exception.recovery)}</div>`, foot: btn('定位触发步骤', 'locate-exception', 'primary') };
  C().exceptionId = id; renderOverlay();
}
function globalSearch(query) {
  const m = M(), q = query.toLowerCase();
  const full = [
    ...m.domains.map(item => ({ ...item, type: '领域', route: 'explore' })), ...m.scenarios.map(item => ({ ...item, type: '场景', route: 'scenario' })),
    ...m.actions.map(item => ({ ...item, type: '动作', route: 'action' })), ...m.rules.map(item => ({ ...item, type: '规则', route: 'knowledge' })),
    ...m.surfaces.map(item => ({ ...item, type: '界面', route: 'surface' })), ...m.objects.map(item => ({ ...item, type: '对象', route: 'knowledge' }))
  ];
  const indexed = q.length >= 2 ? [...AtlasModel.scaleIndex(m, 'actions').map(item => ({ ...item, type: '仅索引动作' })), ...AtlasModel.scaleIndex(m, 'surfaces').map(item => ({ ...item, type: '仅索引界面' }))] : [];
  const items = [...full, ...indexed].filter(item => `${item.id}${item.name}`.toLowerCase().includes(q)).slice(0, 12);
  modal('全局搜索 · 仅当前项目', `<div class="searchbox"><input class="input" id="search-modal-input" value="${esc(query)}" placeholder="输入业务名称或稳定 ID"></div><div class="search-results">${items.map(item => `<button class="search-result" data-search-route="${item.route || ''}" data-search-id="${item.id}" data-search-type="${item.type}"><span class="result-icon">${item.type[0]}</span><div><b>${esc(item.name)}</b><span class="mono muted">${item.id}</span><p>${item.type} · ${esc(m.meta.name)}${item.indexOnly ? ' · 无完整语义' : ''}</p></div></button>`).join('') || empty('⌕', '无匹配结果', '尝试完整稳定 ID 或业务名称。')}</div>`, '', true);
}
function agentContext() {
  const m = M(), selected = currentAction() || currentRule(), suggested = selected ? `${selected.id}@${selected.version || selected.currentVersion || ''}` : '';
  state.drawer = { title: '按稳定 ID 获取业务上下文', body: `<div class="notice blue">原型不实现 MCP Server，但演示严格版本语义：请求版本不可用或未发布时明确失败，不自动替换。</div><div class="field"><label>对象与版本</label><input id="agent-ref" value="${esc(suggested)}" placeholder="例如：动作或规则 ID@版本"></div><div id="agent-result"></div>`, foot: btn('获取上下文', 'fetch-agent-context', 'primary') };
  renderOverlay();
}
function fetchAgentContext() {
  const m = M(), reference = $('#agent-ref').value.trim(), match = /^(.+?)@(.+)$/.exec(reference);
  if (!match) { $('#agent-result').innerHTML = '<div class="notice red">请使用 ID@版本 格式。</div>'; return; }
  const [, id, version] = match, rule = E.byId(m.rules, id);
  let action = E.byId(m.actions, id), scenario = E.byId(m.scenarios, id);
  if (action && action.version !== version && m.archives?.[`action:${id}@${version}`]) action = m.archives[`action:${id}@${version}`];
  if (scenario && scenario.version !== version && m.archives?.[`scenario:${id}@${version}`]) scenario = m.archives[`scenario:${id}@${version}`];
  let payload = null, error = '';
  if (rule) {
    const selected = rule.versions[version];
    if (!selected || !['published', 'historical'].includes(selected.status)) error = `${id}@${version} 不可用或未发布`;
    else payload = { id, version, type: 'rule', name: rule.name, definition: clone(selected), usedBy: E.ruleUsage(m, id).actionIds };
  } else if (action) {
    if (action.version !== version || action.status !== 'published') error = `${id}@${version} 不可用或未发布`;
    else {
      const references = E.relationIndex(m).targets(id, 'uses').map(ruleId => {
        const rule = E.byId(m.rules, ruleId), ruleVersion = action.ruleVersions?.[ruleId];
        if (!rule || !ruleVersion || !['published', 'historical'].includes(rule.versions[ruleVersion]?.status)) return { id: ruleId, version: ruleVersion || '未固定', unavailable: true };
        return { id: ruleId, version: ruleVersion, definition: clone(rule.versions[ruleVersion]) };
      });
      if (references.some(reference => reference.unavailable)) error = `${id}@${version} 存在不可用或未固定的规则版本`;
      else payload = { id, version, type: 'action', name: action.name, definition: clone(action), rules: references };
    }
  } else if (scenario) {
    if (scenario.version !== version || scenario.status !== 'published') error = `${id}@${version} 不可用或未发布`;
    else payload = { id, version, type: 'scenario', definition: clone(scenario) };
  } else error = `当前项目中不存在 ${id}`;
  $('#agent-result').innerHTML = error ? `<div class="notice red">${esc(error)}。未返回其他版本。</div>` : `<div class="notice green">返回同一批准版本的一致上下文。</div><pre class="package-code agent-json">${esc(JSON.stringify(payload, null, 2))}</pre>`;
}

/* Creation and first publication */
function addRelation(m, from, type, to, kind = 'knowledge') { m.relations.push({ id: AtlasModel.nextId(m, 'REL'), from, type, to, kind }); }
function rebuildSimpleFlow(m, scenario) {
  let flow = E.flowFor(m, scenario.id);
  if (!flow.id) { flow = { id: AtlasModel.nextId(m, 'FLOW'), scenarioId: scenario.id, nodes: [], edges: [] }; m.flows.push(flow); }
  const actions = m.actions.filter(action => action.scenarioId === scenario.id);
  flow.nodes = [{ id: `${flow.id}-START`, type: 'start', name: '开始', stageId: scenario.stageIds[0] }, ...actions.map(action => ({ id: `${flow.id}-${action.id}`, actionId: action.id, stageId: action.stageId, type: 'action' })), { id: `${flow.id}-END`, type: 'end', name: '完成', stageId: scenario.stageIds.at(-1) }];
  flow.edges = []; const nodeIds = flow.nodes.map(node => node.id);
  nodeIds.slice(0, -1).forEach((id, index) => flow.edges.push({ id: `${flow.id}-E${index + 1}`, from: id, to: nodeIds[index + 1], type: 'next' }));
}
function openFirstPublish() {
  const m = M();
  modal('首次确认并发布', `<div class="notice blue">新对象草稿 → 业务确认 → 首次批准 → v1.0。首次发布不解析任何既有版本号。</div><div class="kv"><span>业务领域</span><span>${m.domains.length}</span><span>业务场景</span><span>${m.scenarios.length}</span><span>业务动作</span><span>${m.actions.length}</span><span>业务规则</span><span>${m.rules.length}</span></div><label class="checkbox"><input type="checkbox" id="first-confirm"> 我确认这些内容已形成可发布的初始业务定义</label><div class="notice amber">规则若包含结构化决策，会先检查冲突与无效引用；人工约束保持人工核验标识。</div>`, btn('取消', 'close') + btn('首次批准并发布 v1.0', 'confirm-first-publish', 'primary'));
}

/* Main action handler */
function handleAction(actionName, element) {
  const m = M(), c = C();
  switch (actionName) {
    case 'projects': go('projects'); break;
    case 'back-overview': go('overview'); break;
    case 'back-scenario': go('scenario'); break;
    case 'return-context': returnContext(); break;
    case 'close': closeOverlays(); break;
    case 'overlay-bg': if (element.classList.contains('overlay')) closeOverlays(); break;
    case 'create-project':
      modal('创建新项目', `<div class="field"><label>项目名称 *</label><input id="new-project-name"></div><div class="field"><label>业务目标</label><textarea id="new-project-goal"></textarea></div><div class="notice blue">项目拥有独立稳定 ID、知识关系、草稿和首次发布流程。</div>`, btn('取消', 'close') + btn('创建并开始构建', 'confirm-create', 'primary')); break;
    case 'confirm-create': {
      const name = $('#new-project-name').value.trim(); if (!name) { toast('请输入项目名称', 'error'); return; }
      const id = `PRJ-${String(Object.keys(store.projects).length + 1).padStart(5, '0')}`;
      store.projects[id] = AtlasModel.createEmptyProject(id, name, $('#new-project-goal').value.trim()); store.currentProjectId = id; resetContext(); save(); go('overview'); break;
    }
    case 'connect':
      modal('接入已有项目', `<div class="field"><label>项目名称</label><input id="connect-name"></div><div class="notice amber">只创建恢复工作台，不读取真实代码仓库。恢复内容必须经证据核验。</div>`, btn('取消', 'close') + btn('创建恢复工作台', 'confirm-connect', 'primary')); break;
    case 'confirm-connect': {
      const id = `PRJ-${String(Object.keys(store.projects).length + 1).padStart(5, '0')}`;
      store.projects[id] = AtlasModel.createEmptyProject(id, $('#connect-name').value.trim() || '已恢复项目', '恢复并核验已有业务知识'); store.currentProjectId = id; resetContext(); save(); go('overview'); break;
    }
    case 'edit-goal': modal('项目业务目标', `<div class="field"><label>业务目标</label><textarea id="project-goal">${esc(m.meta.goal)}</textarea></div>`, btn('取消', 'close') + btn('保存目标', 'save-goal', 'primary')); break;
    case 'save-goal': m.meta.goal = $('#project-goal').value.trim(); m.meta.desc = m.meta.goal; save(); closeOverlays(); render(); break;
    case 'add-domain':
      modal('添加业务领域', `<div class="field"><label>领域名称 *</label><input id="domain-name"></div><div class="field"><label>领域职责</label><textarea id="domain-desc"></textarea></div>`, btn('取消', 'close') + btn('添加领域', 'confirm-domain', 'primary')); break;
    case 'confirm-domain': {
      const name = $('#domain-name').value.trim(); if (!name) { toast('领域名称不能为空', 'error'); return; }
      const id = AtlasModel.nextId(m, 'DOM'); m.domains.push({ id, name, icon: name[0], desc: $('#domain-desc').value, goal: $('#domain-desc').value, caps: [], objects: [], actorIds: [], depends: [], status: 'draft' });
      c.selectedDomainId = id; c.overviewSelection = id; save(); closeOverlays(); render(); break;
    }
    case 'add-scenario':
      modal('创建业务场景', `<div class="field"><label>场景名称 *</label><input id="scenario-name"></div><div class="field"><label>参与者 *</label><input id="scenario-actors" placeholder="使用顿号分隔"></div><div class="field"><label>触发条件</label><input id="scenario-trigger"></div><div class="field"><label>期望业务结果</label><textarea id="scenario-result"></textarea></div>`, btn('取消', 'close') + btn('创建并添加动作', 'confirm-scenario', 'primary')); break;
    case 'confirm-scenario': {
      const name = $('#scenario-name').value.trim(), names = $('#scenario-actors').value.split(/[、,，]/).map(value => value.trim()).filter(Boolean);
      if (!name || !names.length || !m.domains.length) { toast('请先建立领域，并填写场景名称和参与者', 'error'); return; }
      const id = AtlasModel.nextId(m, 'SCN'), participants = names.map(actorNameValue => {
        let item = m.actors.find(actorItem => actorItem.name === actorNameValue);
        if (!item) { item = { id: AtlasModel.nextId(m, 'ACTOR'), name: actorNameValue, concern: '待明确' }; m.actors.push(item); }
        return item.id;
      });
      const scenario = { id, name, version: 'draft', status: 'draft', goal: $('#scenario-result').value || name, trigger: $('#scenario-trigger').value, participants, result: $('#scenario-result').value, stageIds: [], exceptionIds: [], full: true };
      m.scenarios.push(scenario); c.selectedScenarioId = id; save(); go('scenario'); break;
    }
    case 'add-action': {
      const scenario = currentScenario(); if (!scenario) { toast('请先创建场景', 'error'); return; }
      modal('添加业务动作', `<div class="field"><label>动作名称 *</label><input id="action-name"></div><div class="field"><label>执行者</label><select id="action-actor">${scenario.participants.map(id => `<option value="${id}">${esc(actorName(m, id))}</option>`).join('')}</select></div><div class="field"><label>业务目的</label><textarea id="action-purpose"></textarea></div>`, btn('取消', 'close') + btn('创建动作', 'confirm-action', 'primary')); break;
    }
    case 'confirm-action': {
      const scenario = currentScenario(), name = $('#action-name').value.trim(); if (!name) { toast('动作名称不能为空', 'error'); return; }
      let stage = scenario.stageIds.map(id => E.byId(m.stages, id)).filter(Boolean)[0];
      if (!stage) {
        stage = { id: AtlasModel.nextId(m, 'STG'), name: scenario.name, goal: scenario.goal, domainId: m.domains[0].id, input: scenario.trigger, result: scenario.result, actorIds: scenario.participants, stepIds: [], capabilityIds: [], status: 'draft' };
        m.stages.push(stage); scenario.stageIds = [stage.id]; addRelation(m, scenario.id, 'contains', stage.id, 'structure');
      }
      const id = AtlasModel.nextId(m, 'ACT'), stepId = AtlasModel.nextId(m, 'STEP'), actorId = $('#action-actor').value;
      m.steps.push({ id: stepId, number: m.steps.length + 1, stageId: stage.id, actionId: id, name, actorId, kind: 'action', result: $('#action-purpose').value }); stage.stepIds.push(stepId); addRelation(m, stage.id, 'contains', stepId, 'structure');
      m.actions.push({ id, name, version: 'draft', status: 'draft', actorId, stageId: stage.id, scenarioId: scenario.id, stepId, domainId: stage.domainId, capabilityIds: [], depth: 'detailed', purpose: $('#action-purpose').value, pre: [scenario.trigger], input: ['用户输入'], output: [$('#action-purpose').value || name], objectChanges: [], exceptions: [], evidence: [], implementation: null });
      addRelation(m, id, 'belongsTo', scenario.id, 'structure'); rebuildSimpleFlow(m, scenario); c.selectedActionId = id; c.storyNodeId = id; save(); closeOverlays(); render(); break;
    }
    case 'add-rule':
      modal('添加业务规则', `<div class="field"><label>规则名称 *</label><input id="new-rule-name"></div><div class="field"><label>规则约束或业务表达</label><textarea id="new-rule-expression"></textarea></div><label class="checkbox"><input type="checkbox" id="new-rule-decision"> 创建为可试算决策规则（随后在编辑器添加条件与结果）</label><div class="notice blue">新规则从草稿开始，并关联当前场景动作；不会自动获得正式版本。</div>`, btn('取消', 'close') + btn('创建并关联', 'confirm-rule', 'primary')); break;
    case 'confirm-rule': {
      const name = $('#new-rule-name').value.trim(); if (!name) { toast('规则名称不能为空', 'error'); return; }
      const id = AtlasModel.nextId(m, 'RULE'), decision = $('#new-rule-decision').checked, text = $('#new-rule-expression').value.trim();
      const version = { version: 'draft', status: 'draft', name, scope: currentScenario()?.trigger || '当前项目', supportsEvaluation: decision, constraint: decision ? '' : text || '待明确人工核验约束', inputs: [], outcomes: [], rows: [], exceptions: [], effective: '草稿', source: '用户创建' };
      version.summary = E.summarizeRule(version);
      m.rules.push({ id, name, owner: '林岚', currentVersion: null, versions: { draft: version } });
      const linked = m.actions.find(actionItem => actionItem.scenarioId === currentScenario()?.id); if (linked) addRelation(m, linked.id, 'uses', id);
      c.selectedRuleId = id; c.knowledgeTab = 'rules'; save(); go('knowledge'); break;
    }
    case 'first-publish': openFirstPublish(); break;
    case 'confirm-first-publish': {
      if (!$('#first-confirm').checked) { toast('请先完成业务确认', 'error'); return; }
      const result = AtlasModel.firstPublish(m); if (!result.ok) { toast(result.errors[0], 'error'); return; }
      m.changes.forEach(change => { if (change.status === 'draft' && (!change.baseVersion || change.baseVersion === 'draft')) { change.status = 'approved'; change.publishedVersion = 'v1.0'; } }); save(); closeOverlays(); render(); toast('首个正式业务版本 v1.0 已发布'); break;
    }
    case 'focus': c.focus = !c.focus; save(); render(); break;
    case 'toggle-explore': c.explore = !c.explore; save(); render(); break;
    case 'toggle-exceptions': c.showExceptions = !c.showExceptions; save(); render(); break;
    case 'exceptions': {
      const scenario = currentScenario(); state.drawer = { title: `场景异常 · ${scenario.exceptionIds.length} 个`, body: scenario.exceptionIds.map(id => E.byId(m.exceptions, id)).filter(Boolean).map(exception => `<button class="exception-row" data-exception="${exception.id}"><b>${exception.id} · ${esc(exception.name)}</b><span>${esc(exception.trigger)}</span><i>${esc(exception.recovery)}</i></button>`).join('') || '<p class="muted">尚未定义异常。</p>' }; renderOverlay(); break;
    }
    case 'locate-exception': {
      const exception = E.byId(m.exceptions, c.exceptionId), step = E.byId(m.steps, exception.stepId); c.selectedStageId = step.stageId; c.storyNodeId = step.actionId; closeOverlays(); save(); go('scenario'); break;
    }
    case 'edit-scenario': openObjectEditor('scenario', currentScenario()); break;
    case 'scenario-list': go('overview'); break;
    case 'edit-action': openObjectEditor('action', currentAction()); break;
    case 'edit-object': openObjectEditor('object', E.byId(m.objects, c.selectedObjectId)); break;
    case 'save-object-draft': {
      const change = E.byId(m.changes, state.drawer?.changeId), draft = change?.draftDefinition;
      if (!change || !draft) return;
      const reason = $('#definition-reason').value.trim(); if (!reason) { toast('变更原因不能为空', 'error'); return; }
      draft.name = $('#definition-name').value.trim() || draft.name;
      if (change.objectType === 'action') draft.purpose = $('#definition-purpose').value.trim();
      if (change.objectType === 'scenario') { draft.goal = $('#definition-goal').value.trim(); draft.trigger = $('#definition-trigger').value.trim(); draft.result = $('#definition-result').value.trim(); }
      if (change.objectType === 'object') { draft.desc = $('#definition-desc').value.trim(); draft.states = $('#definition-states').value.split('→').map(value => value.trim()).filter(Boolean); draft.props = $('#definition-props').value.split(/[、,，]/).map(value => value.trim()).filter(Boolean); }
      change.reason = reason; change.status = 'draft'; change.history.push({ at: new Date().toISOString(), by: '林岚', text: '保存独立业务定义草稿' });
      save(); closeOverlays(); render(); toast(`${change.id} 草稿已保存，已发布定义未改变`); break;
    }
    case 'edit-rule': closeOverlays(); openRuleEditor(); break;
    case 'edit-selected-rule': {
      const change = activeChange();
      if (change.ruleId) { c.selectedRuleId = change.ruleId; save(); openRuleEditor(); }
      else openObjectEditor(change.objectType, changeTarget(m, change));
      break;
    }
    case 'clear-rule-preview': c.rulePreviewChange = null; save(); render(); break;
    case 'rule-impact': closeOverlays(); ruleImpact(); break;
    case 'save-rule-draft': {
      const change = E.byId(m.changes, state.drawer?.changeId); if (!change) return;
      readRuleEditor(change); if (!change.reason) { toast('修改原因不能为空', 'error'); return; }
      change.status = 'draft'; change.history.push({ at: new Date().toISOString(), by: '林岚', text: '保存独立结构化规则草稿' });
      c.rulePreviewChange = change.id; c.selectedRuleId = change.ruleId; c.ruleVersion = null; save(); closeOverlays(); render(); toast(`${change.targetVersion} 草稿已保存，正式版本未改变`); break;
    }
    case 'editor-add-row': case 'editor-add-exception': {
      const change = E.byId(m.changes, state.drawer?.changeId); readRuleEditor(change); const exception = actionName === 'editor-add-exception';
      const collection = exception ? change.draftRule.exceptions : change.draftRule.rows;
      collection.push({ id: `ROW-${Date.now()}`, priority: Math.max(0, ...[...change.draftRule.rows, ...change.draftRule.exceptions].map(row => row.priority)) + 10, when: {}, outcomeId: change.draftRule.outcomes[0]?.id });
      openRuleEditor(); break;
    }
    case 'editor-add-input': {
      const change = E.byId(m.changes, state.drawer?.changeId); readRuleEditor(change); const number = change.draftRule.inputs.length + 1;
      change.draftRule.inputs.push({ id: `condition${number}`, label: `新条件 ${number}`, kind: 'enum', default: 'no', options: [{ value: 'no', label: '否' }, { value: 'yes', label: '是' }] }); openRuleEditor(); break;
    }
    case 'editor-add-outcome': {
      const change = E.byId(m.changes, state.drawer?.changeId); readRuleEditor(change); const id = `OUTCOME_${change.draftRule.outcomes.length + 1}`;
      change.draftRule.outcomes.push({ id, label: '新结果', actorIds: [], description: '待明确业务结果' }); openRuleEditor(); break;
    }
    case 'submit-change': {
      const change = activeChange(), validation = changeValidation(m, change);
      if (validation.includes('notice red')) { toast('仍有发布前阻塞，请查看当前变更检查', 'error'); render(); return; }
      change.status = 'pending'; if (change.draftRule) change.draftRule.status = 'pending'; change.history.push({ at: new Date().toISOString(), by: '林岚', text: '提交业务审批' }); save(); render(); break;
    }
    case 'approve-change': {
      const change = activeChange(), result = change.ruleId ? E.publishRuleChange(m, change.id, '陈屿') : E.publishObjectChange(m, change.id, '陈屿');
      if (!result.ok) { toast(result.errors[0], 'error'); render(); return; }
      c.ruleVersion = result.version.version; c.rulePreviewChange = null; save(); render(); toast(`${change.ruleId || change.objectId}@${result.version.version} 已发布，旧版本保留为历史`); break;
    }
    case 'view-new-rule': {
      const change = activeChange();
      if (change.ruleId) openRule(change.ruleId);
      else if (change.objectType === 'action') openAction(change.objectId);
      else if (change.objectType === 'scenario') { c.selectedScenarioId = change.objectId; save(); go('scenario'); }
      else { c.selectedObjectId = change.objectId; c.knowledgeTab = 'objects'; save(); go('knowledge'); }
      break;
    }
    case 'issues': go('issues'); break;
    case 'back-change': go('changes'); break;
    case 'reply-issue': case 'investigate-issue': case 'return-supplement': case 'propose-decision': {
      const issue = E.byId(m.issues, c.selectedIssueId), text = $('#issue-reply').value.trim();
      if (actionName === 'propose-decision' && !text) { toast('请输入明确的业务处理结论', 'error'); return; }
      if (actionName === 'reply-issue' && !text) { toast('回复不能为空', 'error'); return; }
      if (text) issue.replies.push({ by: '林岚', text, time: '刚刚' });
      if (actionName === 'propose-decision') {
        if (!issue.evidenceIds.length && issue.requiresChange) { toast('证据不足，不能提交规范修改结论', 'error'); return; }
        issue.decision = text; issue.status = 'confirming'; const change = E.byId(m.changes, issue.changeId); if (change && !change.draftRule) ensureChange(E.byId(m.rules, change.ruleId));
      } else { issue.status = actionName === 'reply-issue' ? 'replied' : actionName === 'return-supplement' ? 'waiting' : 'investigating'; if (actionName !== 'reply-issue') issue.decision = null; }
      save(); render(); showIssue(issue.id); break;
    }
    case 'finalize-issue': {
      const issue = E.byId(m.issues, c.selectedIssueId), change = E.byId(m.changes, issue.changeId);
      if (issue.requiresChange && change?.status !== 'approved') { toast('对应业务版本尚未批准', 'error'); return; }
      issue.status = 'resolved'; issue.decidedVersion = change?.targetVersion || m.meta.version; save(); render(); showIssue(issue.id); break;
    }
    case 'reopen-issue': { const issue = E.byId(m.issues, c.selectedIssueId); issue.status = 'investigating'; issue.decidedVersion = null; save(); render(); showIssue(issue.id); break; }
    case 'locate-issue': { const issue = E.byId(m.issues, c.selectedIssueId); closeOverlays(); if (issue.objectId.startsWith('RULE')) openRule(issue.objectId); else if (issue.objectId.startsWith('ACT')) openAction(issue.objectId); else go('knowledge'); break; }
    case 'new-issue': modal('创建确认问题', `<div class="field"><label>问题内容 *</label><textarea id="new-issue-title"></textarea></div><div class="field"><label>关联业务对象</label><input id="new-issue-object" value="${esc(c.selectedActionId || c.selectedRuleId || '')}"></div>`, btn('取消', 'close') + btn('创建问题', 'confirm-issue', 'primary')); break;
    case 'confirm-issue': {
      const title = $('#new-issue-title').value.trim(); if (!title) { toast('问题内容不能为空', 'error'); return; }
      m.issues.unshift({ id: AtlasModel.nextId(m, 'Q'), title, why: '等待补充事实依据。', status: 'waiting', owner: '陈屿', objectId: $('#new-issue-object').value, changeId: null, blocked: [], replies: [], evidenceIds: [], requiresChange: false, decision: null }); save(); closeOverlays(); render(); break;
    }
    case 'generate-package': {
      const delivery = E.byId(m.deliveries, c.selectedDeliveryId), blocks = deliveryBlockers(m, delivery); if (blocks.length) { toast(blocks[0], 'error'); return; }
      const rule = E.byId(m.rules, delivery.ruleId);
      delivery.packageVersion = `${delivery.id}@${delivery.ruleVersion}`;
      delivery.snapshot = clone({ id: delivery.id, requirementId: delivery.requirementId, scenario: E.byId(m.scenarios, delivery.scenarioId), actions: delivery.actionIds.map(id => E.byId(m.actions, id)), rule: { id: rule.id, version: delivery.ruleVersion, definition: rule.versions[delivery.ruleVersion] }, surfaces: delivery.surfaceIds.map(id => E.byId(m.surfaces, id)), acceptance: delivery.acceptance, evidence: m.facts });
      delivery.stage = 2; save(); render(); toast('正式只读交接包已生成并固定快照'); break;
    }
    case 'advance-delivery': { const delivery = E.byId(m.deliveries, c.selectedDeliveryId); if (!delivery.packageVersion) { toast('请先生成正式交接包', 'error'); return; } delivery.stage = Math.min(5, delivery.stage + 1); save(); render(); break; }
    case 'accept-delivery': { const delivery = E.byId(m.deliveries, c.selectedDeliveryId); if (!delivery.packageVersion) { toast('没有正式交接包，不能验收', 'error'); return; } if (delivery.acceptance.some(item => !item.checked || item.status === 'stale')) { toast('仍有验收条件未确认或待重新核验', 'error'); return; } delivery.stage = 5; save(); render(); break; }
    case 'agent-context': closeOverlays(); agentContext(); break;
    case 'fetch-agent-context': fetchAgentContext(); break;
    case 'run-validation': { const result = E.validateProject(m); modal('一致性检查结果', `<div class="notice ${result.ok ? 'green' : 'red'}">${result.ok ? '全部自动检查通过' : `${result.errors.length} 个错误`}</div>${result.errors.map(error => `<div class="relation-box danger">${esc(error)}</div>`).join('')}${result.warnings.map(warning => `<div class="relation-box warning">${esc(warning)}</div>`).join('')}<p class="muted">覆盖 ID、关系、步骤、流程、指定版本规则、草稿隔离、变更引用、交接快照和验收版本。跨项目与完整发布行为另由 acceptance.test.js 重复执行。</p>`, btn('关闭', 'close'), true); break; }
    case 'actions-index': c.knowledgeTab = 'actions'; save(); go('knowledge'); break;
    case 'new-knowledge': modal('新建业务知识', `<div class="grid-2"><button class="cap-card" data-action="add-rule"><h3>业务规则</h3><p>条件、结果或人工约束</p></button><button class="cap-card" data-action="add-action"><h3>业务动作</h3><p>在当前场景中创建</p></button></div>`, btn('取消', 'close')); break;
    case 'recent': if (state.returnContext) returnContext(); else toast('当前没有待返回的跨页上下文'); break;
    case 'notifications': state.drawer = { title: '待处理通知', body: m.issues.filter(issue => !['resolved', 'cancelled'].includes(issue.status)).map(issue => `<button class="issue-card" data-issue="${issue.id}"><b>${esc(issue.title)}</b><p>${statusText(issue.status)}</p></button>`).join('') || '<p class="muted">没有待处理通知。</p>' }; renderOverlay(); break;
    case 'help': modal('V3 操作提示', `<div class="stack"><p>全景：切换观察角度，选中领域、能力、对象或角色，返回后保持上下文。</p><p>故事板：选择阶段，开启“探索业务结果”，修改条件并观察路径、角色和对象变化。</p><p>规则：结构化决策行是权威定义；草稿与已发布版本分别试算。</p><p>变更：多张变更单独立推进；批准后过期验收必须重新核验。</p><p>所有项目数据保存在当前浏览器 localStorage。</p></div>`, btn('关闭', 'close', 'primary')); break;
    case 'profile': modal('原型数据与重置', `<div class="kv"><span>当前项目</span><span>${esc(m.meta.name)}</span><span>存储</span><span>浏览器 localStorage</span></div><button class="btn danger-btn" data-action="reset">重置全部 V3 演示项目</button>`, btn('关闭', 'close')); break;
    case 'reset': localStorage.removeItem(STORE); store = { currentProjectId: 'PRJ-00001', contexts: {}, projects: { 'PRJ-00001': AtlasModel.createMatureProject(), 'PRJ-00002': AtlasModel.createBookingProject() } }; resetContext(); closeOverlays(); go('overview'); toast('已恢复两个初始演示项目'); break;
    default: break;
  }
}

/* Delegated interaction keeps selection, filters and drafts synchronized */
document.addEventListener('click', event => {
  const element = event.target.closest('[data-route],[data-action],[data-project],[data-domain],[data-scenario],[data-stage],[data-operating-stage],[data-flow-node],[data-open-action],[data-rule],[data-select-rule],[data-object],[data-select-object],[data-overview-lens],[data-overview-select],[data-action-lens],[data-knowledge-tab],[data-surface-mode],[data-surface],[data-issue],[data-change],[data-exception],[data-action-row],[data-action-page],[data-search-route],[data-editor-remove-row],[data-editor-remove-input],[data-revalidate-acceptance]');
  if (!element) return; const data = element.dataset, m = M(), c = C();
  if (data.route) { go(data.route); return; }
  if (data.project) { store.currentProjectId = data.project; C(); save(); go('overview'); return; }
  if (data.domain) { c.selectedDomainId = data.domain; c.overviewSelection = data.domain; save(); go('explore'); return; }
  if (data.scenario) { c.selectedScenarioId = data.scenario; const scenario = currentScenario(); c.selectedStageId = scenario.stageIds[0] || null; c.storyNodeId = m.actions.find(action => action.scenarioId === scenario.id)?.id || null; c.exploreValues = {}; c.explore = false; save(); go('scenario'); return; }
  if (data.stage || data.operatingStage) { c.selectedStageId = data.stage || data.operatingStage; c.storyNodeId = m.actions.find(action => action.stageId === c.selectedStageId)?.id || null; if (data.operatingStage) go('scenario'); else { save(); render(); } return; }
  if (data.flowNode) { c.selectedFlowNodeId = data.flowNode; if (data.flowAction) { c.storyNodeId = data.flowAction; c.selectedActionId = data.flowAction; } save(); render(); return; }
  if (data.openAction) { closeOverlays(); openAction(data.openAction); return; }
  if (data.actionRow) { openAction(data.actionRow); return; }
  if (data.rule) { closeOverlays(); openRule(data.rule); return; }
  if (data.selectRule) { c.selectedRuleId = data.selectRule; c.ruleVersion = null; c.rulePreviewChange = null; save(); render(); return; }
  if (data.object || data.selectObject) { c.selectedObjectId = data.object || data.selectObject; c.knowledgeTab = 'objects'; save(); go('knowledge'); return; }
  if (data.overviewLens) { c.overviewLens = data.overviewLens; c.overviewSelection = null; save(); render(); return; }
  if (data.overviewSelect) { c.overviewSelection = data.overviewSelect; if (data.capabilityOpen) { go('overview'); return; } save(); render(); return; }
  if (data.actionLens) { state.actionLens = data.actionLens; render(); return; }
  if (data.knowledgeTab) { c.knowledgeTab = data.knowledgeTab; save(); render(); return; }
  if (data.surfaceMode) { state.surfaceMode = data.surfaceMode; render(); return; }
  if (data.surface) { c.selectedSurfaceId = data.surface; save(); render(); return; }
  if (data.issue) { closeOverlays(); showIssue(data.issue); return; }
  if (data.change) { c.selectedChangeId = data.change; const change = E.byId(m.changes, data.change); if (change?.ruleId) c.selectedRuleId = change.ruleId; save(); closeOverlays(); go('changes'); return; }
  if (data.exception) { showException(data.exception); return; }
  if (data.actionPage) { state.actionPage = Number(data.actionPage); render(); return; }
  if (data.searchRoute) { const { searchRoute, searchId, searchType } = data; closeOverlays(); if (searchType.startsWith('仅索引')) { toast('该条目仅用于规模索引，未建立业务语义', 'error'); return; } if (searchRoute === 'action') openAction(searchId); else if (searchRoute === 'knowledge' && searchType === '规则') openRule(searchId); else if (searchRoute === 'knowledge') { c.selectedObjectId = searchId; c.knowledgeTab = 'objects'; go('knowledge'); } else if (searchRoute === 'scenario') { c.selectedScenarioId = searchId; go('scenario'); } else if (searchRoute === 'explore') { c.selectedDomainId = searchId; go('explore'); } else { c.selectedSurfaceId = searchId; go('surface'); } return; }
  if (data.editorRemoveRow) { const change = E.byId(m.changes, state.drawer?.changeId); readRuleEditor(change); change.draftRule.rows = change.draftRule.rows.filter(row => row.id !== data.editorRemoveRow); change.draftRule.exceptions = change.draftRule.exceptions.filter(row => row.id !== data.editorRemoveRow); openRuleEditor(); return; }
  if (data.editorRemoveInput) { const change = E.byId(m.changes, state.drawer?.changeId); readRuleEditor(change); const id = data.editorRemoveInput; change.draftRule.inputs = change.draftRule.inputs.filter(input => input.id !== id); [...change.draftRule.rows, ...change.draftRule.exceptions].forEach(row => delete row.when[id]); openRuleEditor(); return; }
  if (data.revalidateAcceptance) { const delivery = E.byId(m.deliveries, c.selectedDeliveryId), acceptance = E.byId(delivery.acceptance, data.revalidateAcceptance), rule = E.byId(m.rules, acceptance.ruleId), result = E.evaluateRule(rule.versions[rule.currentVersion], acceptance.sample); acceptance.expectedOutcomeId = result.outcome?.id; acceptance.ruleVersion = rule.currentVersion; acceptance.status = 'active'; acceptance.requiresReview = false; acceptance.checked = false; acceptance.reviewedAt = new Date().toISOString(); delivery.ruleVersion = rule.currentVersion; save(); render(); toast(`${acceptance.id} 已按当前规则重新核验`); return; }
  if (data.action) handleAction(data.action, element);
});

document.addEventListener('change', event => {
  const target = event.target, data = target.dataset, m = M(), c = C();
  if (target.id === 'rule-version') { c.ruleVersion = target.value; c.rulePreviewChange = null; save(); render(); }
  if (target.id === 'scenario-switch') { c.selectedScenarioId = target.value; const scenario = currentScenario(); c.selectedStageId = scenario.stageIds[0]; c.storyNodeId = m.actions.find(action => action.scenarioId === scenario.id)?.id; c.exploreValues = {}; save(); render(); }
  if (data.exploreInput) { c.exploreValues[data.exploreInput] = target.value; save(); render(); }
  if (data.ruleSim) { c.ruleSim[data.simKey] ||= {}; c.ruleSim[data.simKey][data.ruleSim] = target.value; save(); render(); }
  if (data.actionFilter) { c[data.actionFilter] = target.value; state.actionPage = 1; save(); render(); }
  if (data.surfaceFilter) { c[data.surfaceFilter] = target.value; save(); render(); }
  if (data.check) { activeChange().checks[data.check] = target.checked; save(); render(); }
  if (data.acceptance) { const delivery = E.byId(m.deliveries, c.selectedDeliveryId), acceptance = E.byId(delivery.acceptance, data.acceptance); acceptance.checked = target.checked; save(); }
  if (target.id === 'technical-review') { const delivery = E.byId(m.deliveries, c.selectedDeliveryId); delivery.technicalReview = target.checked; save(); render(); }
  if (state.drawer?.type === 'rule-editor' && (target.matches('[data-rule-editor],[data-row-priority],[data-row-condition],[data-row-outcome],[data-editor-sample]'))) {
    const change = E.byId(m.changes, state.drawer.changeId); refreshRuleEditor(change);
  }
});
let inputTimer;
document.addEventListener('input', event => {
  const target = event.target, c = C();
  if (target.id === 'global-search' || target.id === 'search-modal-input') { clearTimeout(inputTimer); inputTimer = setTimeout(() => globalSearch(target.value), 250); }
  if (target.id === 'project-search') { $$('[data-project]').forEach(card => { card.hidden = !card.dataset.projectName.includes(target.value.toLowerCase()); }); }
  if (target.id === 'overview-query') { c.overviewQuery = target.value; clearTimeout(inputTimer); inputTimer = setTimeout(() => { save(); render(); $('#overview-query')?.focus(); }, 180); }
  if (target.id === 'action-query') { c.actionQuery = target.value; state.actionPage = 1; clearTimeout(inputTimer); inputTimer = setTimeout(() => { save(); render(); const input = $('#action-query'); input?.focus(); input?.setSelectionRange(input.value.length, input.value.length); }, 180); }
  if (target.id === 'surface-query') { c.surfaceQuery = target.value; clearTimeout(inputTimer); inputTimer = setTimeout(() => { save(); render(); $('#surface-query')?.focus(); }, 180); }
  if (state.drawer?.type === 'rule-editor' && target.matches('[data-rule-editor],[data-row-priority],[data-outcome-label]')) {
    const change = E.byId(M().changes, state.drawer.changeId); refreshRuleEditor(change);
  }
});
document.addEventListener('keydown', event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); globalSearch(''); }
  if (event.key === 'Escape') closeOverlays();
});
addEventListener('hashchange', () => { const route = location.hash.slice(1); if (route && route !== state.route) { state.route = route; render(); } });
render();
