# Business Atlas V6 设计与模型约定

## 1. 双向闭环

V6 将产品闭环落实为四组同一事实上的操作：

1. 从现实业务建立知识：实体、动作、规则、事件、状态、因果、技术映射和来源。
2. 从知识建立认知：Projection 按当前焦点与基线读取真实关联，Presentation 决定组件与优先级。
3. 从认知产生协作：Change Set、任务、契约、问题、审核和验收。
4. 从协作更新知识：问题形成决定，草稿经审核发布，旧契约过期，复核后继续。

## 2. Knowledge Command

`src/v6-core.js` 注册自然业务原子操作：

- CreateEntity / SetProperty
- DefineRule / AddBehavior / ConnectBehavior / DefineTransition
- LinkKnowledge / BindImplementation / AttachEvidence
- CreateIssue / ProposeChange / PublishRevision
- RetireEntity / RetireAssertion / MoveLayout / Undo

每个操作通过统一管道：

```text
输入 → 类型/前提/来源校验 → Draft Workspace
→ 操作审计与撤销快照 → 重新投影当前视图
→ Change Set 语义检查 → 审核 → 原子修订集合 → 新 Baseline
```

UI 只显示业务语言。规则条件、状态、分支、字段和关系均通过选择器与动态表单创建，没有 JSON 编辑区。

## 3. Draft Workspace 与 Change Set

工作区包含：entities、assertions、flows、停用集合、操作日志、撤销栈、验证结果、问题关联和审核记录。新建知识默认 r0/a0、draft、unverified。

发布时：

- 新实体生成 r1，既有实体形成下一修订。
- 新断言生成 a1，既有断言形成下一修订。
- 流程形成独立修订。
- 新关联和状态转移先为待核验；审核人确认或可信来源支持后才成为 confirmed。
- 无人工确认且无来源的断言不能自动成为已确认事实。
- 全部对象、断言与流程在同一个 Baseline 中固定版本。

`initProject` 负责刷新后的工作区与 Change Set 重新水合，防止知识状态与历史操作分离。

## 4. Projection 与 Presentation

`projectKnowledge` 只接受明确 rootId。未知对象返回 NOT_FOUND，未授权根对象返回 FORBIDDEN，不回退默认剖面。

关联查询先读取关系，再逐对象检查权限；否则“无权限的必要依赖”会被误当成“没有依赖”。Projection 返回实体、断言、流程、缺失和排除原因。

`focusFacts` 根据当前选中对象实时查询：

- 业务意义、输入、前提与输出。
- 关联规则与对象变化。
- 技术读写、事件与上下游。
- 来源、可信状态、任务与问题。

`compose` 根据实际知识选择流程、决策、状态、实现、事件和证据组件，不使用固定 A/B/C/D/E 报告结构。V5 的 panorama 内容在 V6 中只保留为轻量 View Definition，不再作为权威业务数据。

## 5. 历史修订

统一存档：

- `knowledgeRevisions[entityId@revision]`
- `assertionRevisionStore[assertionId@revision]`
- `flowRevisions[flowId@revision]`

Baseline 同时固定 entries、assertionRevisions 和 flowRevisions。读取旧基线时从存档恢复，而不是在当前 assertions 中过滤最新记录。旧契约按原基线仍能读取 a1，即使当前已经是 a2。

## 6. 正式契约

正式生成不使用用户深度截断，而是沿必要关系计算完整闭包。入口依次检查：

- 根对象和批准基线存在且可访问。
- 根对象已批准，验收明确，根功能具有可信来源或验收证据。
- 必要规则具有适用范围与可信来源。
- 必要对象、关系、流程和证据版本可读取。
- 当前权限可读取所有必要知识与证据。
- 关键未知已解决或具有批准豁免，无阻断性事实冲突。

失败返回 INCOMPLETE_CONTEXT、PERMISSION_INCOMPLETE、EVIDENCE_INCOMPLETE 或 UNSAFE_CONTEXT，并说明缺失和排除原因，不返回貌似完整的包。

## 7. 协作闭环

任务保存 rootId、activeContractId、contractIds、issueIds、验收与历史。问题保存 taskId、contractId、objectId、位置、来源、影响、责任人、分类、决定和 changeSetId。

知识发布时根据版本绑定将旧契约标为 requires-review，任务标为 needs-review。复核生成新契约后，已处理问题关闭，任务恢复 active；只有当前契约有效且问题全部关闭时才能 completed。
