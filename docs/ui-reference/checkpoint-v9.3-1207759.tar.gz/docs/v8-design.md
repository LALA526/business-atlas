# Business Atlas V8 架构与不变量

## 1. Knowledge Read Context

`R.context()` 固定 projectId、baselineId、versionMode、draftWorkspaceId、permissionContext、applicableContext 和 readPurpose。

- published：当前批准基线。
- historical：明确指定的历史基线。
- draft：允许当前工作区叠加预览，并明确标识。

所有读取服务接收同一上下文。不得内部擅自改成 draft，不得在历史缺失时回退最新版本，不得在导出时扩大权限。

治理状态、事实核验状态和结构覆盖状态独立：published 描述发布，confirmed/unverified 描述核验，met/missing/unknown/not_applicable 描述覆盖。

## 2. Command Transaction

Command 在隔离 Draft Workspace 执行：

```text
Prepare → Validate → Apply to Staging → Verify → Commit
```

成功时将实体、断言、流程、操作日志、ID 序列和 Undo 快照一次提交；失败时恢复原工作区与 ID 序列。

AttachEvidence 对发布对象先复制草稿，再创建 Resource、cites 和目标 sourceIds，禁止原地修改冻结对象。

发布 Change Set 使用完整项目副本验证并构造新基线，成功后一次替换正式状态；旧契约对象保留引用并标记过期。

Undo 是用户主动撤销成功操作，Rollback 是失败操作从未发生，两者分别记录。

## 3. Baseline Invariant

历史基线不可变。首次创建演示种子可形成一致初始快照；运行时不得通过初始化函数补充事实或修改历史绑定。

覆盖、创建、发布、初始化、重复迁移、跨项目操作都执行内容级摘要比较。

## 4. Catalog Resolver

Catalog Record 是轻量查询投影，包含 stableId、recordKind、categoryIds、projectId、title、summary、status、versionRef、updatedAt、openAction 和 supportedActions。

数据按 recordKind 从真实集合读取：实体、基线、工作流定义/实例、任务、问题、变更、审核、契约、交付、验收、影响和冲突。不同记录使用不同打开操作。

实体使用 `entity` 字段，治理记录使用 `raw` 字段；检查器分别处理，避免形态混淆。

52 个分类都有 dataSource、supportedActions、readPolicy、statusPolicy、completenessPolicy 和 inspectorProfile。特殊分类归属由 `categoryAssignments` 决定；旧字符串匹配仅是兼容候选，不是新的权威分类依据。

## 5. Coverage

对象级覆盖按类型与真实关系计算，尊重 Read Context。分类级覆盖说明关键职责，不按对象数量平均，未配置标准时显示未配置，不默认完整。

功能、配置、项目介绍、规则、工作流、基线、任务与问题使用不同检查项。分类创建意图在保存时写入结构化归属，改名不影响分类。

## 6. Action Context

操作包含 projectId、targetId、targetKind、command、versionMode、baselineId、returnContext 和 origin。操作不再通过 DOM 查找当前目标。

补充验收、关联场景、添加来源、建立映射等在阅读与构建模式下共用处理函数，保存后返回原焦点。

## 7. 阶段摘要与性能

阶段摘要来自实际进入边、动作、判断、状态转移、退出边和角色。没有业务事实时显示“阶段细节尚未建立”，不复制通用文案。

目录缓存按项目、基线、版本模式、工作区、分类与权限隔离，草稿更新后失效，不修改权威事实。大目录继续按每页 20 项查询。
