# Business Atlas V9：领域模型与责任边界

> 本文是首条切片和后续实施的统一术语。字段名用于说明语义，不要求机械复制原型的 JSON 存储结构。

## 1. 核心原则

### 1.1 三种身份不能混用

- **内部稳定 ID**：如 `PRJ-*`、`FEAT-*`、`AST-*`、`BL-*`，由目标项目域内使用；重命名不改变身份。
- **外部稳定身份**：`(sourceProjectId, stableExternalId)` 唯一映射到内部实体/断言；重导不能靠名称重新认亲。
- **修订身份**：`entityId@revision`、`assertionId@revision`、`flowId@revision` 指向不可变内容；当前指针可变，历史修订不可变。

同名只产生“潜在重复”提示，不自动合并。跨项目引用必须显式建模，不得借相同名称或相同外部 ID 隐式共享对象。

### 1.2 版本分层

| 层 | 表示什么 | 变化规则 |
|---|---|---|
| 对象/断言/流程修订 | 一份具体内容 | 修改先产生草稿修订；已绑定修订不可原地改 |
| Baseline | 某次批准时完整修订集合及批准记录 | 发布后冻结；当前基线指针可前进，旧基线不前进 |
| Contract 快照 | 为某任务从指定基线计算的交付闭包 | 固定版本绑定；后续知识变化只标记需复核 |
| 技术版本层 | `architectureRevision`、`codeRevision`、依赖、部署、运行配置 | 与业务基线分开；纯技术版本变化不制造空业务基线 |
| View revision | 图形布局与阅读配置 | 只改展示，不改变知识修订或业务基线 |

### 1.3 四种状态不可压缩成一个 `status`

1. **治理/发布**：draft、proposed、published、historical、retired 等。
2. **事实/核验**：AKP 保留 `observed / documented_intent / inferred / unknown / conflicting`；阅读还可出现 `unverified / confirmed / conflicted`。
3. **适用性**：`applicable / not_applicable / unknown / conflict`。
4. **结构覆盖**：`met / missing / unknown / unverified / not_applicable`。

`published ≠ confirmed`；`observed ≠ approved specification`；对象数量多不等于覆盖完整。

## 2. 聚合与职责

| 概念 | 身份与版本 | 责任与关键内容 | 主要责任角色 |
|---|---|---|---|
| **Project** | `projectId`；有当前基线指针及项目 Schema 版本 | 知识隔离边界；保存定位、范围、Schema/分类、适用维度、权限策略和各版本层。项目容器与类型为 `Project` 的知识实体可关联，但语义不同 | 项目负责人、知识负责人 |
| **Knowledge Entity** | `entityId + revision`；`typeId` 稳定 | 业务或工程节点，如 Feature、Rule、Component、Test；包含属性、分类、来源、敏感性、适用上下文和事实等级，不保存“当前适用”的全局结论 | 知识编辑者；对应业务/技术 Owner |
| **Assertion** | `assertionId + revision` | 一条可引用语义声明：`subject + predicate + object/value + qualifiers + sourceRefs + factKind`。谓词受 Schema 约束；关系两端必须可读、版本有效 | 知识编辑者、事实复核人 |
| **Source** | `sourceId/resourceId + sourceRevision/contentHash` | 原始依据及定位：URI/path、行范围/章节/锚点、摘录、采集方式、敏感性和修订。原型中主要以 `Resource` 实体承载，概念上不是普通业务断言 | 来源提供人、知识负责人 |
| **Applicability** | 值对象，不独立建立全局 ID | 比较知识声明条件与 Read Context。核心维度含组织、租户、区域、环境、业务范围、系统/配置版本、有效期；项目可扩展 | 项目 Schema 负责人定义维度；调用者提供当前条件 |
| **Baseline** | `baselineId`；批准时间和确认记录固定 | 绑定实体、断言、流程修订的批准快照。提供当前/历史阅读锚点，不负责存储后续协作活动 | 有权批准人 |
| **ChangeSet** | `changeSetId`；`baseBaselineId` 和自身状态/操作序列 | 隔离草稿工作区，记录 operations、删除候选、差异、验证、审核决定和最终 `publishedBaselineId`；是写路径事务边界 | 编辑者提交，独立审核人批准 |
| **Task** | `taskId`；关联 Contract 和验收记录 | 描述开发、理解或验证目的，绑定根知识与知识集合；不代表知识本身，也不能绕过基线直接执行 | 任务 Owner、验收人 |
| **Issue** | `issueId`；状态、回复和解决基线留痕 | 表达待确认、冲突、缺陷或执行发现，关联对象、Task、Contract、影响和负责人；可驱动 ChangeSet，不直接修改批准知识 | 指定业务/技术确认人 |
| **Feedback** | `feedbackId`；`originContext`、history、resolvedBaselineId | 携带提交时的页面、基线、知识和证据，经历 triage、分析、处理中、关闭或重复；必须连接实际工作结果 | 报告人、知识负责人、验收人 |
| **AgentRun** | 外部 `runId`；开始/结束时间，reviewStatus | 保存外部执行证据：指令、tool-call、observation、inference、proposal、question、outcome 及 sourceRefs。不同事件类型不可混为事实 | Agent 生产者负责记录；人工复核人负责采纳 |
| **KnowledgePackage** | `packageId + contentHash`；格式版本 `AKP/0.1` | 可移植输入单元：manifest、entities、assertions、business/technical structures、sources、unknowns/conflicts、importProvenance。记录导入提案和发布状态，不是批准 Contract | 外部生产者生成；导入人确认 |
| **Contract** | `contractId/packageId`；固定 `versionBinding` | 面向 Task 的批准知识交付快照，包含必要依赖闭包、规则、实现、来源、验收、未知与完整性。读取时另生成当前授权视图 | 任务 Owner 生成/复核；读取者只能获得授权视图 |
| **VisualView** | `viewId + layoutRevision`；每次投影另带 Read Context | 保存根知识、视图类型、来源图像、热点和布局；流程/状态/架构/数据/时序/界面均由同一知识读取边界生成 | 知识阅读者/视图编辑者；不拥有新事实 |

## 3. 关键关系

```text
Project 1 ── * Knowledge Entity
Project 1 ── * Assertion ── * SourceRef ── 1 Source
Project 1 ── * Baseline ── * {EntityRevision, AssertionRevision, FlowRevision}
Project 1 ── * ChangeSet ── 1 Baseline（发布后）
Project 1 ── * Task ── * Contract ── 1 Baseline
Feedback ── 0..1 Issue/ChangeSet/Task ── 0..1 Baseline（解决后）
AgentRun ── 0..* proposal/question ── 0..* KnowledgePackage/Issue
VisualView ── Read Context + Entity/Assertion/Flow ──> 临时图形投影
```

KnowledgePackage 是“待导入知识及来源的运输格式”；Contract 是“从已批准基线为特定任务生成的交付快照”。二者不得复用生命周期或互相冒充。

## 4. 统一读取上下文

所有实体、关系、流程、来源、目录、问答、Contract 和图形读取必须基于：

```json
{
  "projectId": "PRJ-SELF",
  "baselineId": "BL-...",
  "versionMode": "published | historical | draft",
  "draftWorkspaceId": null,
  "permissionContext": "由服务端身份派生，不能信任客户端自报角色",
  "applicableContext": {"environment": "test", "asOf": "..."},
  "applicabilityMode": "explore | current",
  "readPurpose": "understand | analysis | build | formal",
  "timeMode": "current-activity | as-approved"
}
```

- `explore` 可展示适用、不适用、未知与冲突的比较；`current` 只允许明确适用内容成为当前结论。
- 声明了环境但请求缺少环境，或声明有效期但缺少 `asOf`，结果必须是 `unknown`。
- `draft` 只能叠加指定工作区；`published/historical` 不得隐式叠加草稿。
- 历史对象不存在时返回缺失，不得退回“当前最新对象”。

统一结果码：`OK`、`NOT_FOUND`、`FORBIDDEN`、`VERSION_UNAVAILABLE`、`CONTEXT_INSUFFICIENT`、`APPLICABILITY_UNKNOWN`、`DATA_INTEGRITY_ERROR`。响应不得借错误消息、关系端点或计数泄露受限内容。

## 5. 来源、事实与采纳规则

1. Entity 可有对象级 `sourceIds`；Assertion 必须有结构化 `sourceRefs`，其中 `locator` 精确到行、章节或锚点。
2. 来源路径、修订、内容哈希和采集方式共同回答“从哪里、哪个版本、如何得到”。
3. `observed` 只说明观察到；`documented_intent` 只说明资料表达意图；`inferred` 必须保持待核验；`unknown/conflicting` 不得被导入器省略。
4. Agent 工具输出先是 observation；推断与提案另存。任何类型都不能因导入或发布自动变成已确认事实。
5. 同名、相互矛盾、来源过期或端点缺失进入人工处理，不由“置信度高”自动裁决。
6. 引用读取仍受权限与适用性约束；答案不能因为已经保存就继续暴露后来无权读取的来源。

## 6. 写入与生命周期

### 6.1 知识与基线

```text
AKP / Agent proposal / 人工 Command
  → validate + preview
  → ChangeSet(draft)
  → propose
  → human review（可退回）
  → atomic publish
  → Baseline(approved, immutable)
```

导入预览本身不能创建业务草稿；提交导入只创建/更新草稿。发布前重新校验完整项目，成功后一次写入修订、基线、当前指针、审核和审计记录。

### 6.2 反馈

```text
triage → analyzing → in-progress → closed
                   ├─ Issue + ChangeSet → published → resolvedBaselineId
                   └─ Task → accepted/completed
```

未发布 ChangeSet 或未完成 Task 时不得关闭对应反馈。重复反馈可标记 `duplicate`，但保留原上下文与关联。

### 6.3 删除与失效

首条切片不物理删除已发布历史。退休/删除以新 ChangeSet 表达；外部增量包中的“消失”只形成删除候选。被后续知识影响的 Contract 标记 `requires-review/valid=false`，原快照仍保留用于审计。

## 7. 责任分界

- **Schema** 决定可表达什么，不证明内容为真。
- **Applicability evaluator** 只比较已声明条件，不猜测缺失环境。
- **Read service** 决定当前上下文能看到什么，是权限和版本的最后领域边界。
- **Projection/Search/VisualView** 组织阅读，不拥有第二份事实。
- **ChangeSet** 负责变更隔离和原子发布；Feedback、AgentRun、ImportProposal 都没有直接发布权。
- **人工复核人** 对采纳、冲突裁决和批准负责，系统保留其决定而不是隐藏责任。
