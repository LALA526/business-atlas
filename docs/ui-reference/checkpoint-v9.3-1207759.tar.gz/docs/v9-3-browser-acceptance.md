# V9.3 实际浏览器业务验收

## 方法与边界

- 工具：本机 Google Chrome CDP，脚本 `scripts/browser-cdp-v9-3.js`。
- 模式：`file://` 直接打开 `dist/business-atlas-v9.3.html`，无 HTTP 服务依赖。
- 证据：`artifacts/v9-3-browser-results.json`、`artifacts/v9-3-browser/layout-results.json` 和 11 张 PNG。
- 同时使用 OpenCode Chromium 进行表单、按钮和视角切换的实际交互核对。
- 无独立真人测试者；截图经过工具读取复核，不做像素基线或真实用户理解效率宣称。

## 六条旅程

| 旅程 | 实际操作与结果 | 证据 |
|---|---|---|
| A 理解已有业务功能 | 打开制造质量异常登记；直接看到目的、质检员/生产班组长、条件、结果、异常、四案例、实现一致性和来源 | `A-feature-decision.png` |
| B 验证业务规则 | 正例 REGISTER、反例 REJECT、缺失依据 MISSING_INPUT；轨迹显示具体条件和缺失事实 | `B-rule-positive.png`、`B-rule-unknown.png` |
| C 目标与实现差异 | 123 与 DOC-123、1234 与 DOC-1234 的观察分别展示；词元机制存在但目标规范未批准 | `C-search-observed.png`、`C-search-mechanism.png` |
| 新需求与 Task | 创建“调整质量异常登记的批次版本判断”，选择功能，读取 v1.1 规则，新增 expectedVersionMatch 候选条件，显示差异与影响，状态仍 proposed | `D-task-semantic-contract.png`、`D-task-difference-impact.png` |
| E 开发与知识交付 | 模拟 PR、测试、KnowledgeChange、Manifest 全关联；知识待审批，点击完成被阻止 | `E-delivery-knowledge-pending.png`、`E-completion-blocked.png` |
| F 复杂流程与图形 | 七阶段完整，RULE-M001 被找到，STG-M06 的 RELEASE 分支和 REWORK 回流存在，完整 14 条边，无 GROUP-undefined | `F-seven-stage-flow.png` |

## 响应式、离线与控制台

| 视口 | documentWidth | bodyWidth | 结论 |
|---|---:|---:|---|
| 1440×900 | 1425 | 1425 | 无整页横向溢出 |
| 1280×800 | 1265 | 1265 | 无整页横向溢出 |
| 1024×720 | 1009 | 1009 | 无整页横向溢出 |
| 800×600 | 785 | 785 | 无整页横向溢出 |

- 浏览器业务断言：**19/19 通过**。
- 控制台错误：**0**。
- 页面外部网络请求：**0**。
- 响应式附加截图：`R-flow-800.png`。
- 局部图节点范围、重叠与语义由 V9.3-39 至 V9.3-47 自动化共同验证；截图只作为补充证据。

## 复现

```powershell
node build.js
node scripts/browser-cdp-v9-3.js
```

需要本机 Chrome，可用 `CHROME_PATH` 指定位置。脚本使用独立临时 Chrome Profile，不读取日常浏览器项目数据。
