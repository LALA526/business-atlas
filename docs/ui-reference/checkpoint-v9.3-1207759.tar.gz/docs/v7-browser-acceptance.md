# V7 真实浏览器验收记录

验收日期：2026-11-15。工具：OpenCode 内嵌 Chromium；离线检查使用本机 Google Chrome Headless。

## A–I 用户旅程

| 旅程 | 实际操作与结果 | 截图 |
|---|---|---|
| A 标准知识目录 | 制造项目显示五个一级维度和 52 个分类；进入系统认知→配置，打开 CFG-M01 和相关规则；返回仍为 system.config 且保持 CFG-M01 选择 | `A-framework-catalog.jpg` |
| B 知识建设引导 | 创建空白“园区设备知识建设”，五个维度正常显示且无预置对象；通过目录维护项目介绍，创建领域、能力、系统、模块、API 和术语，全部进入同一 Change Set | `B-schema-project-building.jpg` |
| C 跨行业类型扩展 | 创建 ManufacturingBatch、LegalMaterial 和新注册 InspectionItem；均完成 Schema 表单、关联、r1 发布、第二修订 r2；旧基线恢复 r1 | `C-custom-type-r2.jpg` |
| D 孤立功能处理 | FEAT-M01/M02/A01/B01 显示真实场景与动作；规则和技术映射按真实多层关系计算，验收/证据缺失明确显示，并提供直接补充操作 | `DF-feature-coverage-and-technology.jpg` |
| E 复杂流程阅读 | 质量场景显示业务全貌；聚焦返工或报废阶段，显示 9 条局部显式边及回流；选择返工节点查看状态、规则与实现，无“已放行→已报废” | `E-layered-flow.jpg` |
| F 目录建立技术关联 | 从 API-M01 建立到 ACT-M009、FEAT-M01、DATA-M03 的实现/读取/写入关系；功能草稿视图同步显示 API、数据与规则，没有复制第二份定义 | `DF-feature-coverage-and-technology.jpg` |
| G 目录与治理一致 | RULE-M001 草稿同步到目录与剖面；批准后当前为 v1.1，旧基线为 v1.0；分类标签与筛选不改变修订 | 与 D/F 共用真实功能与覆盖截图 |
| H 大规模目录 | 生成 2000 个明确标注的轻量索引对象；分类计数 2000、单页 20 项、共 100 页；精确搜索 001000 仅剩 1 项，选择与返回保持目录状态 | `H-large-catalog.jpg` |
| I 协作回归 | 预约正式契约先因 3 条规则缺来源被阻断；复用 SRC-B01 补齐后生成。问题驱动修订使旧契约失效，第二份契约生效，问题关闭，任务 completed | `I-collaboration-completed.jpg` |

## 实测中修复的问题

- 流程布局给冻结节点写坐标，改为布局副本。
- 功能实现与动作技术映射混用，沿真实动作和 API 关系统一 Projection 与 Coverage。
- 创建后仍停留在旧批准基线，编辑后自动回到当前草稿。
- 缺失 Projection 的 flows 未保护，轻量对象不再报错。
- 原始断言与邻接包装混用导致数据关系漏显示，统一通过 Projection neighbors 补齐。
- 导航返回栈保存旧根对象、焦点、基线和目录状态，避免错误覆盖。

最终旅程均复核通过，既有四项目、模块开发版和 V7 空白项目 console 均为 0 error。

## 离线与模块版

模块开发版 `index.html` 加载相同 14 个运行脚本，制造目录显示五个维度，console 0 error。

单文件通过以下地址直接启动，无 HTTP 服务：

```text
file:///E:/Business%20Atlas/dist/business-atlas-v7.html#PRJ-00003/home
```

首页完整渲染，截图 `offline-single-file.png`。静态检查无外部脚本、样式、字体或图片依赖。

## 非声称事项

本验收不证明真实后端、认证、多人并发、仓库读取、生产级流程调度或真实 Agent 已实现。结构覆盖完整也不等于事实可信。
