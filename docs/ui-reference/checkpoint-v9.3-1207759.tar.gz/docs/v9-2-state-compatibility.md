# Business Atlas V9.2 旧路由与状态兼容

## 1. 数据保留

继续使用 `business-atlas-v9` 和 storageVersion 9。项目、草稿、基线、问答、反馈、Agent Run、任务、契约和 Visual View 不因导航重构被清空。`assistantByProject` 只保存助手呈现状态，不写入业务事实。

## 2. 旧入口

- `ask`：打开项目助手并恢复合理工作区。
- `feedback`：进入任务与问题中的使用反馈。
- `agents`：进入执行活动。
- `visuals`：进入对应根的专注画布。
- `imports`：仍可访问 AKP 管理，但不再占据普通主导航。

旧路由保留项目和对象上下文，不因移除一级菜单产生空白页。

## 3. 阅读状态

未选择 rootId 时进入真实内容选择器，项目根对象不被当成用户已选对象。空白项目才显示知识尚未建立。批准、草稿、历史读取严格通过 Read Context，正式入口不再默认 `draft:true`。

编辑/保存/发布先写回 read 再持久化，避免刷新后误留 build。焦点恢复使用 `focus({preventScroll:true})` 并恢复滚动位置；pointerdown 提前记录反馈前的位置。

## 4. 助手与项目隔离

会话、草稿、滚动和展开项按项目保存，跨页不丢；项目切换不混用历史或权限。Enter 发送、Shift+Enter 换行，IME 组合输入和空内容不发送，重复提交有锁。

## 5. Agent 证据

`raw-captured-event`、`verified-script-execution`、`reconstructed-analysis-record`、`knowledge-proposal` 分别表示原始事件、可验证脚本执行、事后重建分析和知识提案。Self 的真实路径、行范围、哈希不因重建标记而降低价值，但没有原始工具日志时必须说明。
