# Business Atlas V9 浏览器验收记录

验收日期：2026-11-15。目标为 `dist/business-atlas-v9.html`。五条主旅程在 OpenCode Chromium 中通过 HTTP 打开同一单文件执行；离线验收另在本地 Google Chrome 通过 CDP 使用真实 `file://` 执行。未使用生产后台、外部网络资源、LLM 或 MCP。

## 旅程 A：Business Atlas 管理自身项目

- 默认项目为 `PRJ-SELF / Business Atlas — Self Knowledge`。
- `scripts/extract-self-knowledge.js` 从当前真实工作区提取 **56 个实体、49 条断言、25 份来源**，来源包含实际路径、锚点、行范围、修订与 SHA-256。
- `scripts/prepare-self-project.js` 没有手写项目种子，而是实际调用 `stagePackage → previewImport → commitImport → ProposeChange → PublishRevision`，形成 `IMP-PRJ-SELF-0001`、`CS-PRJ-SELF-0001`、`BL-PRJ-SELF-CS-002`。
- 在项目地图查看产品定位、13 项核心功能、系统/组件、技术、依赖、数据、版本、工程约定和测试；架构图初始投影 36 个节点、38 条关系。
- 从功能、组件和图形可进入真实来源对象，来源视图显示 URI、行范围和摘录。
- 未知清单明确生产后台/数据库、企业权限、真实 MCP/LLM、仓库同步、生产部署和多人协作未实现。
- 在同一最终包上再次上传，预览为 **56 个实体未变化、49 条断言未变化、0 新增、0 更新**；提交返回 `idempotent:true`，`draftWorkspace:null`，对象/断言/基线数量不增加。

截图：`J1-akp-import.png`、`J1-self-architecture.png`。

## 旅程 B：售前理解系统

实际输入：“这个系统能否管理老项目的业务知识？”，角色为售前，意图为 REQUIREMENT。

- 回答聚焦 `SELF-FEAT-AKP`，状态为 `prototype_only / 特定条件支持（原型能力）`，没有回答“全面支持老项目逆向”。
- 解释外部 Agent 生成 AKP、平台校验预览、人工确认进入草稿，并列出不能自动逆向、生产后台、真实权限、MCP/LLM 和部署边界。
- 关键结论可回到 `src/v9-akp.js` 的实际定位及 `tests/v9-acceptance.test.js`，共 6 项对象/断言/来源引用。
- 继续输入“它如何接入知识？”，第二条回答保留同一 `conversationId`，`followUpOf=ANS-PRJ-SELF-00001`，意图 HOW，焦点仍为 `SELF-FEAT-AKP`。
- 可切换内部理解版与客户简明版；回答标记“确定性知识查询，未调用 LLM”。

截图：`J2-presales-followup.png`。

## 旅程 C：Agent 知识整理与执行记录

- 打开 `RUN-SELF-ANALYSIS-001`，显示“外部导入记录”，`simulated:false`。
- 展示 4 次实际工具记录：read、grep、shell、node:crypto；另有任务、计划、观察、推断、提案、待确认和结果。
- 记录 25 份来源、56 个实体、49 条关系提案和 6 项未知；主视图只展开前 12 个提案，其余进入导入预览，避免长对话淹没重点。
- 从 `SRC-SELF-ACCESS` 进入实际来源对象，随后可进入对应知识/导入预览；工具输出不自动形成批准断言。
- 未决问题可创建普通 Issue，保持 `requires-human-review`。

截图：`J3-agent-run.png`。

## 旅程 D：同事发现问题并反馈

实际从 `VIEW-SELF-ARCH` 提交“当前技术架构图缺少组件”：

1. 类型选择“技术映射纠错”，自动携带 `SELF-SYSTEM`、原基线、视图 revision、环境和阅读用途。
2. 确认分流后转为 `Q-PRJ-SELF-0001 + CS-PRJ-SELF-0002`；此时旧基线未改变。
3. 通过通用 Schema 表单创建“外部知识接入组件”，再通过统一 LinkKnowledge 建立 `belongsTo SELF-SYSTEM`。
4. 提交并原子发布 `BL-PRJ-SELF-CS-003`；架构图按同一知识重新投影并出现新节点。
5. 反馈记录 `resolvedBaselineId=BL-PRJ-SELF-CS-003` 后关闭；最终实现同时在关闭反馈时解决关联 Issue，V9-31 有回归断言。

截图：`J4-feedback-closed.png`。

## 旅程 E：图文结合认识复杂业务

在制造质量项目中：

- 打开分层质量异常流程，选择 `ACT-M005` 判断节点，查看规则、来源、实现、数据与对象关系。
- 切换生产批次状态视图：7 个合法状态、8 条显式转移；历史未核验回边单独以 unverified 虚线呈现，不混入已确认路径。
- 切换系统组件/API、数据读写和保存时序，关系均来自知识断言。
- 打开 `VIEW-M-SURFACE`，显示明确标注的 `simulated-prototype`，点击 `ACT-M001` 操作热点返回登记业务动作。
- 继续打开完整认知剖面，查看 `RULE-M002`、`API-M00`、质量异常/批次数据、事件和 QD/MQ 来源定位；返回后仍保持原视觉焦点。
- Mermaid/ASCII 只从同一投影导出；缩放只改 view layout，不改业务基线。

截图：`J5-surface-hotspot.png`。

## 离线 file:// 与控制台

本地 Chrome 使用 `file:///E:/Business%20Atlas/dist/business-atlas-v9.html` 打开，CDP 实际检查：

- `location.protocol=file:`，标题正确，Self Knowledge 与 AKP 全局模块可用。
- 外部资源 `externalResources=[]`，未发起外部网络请求。
- 售前问题可生成并写入 localStorage。
- `consoleErrors=[]`；Chromium 主旅程最终控制台同样为 0。
- 初始完整项目存储约 1.8 MiB 字符，未出现初始化容量错误。

记录：`artifacts/v9-browser/offline-results.json`、`offline-file-presales.png`。

## 验收中发现并修复的问题

- V6 权限读取把无权限误归类为缺失，恢复 `PERMISSION_INCOMPLETE`。
- 已发布 Self 的 Undo 快照造成存储膨胀，发布后清空活动草稿 Undo 栈。
- 重复包初次仍会重写 unchanged 来源/对象，改为提交阶段幂等；预览断言也改为 unchanged。
- Agent JSONL 首行解析、适用性工厂依赖和实体 current 过滤缺陷。
- 探索模式问答错误地只使用 applicable 关系，改为探索展示全部、当前模式才作结论过滤。
- 第 75 页对象检查器无法读取，改为按同一上下文直接解析稳定 ID。
- 反馈关闭后关联 Issue 未解决，增加同步解决和测试。
- 来源/Agent locator 显示 `[object Object]`，改为可读结构化定位。
- 干净重建遇到旧 README 锚点和无 `.git` 环境，改为 V9 锚点和显式可选 Git provenance；最终 SHA-256 一致。
