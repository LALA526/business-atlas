# Business Atlas V9：推荐实施架构（模块化单体）

> 本文描述**受控试点之后首条生产化纵向切片的建议架构**，不是对当前前端原型的现状声明。当前没有后端、生产数据库、真实认证、真实 MCP/LLM 或多人协作。

## 1. 架构决定

采用**一个后端应用、一个主数据库、一个证据对象存储、按模块划分边界的模块化单体**。首条切片不引入微服务、服务网格、Kafka、独立图数据库或 Kubernetes 平台。

理由：当前最主要的风险是领域一致性、权限绕过、版本不可变和真实工作流价值，而不是服务间横向扩展。单事务更容易保证导入与基线原子性，模块边界足以支持未来拆分。

建议默认技术形态（可在实施 ADR 中替换，但不可改变领域约束）：

- Web 前端 + REST/OpenAPI 后端。
- PostgreSQL：结构化记录、JSONB 属性、事务、全文检索和任务/outbox。
- S3 兼容对象存储或受控文件存储：原始来源、导入包和大附件；数据库只存元数据、哈希与定位。
- 单进程或少量同构实例；试点期一个应用实例即可。任务使用数据库队列，避免先建独立消息平台。

## 2. 逻辑结构

```text
Browser / External Agent
          │ HTTPS / OpenAPI / AKP / AgentRun
          ▼
┌──────────────────── Modular Monolith ────────────────────┐
│ API & Auth Middleware                                    │
│ Project │ Knowledge │ Version │ Import │ Read/QA         │
│ Feedback/Task/Issue │ Contract │ Visual │ Agent Adapter  │
│          Domain Services + Access Policy + Commands      │
│ Search/Index │ Jobs/Outbox │ Audit │ Unit of Work        │
└───────────────┬───────────────────────┬──────────────────┘
                ▼                       ▼
          PostgreSQL              Evidence Blob Store
       facts/revisions/index        source/package/attachment
```

外部 Agent、未来 MCP 和仓库提取器只能通过适配器进入；不能直接访问数据库、修改当前基线或调用内部审核函数。

## 3. 模块职责

| 模块 | 必须负责 | 不得负责/首期约束 |
|---|---|---|
| **前端 Web** | 项目/导入/审核/阅读/问答/反馈界面；展示基线、适用性、引用和错误；乐观并发提示 | 不作为授权边界，不在浏览器持有权威共享数据；可复用 V9 交互和投影语义 |
| **API** | OpenAPI、输入大小/媒体类型检查、身份上下文、统一响应、Idempotency-Key、ETag/版本参数、requestId | 不编写第二套领域规则；HTTP 错误与领域结果码一致 |
| **领域核心 Domain** | Project、Knowledge Entity、Assertion、Applicability、ChangeSet、Task、Issue、Feedback、Contract 的状态机与不变量 | 不依赖 Web、数据库或具体模型供应商；以纯领域测试覆盖规则 |
| **知识存储 Knowledge Repository** | 当前记录、不可变修订、来源元数据、外部 ID 映射、事务 Unit of Work | 不直接接受未经 Command/Import 服务的写入；JSONB 不代替身份和关系约束 |
| **版本 Versioning** | Baseline 快照、修订绑定、差异、当前指针、历史读取、Contract 过期标记 | 历史缺失不回退最新；技术版本层不隐式改变业务基线 |
| **统一读取 Access/Read** | 组装 Read Context，依次执行身份、版本、权限、适用性和端点闭合过滤，输出授权投影 | 所有读取包括搜索、导出和图形都必须经过；禁止 Controller 绕过 |
| **搜索/索引 Search & Index** | 目录投影、对象检索、筛选、分页和确定性问答候选；由修订事件重建 | 索引不是事实源，不存放越过权限的公共索引；首期优先 PostgreSQL，不独建搜索引擎 |
| **证据 Blob** | 原始包、源码摘录/附件、Agent 大日志的内容寻址存储、哈希、保留策略和受控下载 | 数据库不塞大文本；下载必须再次鉴权，不暴露永久公开 URL |
| **导入 Import** | AKP parse/validate/preview、外部 ID 映射、人工决定、原子草稿、幂等、discard、未知/冲突保留 | 不直接发布，不自动合并同名，不把推断升级为事实 |
| **Agent/MCP Adapter** | Agent Run JSON/JSONL 规范化、脱敏、事件分类、提案转 AKP/Issue；未来 MCP 仅作端口实现 | 首期无需真实 MCP/LLM；供应商字段不是领域身份，工具输出不自动批准 |
| **认证授权 Auth** | OIDC/受控身份、项目成员、角色/clearance、服务端 permissionContext、最小权限和导出授权 | 禁止客户端自报 admin；原型角色选择器不得移植为安全机制 |
| **任务 Jobs** | 大导入、索引重建、导出、哈希/存储核对；状态、重试、幂等和取消 | 首期小导入可同步；异步任务不能绕过同一事务与审核规则 |
| **审计 Audit** | 登录、读取敏感证据、Command、导入决定、审核、发布、权限变更和任务结果；关联 actor/requestId | 审计不是可改业务草稿；失败回滚与主动 Undo 分开记录 |

## 4. 建议数据分组

不要求一张表对应一个 JSON 对象；以下为逻辑存储边界：

| 分组 | 主要记录与约束 |
|---|---|
| 项目与权限 | `project`、`project_member`、`schema_registry`、`applicability_schema`；成员角色唯一约束和项目外键 |
| 知识与修订 | `knowledge_entity`、`entity_revision`、`assertion`、`assertion_revision`、`flow_revision`；`(project_id, id, revision)` 唯一，修订内容 hash 校验 |
| 外部身份 | `external_id_map`：`(project_id, source_project_id, kind, stable_external_id)` 唯一；禁止按名称映射 |
| 来源 | `source`、`source_revision`、`source_ref`、`blob_object`；定位 JSONB、revision/hash 必填，敏感级别与服务端策略一致 |
| 基线 | `baseline`、`baseline_entity`、`baseline_assertion`、`baseline_flow`；追加写，数据库权限禁止 UPDATE/DELETE 已批准记录 |
| 变更与审核 | `change_set`、`change_operation`、`review_decision`；`base_baseline_id`、状态、预期修订、发布基线和事务日志 |
| 导入 | `import_proposal`、`knowledge_package`、`import_decision`；packageId/contentHash、状态、预览、错误和草稿关联，幂等键唯一 |
| 协作 | `task`、`issue`、`feedback`、`feedback_history`、`contract`；保留 originContext、解决基线和验收绑定 |
| Agent 与视图 | `agent_run`、`agent_event`、`tool_call`、`visual_view`；事件类型、reviewStatus、脱敏标记、布局修订分别保存 |
| 系统 | `outbox_event`、`job`、`audit_event`、`idempotency_record`；与业务提交同事务写 outbox/审计，异步 worker 只执行副作用 |

属性、qualifiers、applicableContext 和 locator 可用 JSONB；实体 ID、项目 ID、端点、版本绑定、状态和权限主体必须结构化并可加约束/索引。

## 5. 两条关键执行路径

### 5.1 读路径

```text
Authenticated principal
→ 建立服务端 PermissionContext
→ 校验 project/baseline/versionMode/draftWorkspace
→ 读取指定修订（历史绝不回退）
→ 对象权限过滤
→ Applicability 评估
→ 关系双端点、来源、引用和 Contract 完整性过滤
→ Catalog/QA/Visual/Export 投影
→ 带 ReadContext、requestId 的统一结果
```

缓存键至少包括：`projectId + baselineId + versionMode + draftWorkspaceId + permissionContext + applicableContext + applicabilityMode + readPurpose + timeMode + category/filter + projectReadRevision`。

Command、导入、反馈、Agent 和发布产生修订事件，递增项目读取代次并按主题失效索引/目录。权限或适用条件变化不得共用旧缓存。缓存失败不得改变事实。

### 5.2 导入与发布写路径

```text
上传包（哈希、病毒/活动内容检查）
→ 单事务保存 ImportProposal + parse/validate/preview（无业务草稿）
→ 人工逐项决定
→ staging 重校验 + external ID 映射 + Commands
→ 单事务提交 Source/Entity/Assertion/Unknown/ChangeSet + outbox + audit
→ 提交 ChangeSet，独立审核人检查差异与来源
→ 完整项目校验 + If-Match(baseBaseline/currentRevision)
→ 单事务追加修订和 Baseline、推进当前指针、失效旧 Contract、写 outbox/audit
→ 异步刷新索引
```

任一步失败均不出现半包、半基线或提前推进的指针。重复 Idempotency-Key 返回首次结果；同一包重导按稳定身份和内容判断无操作，不制造空草稿。

## 6. 统一 API 结果与并发

领域结果保留 `OK / NOT_FOUND / FORBIDDEN / VERSION_UNAVAILABLE / CONTEXT_INSUFFICIENT / APPLICABILITY_UNKNOWN / DATA_INTEGRITY_ERROR`，另以 HTTP 状态表达传输语义。建议映射：

- `FORBIDDEN → 403`，`NOT_FOUND → 404`，`VERSION_UNAVAILABLE/并发冲突 → 409`。
- 上下文不足、适用性未知或校验失败 `→ 422`；包过大 `→ 413`。
- 乐观锁 `If-Match` 不匹配 `→ 412`；数据完整性错误 `→ 500`，不返回内部敏感细节。

所有变更携带 actor、requestId、idempotencyKey 和预期版本。发布时若当前基线已不同于 `baseBaselineId`，必须重新生成差异/审核，不能最后写入者覆盖。

## 7. 安全与审计底线

- 服务端认证和授权是共享/多人切片的启用前提；仅单操作者离线试点可继续使用当前原型，但不得存放未批准敏感资料。
- 上传视为不可信输入：限制包/字段/事件大小，拒绝原型污染与活动内容，安全解析 JSON，必要时装入隔离扫描任务。
- Agent 参数、输出、用户指令和来源先按规则脱敏再持久化；保留脱敏事件与失败原因，不能静默声称完整。
- 导出、Mermaid/ASCII/SVG、来源下载和搜索缓存继承相同 Read Context；SVG 文本转义，禁止脚本和外部资源。
- 审计追加写并关联基线/ChangeSet；日志不记录秘密、完整敏感包或访问令牌。
- 数据库每日备份、对象存储版本化和恢复演练属于共享试点上线门槛，而不是“生产后再补”。

## 8. 部署与可观测性

受控共享环境建议一个应用容器/进程、PostgreSQL 和私有 Blob 存储即可。提供健康检查、结构化日志、requestId、导入/发布耗时、失败率、任务积压、数据库与 Blob 容量指标。暂不承诺高可用或多地域。

每次发布保存数据库 migration 版本、应用版本和 AKP/AgentRun Schema 版本。迁移只新增或转换当前可写结构，不得重写已批准基线内容；需要校正时以审计迁移记录和新修订处理。

## 9. 从 V9 原型迁移的方式

- 把 `v9-applicability.js`、`v9-access.js`、`v9-akp.js`、`v9-services.js` 中的行为规格转成服务端领域测试，而不是把浏览器 store 整体当数据库。
- 以 `packages/schema/akp-v0.1.schema.json`、`agent-run-events-v0.1.schema.json` 和真实 Self 包作为契约 fixture。
- 前端可渐进复用五维目录、差异审核、引用问答和反馈闭环交互；权限改为服务端返回的能力集合。
- 不承诺自动迁移任意 `localStorage`。需要迁移时另定义显式导出/校验工具；首选从原 AKP 重放到新后端并核对计数、哈希和基线。
- V3–V9 测试继续作为回归规格，新增 API、数据库事务、重启恢复、并发和真实授权测试，不用原型测试代替它们。

## 10. 暂不做与后续拆分条件

首期不做独立搜索集群、图数据库、事件溯源平台、实时协同 CRDT、微服务和自动仓库同步。只有在有测量依据时，才考虑把搜索、Blob、任务 worker 或提取器进程独立部署；即使拆部署，也保持同一领域契约和版本语义，不拆成多套事实源。
