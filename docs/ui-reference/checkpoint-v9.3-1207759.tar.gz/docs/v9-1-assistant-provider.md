# Business Atlas V9.1 Assistant Provider 接口约定

## 1. 当前事实边界

当前唯一实现是 `ExistingKnowledgeQueryProvider`。它调用 V9 的确定性对象检索、适用性评估、关系查询和解释组合，**没有连接真实 LLM、MCP、模型路由或 Agent 编排**。

UI 面向未来 Provider 设计，但不得把此能力描述为通用 AI。无法可靠映射时必须返回 `CONTEXT_INSUFFICIENT`、资料不足或候选知识。

## 2. 方法

```text
getCapabilities()
createConversation(project, input)
sendMessage(project, input)
cancelRequest(requestId)
listHistory(project, input)
resolveKnowledgeReferences(project, input)
```

Provider 可替换，UI 不依赖具体模型供应商、流式协议或工具协议。

## 3. 输入

`sendMessage` 至少支持：

```json
{
  "requestId": "optional-cancel-id",
  "conversationId": "CONV-...",
  "followUpOf": "ANS-... or null",
  "text": "自然语言问题",
  "role": "newcomer | analyst | developer | tester | presales | agent",
  "readContext": {
    "projectId": "PRJ-...",
    "baselineId": "BL-...",
    "versionMode": "published | historical | draft",
    "permissionContext": {},
    "applicableContext": {},
    "applicabilityMode": "explore | current",
    "readPurpose": "understand"
  },
  "contextualFocus": {
    "knowledgeId": "当前对象，可为空",
    "taskId": "当前任务，可为空",
    "visualViewId": "当前视图，可为空",
    "origin": "home | studio | catalog | tasks | imports"
  }
}
```

焦点用于优先检索，但明确命中的其他 Feature/Rule 也可补充，避免“这个系统……”被误解为仅问当前对象。只有“继续/接着/追问”或以“它/这个（非这个系统）”开头才默认继承上一回答。

## 4. 输出

成功：

- `ok:true`
- `answer`：query、intent、conversationId、followUpOf、conclusions、limitations、readContext、deterministic。
- `citations`：知识、断言、来源、定位、修订和基线。
- `unknowns`：未知、适用性不足、冲突和未实现边界。
- `actions`：打开知识、保留助手和 returnContext。

失败：

- `ok:false`
- `code`：`CONTEXT_INSUFFICIENT / CANCELLED / FORBIDDEN / ...`
- `guidance`：自然语言澄清提示。
- `candidates/actions`：可选择的后续知识操作，不生成虚构结论。

## 5. 能力与权限

`getCapabilities` 声明 deterministic、llmConnected、supportsCancellation、history、references 和限制。`listHistory` 不仅按 project/conversation 过滤，还必须使用当前 Read Context 重新过滤焦点和引用，防止旧回答在权限变化后泄露。

发送和引用解析都使用同一权限、基线和适用条件。切换项目时 Provider 接收另一个 project 实例，不共享原始存储或角色。

## 6. 未来 Provider

真实 Agent Provider 应实现同一输入输出，并补充：

- 流式增量事件、取消和错误恢复。
- 工具调用、观察、推断、提案的事件类型。
- 服务端派生身份和权限，客户端不得自报 admin。
- 模型/供应商 only as provenance，不进入知识身份。
- 未经人工确认的提案不得直接成为批准知识。

这些属于正式开发，不在 V9.1 原型内实现。
