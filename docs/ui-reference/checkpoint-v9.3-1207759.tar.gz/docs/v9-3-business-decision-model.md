# V9.3 业务决策模型与条件语义

## 1. 同一知识，不同事实性质

V9.3 不建立第二套规范库。Rule、Flow、Scenario、Action、Entity、Assertion、Source 和 Schema Registry 仍是权威知识。阅读、任务、验收与 Agent 上下文只是受控投影。

| 事实 | 标识 | 回答 | 不能冒充 |
|---|---|---|---|
| 目标业务规范 | `target_specification` | 业务应当怎样处理 | 当前代码行为、技术推断 |
| 当前观察行为 | `observed_behavior` | 指定版本/环境下实际观察到什么 | 已批准目标、所有版本的普遍行为 |
| 技术实现机制 | `implementation_mechanism` | API、组件、SQL、配置、事件怎样实现 | 业务匹配规则或业务默认值 |

推荐追踪链：**目标规范 → 期望行为 → 实现符合性 → 当前观察 → 技术依据**。符合性是关系判断，不是新的对象级总状态，也不替代 Governance、Verification、Applicability、Coverage。

## 2. Business Decision Semantics

每个重要业务判断按需要说明以下十项；简单业务可用短文本，完整性检查会指出未知，不要求十张空表。

1. **Context**：业务情况、组织、环境、版本和适用范围。
2. **Inputs**：输入字段的业务含义、来源、类型、是否必要。
3. **Preconditions**：执行判断前必须成立的前提。
4. **Evaluation**：比较对象、比较方式、大小写、空值和多结果语义。
5. **Priority**：同时命中时的已批准顺序；没有批准策略就返回冲突或待确认。
6. **Branch**：成立、不成立及例外分别走向哪里。
7. **Outcome**：执行动作、拒绝、不执行、更新状态、产生事件、人工处理或无法判断。
8. **Default**：所有条件均不成立时的已批准结果；未定义则返回 `NO_MATCH_NO_DEFAULT`。
9. **Exception**：缺失、非法状态、冲突及恢复方式。
10. **Evidence**：来源、定位、责任人、批准状态与生效版本。

旧 `when:{x:'A'}` 会规范化为 `equals`；旧行内唯一数值优先级可表示该批准版本中的显式行优先级。跨规则优先级必须有单独批准，不得默认第一条、最新或最窄优先。

## 3. 可执行条件

| 操作 | 输入要求 | 关键语义 |
|---|---|---|
| `equals` / `notEquals` | `inputId`,`value` | 严格值比较；缺失输入为未知 |
| `contains` | `inputId`,`value`,`caseSensitive` | 字符串/数组包含；必须声明大小写，空值策略可显式声明 |
| `startsWith` | 同上 | 字符串前缀，不自动等于任意子串 |
| `exists` / `notExists` | `inputId` | 自有属性且非 `null/undefined`；空字符串是已提供值 |
| `greaterThan` / `lessThan` | 数值 `inputId`,`value` | 仅有限数值比较，其他类型不擅自转换 |
| `in` | `inputId`,`values[]` | 值属于显式集合 |
| `all` / `any` | `conditions[]` | 三值逻辑组合；`all` 假优先，`any` 真优先，未知不被当成假 |

不支持的操作返回 `UNSUPPORTED_CONDITION`，不会默认 `true`。字符串比较缺少大小写语义同样停止模拟。

## 4. 三值评估与确定性

每个条件返回 `true / false / unknown / unsupported`。评估结果包含：适用性、前提、每条规则行、条件轨迹、命中分支、业务结果、缺失事实、冲突、默认使用、规则版本、基线和来源。

- 未批准规则：`UNAPPROVED_TARGET`，不能正式求值。
- 不适用与适用性未知：分别返回 `NOT_APPLICABLE` / `APPLICABILITY_UNKNOWN`。
- 高优先级条件未知时，不跳过去采用低优先级结果。
- 多行不同结果且未确认优先级：`UNCONFIRMED_PRIORITY`；同优先级冲突：`RULE_CONFLICT`。
- 所有条件均不成立且有批准默认分支才使用默认结果。
- 同一输入、规则修订、基线、权限与适用上下文产生相同结果。

评估是只读操作，不创建 Change Set、不修改案例、不批准知识。

## 5. 业务案例

`BusinessCase` 是普通授权知识实体，包含 `caseKind / decisionRef / inputs / expected / confirmationStatus / sourceIds`。类型包括正例、反例、边界、未知和回归。`decisionRef` 固定 `ruleId + version`；验证只比较预期与规则结果。

`CASE_CONFLICT` 表示案例与规则不一致，需要治理，不得偷偷修改规则适配案例。未知例表示缺少必要事实或规范，预期就是“无法判断”，不是失败结果。

## 6. 符合性与版本失效

允许 `consistent / inconsistent / unverified / missing_target / missing_observation / requires_reverification / partial / source_conflict` 等关系状态。

- 无目标：即使有观察和 SQL，也显示缺少目标规范。
- 无观察：有目标和组件也只能显示尚未验证。
- 观察版本与当前代码版本不同：需要重新核验，旧符合性不能沿用。
- 推断未确认：显示未验证，不显示批准行为。
- 部分路径有证据：只能标为部分适用，不能宣称全部规则组合通过。

黄金样本中，`parameterName` 只批准存在性；具体比较字段仍未知。123/1234 只保存当前词元观察与技术机制，目标匹配规则保留业务 Owner 决策记录，推荐不等于批准。
