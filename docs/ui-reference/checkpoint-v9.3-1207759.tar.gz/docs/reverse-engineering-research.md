# Business Atlas V9：逆向工程独立研究路线

> 定位：研究如何由仓库/资料生成**可核验的 AKP 提案**，与首条纵向切片并行但不耦合交付。V9 只证明一个受控真实源码样本可由外部 Agent 生成 AKP，并经真实导入器进入 `PRJ-SELF`；**没有实现通用仓库逆向、持续同步或平台内真实 Agent/MCP/LLM**。

## 1. 研究目标与非目标

### 要回答的问题

1. 在明确语言、目录和修订范围内，哪些业务/工程知识可以稳定提取，哪些只能标为未知？
2. 每条观察、文档意图和推断能否保留可复核的来源、工具链和生成过程？
3. 新版本输入如何形成增量更新候选，而不覆盖人工知识、误删对象或制造重复？
4. 来源间冲突、代码与文档不一致、身份变化及适用条件如何进入人工处理？
5. 更换模型、Agent、MCP Provider 或语言解析器后，核心格式与审核流程是否仍可使用？

### 不在研究承诺内

- “任意老项目一键还原完整业务”“代码即全部事实”或无人审核自动发布。
- 将静态调用关系当作真实运行时因果，将注释/命名当作已确认需求。
- 在未取得授权时上传源码、秘密、个人信息或客户数据到外部服务。
- 为演示接更多供应商而扩大主产品；首条切片不依赖任何特定提取器成功。

## 2. 总体管线

```text
授权的只读 Source Snapshot
→ Extractor（语言/资料特定）
→ 原始观察 + Tool/Observation/Inference/Proposal 事件
→ 规范化为 AKP/0.1 + AgentRun
→ 平台既有 parse/validate/preview
→ 增量三路差异与冲突队列
→ 人工逐项决定
→ ChangeSet 草稿
→ 独立审核与 Baseline 发布
```

Extractor 没有 Baseline 写权限，也不能直接调用内部 Repository。平台只接受版本化交换格式，因此同步/异步、本地/外部、有无 LLM 都不改变治理主线。

## 3. Extractor 契约

### 3.1 描述与输入

```json
{
  "descriptor": {
    "extractorId": "example-source-extractor",
    "extractorVersion": "0.1.0",
    "capabilities": ["source-file", "csharp-project"],
    "outputFormats": ["AKP/0.1", "AgentRunEvents/0.1"]
  },
  "request": {
    "snapshotId": "SNAP-...",
    "sourceProjectId": "BUSINESS-ATLAS-SELF",
    "sourceRevision": "commit-or-content-tree-hash",
    "declaredScope": ["src/**", "tests/**"],
    "includePaths": ["src/**"],
    "excludePaths": ["**/*.secret"],
    "locale": "zh-CN",
    "previousPackage": {"packageId": "AKP-...", "contentHash": "..."},
    "options": {"maxFiles": 500, "allowModelInference": false}
  }
}
```

服务端/研究工具实际传给 Extractor 的是受控只读快照或最小文件流，不是无限制工作区凭据。`credentialsRef` 如未来需要，只能由宿主解析，不得写入 AKP、日志或事件正文。

### 3.2 输出

```json
{
  "package": "AKP/0.1 object",
  "agentRun": "AgentRunEvents/0.1 object or JSONL reference",
  "diagnostics": [
    {"code": "UNSUPPORTED_SYNTAX", "path": "src/x", "severity": "warning", "locator": "..."}
  ],
  "coverage": {
    "discoveredFiles": 100,
    "readFiles": 95,
    "skippedFiles": [{"path": "...", "reason": "..."}],
    "uninvestigatedScopes": ["runtime behavior", "production topology"]
  },
  "statistics": {"entities": 56, "assertions": 49, "sources": 25}
}
```

硬性要求：

- `manifest.producer` 描述实际生产者，但不要求特定 model/provider；`sourceRevision` 和 `declaredScope` 必填。
- 每个 Entity/Assertion 有稳定外部 ID；断言 SourceRef 含精确 locator，来源含 revision、hash、captureMethod。
- `unknownsAndConflicts` 包含不支持语法、读取失败、缺失来源和未验证推断；不能用空数组掩盖部分失败。
- `importProvenance` 连接 `agentRunId`、toolExecutionRefs、源文件修订、提取时间和策略。
- 输出先通过平台真实校验器；Extractor 自报 `valid=true` 没有意义。

## 4. 来源与事实等级

| 类型 | 示例 | AKP 表达 | 审核要求 |
|---|---|---|---|
| 直接观察 | 文件存在、组件声明、显式依赖、测试命令 | `observed` + 文件修订/行范围/hash | 核对定位与范围；不等于业务批准 |
| 文档意图 | ADR、需求、注释中的目标或约束 | `documented_intent` + 文档版本/章节 | 判断文档是否仍有效，不能冒充运行现状 |
| 推断 | 由命名猜业务职责、由依赖猜运行时调用 | `inferred` + explanation + 支撑观察 | 默认待核验，可转 Issue；不能仅凭置信度批准 |
| 未知 | 未读取目录、动态配置、生产部署、外部人工流程 | `unknown` + 未调查范围/原因 | 明确补资料或保持未知 |
| 冲突 | 代码与规范矛盾、两个来源声明不同规则 | `conflicting` + 双方来源 | 人工决定，保留被否决版本及理由 |

置信度可用于排序，不是事实状态，也不参与自动覆盖。运行时才发生的行为、配置中心和人工约定若未观察，应明确未知。

## 5. 增量更新

### 5.1 身份和指纹

- 主键：`(sourceProjectId, stableExternalId)`，内部映射由平台保存。
- 来源指纹：`sourceRevision + contentHash + locator`；提取器版本与策略进入 provenance。
- 候选内容指纹：规范化属性/谓词/qualifiers/sourceRefs 的 hash；布局、生成时间和日志顺序变化不应制造知识差异。
- 稳定 ID 的生成规则必须版本化。移动/重命名文件不自动等于同一业务对象；需要重命名线索和人工确认。

### 5.2 三路差异

以“上次已采纳外部包 A、当前项目知识 B、新提取包 C”比较：

1. A→C 无变化：unchanged，幂等结束。
2. A→C 有变化、A→B 无人工变化：形成 update-candidate。
3. A→C 与 A→B 都变化：形成 conflict，展示双方差异和来源，不覆盖 B。
4. C 新增：create-candidate；同名不同 ID 只提示重复。
5. A 有、C 消失：delete/retire-candidate，并列出 B 中仍引用它的断言、Contract 和适用条件。
6. 只有技术 revision/hash 变化：更新技术版本层，不创建空业务草稿或基线。

整包失败不应用任何增量。部分文件读取失败时，必须将范围标为不完整，禁止把“未读到”解释成“已删除”。

## 6. 冲突与人工复核队列

| 冲突 | 系统动作 | 禁止动作 |
|---|---|---|
| 两个提取器对同一对象给出不同断言 | 分别保留来源和生产者，创建 conflict/比较视图 | 按供应商、置信度或最后写入自动选胜者 |
| 新代码与已批准规范不同 | 保留规范与观察两条事实，创建 Issue，要求业务/技术判断 | 直接把规范改成代码行为，或反向宣称代码合规 |
| 外部更新与人工编辑同一内容 | 三路 diff，要求逐项选择/重新编辑 | 覆盖人工修订、静默合并文本 |
| 外部对象消失但仍有内部引用 | 删除候选 + 影响清单 | 级联物理删除历史和引用 |
| 适用条件缺失或相互排斥 | `unknown/conflict`，补充上下文后再评估 | 默认所有环境适用 |
| 来源定位失效或修订过旧 | 标记 stale/unverified，阻止正式采纳 | 使用最新文件内容冒充旧版本证据 |

复核界面至少显示：稳定 ID、旧/新/当前三方内容、事实等级、来源修订与定位、影响关系、未知和决定理由。接受外部提案也只能进入草稿；最终发布仍走既有 approver。

## 7. 无供应商锁定

- **交换格式锁定领域，不锁定供应商**：AKP/0.1 与 AgentRunEvents/0.1 使用公开 JSON Schema、语义版本和兼容性说明。
- **模型可替换**：model/provider 只是 provenance；无模型、规则解析器、人工整理和不同 LLM 都可生成同一格式。
- **MCP 可替换**：未来 MCP 只是一种工具传输适配器，不是存储协议或身份中心；也允许 CLI、CI、离线脚本和直接文件上传。
- **解析器可替换**：语言 extractor 通过 descriptor/capabilities 注册，输出同一 Entity/Assertion/Source 语义。
- **数据可退出**：原始包、来源、映射、审核决定和诊断可导出；不得只在某供应商会话中保留关键证据。
- **确定性可重放**：同一快照、配置和 extractor 版本应可重跑并解释差异；模型非确定性必须记录参数并允许结果不自动覆盖已采纳知识。

新增供应商只需实现 Adapter/Extractor，不得修改 Baseline、权限或审核规则。

## 8. 安全与研究数据边界

- 研究快照只读、最小范围、明确授权；排除密钥、凭据、个人数据和无关第三方代码。
- 外部模型调用默认关闭；启用前逐项目批准数据出境/保留策略，优先本地或受控环境。
- 工具在沙箱运行，限制文件、网络、CPU、内存、执行时间和输出大小；不执行仓库构建脚本或未知测试命令作为默认提取步骤。
- 工具参数、输出和事件先入脱敏层，再入 AgentRun；保留 `redacted/truncated` 标记和失败原因。
- 每轮保存输入树 hash、extractor 版本、配置、工具版本和人工决定，支持复核与撤销。
- 研究结果不自动获得生产仓库 webhook 或写权限；持续同步需另做安全和可靠性设计。

## 9. 评价方法与阶段闸门

### 指标

- **来源完备率**：可采纳断言中具有有效 revision + locator + hash 的比例；目标应先达到 100% 可定位，不能用无来源断言补数量。
- **身份稳定性**：无语义变化重跑的重复/误新增数、相同输入幂等率。
- **建议质量**：按类型抽样统计人工接受、修改、拒绝率，分开 observed 与 inferred；不混报一个“准确率”。
- **增量正确性**：更新、重命名、删除候选和人工冲突的三路 diff 正确案例数。
- **未知诚实度**：未调查范围是否被保留，是否出现无依据部署/业务结论。
- **成本**：每文件/每有效提案耗时、人工复核时间、外部模型用量与数据泄露事件。

阈值由研究样本基线后确定，不在没有测量前承诺“95% 自动理解”等数字。

### 阶段

| 闸门 | 最小产出 | 通过条件 |
|---|---|---|
| R0 契约冻结 | Extractor descriptor/request/result、AKP/AgentRun fixtures、黄金来源集 | 两种不同生产者可通过同一真实校验器，无供应商专字段进入核心 |
| R1 单快照复核 | 一个明确语言/目录的只读 extractor，完整 provenance 与未知清单 | 所有提案可定位，失败范围可见，人工能拒绝且不污染草稿 |
| R2 增量与冲突 | 变更、移动、删除、人工编辑、代码/文档冲突 fixture | 三路 diff 正确，无静默覆盖/误删/重复，未读不当作删除 |
| R3 多样化研究 | 第二类语言或资料、第二个独立 extractor/生产者 | 同一审核管线可用，替换供应商不改领域核心 |
| R4 受控集成研究 | 在研究环境定时生成新 AKP，人工触发导入 | 权限、脱敏、重放、撤销和成本均有记录；仍不自动发布 |

任何闸门失败都停留在研究环境，不通过增加页面或供应商数量掩盖。持续仓库同步只有在 R4 后另立安全、运维和价值评审。

## 10. 与主线的交接

研究路线唯一稳定交付物是**有来源的 AKP + AgentRun + 诊断/覆盖报告**。首条切片提供统一导入、权限、版本、审核和反馈；逆向路线不得复制这些能力。两条路线可并行规划和测试，但当前结论仅是“真实包接入已验证”，不是“通用逆向已就绪”。
