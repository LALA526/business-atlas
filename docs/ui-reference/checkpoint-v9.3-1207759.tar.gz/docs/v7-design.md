# Business Atlas V7 设计与模型约定

## 1. 三层分离

Project Knowledge Framework 只声明分类、阅读视图、创建操作和覆盖检查项。Knowledge Semantic Model 继续管理知识事实与版本。Knowledge Workspace 负责创建、阅读与协作。

目录分类、项目业务领域、语义关系三者独立：业务领域如生产、销售是项目知识；五维目录是软件工程信息组织标准；配置影响规则等是语义断言。

## 2. Framework Registry

每个目录节点包含 categoryId、parentId、name、description、dimension、applicableTypes、defaultViews、suggestedCreationActions、completenessCriteria、order、visibilityPolicy。

`frameworkOverrides` 只保存自定义分类、隐藏和显示标签，不进入知识对象修订。一个对象可以命中多个分类，但目录查询始终返回同一对象身份，不创建副本。

## 3. Schema 与 Command

CreateEntity 不再用行业 PREFIX 判断类型是否合法，而是查询 Schema Registry 的 instantiable、editable、permissions 和 fields。PREFIX 仅用于可读 ID 前缀；自定义类型使用通用稳定序列。

Schema 表单支持文本、长文本、数字、枚举、日期、布尔、对象引用、引用集合、资源引用和常用结构属性。结构输入采用逐行或键值文本，不向普通用户暴露 JSON。

创建、修改、关联、停用、审核发布、历史还原全部沿用 V6 Change Set，没有行业专用创建通道。

## 4. Knowledge Coverage

覆盖检查按类型执行：

- Feature：定义、场景、动作、规则、实现映射、验收和证据。
- Rule：定义、适用范围、判断/约束、来源。
- API：定义、接口契约、业务映射、数据读写。
- Configuration：定义、生效范围、业务影响。
- Term：标准定义和适用上下文。
- BusinessObject：定义、合法状态与可选状态转移。

检查项具有 met、missing、unknown、unverified、not_applicable。结构覆盖与事实可信分开计算，不生成完成率。

功能与规则的实现关系可沿功能→动作→API/数据继续投影；只有真实关系存在才计入。没有关系的对象显示缺口和补充操作，不按名称相似自动连接。

## 5. 分层阅读

流程全貌按阶段组织，局部视图只展开当前阶段及相邻节点。布局使用流程显式边，回流与异常单独路由；开始节点和正常边决定层级，返回边不决定层级。

布局节点使用副本，不修改冻结知识。拖拽只写 layout，流程边和契约版本保持不变。状态型、决策型和案件型对象继续使用各自语义视图，不强制统一成流程图。

## 6. 导航与规模

`catalogViews[categoryId]` 保存每个分类的搜索、状态、排序、页码和选择。返回时恢复原分类与来源焦点。

目录查询先筛选、稳定排序，再按每页 20 项读取，避免把 2000 个对象渲染成长页面。2000 个压力对象明确标注为轻量索引记录，不冒充复杂业务。

## 7. 治理一致性

目录与标签变化不生成业务修订。新建和修改知识仍进入 Draft Workspace，经 Change Set 审核形成对象、断言、流程和基线的一致版本。

正式契约继续按必要依赖闭包、权限、验收、来源、关键未知和冲突检查。问题、变更、契约过期、复核和验收沿用 V6 真实关联，不因目录重构而分离。
