# Business Atlas V9 设计约定

## 1. 收敛目标

V9 不再扩张行业页面，而是把 V8 的三层结构收敛为可接收真实知识、阅读、问答、反馈和记录 Agent 证据的原型：

- Project Knowledge Framework：五维目录，系统认知内扩展工程知识。
- Knowledge Semantic Model：实体、断言、流程、来源、适用性、事实等级、版本与技术关系。
- Knowledge Workspace：建构、导入、阅读、问答、反馈、Agent 记录和图文联动。

所有入口使用同一知识身份。没有售前 FAQ 库、Agent 事实库、反馈知识库或图形事实库。

## 2. 不可绕过的读取边界

`src/v9-access.js` 是所有新增读取的统一协议：

`OK / NOT_FOUND / FORBIDDEN / VERSION_UNAVAILABLE / CONTEXT_INSUFFICIENT / APPLICABILITY_UNKNOWN / DATA_INTEGRITY_ERROR`

Read Context 包含 projectId、baselineId、versionMode、draftWorkspaceId、permissionContext、applicableContext、applicabilityMode、readPurpose、timeMode 和 asOf。V6 按 ID 读取也实际检查权限；关系端点、目录治理记录、问答引用、图形节点、Agent 提案和契约衍生内容不能用 UI 隐藏代替授权。

Contract Snapshot 保持原生成版本；Authorized Contract View 每次按当前权限和适用条件重新生成。缺少必要授权时 `executionAllowed=false`，不能把删减版用于正式执行。

## 3. 适用性与时间

`src/v9-applicability.js` 组合所有已声明维度：组织、租户、地区、环境、业务范围、系统版本、配置版本和有效期；项目可增加工厂、产线等自定义维度。

- mismatch → not_applicable。
- 缺少判断条件 → unknown，不默认适用。
- 显式事实冲突 → conflict。
- explore 保留全部及状态；current 只以 applicable 为当前结论依据。

Business Knowledge Snapshot 与 Collaboration History 分离。历史基线可关联后续问题、反馈和变更，但后续活动不回写旧快照。支持 as-approved / as-known-at / current-activity 的视图语义，未宣称实现通用双时间数据库。

## 4. 写入、缓存与版本

所有知识写入继续经 V6 Command Transaction 和 Change Set。新增 `DefineFlowStructure` 也走同一事务。发布在完整项目副本中成功后才替换当前项目；失败无部分写入。活动草稿发布时清空 Undo 栈，但保留操作审计、不可变修订和基线。

`V9Access.integrateCommands()` 统一推进 `_readRevision` 并发出 knowledge/assertion/baseline/governance/feedback/agent/import/permission/catalog 事件。Catalog 缓存键包含项目、基线、版本、工作区、角色、环境、适用模式、用途和修订代次，不在按钮后临时清缓存。

Approved Business Baseline 与 Architecture Revision、Code Revision、Dependency Versions、Deployment Version、Runtime Configuration 分层。技术升级不自动形成业务基线；相关行为需另行影响复核。

## 5. AKP/0.1

Schema：`packages/schema/akp-v0.1.schema.json`。实现：`src/v9-akp.js`。

流程：选择 JSON → 非可信输入/容量检查 → Manifest、类型、引用、来源和版本校验 → 稳定外部 ID 映射与变更预览 → 接受/拒绝 → 项目副本原子提交到当前 Draft Workspace → 既有审核发布。

事实等级是 observed、documented_intent、inferred、unknown、conflicting。源码观察不自动成为批准规范；冲突发布后仍保持冲突。名称相同只提示潜在重复，不自动合并。未变化的实体、来源和断言不重复写入；整包无变化只记录幂等结果。未发布导入可撤销。技术版本可单独更新，不产生空业务 Change Set。

原型上限 8 MiB、5000 实体、20000 断言。导入文本只在转义后显示；危险协议/事件处理器拒绝，不执行导入 HTML/SVG/Mermaid/代码。`hash()` 是重复识别用 FNV-1a，不是安全签名；来源使用 SHA-256 内容哈希。

## 6. 工程知识

在系统认知中增加架构与系统边界、技术栈与框架、部署与运行、架构决策与工程约定、构建流水线、视觉资料；没有第六个一级维度。

通用 Schema 支持 ArchitectureDecision、Technology、Framework、Dependency、Runtime、Component、BuildPipeline、DeploymentUnit、EngineeringConvention、Test、UIOperation、SourceAsset、ExplanationAsset。技术关系包括 implements、exposes、uses、dependsOn、hosts、affects、reads/writes、constrains、verifies、impacts；关系语义不能互换为业务因果。

组件认知剖面同时展示职责、业务功能、API、框架、依赖、数据、部署、ADR、代码来源和影响关系。

## 7. 问答、反馈与 Agent

问答只运行有限意图识别、对象检索、适用性判断、确定性关系查询与解释组合；不支持假装理解任意自然语言，也不调用 LLM。角色改变重点和格式，不改变事实。结论携带对象、关系、基线、环境和来源；售前明确支持/条件支持/未确认/不支持/资料不足，原型能力不冒充生产支持。

反馈类型分别记录，自动携带工作上下文。流程为待分流 → 分析 → 处理决定 → Issue/Change Set/Task → 实施发布/验收 → 关闭；反馈本身不修改批准知识，关闭时同步解决关联 Issue。

Agent Run 支持 JSON/JSONL 外部记录和明确模拟记录。任务、工具调用、观察、推断、提案、待确认和结果分别展示；敏感参数脱敏。工具输出只是证据，Knowledge Proposal 必须人工审核。

## 8. 图形与视觉资料

- Source Asset：截图/原型等原始视觉资料。
- Semantic View：由知识模型和显式流程/转移/断言投影。
- Explanation Asset：人工说明图，未经核验不成为事实。

V9 支持业务流程、状态、架构、数据、时序、界面热点，以及 Mermaid/ASCII 导出。图形只保存布局和阅读上下文；布局调整不改变事实或业务版本。原型热点与 Surface/UIOperation/Action 多对多关联，不复制可运行行业页面。

## 9. 可信度、覆盖与存储

Governance、Verification、Applicability、Coverage 分别展示。分类覆盖按目录职责、关系、来源和已调查环境列出未覆盖对象，并直接接原有 Action Context；不计算虚构项目完成率。

少量数据存 localStorage，容量失败显式报错并可导出备份。图片、大日志和大型项目需要正式文件/证据存储。当前权限、协作、Agent 和来源都是原型业务规则，不是企业安全或生产部署承诺。
