# V9.3 数据迁移、兼容与 AKP 扩展

## 1. 兼容原则

- 继续使用 `business-atlas-v9` localStorage、`storageVersion=9`、既有路由和项目身份。
- 不清空 V9.2 项目、草稿、问答、反馈、Agent Run、任务、契约或 Visual View。
- 不创建第二知识数据库，不修改 AKP/0.1 的基础包装格式。
- 旧 Rule `when/inputs/outcomes/rows` 在读取时规范化；旧 Task 按需显示未分析语义，不自动回写。
- 历史基线不可变；认知样本和制造语义扩展通过新的显式迁移 Change Set 形成新基线。

## 2.  additive Schema

新增可实例化类型：`BusinessCase`、`ObservedBehavior`，仍使用统一 Entity、Source、Permission、Revision、Baseline、AKP 与 Read Context。技术机制继续复用 API、Component、Module、DataEntity 等实体和 `factKind/semanticRole`。

Task 增加可选 `semanticContract / impactInvestigation / delivery / deliveryState`；项目增加可选 `decisionRecords / knowledgeDeliveryManifests / v93SchemaVersion`。旧数据没有这些字段时按未知处理，不自动编造。

## 3. 用户草稿保护

V9.2 已有草稿的制造项目不会执行自动发布迁移，标记 `_v93SemanticsMigrationDeferred`。只有没有用户未发布操作的样本项目才执行显式样本迁移。正常运行升级不得借版本迁移发布用户草稿。

## 4. AKP/0.1 兼容扩展

BusinessCase 与 ObservedBehavior 可作为普通实体及来源关系交换；Task 语义合同采用独立 `BusinessAtlas.TaskSemanticContract/1.0` 授权导出，不伪装成 AKP，也不把 Contract Snapshot 当作当前授权视图。

修复 V9-06 跨日问题：AKP 未声明 `validTime` 时使用 `{from:null,to:null}`，表示未声明时间边界；不再把导入日擅自当成业务生效日。显式有效期仍按适用性规则验证。

## 5. 严格版本与权限

- 指定不存在的规则版本返回 `VERSION_UNAVAILABLE`，不回退 draft/current。
- Flow 引用逐节点按版本、权限、适用性解析；不可读引用裁剪并在正式闭包中阻断。
- 任务、问题、首页、决策评估、图形、问答和导出统一使用 Read Context。
- 非管理员备份变为当前项目授权导出；管理员全量备份仍是明确的高权限操作。
- 权限缓存键继续包含角色、基线、工作区、环境和用途；角色切换同时清空评估展示状态。

## 6. 已知限制

这是前端原型迁移，不是服务端数据库在线迁移。企业认证、真实写授权、多人并发、仓库同步和真实 Agent 编排不在本轮。生产化需要服务端 Schema 版本、迁移日志、回滚策略和数据库约束。
