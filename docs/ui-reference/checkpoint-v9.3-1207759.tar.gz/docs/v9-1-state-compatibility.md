# Business Atlas V9.1 旧路由与状态兼容

## 1. 不清空用户数据

V9.1 继续使用 `business-atlas-v9` 和 `storageVersion: 9`。初始化不删除 projects、draftWorkspace、baselines、questionAnswers、feedbackRecords、agentRuns、importProposals 或 visualViews。

`migrateStore` 只补充 `assistantByProject`，并从旧 `contexts.askDraft / conversationId / answerFormat` 迁移一次面板状态。重复迁移不得覆盖用户后续编辑。

## 2. 旧路由映射

| V9 路由 | V9.1 行为 |
|---|---|
| `ask` | 打开当前项目助手，并把地址恢复为合理工作区；不显示旧问答整页 |
| `feedback` | 进入 `tasks`，`collaborationTab=feedback`，并立即持久化 |
| `agents` | 进入 `tasks`，`collaborationTab=activity` |
| `visuals` | 找到对应 Visual View，进入其根知识的认知工作台专注画布 |

所有映射保留当前 projectId。Visual 映射保留 view/root/focus；项目切换不混用会话或权限。

## 3. 助手状态

`assistantByProject` 与主工作区 contexts 分离：

- 打开/关闭和最小化不改变 route。
- 页面渲染只同步 contextualFocus，不清空 activeConversationId、draftText 或历史。
- 关闭再打开保留最近会话。
- 滚动位置独立恢复。
- 项目切换使用各自状态，不共享另一个项目的回答和权限。
- 历史回答在展示前再次按当前权限过滤。

## 4. 反馈返回行为

在 pointerdown 阶段先记录滚动位置，避免点击顶部按钮时浏览器先滚到顶部。提交或取消关闭弹窗后恢复焦点和 scroll。只有用户主动“查看处理进度”才进入任务反馈视图。

## 5. 图形与知识焦点

`studioPresentation` 和 `visualViewId` 分别记录呈现方式与实际定义。切换时同步更新；root/baseline/permission 不重置。`visualFocusId` 和 `focusId` 同步，节点不在新图中时不强制回退根对象。专注模式只是布尔状态，返回原工作台。

## 6. 任务与执行记录

Agent Run 不强行生成 Task。已有 Task 的从任务进入；无 Task 的从 Import Proposal 或项目活动进入。从提案进入知识后沿用原 returnStack 返回任务/活动。JSON/JSONL 导入继续写原 `agentRuns`，不是另建活动存储。
