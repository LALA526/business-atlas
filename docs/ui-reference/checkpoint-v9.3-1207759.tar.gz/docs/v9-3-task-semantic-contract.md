# V9.3 Task Semantic Contract 约定

## 1. 定位

Task Semantic Contract 是现有 Task 的业务语义与变更约束，不是新导航、新知识库，也不是复制一份规则文档。字段格式为 `TSC/1.0`，与原有正式 Knowledge Contract、Issue、Change Set、验收和 V1.2 交付记录共同工作。

## 2. 七个部分

- **Business Intent**：真实业务目的、具体问题、原因、需求提出版本。
- **Existing Behavior**：批准规则的 `ruleId + version + baselineId`、当前观察引用及符合性。
- **Target Behavior**：候选目标、适用范围、条件/判断/结果、默认和异常。未批准内容始终为 `proposed`。
- **Business Difference**：新增、修改、删除、保持不变及未知项。
- **Impact Scope**：功能、角色、对象、规则、流程、状态、API、数据、配置、组件、界面、任务与验收的影响调查。
- **Acceptance Cases**：正、反、边界、回归与必要未知案例的版本引用及测试绑定。
- **Knowledge Delivery**：创建/更新哪些知识、保留哪些历史、验证哪些实现、关闭哪些问题、目标基线状态。

## 3. 引用而非复制

典型候选：

```text
RULE-M002 @ v1.1 @ BL-PRJ-00003-CS-003
  → proposal-1 / patch-decision-row MR2-03
  → 原条件 AND expectedVersionMatch equals true
  → approvalStatus = proposed
```

Task 保存规则身份、基线版本、判断行和差异操作，不保存另一份完整 `rows/versions` 规范。候选预览可以物化临时结果，但不能回写旧基线。批准仍通过 Issue / Decision Record / Change Set / 审核发布完成。

## 4. 严格程度

完整合同：`new-feature`、`business-rule-change`、`api-behavior-change`、`data-semantic-change`、`cross-module-technical-change`。

简化合同：文案、纯样式、不改变外部行为的内部重构。简化仍需说明业务目的、哪些行为保持不变、怎样回归验证，不能简化成只有标题。

旧 Task 通过按需兼容投影显示 `legacy-unassessed`：缺少内容明确标为未分析，不自动补齐，也不回写原任务。

## 5. 生命周期

1. 用户只填写业务目标、问题、关联功能、目标描述和来源。
2. 系统经 Read Context 读取批准规则、当前观察、实现与未决问题。
3. BA/用户/Agent 形成候选决策，系统显示当前规范、候选目标、差异和待确认。
4. 系统生成影响候选；责任人逐项记录必须修改、无需修改、转其他 Task 或待确认。
5. 形成开发工作项，关联原需求、业务语义版本、影响项、实现、测试和知识交付要求。
6. 代码合并后形成 Delivery Manifest；知识提案独立审批，不自动成为基线。
7. 只有目标、影响、实现、测试、验收、旧路径、知识和版本全部闭合才可声明完整交付。

## 6. Agent 权限

Agent 可调查源码、调用链、重复实现、未使用路径、潜在影响，提出技术收敛、测试和知识提案；不改变业务语义的授权内部工程决定可独立记录。

目标规则、客户可见行为、重要默认值、数据删除、关键权限、不可逆迁移必须由相应 Owner 决定。推荐记录包含当前行为、选项、业务结果、兼容影响和推荐理由，但 `approval:null` 前不得进入正式规范。
