# Business Atlas V5 设计与模型约定

## 1. 产品判断

V5 不以知识对象数量或页面数量作为完成度，而以三个问题判断：

1. 新人能否沿业务与技术两个方向认识项目？
2. BA、开发、测试能否在同一功能上下文中理解条件、动作、对象变化、实现和证据？
3. 人或 Agent 能否取得版本明确、权限过滤、未知可见且可反馈的任务契约？

Wiki、流程、资料、术语和治理界面均服务于这三种成果物。

## 2. 三层统一业务认知语法

### 2.1 知识实体

保留稳定 ID 和类型身份。V4 legacy collection 通过适配读取，V5 发布覆盖保存在 `publishedEntities`，不可变历史保存在 `knowledgeRevisions`。

### 2.2 语义断言

```js
{
  assertionId: 'AST-M-BLOCK-RELEASE',
  subject: 'RULE-M001',
  predicate: 'blocks',
  object: 'ACT-M009',
  qualifiers: {
    condition: '缺陷严重、不可返工或复检未通过',
    organization: '华东一厂',
    version: 'v1.0'
  },
  sourceRefs: [{ resourceId: 'SRC-M01', locator: 'MR-01 至 MR-03' }],
  factKind: 'approved_specification',
  verificationStatus: 'confirmed',
  validTime: { from: '2026-11-14', to: null },
  revision: 'a1',
  owner: '项目业务与技术共同确认'
}
```

`PREDICATES` 声明关系的合法主语和宾语范围。自定义 Schema 的 `relations` 进一步限制项目扩展类型允许的关系。配置 `affects` 必须同时具有环境、组织/业务范围和配置版本。

无来源的新断言强制为 `unverified`。V4 已批准关系属于显式迁移输入，不等于 V5 新建断言的默认行为；无法通过 V5 类型校验的旧关系保留为关系数据，但不提升为语义断言。

### 2.3 上下文与可信度

- 事实类别：批准规范、观察实现、历史意图。
- 核验状态：已确认、待核验、冲突、待复核。
- 适用范围：项目、组织、地区、租户、业务范围、版本、环境、生效时间。
- 来源：资源 ID 加段落、行号、配置键、测试或人工确认的精确定位。

## 3. 状态与流程的正确性

`BusinessObject.states` 只表示合法状态目录。`transitions[]` 的每项必须具有：

```text
fromState / toState / triggerEvent / guard / actionRef / effect / sourceRefs / verificationStatus
```

生产批次有 7 条已确认转移和 1 条待核验旧笔记推断。已放行、已报废没有出口；待复检根据条件分别进入已放行或返工中。未核验的“质量隔离 → 返工中”默认折叠且不属于批准路径。

`Flow.nodes` 不推导边。正常、条件、并行、汇合、异常、恢复和终止均来自 `Flow.edges`。并行节点必须存在显式 join 或有效 joinId；本原型不把并行定义伪装成并行实例调度。

语义检查包括：端点、主宾语类型、配置范围、转移状态和动作、分支结果、异常回流、并行汇合、已确认转移来源。它不是 BPMN 引擎。

## 4. 功能全景剖面

`project.panoramas[]` 是演示数据中的组装配置，不是另一份业务文档。每一步引用实体和断言，展示输入、输出和上下游。

制造保存链 `PAN-M-REGISTER` 显式包含：

```text
UI-M001 保存
→ API-M00 接收请求和 expected_version
→ RULE-M002 前置判断
→ ACT-M001 创建异常
→ DATA-M02 写入 quality_defect
→ ACT-M002 批次生产中 → 质量隔离
→ DATA-M03 写入 batch_quality
→ EVT-M01 提交后发布事件
```

一个 API 实现两个动作，两个动作写不同数据，多个动作共享一个事务。事件启动调查上下文采集，不直接放行。失败包括 422、409 全回滚和 outbox 异步重试。

## 5. Presentation Profile

`project.presentationProfiles` 将知识类型映射到通用组件。组件无数据时隐藏；影响判断的缺失显示缺口。配置不是 JSON 页、对象不是状态数组、数据实体不是只有字段表。

项目可注册 Schema 并复用 `*` Profile，也可为新类型组合现有组件。核心渲染器没有制造、政务或预约专用页面分支。

## 6. 统一 Knowledge Change

所有 V5 UI 知识写入走以下命令：

```text
createChange → updateDraft → submitChange → approveChange → createBaseline
```

- `createChange` 固化 baseSnapshot，创建独立 draft。
- `updateDraft` 检查草稿状态和预期变更修订，执行 Schema / JSON 校验。
- `submitChange` 要求非空原因、真实内容差异和影响复核。
- `approveChange` 记录 ReviewDecision，生成不可变 published revision。
- `ImpactReview` 只标记关联知识重新核验，不自动升级关联对象。
- `createBaseline` 固化全部对象和断言的具体修订。

项目首页资料、legacy Rule/Action/Scenario 的完整 JSON 结构、自定义对象和 Assertion 均进入同一机制。历史基线及历史引用不被修改。软件 release 与配置版本层不因知识发布而自动变化。

## 7. Activity Capability Registry

活动定义包含角色、输入、完成条件、证据、允许转移、权限、可选分支和 `capabilities`。运行组件只渲染白名单操作，`executeActivity` 再校验一次。

制造调查活动允许调查结论、检测证据、复检任务、处置建议和完成，不允许开发交接。开发交付活动才允许交接包或 Agent。政务会签允许法规材料、会签意见、补正和部门决定。

## 8. Knowledge Context Package

同一知识模型按开发、测试、BA、Agent 和影响分析用途动态生成契约。正式模式只纳入当前批准基线中的已确认、批准规范断言，并包含：

Task Intent、Business Context、Approved Requirements、Constraints、Behavior、Implementation Context、Unknowns、Acceptance、Evidence、Version Binding、Feedback Contract。

权限或基线排除项单独列示。与任务相关的 `blocksFormal` 未知阻止正式交接；探索模式明确标注不可直接实施。反馈固定进入 `pending_verification` 并创建待确认问题，不能改写基线。
