# Business Atlas V9.1 主要交互组件约定

## 1. Main Workspace 与 Context Tools 分离

`src/v6-app.js` 负责主路由和现有领域工作；`src/v9-1-ui.js` 负责上下文呈现。`src/v9-1-assistant.js` 提供 Provider 和项目独立面板状态。不得把面板开关、草稿或当前图形页签写入业务实体、基线或 Change Set。

## 2. Workspace Action Context

`workspaceActionContext()` 统一提供：

- `projectId / route / knowledgeId / taskId`
- `baselineId / versionMode / applicableContext / permissionContext`
- `visualViewId / focusId / origin / returnContext`

不是所有操作都需要全部字段，但读取和返回必须使用明确上下文。主工作区与助手可以独立更新各自焦点，不得互相清空。

## 3. Assistant Panel

### 状态

`store.assistantByProject[projectId]`：

- `isOpen / minimized`
- `activeConversationId / draftText`
- `relatedProjectId / contextualFocus`
- `scrollPosition / optionalExpandedCitation`
- `answerFormat / returnRoute`

`questionAnswers` 仍是项目内的权威回答记录；面板只保存呈现状态。切换页面同步 contextualFocus，切换项目使用各项目自己的状态和 Provider 历史。

### 行为

- 打开、收起、关闭不调用主路由 `go()`。
- 打开引用复用 `openStudio()`，面板保持打开。
- 输入只更新 draftText，不发送网络请求。
- 发送由 Assistant Provider 执行；未知时保留输入并提示澄清。
- 关闭再打开恢复会话；Esc 关闭面板或模态弹窗。
- 桌面左侧展开并为工作区留出空间；窄屏使用可关闭浮动面板，关键操作保持可恢复。

## 4. Feedback Dialog 与 Management

`openFeedback` 在 pointerdown/click 前保存滚动位置。弹窗仅收集类型和内容，自动携带知识、基线、环境和 origin。`save-feedback` 调用现有 Feedback Service，随后关闭弹窗并恢复 focus/scroll，不调用 `go('feedback')`。

`view-feedback-progress` 是用户主动选择的例外，进入 `tasks + collaborationTab=feedback`。管理继续复用 V9 的分流、转变更/任务、发布/验收和关闭逻辑。

## 5. Activity View

`activityWorkspace` 复用 `renderAgents` 的详情和文件导入，嵌入“任务与问题”。任务详情通过 `open-task-activity` 进入；导入通过 `open-import-activity` 进入。无 Task 的 Run 保留在项目活动列表，不伪造任务关联。

## 6. Visual Presentation

- `availableVisualViews(project, projection)`：只返回当前知识投影实际包含的视图。
- `studioWorkbench`：组合左侧结构、中央文字/图形/并读、右侧焦点检查器。
- `renderVisuals`：可嵌入画布、工具栏、缩放、Mermaid/ASCII 和 Source Asset。
- `renderVisualInspector`：显示当前焦点、规则、关系和来源。

`studioPresentation` 表示文字/图形/并读方式，`visualViewId` 表示实际定义，二者在切换时同步但职责不同。`visualFocusId` 与知识 `focusId` 同步；节点不在新图中时，允许无高亮，但不得重置知识焦点。

专注模式是 `visualFocusMode` 布尔状态，不是路由。旧 `visuals` 重定向到相应根的专注画布，返回原工作台。

## 7. Home Composition

`homeComposition(project, entities)` 输出非空 section 列表和 composition 类型。它只读取通用知识类型、数量和导入记录，不读取项目名称，不添加专用项目分支。标准目录仍由 Framework Registry 提供。
