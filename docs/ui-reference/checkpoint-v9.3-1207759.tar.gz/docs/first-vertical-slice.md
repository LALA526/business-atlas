# Business Atlas V9：首条纵向切片实施规划

> 目标：用最小但完整的真实服务闭环替代继续扩原型。**现在即可并行启动实施规划与受控试点准备**；本文不是已完成实现声明。

## 1. 切片目标与范围

### 用户闭环

```text
创建项目
→ 上传 AKP/0.1
→ 解析、校验、预览
→ 人工确认后原子写入 ChangeSet 草稿
→ 查看差异/来源并人工审核
→ 原子发布不可变 Baseline
→ 按基线/环境浏览与确定性问答（含引用）
→ 提交并分流 Feedback
→ 转 Issue + 新 ChangeSet（或 Task）
→ 修改、审核、发布/验收
→ 关闭 Feedback 并记录解决基线
```

这条链路同时验证知识写入、版本治理、服务端读取、权限、引用和反馈价值；不能只做一个“上传接口”或只把 localStorage 换成数据库。

### 切片内

- 单组织下的多个隔离项目；项目成员为 admin、editor、approver、reader，支持对象敏感性/clearance。
- AKP/0.1 JSON 文件上传、真实 Self 包和人工构造包；来源可为文本/受控 Blob。
- 草稿差异、审核退回/批准、基线历史、对象/关系/来源浏览。
- 基于对象选择和有限文本匹配的 WHY/HOW/IMPACT/DIFFERENCE/REQUIREMENT 问答；不调用 LLM。
- 反馈转 Issue+ChangeSet；Task 仅保留最小创建、完成和反馈关联能力。
- 服务端审计、备份恢复、OpenAPI、基本作业与索引重建。

### 切片外

真实 MCP/LLM、仓库同步/自动逆向、多人实时编辑、通知IM、开放注册、复杂 BPMN、全量图形编辑、微服务和高可用。AgentRun 可作为独立适配器后续接入，不阻塞本闭环。

## 2. 角色与最小权限

| 动作 | admin | editor | approver | reader |
|---|---:|---:|---:|---:|
| 创建/配置项目、成员和 Schema | ✓ | — | — | — |
| 上传/预览/提交导入、编辑 ChangeSet | ✓ | ✓ | — | — |
| 查看草稿 | ✓ | 自己或被授权工作区 | 待审工作区 | — |
| 审核并发布 | ✓ | — | ✓ | — |
| 浏览批准知识、问答、提交反馈 | ✓ | ✓ | ✓ | ✓（仍受对象权限） |
| 分流反馈、关闭反馈 | ✓ | 可配置 | 可配置 | — |

发布者与最后编辑者默认分离；小型试点若允许同人，必须由项目策略显式开启并写入审计。`permissionContext` 永远由服务端身份和项目成员关系生成，客户端只传读取条件，不传可信角色。

## 3. 状态机

### ImportProposal

```text
previewed ──commit──> committed ──review/publish──> reviewed-and-published
   │                    │
   │                    └─discard（仅未发布且工作区未推进）─> discarded
   └─校验失败─> invalid（可读取错误，不可 commit）
```

同一内容重导可返回 `idempotent=true`；不得重复创建对象、断言或空 ChangeSet。作废不能覆盖后续工作。

### ChangeSet

`draft → proposed → published`；审核退回为 `draft`，可显式 `discarded`。发布需绑定 `baseBaselineId`、预期当前基线和最新差异审核。

### Feedback

`triage → analyzing → in-progress → closed`，另有 `duplicate`。ChangeSet 未发布或 Task 未验收时关闭返回 409，原批准知识始终不被反馈直接修改。

## 4. API 草案

统一前缀 `/api/v1`，OpenAPI 为首条切片契约产物。写请求带 `Idempotency-Key`；ChangeSet 提交/发布和反馈状态变更带 `If-Match` 或 `expectedRevision`。

| 方法与路径 | 用途 | 关键结果/约束 |
|---|---|---|
| `POST /projects` | 创建项目 | 返回 projectId、空当前基线、Schema 版本；无虚构初始知识 |
| `GET /projects/{projectId}` | 项目摘要 | 当前基线、成员能力、导入/待审计数；按权限裁剪 |
| `POST /projects/{projectId}/imports` | 上传 AKP，parse+validate+preview | 持久化 proposal/package/hash；返回 validation、create/update/unchanged/duplicate/unknown/conflict 预览；不写业务草稿 |
| `GET /imports/{importId}` | 查看错误、警告和预览 | 大包正文不随每次响应返回；保留无效引用与未知 |
| `PUT /imports/{importId}/decisions` | 保存逐项接受/拒绝决定 | 不允许通过拒绝来源而留下悬空必需引用 |
| `POST /imports/{importId}/commit` | 原子导入 ChangeSet | 返回 changeSetId、draftWorkspaceId、summary；重复请求返回首次结果 |
| `POST /imports/{importId}/discard` | 撤销未发布导入 | 工作区已发布/切换或已有后续操作时拒绝 |
| `GET /change-sets/{changeSetId}` | 草稿、操作、验证和审核状态 | 按项目与工作区权限读取 |
| `GET /change-sets/{changeSetId}/diff` | 相对 baseBaseline 的对象/断言/来源差异 | 显示事实等级、未知和冲突，不只显示名称 |
| `POST /change-sets/{changeSetId}/commands` | 反馈修正等后续草稿命令 | 复用领域 Command；失败整体回滚 |
| `POST /change-sets/{changeSetId}/submit` | 提交审核 | 原因非空、完整校验通过；记录 proposed 状态 |
| `POST /change-sets/{changeSetId}/reviews` | 批准或退回 | approver、comment、diffHash、时间追加写 |
| `POST /change-sets/{changeSetId}/publish` | 原子形成新 Baseline | 校验最新 diff 已批准且基线未变化；返回 baselineId 和 impactedTasks |
| `GET /baselines/{baselineId}` | 基线元数据与修订绑定 | 已批准内容只读；条目仍按当前权限裁剪 |
| `GET /projects/{projectId}/entities` | 目录/对象列表 | 查询带 baselineId、versionMode、applicableContext、purpose、分页；统一 Access |
| `GET /entities/{entityId}` | 对象及来源/覆盖 | 不存在、无权、版本不可用分别返回统一结果，不泄露端点 |
| `GET /entities/{entityId}/relations` | 关系及适用性 | 双端点均需可读，来源引用继续过滤 |
| `POST /projects/{projectId}/answers` | 确定性问答 | 输入 text/intent/role/rootId/followUpOf/readContext；输出结论、limitations、citations、readContext |
| `POST /projects/{projectId}/feedback` | 提交反馈 | 自动/显式保存 originContext、baselineId、relatedKnowledgeIds、evidenceRefs |
| `POST /feedback/{feedbackId}/triage` | 分流、查重、指定负责人 | 追加 history，不改知识 |
| `POST /feedback/{feedbackId}/work-items` | 转 Issue+ChangeSet 或 Task | 返回 workItem；状态 in-progress |
| `POST /feedback/{feedbackId}/close` | 验收关闭 | 校验关联工作完成，记录 resolvedBaselineId/resolution |

`POST /imports` 创建的是导入提案资源，因此即使包校验失败也可返回 `201 + status=invalid`；业务错误在 `validation.errors` 中逐项给出。不可解析、超限或不支持媒体类型使用 400/413/415，不能生成可提交提案。

读取沿用 `OK / NOT_FOUND / FORBIDDEN / VERSION_UNAVAILABLE / CONTEXT_INSUFFICIENT / APPLICABILITY_UNKNOWN / DATA_INTEGRITY_ERROR`。写请求可增加明确的校验/并发错误类型，但不得把它们伪装成读取成功。所有响应带 requestId；错误响应不带秘密、受限名称或内部堆栈。

## 5. 最小数据契约

### Project

`projectId, name, purpose, schemaVersion, applicabilitySchema, currentBaselineId, revision, createdBy, createdAt`。

### ImportProposal / KnowledgePackage

`importId, projectId, packageId, contentHash, formatVersion, sourceProjectId, sourceRevision, producer, provenance, status, preview, validation, decisions, changeSetId, idempotencyKey, createdAt`。

原始包存 Blob；预览存稳定外部 ID、候选内部 ID、动作和差异摘要。`unknownsAndConflicts` 作为一等记录保存，不能仅写日志。

### ChangeSet / Baseline

- ChangeSet：`changeSetId, projectId, baseBaselineId, title, reason, status, operations, validation, reviewDecisions, revision, publishedBaselineId`。
- Baseline：`baselineId, projectId, createdAt, approvalStatus, entityRevisions, assertionRevisions, flowRevisions, confirmations, contentHash`。
- 发布记录和修订追加写；`currentBaselineId` 的更新与新 Baseline 同事务。

### Answer / Feedback

- Answer：`answerId, conversationId, query, intent, role, focusIds, readContext, conclusions, citations, limitations, deterministic=true, createdAt`。答案缓存/历史不能绕过当前来源权限。
- Feedback：`feedbackId, projectId, reporter, category, title, description, originContext, relatedKnowledgeIds, evidenceRefs, status, owner, workItem, history, resolvedBaselineId, resolution`。

## 6. 必须写成测试的领域不变量

1. 无效包、无效端点、缺少 locator、危险内容和未注册类型不得产生业务草稿。
2. 预览阶段不改变实体、断言、基线、外部 ID 映射和 ID 序列。
3. 提交导入只写一个完整 ChangeSet；任一步失败数据库状态与提交前一致。
4. `(projectId, sourceProjectId, stableExternalId)` 映射稳定；同名不自动合并，重复导入幂等。
5. `observed/documented_intent/inferred/unknown/conflicting` 全量保留，发布不自动变成 confirmed。
6. 未经审核不能发布；审核后差异再变化必须重新审核。
7. 发布时当前基线与 `baseBaselineId` 不一致，返回 409/412，不覆盖别人刚发布的内容。
8. 已批准 Baseline 及其修订不可 UPDATE/DELETE；历史读取不回退最新。
9. 草稿只在显式 draft Read Context 可见；当前批准读取不被导入或反馈污染。
10. 列表、按 ID、关系、问答、来源下载、Contract 和导出均无权限绕过。
11. 缺少声明所需环境/时间时问答显示未知；不将不适用或冲突作为当前事实。
12. 每条确定性回答有焦点、基线和可打开引用；无法映射时返回候选对象，不编造回答。
13. 反馈本身不创建基线；关闭必须引用已发布 ChangeSet 或已验收 Task。
14. 后续反馈、布局和 Agent 活动不回写历史；缓存按权限/环境/版本/用途隔离。
15. 应用重启后数据、幂等结果、审核与基线仍可恢复，不依赖进程内存。

## 7. 测试方案

| 层 | 必测内容 | 可复用证据/fixture |
|---|---|---|
| 纯领域单元 | 适用性、权限闭合、外部 ID、预览、状态机、Contract 完整性 | V9 51 项行为规格，`src/v9-*.js` |
| API 契约 | OpenAPI、统一错误、Idempotency-Key、If-Match、分页、输入限制 | AKP/AgentRun JSON Schema；正反向请求 golden files |
| 数据库集成 | 导入/发布事务、约束、历史追加写、并发发布、outbox、重启 | 故障注入在每个提交点中断；比较提交前后快照 |
| 授权集成 | 四角色、敏感对象、关系端点、搜索、导出、Blob 下载和缓存 | V9-01/02/04/05/26 等场景扩展为真实身份 |
| 浏览器 E2E | 从空项目走完整闭环，审核退回、反馈再变更、历史浏览 | 真实 Self 包与小型人工包，不依赖演示种子 |
| 恢复与安全 | 备份恢复、哈希核对、恶意 JSON、超大包、秘密脱敏、日志检查 | `packages/business-atlas-self.akp.json` 与 V9 破坏性用例 |
| 回归 | V3–V8 198 项与 V9 51 项保留；新实现另建服务端测试，不把 249 项通过当服务端覆盖 | 当前测试及 `artifacts/` 结果 |

性能首测只设可复核基线：Self 包、2000 对象目录分页、典型问答和两次并发发布；记录耗时与资源后再定容量目标，不无依据承诺 SLA。

## 8. 验收条件

首条切片只有全部满足以下条件才算完成：

1. 新用户通过 API/UI 创建空项目，无初始基线和虚构知识。
2. 上传真实 Self 包后，预览报告 56 个实体、49 条断言、25 个来源；导入草稿计数一致，来源路径/行范围可打开。
3. 首次导入前及人工发布前均没有包含 Self 知识的批准基线；审核发布后恰有一个新基线。
4. 相同包重复提交返回幂等结果，实体、断言、基线和草稿数量不增加；中断导入无任何部分记录。
5. reader 能按批准基线浏览并回答三个预置问题，每个结论可追溯到对象、修订、基线和来源；无法映射的问题明确要求选择对象。
6. 缺少环境时适用性为 unknown；受限对象不能通过列表、直接 ID、关系、问答、导出或缓存读取。
7. 两个编辑者基于同一基线提交变更时，后发布者必须重新基于最新基线生成差异并审核。
8. 对回答提交反馈，分流并转 Issue+ChangeSet，修正后发布；反馈关闭记录新基线，旧基线摘要保持不变。
9. 应用和数据库重启后继续读取同一基线、导入提案、审核记录和反馈；备份恢复到独立环境后计数/哈希一致。
10. OpenAPI、领域测试、E2E、权限/恢复报告和审计样例齐备；没有以“原型已有”替代新服务验证。

## 9. 分阶段实施与并行方式

| 阶段 | 交付物 | 退出闸门 |
|---|---|---|
| 0. 契约与 ADR（可立即开始） | OpenAPI 草案、领域状态机、数据 ERD、威胁模型、Self golden fixture | 产品/领域/前后端对身份、版本、权限和结果码签字 |
| 1. 项目与持久化骨架 | 模块化单体、migration、成员认证、Project/Repository/Audit | 空项目重启仍在，服务端不能自报角色越权 |
| 2. AKP 导入到草稿 | parse/validate/preview、Blob、外部 ID、原子 commit/discard、幂等 | Self 计数正确，失败/重导/危险输入测试通过 |
| 3. 审核与基线 | diff、review、publish、历史读取、并发控制和 Contract 失效 | 不可变与并发测试通过，无绕过审核路径 |
| 4. 浏览与问答 | Access API、目录/关系/来源、确定性 Answer 与引用 | 权限/适用性/历史/无答案场景通过 |
| 5. 反馈闭环 | Feedback、Issue/ChangeSet/Task、关闭与解决基线 | 完整 E2E 通过，反馈不能直改批准知识 |
| 6. 共享试点加固 | 备份恢复、审计导出、监控、作业重建、使用文档 | 验收 1–10 全部通过，才开放受控共享环境 |

阶段 0 后，前端可基于 OpenAPI mock、后端可实现 Repository、测试可准备 golden/故障注入，三条工作并行；领域 Owner 负责冻结契约变更。不得为并行而复制三套权限、适用性或导入规则。

## 10. 实施期间的非目标保护

不接受以“顺便”为名加入真实 LLM、MCP、仓库爬取、更多图形、复杂工作流或微服务。逆向研究只按[独立研究路线](reverse-engineering-research.md)产出 AKP；任何自动提取结果仍从本切片的导入与人工审核入口进入。
