# V5 真实浏览器验收记录

验收日期：2026-11-15。浏览器：OpenCode 内嵌 Chromium（六条旅程与跨项目检查）和本机 Google Chrome Headless（`file://` 独立打开）。验收对象为 `dist/business-atlas-v5.html`；模块开发版另做同源码启动检查。

## 六条指定旅程

| 旅程 | 实际操作与断言 | 结果 | 截图 |
|---|---|---|---|
| 1. 新人理解制造质量 | 制造首页阅读边界；打开 `OBJ-M01`；确认 7 条已确认转移、1 条默认折叠待核验转移，无“已放行 → 已报废”；进入 `ACT-M009` 与处置剖面，检查 7 个显式环节、实现和证据 | 通过 | `journey-01-project-map.jpg`、`journey-01-state-object.jpg`、`journey-01-disposition-panorama.jpg` |
| 2. 配置反查业务与技术 | 打开 `CFG-M01`；核对华东一厂、生产环境、配置版本和影响；进入 `RULE-M001`、功能剖面并切换实现细节与 API 环节 | 通过 | `journey-02-configuration-impact.jpg` |
| 3. 异常登记保存全链 | 从 `UI-M001` 打开保存剖面；依次选择规则、API、`quality_defect`、批次隔离和事件；检查输入、输出、上下游、409 回滚和 outbox 说明 | 通过 | `journey-03-registration-trace.jpg` |
| 4. 已发布配置变更 | 提出修改并填写原因；编辑草稿，确认 localStorage 中已发布描述不变；查看 5 项真实差异；确认影响、提交、批准；得到 `CFG-M01@r2` 和 `BL-PRJ-00003-002`；旧基线仍绑定 r1，release=v1.0、配置层不变 | 通过 | `journey-04-baseline-r2.jpg` |
| 5. 质量工作流实际执行 | 当前调查活动只显示调查、证据、复检、处置和完成；填写调查结论与检测证据，完成条件由阻塞转为满足；逐活动推进至 completed；无开发交接按钮；保存 9 条执行记录 | 通过 | `journey-05-quality-completed.jpg` |
| 6. 正式契约与反馈 | 选择 `REQ-M001`、开发目的、批准新基线和深度 4；生成含 31 个事实、52 条断言、4 条验收的正式契约，绑定 CFG-M01@r2；提交旧入口问题与偏差；反馈为 pending_verification，问题为 waiting，基线未变 | 通过 | `journey-06-formal-contract.jpg` |

旅程 5 首次实测发现活动提交按钮的事件委托优先级错误，证据没有写入。修复后重新加载、重新执行并核对 localStorage 中的“调查结论”“检测证据”和两条能力记录，再完成全部活动。最终旅程记录均为修复后的结果。

## 跨项目与权限检查

- 政务 `SCN-G001`：显示 10 条显式流程边、动态案件活动和补正回边，不混入生产批次、质量隔离或返工术语。
- 预约 `OBJ-B03`：显示 5 条真实转移，包括 CapacityConflict 和取消，不混入制造术语。
- 审批项目首页无制造信息泄漏；模型测试另验证成本中心/收款方决策、受限对象权限过滤和项目数据隔离。
- 六条旅程结束及跨项目检查均读取浏览器 console，**0 条 error**。

## 离线与模块版

- 使用 `file:///E:/Business%20Atlas/dist/business-atlas-v5.html#PRJ-00003/home` 直接启动本机 Chrome，无 HTTP 服务依赖，制造首页完整渲染。截图：`offline-single-file.png`。
- 单文件静态检查：无外部 `<script src>`、stylesheet link、CSS `@import` 或网络字体/图片 URL。
- 模块开发版 `index.html` 按 8 个脚本加载相同运行源码，首页及功能入口正常，console 0 error。
- 单文件由 `node build.js` 从模块源码生成；归档解压后重建并比较 SHA-256 的结果见 `artifacts/rebuild-validation.json`。

## 非声称事项

这些截图证明纯前端原型的代表路径和状态真实运行，不证明真实后端、数据库、身份认证、多人并发、仓库读取、生产级工作流并行调度或真实 Agent 调用已经实现。
