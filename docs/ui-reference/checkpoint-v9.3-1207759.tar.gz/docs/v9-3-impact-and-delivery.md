# V9.3 影响调查、完整闭环与 V1.2 映射

## 1. 影响调查不是全图遍历结论

调查维度覆盖目标功能、规则、调用方、前端输入状态、API、后端、数据库、参数、事件、配置、测试、旧路径、兼容、部署迁移和知识。路径遍历只用于产生候选，并排除 `references/cites/belongsTo` 等会把整个项目变成“影响”的泛化扩展。

每项记录：对象/调查维度、路径、关系语义、证据、判断状态、处理决定、进度、调查人和理由。

| 状态 | 含义 |
|---|---|
| `required` | 已确认需要修改或交付；完成前阻止完整交付 |
| `potential` | 语义路径形成的候选，需要进一步证据 |
| `no-change` | 已检查无需修改，必须有理由与证据 |
| `deferred` | 存在影响但由其他 Task 承接，必须有关联网 Task |
| `unknown` | 尚未调查或资料不足 |

可达不等于必须修改；用户点名的文件/参数也不等于完整边界。重复实现、无效兼容、死代码和旧路径必须主动调查，技术收敛不得擅自改变业务语义。

## 2. 完整交付阻断条件

以下任一情况均不能显示“完整交付”：语义合同不完整、业务差异未知、候选决定未批准、正式契约过期/不完整、未决 Issue、影响未调查、必要项未完成、转交无承接、旧路径未核验、实现未合并、测试失败或版本不一致、案例未覆盖、Manifest 缺失、知识提案未批准。

`complete-v93-task` 调用统一 `evaluateDelivery`，不能只改 `task.status` 绕过。历史服务仍供旧回归使用，V9.3 UI 的统一完成入口执行新闭环。

## 3. V1.2 协议映射

| V1.2 机制 | V9.3 原型记录 |
|---|---|
| PR 候选知识 | `delivery.pullRequest.candidateKnowledgeRefs` + `knowledgeChanges(kind=PR-candidate-knowledge)` |
| 合并实现 | `delivery.pullRequest.status=merged`、`implementation.codeRevision` |
| 合并后 Knowledge Delivery Manifest | `delivery.deliveryManifest(status=generated-after-merge)` |
| 测试与验收 | `tests.testedCodeRevision + caseRefs`、`acceptanceRecords` |
| 知识治理与 Baseline | `knowledgeChanges.status`、`manifest.approvedBaselineId`、既有 Change Set / Baseline |
| 部署与知识版本对账 | `manifest.deploymentVersion + reconciliation`、六类版本台账 |
| 开发反馈修正规范 | Task 关联 Issue、Feedback、Knowledge Proposal、Change Set、ADR/Decision Record |

原型中的 PR、测试和 Manifest 均明确标为模拟，不声称连接 GitHub、真实测试执行器或部署平台。

## 4. 状态分离

- `not-ready`：仍有业务、影响、实现或验收阻断。
- `implementation-complete-knowledge-pending`：实现、测试、影响和验收已满足，知识提案或批准基线未完成。
- `fully-delivered`：业务目标、保留约束、实现、测试、影响、知识、版本和批准全部闭合。

六类版本分别展示：需求提出版本、批准业务基线、实现代码版本、测试验证版本、部署版本、知识提案/清单批准状态。代码合并不等于业务规范批准。

## 5. Flow 版本与布局

正式契约保存 `versionBinding.flows` 和 `flowSemantics`。语义指纹排除 `flow.layout/node.layout`：纯布局变化不要求业务任务复核；节点、边、条件、规则绑定变化会使旧契约失效。Flow 中每个 Action/Rule/Event 引用也按权限和基线补全或阻断，避免 `requiredClosure:true` 误报。
