/* Repeatable V3 acceptance checks. Run: node acceptance.test.js */
'use strict';
const assert = require('node:assert/strict');
const M = require('./model.js');
const E = require('./engine.js');
const results = [];
function test(name, fn) {
  try { fn(); results.push({ name, status: 'PASS' }); console.log(`✓ ${name}`); }
  catch (error) { results.push({ name, status: 'FAIL', error: error.message }); console.error(`✗ ${name}\n  ${error.stack}`); }
}
const baseValues = { amount: 'unchanged', cost: 'changed', payee: 'unchanged', conflict: 'no', decisionStatus: 'allPassed' };

test('A1 · 成本中心变化命中原审批人与预算负责人分支', () => {
  const p = M.createMatureProject(), rule = p.rules.find(item => item.id === 'RULE-0017');
  const result = E.evaluateRule(rule.versions['v2.4'], baseValues);
  assert.equal(result.outcome.id, 'BUDGET_REVIEW');
  const flow = E.evaluateFlow(p, 'SCN-00126', baseValues), ids = flow.actions.map(action => action.id);
  assert(ids.includes('ACT-00424') && ids.includes('ACT-00443') && ids.includes('ACT-00444'));
  assert(!ids.includes('ACT-00448') && !flow.nodeIds.has('N-COMPLIANCE') && !flow.nodeIds.has('N-BLOCK'));
  assert(flow.actorIds.includes('ACTOR-02') && flow.actorIds.includes('ACTOR-03'));
  assert(flow.objectChanges.some(change => change.actionId === 'ACT-00424' && change.objectId === 'OBJ-0012'));
});

test('A2 · 收款方变化切换完整重审，版本冲突优先阻断', () => {
  const p = M.createMatureProject();
  const full = E.evaluateFlow(p, 'SCN-00126', { ...baseValues, payee: 'changed' });
  assert(full.nodeIds.has('N-COMPLIANCE'));
  assert(full.explanations.some(item => item.ruleId === 'RULE-0017' && item.outcome.id === 'FULL_REVIEW'));
  const conflict = E.evaluateFlow(p, 'SCN-00126', { ...baseValues, conflict: 'yes' });
  assert(conflict.nodeIds.has('N-BLOCK') && conflict.nodeIds.has('N-MERGE'));
  assert(!conflict.nodeIds.has('N-FORK') && !conflict.actions.some(action => action.id === 'ACT-00424'));
});

test('B · ACT-00424 的前提、规则、输入输出、对象变化、异常、实现和证据完整', () => {
  const p = M.createMatureProject(), action = E.byId(p.actions, 'ACT-00424');
  assert(action.pre.length >= 3 && action.input.length >= 3 && action.output.length >= 3);
  assert.deepEqual(E.relationIndex(p).targets(action.id, 'uses').sort(), ['RULE-0017', 'RULE-0021']);
  assert.equal(action.objectChanges.length, 2); assert(action.exceptions.length >= 3);
  assert(action.implementation?.reads.length && action.implementation?.writes.length && action.evidence.length >= 2);
});

test('C1 · 修改结构化决策行后，草稿与已发布版本分别试算', () => {
  const p = M.createMatureProject(), rule = E.byId(p.rules, 'RULE-0017'), published = rule.versions['v2.4'];
  const beforeText = published.summary, draft = E.clone(published); draft.version = 'v2.5'; draft.status = 'draft';
  draft.rows.find(row => row.id === 'RR-03').outcomeId = 'FULL_REVIEW'; draft.summary = E.summarizeRule(draft);
  assert.equal(E.evaluateRule(draft, baseValues).outcome.id, 'FULL_REVIEW');
  assert.equal(E.evaluateRule(published, baseValues).outcome.id, 'BUDGET_REVIEW');
  assert.equal(published.summary, beforeText); assert.notEqual(draft.summary, beforeText);
});

test('C2 · 批准后生成一致新版本，并将行为受影响的验收标为过期', () => {
  const p = M.createMatureProject(), change = E.byId(p.changes, 'CHG-00318'), rule = E.byId(p.rules, change.ruleId);
  change.draftRule = E.clone(rule.versions['v2.4']); change.draftRule.version = 'v2.5'; change.draftRule.status = 'draft';
  change.draftRule.rows.find(row => row.id === 'RR-03').outcomeId = 'FULL_REVIEW'; change.draftRule.summary = E.summarizeRule(change.draftRule);
  Object.keys(change.checks).forEach(key => { change.checks[key] = true; });
  E.byId(p.issues, 'Q-00218').decision = '确认修改并复核验收'; E.byId(p.issues, 'Q-00218').status = 'confirming';
  change.status = 'pending';
  const result = E.publishRuleChange(p, change.id, '测试审批人'); assert(result.ok, result.errors?.join(';'));
  assert.equal(rule.currentVersion, 'v2.5'); assert.equal(rule.versions['v2.4'].status, 'historical');
  assert.equal(E.evaluateRule(rule.versions['v2.4'], baseValues).outcome.id, 'BUDGET_REVIEW');
  assert.equal(E.evaluateRule(rule.versions['v2.5'], baseValues).outcome.id, 'FULL_REVIEW');
  assert.equal(rule.versions['v2.5'].summary, E.summarizeRule(rule.versions['v2.5']));
  assert.equal(E.byId(p.deliveries[0].acceptance, 'ACC-02').status, 'stale');
  assert.equal(E.byId(p.deliveries[0].acceptance, 'ACC-02').behaviorChanged, true);
  assert.equal(E.byId(p.deliveries[0].acceptance, 'ACC-01').status, 'stale');
  assert.equal(E.byId(p.deliveries[0].acceptance, 'ACC-01').behaviorChanged, false);
  assert.equal(E.byId(p.actions, 'ACT-00424').version, 'v2.4');
  assert.equal(E.byId(p.actions, 'ACT-00424').ruleVersions['RULE-0017'], 'v2.4');
  assert(E.byId(p.actions, 'ACT-00424').input.includes('RULE-0017@v2.4'));
  assert.equal(E.byId(p.actions, 'ACT-00424').referenceReviews['RULE-0017'].status, 'requires-review');
  assert(E.validateProject(p).ok, E.validateProject(p).errors.join(';'));
});

test('C3 · 未解决核验、冲突优先级和未覆盖组合会阻止发布', () => {
  const p = M.createMatureProject(), change = E.byId(p.changes, 'CHG-00318'), rule = E.byId(p.rules, change.ruleId);
  change.draftRule = E.clone(rule.versions['v2.4']); change.status = 'pending';
  Object.keys(change.checks).forEach(key => { change.checks[key] = true; });
  assert(!E.publishRuleChange(p, change.id).ok);
  E.byId(p.issues, 'Q-00218').decision = '已确认';
  change.draftRule.rows[1].priority = change.draftRule.rows[0].priority;
  assert(E.validateRuleVersion(change.draftRule).errors.some(error => error.includes('优先级')));
  const incomplete = E.clone(rule.versions['v2.4']); incomplete.rows = incomplete.rows.filter(row => row.id === 'RR-04'); incomplete.exceptions = [];
  assert(E.validateRuleVersion(incomplete).uncovered.length > 0);
});

test('D · 多变更单持有独立规则、草稿、状态和影响', () => {
  const p = M.createMatureProject(), first = E.byId(p.changes, 'CHG-00318'), second = E.byId(p.changes, 'CHG-00319');
  assert.notEqual(first.ruleId, second.ruleId); assert.equal(first.status, 'draft'); assert.equal(second.status, 'draft');
  first.draftRule = E.clone(E.byId(p.rules, first.ruleId).versions['v2.4']);
  second.draftRule = E.clone(E.byId(p.rules, second.ruleId).versions['v2.4']);
  first.draftRule.scope = '第一张变更单独立范围';
  assert.notEqual(second.draftRule.scope, first.draftRule.scope);
  assert(E.ruleUsage(p, first.ruleId).actions.length !== E.ruleUsage(p, second.ruleId).actions.length);
});

test('D2 · 动作等非规则对象也使用独立变更单与历史快照', () => {
  const p = M.createMatureProject(), action = E.byId(p.actions, 'ACT-00424'), original = action.purpose;
  const change = { id: 'CHG-90001', title: '修改动作', objectType: 'action', objectId: action.id, baseVersion: 'v2.4', targetVersion: 'v2.5', status: 'pending', draftDefinition: E.clone(action), checks: { actions: true, scenarios: true, acceptance: true, technical: true }, history: [] };
  change.draftDefinition.purpose = '独立修改后的业务目的'; p.changes.push(change);
  const result = E.publishObjectChange(p, change.id, '测试审批人'); assert(result.ok, result.errors?.join(';'));
  assert.equal(action.purpose, '独立修改后的业务目的'); assert.equal(action.version, 'v2.5');
  assert.equal(p.archives['action:ACT-00424@v2.4'].purpose, original);
  assert(E.validateProject(p).ok, E.validateProject(p).errors.join(';'));
});

test('E1 · 预约项目使用相同规则、流程、对象组件且无审批案例术语', () => {
  const p = M.createBookingProject(), text = JSON.stringify(p);
  for (const forbidden of ['审批经理', '重审范围', '成本中心', '完整重审']) assert(!text.includes(forbidden));
  assert.equal(p.actions.length, 8); assert.equal(p.rules.length, 3); assert(p.objects.some(object => object.states.includes('已取消')));
  const allowed = E.evaluateFlow(p, 'SCN-B001', { capacity: 'sufficient', slot: 'free', changeType: 'none', targetSlot: 'free' });
  assert(allowed.actions.some(action => action.id === 'ACT-B0005'));
  assert(!allowed.actions.some(action => action.id === 'ACT-B0008'));
  assert(allowed.objectChanges.some(change => change.objectId === 'OBJ-B02' && change.after === '已占用'));
});

test('E2 · 容量不足或时间冲突不会确认预约，改期失败保留原预约', () => {
  const p = M.createBookingProject();
  for (const values of [{ capacity: 'insufficient', slot: 'free' }, { capacity: 'sufficient', slot: 'occupied' }]) {
    const result = E.evaluateFlow(p, 'SCN-B001', { changeType: 'none', targetSlot: 'free', ...values });
    assert(!result.actions.some(action => ['ACT-B0004', 'ACT-B0005'].includes(action.id)));
    assert(result.nodeIds.has('BN-UNAVAILABLE'));
  }
  const keep = E.evaluateFlow(p, 'SCN-B001', { capacity: 'sufficient', slot: 'free', changeType: 'reschedule', targetSlot: 'occupied' });
  assert(keep.nodeIds.has('BN-END') && !keep.actions.some(action => action.id === 'ACT-B0008'));
});

test('F · 空项目首次发布生成合法 v1.0，稳定 ID 与数据可重建', () => {
  const p = M.createEmptyProject('PRJ-90001', '新产品');
  p.domains.push({ id: M.nextId(p, 'DOM'), name: '领域', caps: [], objects: [], actorIds: [], depends: [] });
  p.actors.push({ id: M.nextId(p, 'ACTOR'), name: '用户' });
  const scenarioId = M.nextId(p, 'SCN'), stageId = M.nextId(p, 'STG'), actionId = M.nextId(p, 'ACT'), stepId = M.nextId(p, 'STEP'), ruleId = M.nextId(p, 'RULE');
  p.scenarios.push({ id: scenarioId, name: '场景', stageIds: [stageId], exceptionIds: [], participants: [p.actors[0].id], status: 'draft' });
  p.stages.push({ id: stageId, stepIds: [stepId], domainId: p.domains[0].id, actorIds: [p.actors[0].id] });
  p.steps.push({ id: stepId, actionId, stageId });
  p.actions.push({ id: actionId, name: '动作', scenarioId, stageId, stepId, domainId: p.domains[0].id, status: 'draft', objectChanges: [], evidence: [] });
  const version = { version: 'draft', status: 'draft', supportsEvaluation: false, constraint: '必须人工确认', inputs: [], outputs: [], outcomes: [], rows: [], exceptions: [] };
  version.summary = E.summarizeRule(version); p.rules.push({ id: ruleId, name: '规则', currentVersion: null, versions: { draft: version } });
  p.relations.push({ id: 'REL-1', from: actionId, type: 'uses', to: ruleId }, { id: 'REL-2', from: actionId, type: 'belongsTo', to: scenarioId, kind: 'structure' });
  const result = M.firstPublish(p, '测试负责人'); assert(result.ok, result.errors?.join(';'));
  assert.equal(p.meta.version, 'v1.0'); assert(!JSON.stringify(p).includes('vNaN'));
  assert.equal(p.rules[0].currentVersion, 'v1.0'); assert.equal(p.actions[0].version, 'v1.0');
  const restored = JSON.parse(JSON.stringify(p)); assert.equal(restored.actions[0].id, actionId); assert.equal(restored.meta.version, 'v1.0');
});

test('G · 500 动作 / 1024 界面为隔离索引，完整语义数量不被冒充', () => {
  const p = M.createMatureProject(), actionIndex = M.scaleIndex(p, 'actions'), surfaceIndex = M.scaleIndex(p, 'surfaces');
  assert.equal(p.actions.length + actionIndex.length, 500); assert.equal(p.surfaces.length + surfaceIndex.length, 1024);
  assert(actionIndex.every(item => item.indexOnly)); assert(surfaceIndex.every(item => item.indexOnly));
  assert(actionIndex.filter(item => item.name.includes('0001')).length >= 1);
  assert(!p.relations.some(relation => relation.from.startsWith('IDX-') || relation.to.startsWith('IDX-')));
  assert.equal(M.createBookingProject().scale.actions, 8);
});

test('H1-H4 · 重要 ID 唯一、关系与步骤引用有效、规则正反向一致', () => {
  for (const p of [M.createMatureProject(), M.createBookingProject()]) {
    const validation = E.validateProject(p); assert(validation.ok, validation.errors.join(';'));
    p.rules.forEach(rule => E.ruleUsage(p, rule.id).actions.forEach(action => assert(E.relationIndex(p).targets(action.id, 'uses').includes(rule.id))));
    assert(p.actions.every(action => action.rules === undefined)); assert(p.rules.every(rule => rule.actionIds === undefined));
  }
});

test('H5-H8 · 指定版本试算、草稿隔离、发布一致性、变更对象引用', () => {
  const p = M.createMatureProject(), rule = E.byId(p.rules, 'RULE-0017'), snapshot = JSON.stringify(rule.versions['v2.4']);
  const change = E.byId(p.changes, 'CHG-00318'); change.draftRule = E.clone(rule.versions['v2.4']); change.draftRule.scope = '草稿独立修改';
  assert.equal(JSON.stringify(rule.versions['v2.4']), snapshot);
  assert.equal(E.evaluateRule(rule.versions['v2.4'], baseValues).outcome.id, 'BUDGET_REVIEW');
  p.changes.forEach(item => assert(E.byId(p.rules, item.ruleId)));
});

test('H9 · 正式交接包只能固定已批准版本与不可变快照', () => {
  const p = M.createMatureProject(), delivery = p.deliveries[0], rule = E.byId(p.rules, delivery.ruleId);
  assert(!rule.versions[delivery.ruleVersion]);
  delivery.packageVersion = `${delivery.id}@${delivery.ruleVersion}`; delivery.snapshot = null;
  assert(!E.validateProject(p).ok);
  delivery.packageVersion = null; delivery.ruleVersion = rule.currentVersion;
  delivery.packageVersion = `${delivery.id}@${delivery.ruleVersion}`; delivery.snapshot = { rule: E.clone(rule.versions[rule.currentVersion]) };
  const before = JSON.stringify(delivery.snapshot); rule.versions[rule.currentVersion].scope = '后续变更不污染快照';
  assert.equal(JSON.stringify(delivery.snapshot), before); assert(E.validateProject(p).ok);
});

test('H10 · 项目数据与版本变更不会相互串用', () => {
  const first = M.createMatureProject(), second = M.createBookingProject(), bookingText = JSON.stringify(second);
  first.rules[0].versions['v2.4'].scope = '只修改第一个项目'; first.meta.version = 'v9.9';
  assert.equal(JSON.stringify(second), bookingText);
  assert(!E.byId(second.actions, 'ACT-00424')); assert(!E.byId(first.actions, 'ACT-B0005'));
});

test('H11-H12 · 首次发布无非法版本，验收与当前规则关系可检查', () => {
  const p = M.createMatureProject(); assert(!JSON.stringify(p).includes('vNaN'));
  const stale = p.deliveries[0].acceptance.find(item => item.ruleVersion !== p.rules[0].currentVersion);
  assert.equal(stale, undefined);
  p.deliveries[0].acceptance[0].ruleVersion = 'v0.1';
  assert(E.validateProject(p).warnings.some(warning => warning.includes('重新核验')));
});

const failed = results.filter(result => result.status === 'FAIL');
console.log(`\n${results.length - failed.length}/${results.length} 项通过。`);
if (failed.length) process.exitCode = 1;
