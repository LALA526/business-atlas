/* Business Atlas V4 repeatable model, schema, relation, view-selection and workflow acceptance checks. */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const M = require('./model.js');
const VM = require('./v4-model.js');
const E = require('./engine.js');
const K = require('./v4-core.js');
const V = require('./v4-views.js');
const results = [];
function test(name, fn) { try { fn(); results.push({ name, status: 'PASS' }); console.log(`✓ ${name}`); } catch (error) { results.push({ name, status: 'FAIL', error: error.message }); console.error(`✗ ${name}\n  ${error.stack}`); } }
const projects = VM.createProjectSet();
const approval = projects['PRJ-00001'], booking = projects['PRJ-00002'], manufacturing = projects['PRJ-00003'], government = projects['PRJ-00004'];
const relation = (p, from, type, to) => p.relations.find(item => item.from === from && item.type === type && item.to === to);
function validDefinition(id, stages = ['提出', '执行', '确认']) { return { id, name: `${id} 流程`, purpose: 'delivery', stages: stages.map((name, index) => ({ id: `s${index + 1}`, name, role: index === 1 ? '人工执行者' : '负责人', required: true })) }; }

test('V4-01 · 自定义知识类型可注册、创建、读取和修改，修订独立', () => {
  const p = VM.createBlankProject('PRJ-T01', '扩展测试');
  K.registerType(p, { id: 'Equipment', name: '设备', fields: [{ id: 'serial', label: '序列号', dataType: 'text', required: true }, { id: 'capacity', label: '容量', dataType: 'number' }, { id: 'active', label: '启用', dataType: 'boolean' }] });
  const item = K.createEntity(p, 'Equipment', { id: 'EQ-001', name: '一号设备', props: { serial: 'SN-1', capacity: 20, active: true }, status: 'published' });
  assert.equal(K.getEntity(p, 'EQ-001').props.capacity, 20);
  const updated = K.updateEntity(p, item.id, { props: { serial: 'SN-1', capacity: 30, active: false } }, 'r1');
  assert.equal(updated.revision, 'r2'); assert.equal(updated.props.capacity, 30); assert.equal(updated.revisions.r1.props.capacity, 20);
});

test('V4-02 · 自定义类型直接由通用对象视图和属性表展示', () => {
  const p = VM.createBlankProject('PRJ-T02', '通用视图测试'); K.registerType(p, { id: 'SpecialThing', name: '特殊事项', fields: [{ id: 'amount', label: '数量', dataType: 'number', required: true }] });
  const item = K.createEntity(p, 'SpecialThing', { id: 'ST-1', name: '特殊实例', description: '没有专用页面', props: { amount: 8 } });
  const views = V.availableViews(p, item); assert(views.some(view => view.id === 'summary')); assert(views.some(view => view.id === 'relations'));
  const html = V.KnowledgeSummary(p, item) + V.PropertyTable(p, item); assert(html.includes('没有专用页面')); assert(html.includes('数量')); assert(!html.includes('ManufacturingBatchPage'));
});

test('V4-03 · 四个项目共用核心语义、Schema、关系和版本机制', () => {
  Object.values(projects).forEach(p => {
    for (const key of ['Rule', 'Term', 'System', 'Configuration', 'Resource', 'Feature']) assert(p.schemaRegistry[key], `${p.meta.id} 缺少 ${key}`);
    assert(p.versionLayers.baseline && p.versionLayers.release && p.versionLayers.config);
    assert(p.workflowDefinitions.length && p.workspace.readingPaths.length >= 2);
    const validation = E.validateProject(p); assert(validation.ok, `${p.meta.id}: ${validation.errors.join(';')}`);
    p.knowledge.forEach(item => assert.deepEqual(K.validateEntity(p, item), [], `${p.meta.id}:${item.id} Schema 校验失败`));
  });
});

test('V4-04 · 第五项目仅靠数据、类型和定义即可建模，核心无行业页面分支', () => {
  const p = VM.createBlankProject('PRJ-00005', '园区能源管理', '追踪园区能源异常');
  p.domains.push({ id: 'DOM-X01', name: '能源监测', caps: [], objects: [], actorIds: [], depends: [] }, { id: 'DOM-X02', name: '异常处置', caps: [], objects: [], actorIds: [], depends: [] });
  p.scenarios.push({ id: 'SCN-X01', name: '能耗异常核查', goal: '确认异常并形成处理记录', stageIds: [], exceptionIds: [], participants: [], status: 'draft', expressionMode: 'case', caseModel: { completionConditions: ['原因已确认'], dynamicTasks: ['现场核查'], evidenceIds: [], availableActivityIds: [] } });
  K.registerType(p, { id: 'EnergyMeter', name: '能源表计', fields: [{ id: 'meterCode', label: '表计编码', dataType: 'text', required: true }] });
  const meter = K.createEntity(p, 'EnergyMeter', { id: 'METER-X01', name: '东区总表', props: { meterCode: 'E-001' } });
  K.addRelation(p, { from: meter.id, type: 'references', to: 'SCN-X01' });
  assert(V.availableViews(p, K.getEntity(p, 'SCN-X01')).some(view => view.id === 'case')); assert(V.RelationExplorer(p, meter).includes('能耗异常核查'));
  const app = fs.readFileSync(require.resolve('./v4-app.js'), 'utf8'); assert(!/render(Manufacturing|Government|Booking|Approval)Page/.test(app)); assert(!app.includes('园区能源管理'));
});

test('V4-05 · 项目首页资料来自 Project Profile，空白项目没有虚构业务内容', () => {
  const blank = VM.createBlankProject('PRJ-T05', '纯知识项目', '只整理资料'); blank.profile.positioning = '独特的第五项目定位';
  assert.equal(blank.profile.positioning, '独特的第五项目定位'); assert.equal(blank.scenarios.length, 0); assert.equal(blank.actions.length, 0); assert.equal(blank.knowledge.length, 0);
  assert.notEqual(approval.profile.positioning, manufacturing.profile.positioning);
});

test('V4-06 · Feature、Capability、Term 与 Business Object 是不同知识身份', () => {
  assert(K.getEntity(approval, 'FEAT-A01').typeId === 'Feature'); assert(K.getEntity(approval, 'CAP-11').typeId === 'Capability');
  assert(K.getEntity(approval, 'TERM-A001').typeId === 'Term'); assert(K.getEntity(approval, 'OBJ-0012').typeId === 'BusinessObject');
  assert.notEqual(K.getEntity(approval, 'TERM-A001').id, K.getEntity(approval, 'OBJ-0012').id);
  assert(K.getEntity(approval, 'DLV-HIST-01').name); assert(K.allEntities(approval).filter(item => ['Evidence', 'Change', 'Delivery'].includes(item.typeId)).every(item => item.name));
});

test('V4-07 · 同名术语按上下文指向不同概念且互相标注易混淆', () => {
  const first = K.getEntity(government, 'TERM-G001'), second = K.getEntity(government, 'TERM-G002');
  assert.equal(first.name, second.name); assert.notEqual(first.id, second.id); assert.notEqual(first.props.context, second.props.context);
  assert(first.props.confusedWith.includes(second.id) && second.props.confusedWith.includes(first.id));
});

test('V4-08 · 配置、环境、规则与配置版本可双向追踪', () => {
  for (const [p, cfg, rule, env] of [[approval, 'CFG-A01', 'RULE-0017', 'ENV-A-PROD'], [manufacturing, 'CFG-M01', 'RULE-M001', 'ENV-M-PROD']]) {
    const config = K.getEntity(p, cfg); assert(config.props.configVersion); assert(config.props.environments.includes(env));
    assert(relation(p, cfg, 'affects', rule)); assert(relation(p, cfg, 'references', env)); assert(K.incoming(p, rule, 'affects').some(item => item.from === cfg));
  }
});

test('V4-09 · 数据资源可以反向定位读写它的业务动作', () => {
  const reads = K.incoming(manufacturing, 'DATA-M01', 'reads'); assert(reads.some(item => item.from === 'ACT-M005'));
  assert(K.relationsFor(manufacturing, 'DATA-M01', { depth: 1 }).nodes.some(item => item.id === 'ACT-M005'));
  assert(V.DataMapping(manufacturing, K.getEntity(manufacturing, 'DATA-M01')).includes('ACT-M005'));
});

test('V4-10 · 原始证据保留独立身份、原始版本与精确定位并连接结构化知识', () => {
  const source = K.getEntity(manufacturing, 'SRC-M01'); assert.equal(source.typeId, 'Resource'); assert(source.props.uri && source.props.sourceVersion && source.props.locator);
  assert(relation(manufacturing, 'RULE-M001', 'cites', source.id)); assert(V.ResourceViewer(manufacturing, source).includes('原始资料'));
});

test('V4-11 · 工作流定义不依赖任何固定阶段数组', () => {
  const p = VM.createBlankProject('PRJ-T11', '两阶段项目'); const def = K.createWorkflow(p, validDefinition('WFD-T11', ['登记', '关闭']));
  const instance = K.instantiateWorkflow(p, def.id, { subjectId: 'CASE-1' }); assert.equal(def.stages.length, 2); assert.equal(K.currentStage(instance).name, '登记');
  assert(K.advanceWorkflow(p, instance.id).ok); assert.equal(K.currentStage(instance).name, '关闭'); assert(K.advanceWorkflow(p, instance.id).ok); assert.equal(instance.status, 'completed');
});

test('V4-12 · 不同工作流使用同一 WorkflowProgress 组件', () => {
  const a = approval.workflowInstances[0], b = manufacturing.workflowInstances[0];
  const htmlA = V.WorkflowProgress(null, a), htmlB = V.WorkflowProgress(null, b);
  assert(htmlA.includes('v4-workflow-progress') && htmlB.includes('v4-workflow-progress')); assert.notEqual(htmlA, htmlB); assert(!htmlA.includes('开发交接 ·'));
});

test('V4-13 · 实例固定定义版本与快照，后续定义变化不污染实例', () => {
  const p = VM.createBlankProject('PRJ-T13', '版本测试'); const def = K.createWorkflow(p, validDefinition('WFD-T13'));
  const instance = K.instantiateWorkflow(p, def.id, {}); def.stages[0].name = '修改后的名称'; def.version = 'v2';
  assert.equal(instance.definitionVersion, 'v1'); assert.equal(instance.definitionSnapshot.stages[0].name, '提出'); assert.equal(K.currentStage(instance).name, '提出');
});

test('V4-14 · 可选阶段可跳过，条件退回与重新打开保留记录', () => {
  const p = VM.createBlankProject('PRJ-T14', '退回测试'); const def = K.createWorkflow(p, { id: 'WFD-T14', name: '退回流程', stages: [{ id: 'a', name: '提出', role: 'BA' }, { id: 'b', name: '额外审查', role: '审查员', required: false }, { id: 'c', name: '验证', role: '测试员', returnTo: 'a', returnWhen: { equals: { key: 'result', value: 'fail' } } }] });
  const instance = K.instantiateWorkflow(p, def.id, {}); K.advanceWorkflow(p, instance.id); assert(K.skipWorkflowStage(p, instance.id).ok); assert.equal(instance.currentStageId, 'c');
  assert(!K.returnWorkflow(p, instance.id, { context: { result: 'pass' } }).ok); assert(K.returnWorkflow(p, instance.id, { context: { result: 'fail' } }).ok); assert.equal(instance.currentStageId, 'a');
  K.advanceWorkflow(p, instance.id); K.skipWorkflowStage(p, instance.id); K.advanceWorkflow(p, instance.id); assert.equal(instance.status, 'completed');
  assert(K.reopenWorkflow(p, instance.id, { stageId: 'c' }).ok); assert.equal(instance.status, 'active'); assert(instance.records.some(record => record.type === 'reopen'));
});

test('V4-15 · 不包含 Agent 的传统流程能够正常完成', () => {
  const def = booking.workflowDefinitions[0]; assert(!JSON.stringify(def).toLowerCase().includes('agent'));
  const instance = K.instantiateWorkflow(booking, def.id, { subjectId: 'REQ-NO-AGENT' });
  while (instance.status === 'active') { const result = K.advanceWorkflow(booking, instance.id, { force: true }); assert(result.ok, result.errors?.join(';')); }
  assert.equal(instance.status, 'completed');
});

test('V4-16 · 规则发布后历史定义内容不被覆盖，动作版本不被动提升', () => {
  const p = VM.createProjectSet()['PRJ-00001'], rule = E.byId(p.rules, 'RULE-0017'), before = E.clone(rule.versions['v2.4']), action = E.byId(p.actions, 'ACT-00424'), actionVersion = action.version;
  const change = { id: 'CHG-V4-16', title: '测试版本独立', ruleId: rule.id, baseVersion: 'v2.4', targetVersion: 'v2.5', status: 'pending', reason: '测试', draftRule: E.clone(before), checks: { actions: true, scenarios: true, acceptance: true, technical: true }, history: [] };
  change.draftRule.scope = '新的独立规则范围'; change.draftRule.summary = E.summarizeRule(change.draftRule); p.changes.push(change);
  const result = E.publishRuleChange(p, change.id, '验收人'); assert(result.ok, result.errors?.join(';'));
  assert.equal(action.version, actionVersion); assert.equal(rule.versions.v2_4, undefined); assert.equal(rule.versions['v2.4'].scope, before.scope); assert.deepEqual(rule.versions['v2.4'].rows, before.rows);
  assert.equal(action.referenceReviews[rule.id].status, 'requires-review');
});

test('V4-17 · 知识基线、软件发布、配置和部署版本明确分离', () => {
  const p = manufacturing; assert.notEqual(p.versionLayers.baseline, p.versionLayers.release); assert.notEqual(p.versionLayers.release, p.versionLayers.config);
  const old = p.versionLayers.release; p.versionLayers.baseline = 'BL-NEW'; assert.equal(p.versionLayers.release, old); assert(p.versionLayers.deployments[0].environment);
});

test('V4-18 · 跨项目知识、关系和工作流数据隔离', () => {
  const text = JSON.stringify(booking); manufacturing.knowledge.push(K.entity('KnownIssue', { id: 'ONLY-M', name: '仅制造可见' })); manufacturing.workflowDefinitions[0].name = '仅制造修改';
  assert.equal(JSON.stringify(booking), text); assert(!K.getEntity(booking, 'ONLY-M')); assert(!booking.relations.some(item => item.from === 'ONLY-M'));
});

test('V4-19 · 关系正反向查询与关系属性一致', () => {
  const rel = relation(government, 'RULE-G001', 'cites', 'SRC-G01'); assert(rel);
  assert(K.outgoing(government, 'RULE-G001', 'cites').some(item => item.id === rel.id)); assert(K.incoming(government, 'SRC-G01', 'cites').some(item => item.id === rel.id));
  assert.equal(rel.verified, true); assert(rel.explanation.length > 0);
  const local = K.relationsFor(manufacturing, 'SCN-M001', { depth: 1 });
  assert(local.nodes.some(item => item.id === 'STG-M01')); assert(!local.nodes.some(item => item.id === 'STEP-M001'));
  assert(local.edges.every(item => String(item.from).split('@')[0] === 'SCN-M001' || String(item.to).split('@')[0] === 'SCN-M001'));
});

test('V4-20 · 缺少流程、状态或字段数据时适用视图自然收缩', () => {
  const p = VM.createBlankProject('PRJ-T20', '空数据'); K.registerType(p, { id: 'Note', name: '笔记', fields: [] }); const note = K.createEntity(p, 'Note', { id: 'NOTE-1', name: '只有定义', description: '没有流程' });
  const ids = V.availableViews(p, note).map(view => view.id); assert(!ids.includes('flow') && !ids.includes('state') && !ids.includes('data') && !ids.includes('config'));
  const scenario = { id: 'S', typeId: 'Scenario', name: '无阶段', stageIds: [] }; assert(!V.availableViews(p, scenario).some(view => view.id === 'flow'));
});

test('V4-21 · 空项目不生成虚构参与者、规则、阶段或统计', () => {
  const p = VM.createBlankProject('PRJ-T21', '尚未研究'); assert.equal(p.actors.length + p.rules.length + p.stages.length, 0); assert.equal(K.health(p).modeled, 0); assert(K.health(p).note.includes('不等于'));
});

test('V4-22 · 权限与敏感度进入对象模型和通用查询契约', () => {
  const p = VM.createBlankProject('PRJ-T22', '权限测试'); K.createEntity(p, 'Resource', { id: 'SEC-1', name: '受限文件', sensitivity: 'restricted', permissions: { read: ['admin'], edit: ['admin'] }, props: { uri: 'secret://1', parseStatus: 'unparsed' } });
  const denied = K.queryKnowledge(p, { id: 'SEC-1', permission: { role: 'external', clearance: 'public' } }); assert.equal(denied.ok, false); assert.equal(denied.code, 'FORBIDDEN');
  const allowed = K.queryKnowledge(p, { id: 'SEC-1', permission: { role: 'admin', clearance: 'restricted' } }); assert(allowed.ok);
});

test('V4-23 · 数值、布尔、日期、枚举、引用和结构化属性执行不同校验', () => {
  const p = VM.createBlankProject('PRJ-T23', '类型测试'); K.registerType(p, { id: 'Typed', name: ' typed ', fields: [{ id: 'n', label: '数值', dataType: 'number' }, { id: 'b', label: '布尔', dataType: 'boolean' }, { id: 'd', label: '日期', dataType: 'date' }, { id: 'e', label: '枚举', dataType: 'enum', options: ['a', 'b'] }, { id: 'r', label: '引用', dataType: 'ref' }, { id: 'j', label: '结构', dataType: 'json' }] });
  const schema = K.schemaFor(p, 'Typed'), field = id => schema.fields.find(item => item.id === id);
  assert(K.validateValue(field('n'), '8', p)); assert.equal(K.validateValue(field('n'), 8, p), null); assert(K.validateValue(field('d'), '不是日期', p));
  assert(K.validateValue(field('e'), 'c', p)); assert(K.validateValue(field('r'), 'MISSING', p)); assert.equal(K.validateValue(field('j'), { a: 1 }, p), null); assert(K.validateValue(field('b'), 'true', p));
});

test('V4-24 · AI 推断关系不会进入仅批准视角', () => {
  const p = VM.createBlankProject('PRJ-T24', '关系可信测试'); K.createEntity(p, 'Term', { id: 'T-A', name: '甲', props: { shortDefinition: '甲' } }); K.createEntity(p, 'Term', { id: 'T-B', name: '乙', props: { shortDefinition: '乙' } });
  K.addRelation(p, { from: 'T-A', to: 'T-B', type: 'references', trust: 'inferred', verified: false });
  assert.equal(K.queryKnowledge(p, { id: 'T-A', view: 'approved' }).relations.length, 0); assert.equal(K.queryKnowledge(p, { id: 'T-A', view: 'all' }).relations.length, 1);
});

test('V4-25 · 通用 Adapter 查询支持指定深度、版本和项目范围', () => {
  const result = K.queryKnowledge(approval, { id: 'ACT-00424', version: 'v2.4', depth: 2, permission: { role: 'reader', clearance: 'restricted' } });
  assert(result.ok); assert.equal(result.projectId, approval.meta.id); assert.equal(result.root.id, 'ACT-00424'); assert.equal(result.query.depth, 2); assert(result.nodes.some(item => item.id === 'RULE-0017'));
  const missing = K.queryKnowledge(approval, { id: 'RULE-0017', version: 'v9.9' }); assert.equal(missing.ok, false); assert.equal(missing.code, 'VERSION_UNAVAILABLE');
});

test('V4-26 · 旧交接包快照不随后续规则发布改变', () => {
  const p = VM.createProjectSet()['PRJ-00001'], delivery = p.deliveries[0], rule = E.byId(p.rules, 'RULE-0017'); delivery.ruleVersion = 'v2.4'; delivery.packageVersion = 'DLV-00086@v2.4'; delivery.snapshot = { rule: E.clone(rule.versions['v2.4']) };
  const snapshot = JSON.stringify(delivery.snapshot); rule.versions['v2.4'].scope = '当前定义被外部测试修改'; assert.equal(JSON.stringify(delivery.snapshot), snapshot);
});

test('V4-27 · 工作流进入条件不满足时不创建错误推进', () => {
  const p = VM.createBlankProject('PRJ-T27', '分支测试'); const def = K.createWorkflow(p, { id: 'WFD-T27', name: '条件流程', stages: [{ id: 'a', name: '登记', role: '人员' }, { id: 'b', name: '高风险审查', role: '人员', entryWhen: { equals: { key: 'risk', value: 'high' } } }, { id: 'c', name: '结束', role: '人员' }] });
  const instance = K.instantiateWorkflow(p, def.id, {}); const result = K.advanceWorkflow(p, instance.id, { context: { risk: 'low' } }); assert(result.ok); assert.equal(instance.currentStageId, 'c');
});

test('V4-28 · 必需产物与活动确认真实阻塞推进', () => {
  const p = VM.createBlankProject('PRJ-T28', '产物测试'); const def = K.createWorkflow(p, { id: 'WFD-T28', name: '产物流程', stages: [{ id: 'a', name: '审查', role: '人员', confirmation: true, artifacts: ['审查记录'] }] }); const instance = K.instantiateWorkflow(p, def.id, {});
  assert(!K.advanceWorkflow(p, instance.id).ok); instance.confirmations.a = { by: '负责人' }; assert(!K.advanceWorkflow(p, instance.id).ok); instance.artifacts['审查记录'] = { id: 'DOC-1' }; assert(K.advanceWorkflow(p, instance.id).ok);
});

test('V4-29 · 大量知识索引使用分页而非固定数量或巨型关系图', () => {
  const p = VM.createBlankProject('PRJ-T29', '规模测试'); K.registerType(p, { id: 'Record', name: '记录', fields: [] });
  for (let i = 0; i < 1000; i++) p.knowledge.push(K.entity('Record', { id: `REC-${i}`, name: `记录 ${i}` }));
  const page = K.paginate(p.knowledge, 20, 20); assert.equal(page.items.length, 20); assert.equal(page.pages, 50); assert.equal(page.total, 1000); assert.equal(page.items[0].id, 'REC-380');
});

test('V4-30 · 原始资料与结构化结论不是同一对象，提炼关系可追溯', () => {
  assert.notEqual(K.getEntity(government, 'SRC-G01').typeId, K.getEntity(government, 'RULE-G001').typeId);
  assert(K.getEntity(government, 'RULE-G001').versions); assert(K.getEntity(government, 'SRC-G01').props.uri);
  const graph = K.relationsFor(government, 'SRC-G01', { depth: 1 }); assert(graph.nodes.some(item => item.id === 'RULE-G001'));
});

test('V4-31 · 案件模型表达完成条件与动态活动，而非伪装固定流水线', () => {
  const scenario = E.byId(government.scenarios, 'SCN-G001'); assert(scenario.caseModel.completionConditions.length >= 3); assert(scenario.caseModel.dynamicTasks.length >= 2);
  assert(V.availableViews(government, { ...scenario, typeId: 'Scenario' }).some(view => view.id === 'case')); assert(V.CaseActivityView(government, scenario).includes('动态'));
});

test('V4-32 · 制造返工回边和批次自定义实例是真实数据', () => {
  const flow = E.flowFor(manufacturing, 'SCN-M001'); assert(flow.edges.some(edge => edge.type === 'return' && edge.to === 'MN-ACT-M005'));
  const batch = K.getEntity(manufacturing, 'BATCH-M-001'); assert.equal(batch.typeId, 'ManufacturingBatch'); assert.equal(typeof batch.props.quantity, 'number'); assert.equal(typeof batch.props.released, 'boolean'); assert.equal(batch.props.qualityState, '待复检');
  assert(K.validateEntity(manufacturing, batch).length === 0);
});

const failed = results.filter(result => result.status === 'FAIL');
console.log(`\n${results.length - failed.length}/${results.length} 项 V4 验收通过。`);
if (failed.length) process.exitCode = 1;
